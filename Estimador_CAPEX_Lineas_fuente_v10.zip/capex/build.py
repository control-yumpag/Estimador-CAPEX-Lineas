import json, os, re
base='/home/claude/capex'
P=lambda n: open(os.path.join(base,'parts',n),encoding='utf-8').read()
css=P('style.css'); body=P('body.html'); engine=P('engine.js'); ui=P('ui.js'); v3=P('viewer3d.js'); body2=P('body2.html'); engine2=P('engine2.js'); ui2=P('ui2.js'); p2=P('planta2d.js')
gltf=open(os.path.join(base,'GLTFLoader.js'),encoding='utf-8').read()
bgu=open(os.path.join(base,'BufferGeometryUtils.js'),encoding='utf-8').read()
tlod=P('towerlod.js'); precios=P('precios.js'); informe=P('informe.js'); proyecto=P('proyecto.js'); escal=P('escal.js'); pertmap=P('pertmap.js')
import glob
refs=[]
for f in sorted(glob.glob(os.path.join(base,'refmodels','*.json'))):
    refs.append(json.load(open(f,encoding='utf-8')))
refs_safe=json.dumps(refs,separators=(',',':')).replace('</','<\\/')
# el espacio <= 60 kV se inserta antes del toast
assert '<div class="toast" id="toast"></div>' in body
body=body.replace('<div class="toast" id="toast"></div>', body2+'\n<div class="toast" id="toast"></div>')
db=open(os.path.join(base,'db.json'),encoding='utf-8').read()
db_safe=db.replace('</','<\\/').replace('<!--','<\\!--')
osi=open(os.path.join(base,'osi.json'),encoding='utf-8').read()
osi_safe=osi.replace('</','<\\/').replace('<!--','<\\!--')
three=open(os.path.join(base,'three.min.js'),encoding='utf-8').read()
orbit=open(os.path.join(base,'OrbitControls.js'),encoding='utf-8').read()
for s in (three,orbit,gltf,bgu,tlod,engine,ui,v3,engine2,ui2,p2,precios,informe,proyecto,escal,pertmap):
    assert '</script' not in s.lower(), 'script contains closing tag'

fonts='<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:wght@600;700&family=Source+Sans+3:wght@400;600;700&family=JetBrains+Mono:wght@400;700&display=swap">'

content = f"""<title>Estimador CAPEX Líneas</title>
<meta name="description" content="Estimador paramétrico de CAPEX de líneas eléctricas de baja, media, alta y extra alta tensión (380/220 V a 500 kV) en USD sin IGV: bases COES 2025/26 y Osinergmin BDME 2025, postes de concreto, madera y acero, torres de celosía, marcas por componente, escalamiento de precios a años futuros, riesgo AACE y BIM 3D paramétrico.">
{fonts}
<style>
{css}
</style>
{body}
<script id="db" type="application/json">{db_safe}</script>
<script id="osi" type="application/json">{osi_safe}</script>
<script id="refmodels" type="application/json">{refs_safe}</script>
<script>{three}</script>
<script>{orbit}</script>
<script>{gltf}</script>
<script>{bgu}</script>
<script>
{precios}
{proyecto}
{escal}
{engine}
{ui}
{engine2}
{ui2}
{tlod}
{v3}
{p2}
{pertmap}
{informe}
</script>
"""
# artifact variant (no skeleton)
open(os.path.join(base,'artifact.html'),'w',encoding='utf-8').write(content)
# standalone
standalone = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<style>:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}} img{{max-width:100%}} [hidden]{{display:none!important}}</style>
{content}
</head>
<body></body>
</html>
"""
# In the standalone version the body content is inside <head>, which browsers would move; better to structure properly:
standalone = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Estimador CAPEX Líneas</title>
<meta name="description" content="Estimador paramétrico de CAPEX de líneas eléctricas de baja, media, alta y extra alta tensión (380/220 V a 500 kV) en USD sin IGV: bases COES 2025/26 y Osinergmin BDME 2025, postes de concreto, madera y acero, torres de celosía, marcas por componente, escalamiento de precios a años futuros, riesgo AACE y BIM 3D paramétrico.">
{fonts}
<style>
:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}} img{{max-width:100%}} [hidden]{{display:none!important}}
{css}
</style>
</head>
<body>
{body}
<script id="db" type="application/json">{db_safe}</script>
<script id="osi" type="application/json">{osi_safe}</script>
<script id="refmodels" type="application/json">{refs_safe}</script>
<script>{three}</script>
<script>{orbit}</script>
<script>{gltf}</script>
<script>{bgu}</script>
<script>
{precios}
{proyecto}
{escal}
{engine}
{ui}
{engine2}
{ui2}
{tlod}
{v3}
{p2}
{pertmap}
{informe}
</script>
</body>
</html>
"""
os.makedirs('/mnt/user-data/outputs',exist_ok=True)
out='/mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html'
open(out,'w',encoding='utf-8').write(standalone)
print('artifact',len(content),'standalone',len(standalone),'->',out)
