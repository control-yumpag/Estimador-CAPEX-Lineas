/* ===================== MAPA DE PUNTOS PERT: cómo triangula el método de tres puntos (Mín · Base · Máx) y cómo se compara con la simulación ===================== */
window.PERTMAP=(function(){
  const E_=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const F=(v,d=0)=>(v==null||isNaN(v))?'—':v.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
  const FK=v=>v==null||isNaN(v)?'—':Math.abs(v)>=1e6?(v/1e6).toLocaleString('en-US',{maximumFractionDigits:2})+' M':Math.abs(v)>=1e3?(v/1e3).toLocaleString('en-US',{maximumFractionDigits:0})+' k':F(v);
  const P=(v,d=1)=>(v==null||isNaN(v))?'—':(v>0?'+':'')+v.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d})+' %';
  const SHORT={estr:'Estructuras (suministro)',cond:'Conductores, guarda, aisladores',civ:'Obras civiles y accesos',em:'Montaje y pruebas',ind:'Indirectos y dueño',est:'Estudios e ingeniería',esc:'Escalamiento y riesgos',lsum:'Línea: suministro',lobra:'Línea: montaje y OC',tr:'Transformadores',at:'Bahías, celdas, SCADA',sobra:'SE: montaje, OC, ingeniería',land:'Terreno SE',ext:'Ampliación SE existente'};
  /* paquetes + rangos del motor activo → filas con los tres puntos, esperado PERT, media triangular y σ */
  function rows(mode){
    const A=mode==='A'; const X=A?(typeof R!=='undefined'?R:null):(typeof R2!=='undefined'?R2:null); if(!X) return null;
    const stt=A?(typeof state!=='undefined'?state:null):(typeof oState!=='undefined'?oState:null);
    const pk=A?riskPackages(X):riskPackagesOsi(X); const cls=X.inp.cls;
    const rr=(stt&&stt.riskRanges&&stt.riskRanges.cls===cls)? stt.riskRanges.r : JSON.parse(JSON.stringify((A?RISK_DEFAULT:RISK2_DEFAULT)[cls]));
    const out=pk.map(p=>{ const r=rr[p.k]||[0,0]; const a=p.base*(1+r[0]/100), m=p.base, b=p.base*(1+r[1]/100); const e=(a+4*m+b)/6; return {k:p.k,name:SHORT[p.k]||p.name,base:p.base,lo:r[0],hi:r[1],a,m,b,e,tri:(a+m+b)/3,sd:(b-a)/6}; });
    const rs=rr.sys||[0,0]; const fSys=(2+rs[0]/100+rs[1]/100+4)/6;
    const sB=out.reduce((s,r)=>s+r.base,0), sA=out.reduce((s,r)=>s+r.a,0), sBx=out.reduce((s,r)=>s+r.b,0), sE=out.reduce((s,r)=>s+r.e,0), sT=out.reduce((s,r)=>s+r.tri,0);
    const varSum=out.reduce((s,r)=>s+r.sd*r.sd,0);
    const tot={k:'tot',name:'Estimado base (B) + sistémico',base:sB,lo:(sA*(1+rs[0]/100)/sB-1)*100,hi:(sBx*(1+rs[1]/100)/sB-1)*100,a:sA*(1+rs[0]/100),m:sB,b:sBx*(1+rs[1]/100),e:sE*fSys,tri:sT*(3+rs[0]/100+rs[1]/100)/3,sd:Math.sqrt(varSum)*fSys,sys:rs,fSys};
    return {rows:out,tot,mc:stt?stt.mc:null,B:X.B,cls};
  }
  /* SVG: una fila por paquete; eje horizontal = desviación respecto a la base (%) */
  function svg(d,opts){ opts=opts||{}; const w=opts.w||760, lw=opts.lw||232, rw=opts.rw||150, rh=opts.rh||38, top=26, bottom=22;
    const all=[...d.rows,d.tot]; const lo=Math.min(...all.map(r=>r.lo),-5)-4, hi=Math.max(...all.map(r=>r.hi),10)+4;
    const mc=d.mc; const mcPts=mc? mcPct(mc,d.B):null; const lo2=mcPts? Math.min(lo,mcPts.p01-2):lo, hi2=mcPts? Math.max(hi,mcPts.p99+2):hi;
    const x0=lw, x1=w-rw; const X=v=>x0+(x1-x0)*(v-lo2)/(hi2-lo2);
    const H=top+rh*(d.rows.length+1)+(mc?rh+24:0)+bottom;
    let s=`<svg class="chart pert" viewBox="0 0 ${w} ${H}" style="width:100%;height:auto">`;
    const step= (hi2-lo2)>80? 20 : (hi2-lo2)>40? 10 : 5; const t0=Math.ceil(lo2/step)*step;
    for(let t=t0;t<=hi2;t+=step){ const x=X(t); s+=`<line class="${t===0?'axis':'grid'}" x1="${x}" x2="${x}" y1="${top-6}" y2="${H-bottom+2}" ${t===0?'stroke-width="1.5"':''}></line><text x="${x}" y="${top-10}" text-anchor="middle" style="font-size:10px">${t>0?'+':''}${t} %</text>`; }
    s+=`<text x="${x0}" y="${H-6}" style="font-size:10px">← más barato</text><text x="${x1}" y="${H-6}" text-anchor="end" style="font-size:10px">más caro →</text>`;
    all.forEach((r,i)=>{ const y=top+rh*i, yb=y+rh-8, yt=y+6, ym=y+rh/2+2; const tot=r.k==='tot';
      if(tot) s+=`<line x1="0" x2="${w}" y1="${y}" y2="${y}" class="axis"></line>`;
      // triángulo (a, m, b) con vértice en la base
      s+=`<polygon points="${X(r.lo)},${yb} ${X(0)},${yt} ${X(r.hi)},${yb}" fill="var(--accent)" opacity="${tot?0.22:0.14}"></polygon><line x1="${X(r.lo)}" x2="${X(r.hi)}" y1="${yb}" y2="${yb}" stroke="var(--line-2)"></line>`;
      // ± σ alrededor del esperado
      const ePct=(r.e/r.base-1)*100, sPct=r.sd/r.base*100, tPct=(r.tri/r.base-1)*100;
      s+=`<line x1="${X(ePct-sPct)}" x2="${X(ePct+sPct)}" y1="${ym}" y2="${ym}" stroke="var(--accent)" stroke-width="3" opacity=".35"><title>±σ = ${P(sPct)} (σ = (Máx − Mín)/6)</title></line>`;
      // puntos: mín, base, máx, media triangular (hueco), esperado PERT (rombo)
      s+=`<circle cx="${X(r.lo)}" cy="${yb}" r="4" fill="var(--blue)"><title>Mín ${P(r.lo)} · USD ${F(r.a)}</title></circle><circle cx="${X(0)}" cy="${yt}" r="4" fill="var(--ink-3)"><title>Base (moda) · USD ${F(r.m)}</title></circle><circle cx="${X(r.hi)}" cy="${yb}" r="4" fill="var(--crit)"><title>Máx ${P(r.hi)} · USD ${F(r.b)}</title></circle>`;
      s+=`<circle cx="${X(tPct)}" cy="${ym}" r="3.5" fill="none" stroke="var(--ink)" stroke-width="1.3"><title>Media triangular (Mín + Base + Máx)/3 = ${P(tPct)}</title></circle>`;
      const xe=X(ePct); s+=`<polygon points="${xe},${ym-6} ${xe+6},${ym} ${xe},${ym+6} ${xe-6},${ym}" fill="var(--accent)" stroke="#fff" stroke-width="1"><title>Esperado PERT (Mín + 4·Base + Máx)/6 = ${P(ePct)} · USD ${F(r.e)}</title></polygon>`;
      // etiquetas
      s+=`<text x="6" y="${y+15}" style="font-size:${tot?12:11.5}px;${tot?'font-weight:700;':''}fill:var(--ink)">${E_(r.name.length>34?r.name.slice(0,33)+'…':r.name)}</text><text x="6" y="${y+28}" style="font-size:10px">${tot?`USD ${FK(r.base)} · envolvente ${P(r.lo,0)} / ${P(r.hi,0)} · sist. ×${r.fSys.toFixed(4)}`:`USD ${F(r.base)} · ${P(r.lo,0)} / ${P(r.hi,0)}`}</text>`;
      s+=`<text x="${w-6}" y="${y+15}" text-anchor="end" style="font-size:11.5px;font-weight:700;fill:var(--accent)">${P(ePct)}</text><text x="${w-6}" y="${y+28}" text-anchor="end" style="font-size:10px">+USD ${FK(r.e-r.base)} · σ ${P(sPct)}</text>`;
    });
    if(mcPts){ const y=top+rh*all.length+4, yc=y+rh/2; // nube de puntos de la simulación (cuantiles equiespaciados, jitter vertical determinista)
      s+=`<text x="6" y="${y+15}" style="font-size:11.5px;fill:var(--ink)">Simulación Monte Carlo (${mc.dist==='tri'?'triangular':'beta-PERT'})</text><text x="6" y="${y+28}" style="font-size:10px">${F(mc.s.length)} iteraciones · nube = 400 cuantiles</text>`;
      const n=400; for(let i=0;i<n;i++){ const q=(i+0.5)/n; const v=mc.s[Math.min(mc.s.length-1,Math.floor(q*mc.s.length))]; const pc=(v/d.B-1)*100; const j=((i*7919)%97)/97-0.5; s+=`<circle cx="${X(pc)}" cy="${yc+j*(rh-14)}" r="1.6" fill="var(--blue)" opacity=".55"></circle>`; }
      [[10,mcPts.p10,'P10',0,'end'],[50,mcPts.p50,'P50',1,'end'],[80,mcPts.p80,'P80',0,'start'],[90,mcPts.p90,'P90',1,'start']].forEach(([p,v,l,lv,an])=>{ const x=X(v); s+=`<line x1="${x}" x2="${x}" y1="${y+6}" y2="${y+rh-6+(lv?10:0)}" stroke="${p===80?'var(--good)':'var(--ink)'}" stroke-width="${p===80?2:1}" opacity=".8"></line><text x="${x+(an==='end'?-3:3)}" y="${y+rh+4+lv*11}" text-anchor="${an}" style="font-size:9.5px;${p===80?'fill:var(--good);font-weight:700':''}">${l} ${P(v,1)}</text>`; });
      const xm=X((mc.mean/d.B-1)*100); s+=`<polygon points="${xm},${yc-6} ${xm+6},${yc} ${xm},${yc+6} ${xm-6},${yc}" fill="var(--blue)" stroke="#fff" stroke-width="1"><title>Media simulada ${P((mc.mean/d.B-1)*100)}</title></polygon>`;
      s+=`<text x="${w-6}" y="${y+15}" text-anchor="end" style="font-size:11.5px;font-weight:700;fill:var(--blue)">media ${P((mc.mean/d.B-1)*100)}</text><text x="${w-6}" y="${y+28}" text-anchor="end" style="font-size:10px">P80 − B = +USD ${FK(mc.P(80)-d.B)}</text>`; }
    return s+'</svg>';
  }
  function mcPct(mc,B){ const q=p=>(mc.P(p)/B-1)*100; return {p01:q(1),p10:q(10),p50:q(50),p80:q(80),p90:q(90),p99:q(99)}; }
  function legend(){ return `<div class="tiny" style="display:flex;flex-wrap:wrap;gap:12px;margin-top:6px"><span><svg width="12" height="12"><circle cx="6" cy="6" r="4" fill="var(--blue)"/></svg> Mín (optimista)</span><span><svg width="12" height="12"><circle cx="6" cy="6" r="4" fill="var(--ink-3)"/></svg> Base = moda (más probable)</span><span><svg width="12" height="12"><circle cx="6" cy="6" r="4" fill="var(--crit)"/></svg> Máx (pesimista)</span><span><svg width="14" height="12"><polygon points="7,1 13,6 7,11 1,6" fill="var(--accent)"/></svg> Esperado PERT = (Mín + 4·Base + Máx)/6</span><span><svg width="12" height="12"><circle cx="6" cy="6" r="3.5" fill="none" stroke="var(--ink)" stroke-width="1.3"/></svg> Media triangular = (Mín + Base + Máx)/3</span><span><svg width="22" height="12"><line x1="1" x2="21" y1="6" y2="6" stroke="var(--accent)" stroke-width="3" opacity=".35"/></svg> ±σ, σ = (Máx − Mín)/6</span></div>`; }
  function explain(d){ const t=d.tot; const ePct=(t.e/t.base-1)*100, tPct=(t.tri/t.base-1)*100; const mc=d.mc; const mcTxt= mc? ` La simulación (${mc.dist==='tri'?'triangular':'beta-PERT'}) suma los paquetes muestreados: media ${P((mc.mean/d.B-1)*100)}, P50 ${P((mc.P(50)/d.B-1)*100)}, P80 ${P((mc.P(80)/d.B-1)*100)}; la contingencia a P80 es la distancia de B al P80.` : ' Ejecuta la simulación para ver la nube de puntos del estimado base.';
    return `<p class="small" style="margin:8px 0 0"><b>Cómo triangula PERT.</b> Cada paquete se describe con tres puntos: <b>Mín</b> (optimista), <b>Base</b> (el más probable, la moda) y <b>Máx</b> (pesimista). El triángulo es la distribución implícita; el esperado PERT pondera la moda cuatro veces, E = (Mín + 4·Base + Máx)/6, con desviación estándar σ = (Máx − Mín)/6. Como los rangos son asimétricos (más riesgo al alza), E cae a la derecha de la base y esa distancia es la contingencia esperada del paquete; la media triangular simple (○) da más peso a las colas y por eso queda más a la derecha (total: PERT ${P(ePct)} frente a triangular ${P(tPct)}). El riesgo sistémico multiplica el total por ×${t.fSys.toFixed(4)}. Suma de paquetes: contingencia PERT = <b>${P(ePct)} de B</b> (USD ${F(t.e-t.base)}), σ total ≈ ${P(t.sd/t.base*100)} (paquetes independientes).${mcTxt}</p>`; }
  function render(el,mode){ if(!el) return; const d=rows(mode); if(!d){ el.innerHTML=''; return; } el.innerHTML='<div class="pert-wrap">'+svg(d)+'</div>'+legend()+explain(d); }
  function report(X,mode){ const d=rows(mode); if(!d) return ''; const t=d.tot; const ePct=(t.e/t.base-1)*100;
    return `<div style="break-inside:avoid"><h2>Análisis de rangos y contingencia (PERT)</h2><p class="small">Paquetes de costo del estimado base con sus tres puntos (Clase ${d.cls} AACE: rangos editables en la pestaña Riesgo), esperado PERT y, si se ejecutó, la simulación Monte Carlo. Contingencia PERT = ${P(ePct)} de B (USD ${F(t.e-t.base)}); contingencia aplicada = ${P(X.inp.cont)} de B (USD ${F(X.cont)}).</p>${svg(d,{w:700,lw:210,rw:130,rh:34})}${legend()}</div>
      <table><thead><tr><th>Paquete</th><th class="n">Base USD</th><th class="n">Mín</th><th class="n">Máx</th><th class="n">Esperado PERT</th><th class="n">Δ USD</th><th class="n">σ</th></tr></thead><tbody>${d.rows.map(r=>`<tr><td>${E_(r.name)}</td><td class="n">${F(r.base)}</td><td class="n">${P(r.lo,0)}</td><td class="n">${P(r.hi,0)}</td><td class="n">${F(r.e)}</td><td class="n">${F(r.e-r.base)}</td><td class="n">${F(r.sd)}</td></tr>`).join('')}<tr class="tot"><td>Estimado base (B) × sistémico ${t.fSys.toFixed(4)}</td><td class="n">${F(t.base)}</td><td class="n">${P(t.lo,0)}</td><td class="n">${P(t.hi,0)}</td><td class="n">${F(t.e)}</td><td class="n">${F(t.e-t.base)}</td><td class="n">${F(t.sd)}</td></tr></tbody></table>`; }
  return {rows,svg,render,report};
})();
