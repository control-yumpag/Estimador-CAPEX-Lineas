/* ===================== PROYECTO: identificación, nivel de tensión, clase y programa de ejecución (compartidos por ambos motores) ===================== */
window.PROJ=(function(){
  const KEY='capexlt.proj';
  const q=s=>document.querySelector(s);
  const MES=['ene','feb','mar','abr','may','jun','jul','ago','set','oct','nov','dic'];
  const now=new Date();
  const defStart=`${now.getFullYear()+1}-${String(Math.min(12,now.getMonth()+1)).padStart(2,'0')}`; // mismo mes del año siguiente
  const st={name:'Línea de transmisión – Enlace (ejemplo)', client:'—', rev:'A', by:'', cls:3, start:defStart, months:12, set:'est', manual:''};
  try{ const s=JSON.parse(localStorage.getItem(KEY)||'null'); if(s&&typeof s==='object'){ for(const k of Object.keys(st)) if(s[k]!==undefined&&s[k]!==null) st[k]=s[k]; } }catch(e){}
  function save(){ try{ localStorage.setItem(KEY,JSON.stringify(st)); }catch(e){} }
  function card(){ return document.getElementById('projCard'); }
  /* la tarjeta vive en el panel del motor activo (se mueve, conserva sus manejadores) */
  function mount(mode){ const c=card(); const aside=document.getElementById(mode==='osi'?'side2':'side'); if(c&&aside&&c.parentElement!==aside) aside.prepend(c); }
  function fill(){ const c=card(); if(!c) return;
    q('#pName').value=st.name; q('#pClient').value=st.client; q('#pRev').value=st.rev; q('#pBy').value=st.by||''; q('#pClass').value=String(st.cls);
    q('#pStart').value=st.start; q('#pMonths').value=st.months; q('#pIdxSet').value=st.set; q('#pEscManual').value=st.manual; }
  function read(){ const c=card(); if(!c) return get();
    st.name=q('#pName').value; st.client=q('#pClient').value; st.rev=q('#pRev').value; st.by=q('#pBy').value; st.cls=parseInt(q('#pClass').value)||3;
    const s=q('#pStart').value; if(/^\d{4}-\d{2}$/.test(s)) st.start=s;
    st.months=Math.max(1,Math.min(120,parseInt(q('#pMonths').value)||12)); st.set=q('#pIdxSet').value||'est'; st.manual=q('#pEscManual').value.trim();
    save(); return get(); }
  function get(){ return {...st}; }
  function manualPct(){ if(st.manual==='') return null; const v=parseFloat(st.manual); return isFinite(v)? v : null; }
  function startYM(){ const [y,m]=st.start.split('-').map(Number); return {y,m}; }
  function endYM(){ const {y,m}=startYM(); const idx=(y*12+(m-1))+st.months-1; return {y:Math.floor(idx/12), m:idx%12+1}; }
  function ym(o){ return `${MES[o.m-1]}-${o.y}`; }
  function describe(){ const a=startYM(), b=endYM(); return `${ym(a)} – ${ym(b)} (${st.months} ${st.months===1?'mes':'meses'})`; }
  function yearsTxt(){ const a=startYM(); const cnt={}; for(let i=0;i<st.months;i++){ const idx=a.y*12+(a.m-1)+i; const y=Math.floor(idx/12); cnt[y]=(cnt[y]||0)+1; } return Object.keys(cnt).map(y=>`${y}: ${Math.round(cnt[y]/st.months*100)} %`).join(' · '); }
  function setLabel(){ return st.set==='cru'? 'CRU Construction Escalation Index (abr-2025)' : 'índices del estimador (LME, BLS CPI-U, INEI) + tasas futuras'; }
  function recalcBoth(){ if(window.PRICE&&PRICE.recalcAll) PRICE.recalcAll(); }
  function onClassChange(){ const c=st.cls; const C=(typeof CLASSES!=='undefined')? CLASSES[c] : null; if(C){ const a=q('#inCont'), b=q('#oCont'); if(a) a.value=C.cont; if(b) b.value=C.cont; }
    if(typeof state!=='undefined'&&state){ state.riskRanges=null; state.mc=null; } if(typeof oState!=='undefined'&&oState){ oState.riskRanges=null; oState.mc=null; } }
  function hint(){ const h=q('#pSchedHint'); if(!h) return; const m=manualPct(); const base=window.PRICE? PRICE.year : 2026;
    h.innerHTML=`Cotización de la base de datos → <b>fecha base del estimado (precios ${base})</b> → ejecución <b>${describe()}</b> (${yearsTxt()}). Escalamiento (ítem 3) ${m===null? `calculado por grupo de costo con ${setLabel()}` : `<b>manual: ${m} % de A</b>`}; detalle en la pestaña «Escalamiento».`; }
  function init(){ const c=card(); if(!c) return; fill(); hint();
    ['#pName','#pClient','#pRev','#pBy'].forEach(s=>{ const el=q(s); el.addEventListener('input',()=>{ clearTimeout(el._t); el._t=setTimeout(()=>{ read(); recalcBoth(); },200); }); });
    q('#pClass').addEventListener('change',()=>{ read(); onClassChange(); recalcBoth(); });
    ['#pStart','#pMonths','#pIdxSet','#pEscManual'].forEach(s=>{ const el=q(s); el.addEventListener('change',()=>{ read(); hint(); recalcBoth(); }); });
    const b=q('#pGoEsc'); if(b) b.onclick=()=>{ const t= window.APP_MODE==='osi' ? q('#tabs2 button[data-t="oesc"]') : q('#tabs button[data-t="esc"]'); if(t) t.click(); };
    const ch=q('#chipLevel'); if(ch) ch.onclick=()=>{ const d=c.closest('details')||c; if(d.tagName==='DETAILS') d.open=true; c.scrollIntoView({behavior:'smooth',block:'start'}); };
  }
  document.addEventListener('DOMContentLoaded',init);
  return {get, read, mount, manualPct, describe, yearsTxt, setLabel, startYM, endYM, ym, MES, hint, state:st};
})();
