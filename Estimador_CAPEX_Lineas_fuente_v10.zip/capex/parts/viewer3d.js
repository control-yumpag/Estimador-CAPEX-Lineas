/* ===================== VISOR BIM 3D (Three.js) — torre LOD 350, dinámico ===================== */
window.V3=(function(){
  let inited=false, scene, camera, renderer, controls, root, refRoot, Rcur=null, auto=false, lastInfo=null, lastW=null, lastP=null, lastTer=null, envTex=null, mats=null, mountedIn=null;
  const el=()=>document.getElementById('viewer');
  const ctl={type:'S', disp:'auto', sil:'auto', legs:[0,0,0,0], ins:true, dims:true, ref:false, refIdx:0, sag:3.2, cam:'iso', fund:true};
  const SIL_NAMES={celosia:'celosía autosoportada',bandera:'celosía bandera',tonel:'celosía tonel (barril)',danubio:'celosía Danubio',gato:'cabeza de gato',portico:'pórtico en celosía',vsl:'atirantada VSL',mono:'poste tubular de acero',hmono:'pórtico de postes de acero',poste:'poste con crucetas',compacto:'poste compacto line-post',hpole:'pórtico de dos postes',bt:'red BT autoportante'};
  const PH=[0xc0392b,0xe0a32e,0x2c5f8a];
  let REFS=[]; try{ REFS=JSON.parse((document.getElementById('refmodels')||{}).textContent||'[]'); }catch(e){ REFS=[]; }
  const $id=id=>document.getElementById(id);

  function isDark(){ const r=document.documentElement.getAttribute('data-theme'); return r? r==='dark' : matchMedia('(prefers-color-scheme: dark)').matches; }
  function themeColors(){ return isDark()? {bg:0x101820,fog:0x101820,ground:0x2f3b33,grid1:0x3e4d55,grid2:0x2a353c,label:'#e6ebf0',labelBg:'rgba(23,31,39,0.88)'} : {bg:0xe4edf4,fog:0xe4edf4,ground:0x9aa77a,grid1:0x8ea0ae,grid2:0xb9c6d0,label:'#16212b',labelBg:'rgba(255,255,255,0.9)'}; }
  function theme(){ if(!inited) return; const c=themeColors(); renderer.setClearColor(new THREE.Color(c.bg),1); scene.background=new THREE.Color(c.bg); scene.fog=new THREE.Fog(c.fog,300,1400); if(Rcur) rebuild(); }
  function makeEnv(){
    const cv=document.createElement('canvas'); cv.width=64; cv.height=256; const cx=cv.getContext('2d'); const gr=cx.createLinearGradient(0,0,0,256);
    gr.addColorStop(0,'#5d93c4'); gr.addColorStop(0.42,'#bcd6ea'); gr.addColorStop(0.5,'#e3ddcd'); gr.addColorStop(0.55,'#9aa27c'); gr.addColorStop(1,'#5c6b4a'); cx.fillStyle=gr; cx.fillRect(0,0,64,256);
    const t=new THREE.CanvasTexture(cv); t.mapping=THREE.EquirectangularReflectionMapping; t.encoding=THREE.sRGBEncoding; return t;
  }
  function makeMats(){
    const steel=new THREE.MeshPhysicalMaterial({color:0xb3bcc3,metalness:0.95,roughness:0.5,clearcoat:0.12,clearcoatRoughness:0.7,envMapIntensity:0.9});
    const steelD=new THREE.MeshPhysicalMaterial({color:0x9aa4ab,metalness:0.95,roughness:0.55,envMapIntensity:0.8});
    const fund=new THREE.MeshStandardMaterial({color:0xb9b3a6,metalness:0.05,roughness:0.85});
    const insul=new THREE.MeshPhysicalMaterial({color:0x56705f,metalness:0.1,roughness:0.45,clearcoat:0.35,clearcoatRoughness:0.3});
    const cond=new THREE.MeshStandardMaterial({color:0x8a8f93,metalness:0.85,roughness:0.5});
    const ph=c=>new THREE.MeshStandardMaterial({color:c,metalness:0.7,roughness:0.5});
    const concreto=new THREE.MeshStandardMaterial({color:0xcfcac0,metalness:0.02,roughness:0.9}); const madera=new THREE.MeshStandardMaterial({color:0x8d6a45,metalness:0.0,roughness:0.85});
    return {patas:steel,cuerpo:steel,crucetas:steelD,aisladores:insul,conductores:cond,cond0:ph(0xb5473b),cond1:ph(0xc99a3a),cond2:ph(0x3f6f98),fund,concreto,madera};
  }
  function init(){
    const host=el(); const w=host.clientWidth||800, h=host.clientHeight||560;
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1)); renderer.setSize(w,h);
    renderer.outputEncoding=THREE.sRGBEncoding; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=0.85;
    host.insertBefore(renderer.domElement, host.firstChild);
    scene=new THREE.Scene(); envTex=makeEnv(); scene.environment=envTex; mats=makeMats();
    camera=new THREE.PerspectiveCamera(40,w/h,0.5,4000);
    controls=new THREE.OrbitControls(camera,renderer.domElement); controls.enableDamping=true; controls.dampingFactor=0.09; controls.maxPolarAngle=Math.PI/2-0.02; controls.screenSpacePanning=true; controls.minDistance=6; controls.maxDistance=600;
    scene.add(new THREE.AmbientLight(0xdde8f5,0.75));
    const hemi=new THREE.HemisphereLight(0xbcd6f2,0x6b6250,0.55); hemi.position.set(0,120,0); scene.add(hemi);
    const sun=new THREE.DirectionalLight(0xffffff,1.15); sun.position.set(120,150,90); scene.add(sun);
    const fill=new THREE.DirectionalLight(0x3fa9ff,0.35); fill.position.set(-30,20,-30); scene.add(fill);
    root=new THREE.Group(); scene.add(root); refRoot=new THREE.Group(); scene.add(refRoot);
    inited=true; theme();
    window.addEventListener('resize',resize);
    new ResizeObserver(resize).observe(host);
    loop();
    if(Rcur) rebuild();
  }
  function resize(){ if(!inited) return; const host=el(); const w=host.clientWidth||600, h=host.clientHeight||400; camera.aspect=w/h; camera.updateProjectionMatrix(); renderer.setSize(w,h); }
  function loop(){ requestAnimationFrame(loop); if(!inited) return; if(auto){ root.rotation.y+=0.0025; refRoot.rotation.y=root.rotation.y; } controls.update(); renderer.render(scene,camera); }
  const V=(x,y,z)=>new THREE.Vector3(x,y,z);
  function label(text,p,scale,accent){
    const c=themeColors(); const cv=document.createElement('canvas'); cv.width=320; cv.height=72; const x=cv.getContext('2d');
    x.fillStyle=c.labelBg; x.beginPath(); x.roundRect? x.roundRect(4,4,312,64,10) : x.rect(4,4,312,64); x.fill(); x.strokeStyle=accent||'#d9731a'; x.lineWidth=4; x.stroke();
    x.fillStyle=c.label; x.font='600 30px "Source Sans 3", Arial'; x.textAlign='center'; x.textBaseline='middle'; x.fillText(text,160,39);
    const t=new THREE.CanvasTexture(cv); t.encoding=THREE.sRGBEncoding; const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,depthTest:false,transparent:true})); s.position.copy(p); s.scale.set(scale*4.44,scale,1); s.renderOrder=10; return s;
  }
  function terrain(feet,b){
    const pts= feet.length>=3? feet : [V(-b/2,0,-b/2),V(b/2,0,-b/2),V(b/2,0,b/2),V(-b/2,0,b/2)];
    const n=pts.length; let sx=0,sz=0,sy=0,sxx=0,szz=0,sxz=0,sxy=0,szy=0; pts.forEach(p=>{ sx+=p.x; sz+=p.z; sy+=p.y; sxx+=p.x*p.x; szz+=p.z*p.z; sxz+=p.x*p.z; sxy+=p.x*p.y; szy+=p.z*p.y; });
    let a=0,c=0,d0=sy/n; const m=[[n,sx,sz,sy],[sx,sxx,sxz,sxy],[sz,sxz,szz,szy]];
    try{ for(let i=0;i<3;i++){ let p=i; for(let r=i+1;r<3;r++) if(Math.abs(m[r][i])>Math.abs(m[p][i])) p=r; [m[i],m[p]]=[m[p],m[i]]; if(Math.abs(m[i][i])<1e-9) throw 0; for(let r=0;r<3;r++){ if(r===i) continue; const f=m[r][i]/m[i][i]; for(let k=i;k<4;k++) m[r][k]-=f*m[i][k]; } } d0=m[0][3]/m[0][0]; a=m[1][3]/m[1][1]; c=m[2][3]/m[2][2]; }catch(e){ a=0;c=0;d0=sy/n; }
    const R=Math.max(b*3.4,26); const y=(x,z)=>d0+a*x+c*z; const N=10; const pos=[], idx=[];
    for(let i=0;i<=N;i++) for(let j=0;j<=N;j++){ const x=-R+2*R*i/N, z=-R+2*R*j/N; pos.push(x,y(x,z)-0.02,z); }
    for(let i=0;i<N;i++) for(let j=0;j<N;j++){ const k=i*(N+1)+j; idx.push(k,k+N+1,k+1, k+1,k+N+1,k+N+2); }
    const geo=new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3)); geo.setIndex(idx); geo.computeVertexNormals();
    const tc=themeColors(); const zone=(Rcur&&Rcur.M&&Rcur.M.zone)||'Sierra'; const gcol=isDark()? tc.ground : ({Costa:0xc9bd97,Sierra:0x9aa77a,Selva:0x6f9a63}[zone]||0x9aa77a);
    const mesh=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:gcol,roughness:0.95,metalness:0.02,side:THREE.DoubleSide}));
    const wire=new THREE.LineSegments(new THREE.WireframeGeometry(geo),new THREE.LineBasicMaterial({color:tc.grid1,transparent:true,opacity:0.28}));
    return {mesh,wire,slope:Math.sqrt(a*a+c*c)};
  }
  function dimension(g,p1,p2,text,off,H){
    const mat=new THREE.LineBasicMaterial({color:0xd9731a}); g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([p1,p2]),mat));
    const perp=off.clone().normalize().multiplyScalar(Math.max(0.2,Math.min(0.6,H*0.02))); [p1,p2].forEach(p=>g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([p.clone().sub(perp),p.clone().add(perp)]),mat)));
    g.add(label(text,p1.clone().add(p2).multiplyScalar(0.5).add(off),Math.max(0.55,H*0.05)));
  }
  function weightEstimate(R,type,info){
    const M=R.M; const fams=(M.fams||[]).filter(f=>f.count>0&&f.ton>0).map(f=>({name:f.name,w:f.ton/f.count})).sort((a,b)=>a.w-b.w);
    let W0; const wt={S:1,A:1.9,T:3.4}[type];
    if(fams.length>=3) W0= type==='S'? fams[0].w : type==='T'? fams[fams.length-1].w : fams[Math.floor(fams.length/2)].w;
    else if(fams.length) W0=fams[0].w*wt; else W0=(R.tons/Math.max(1,R.nStruct))*wt/1.42 || ({60:2.8,138:5.5,220:8.5,500:15}[R.inp.kv]||6)*(R.inp.struct==='DT'?1.5:1)*wt;
    const ext=R.inp.ext; const fE=1+0.03*Math.max(0,ext)+0.015*Math.min(0,ext); const legs=(info&&(info.mono||info.poste))?0:ctl.legs.reduce((a,e)=>a+Math.max(0,e),0);
    if(info&&info.poste){ const Hb=Math.round(info.Hbody+1.6); // masa de postes CAC por altura (t): 8/200 0.32, 9/200 0.45, 12 m 0.85, 13/300 1.0, 15 m 1.5, 18 m 2.4, 21 m 3.5 (catálogos de fabricantes); madera ≈ 0.55×
      const tab=[[8,0.32],[9,0.45],[12,0.85],[13,1.0],[15,1.5],[18,2.4],[21,3.5],[25,5.2]]; let m=tab[tab.length-1][1]; for(let i=0;i<tab.length;i++){ if(Hb<=tab[i][0]){ if(i===0) m=tab[0][1]; else { const [h0,m0]=tab[i-1],[h1,m1]=tab[i]; m=m0+(m1-m0)*(Hb-h0)/(h1-h0); } break; } }
      const ft= type==='S'?1.0:type==='A'?1.15:1.3; const arm= info.bt? 0.03 : info.compact? 0.06 : (R.inp.kv>=45? 0.18 : 0.08); // crucetas / armados / ménsulas
      W0=(m*(info.mat==='PM'?0.55:1)*ft+arm)*(info.hframe?2.0:1)+(info.hframe?0.25:0); return {W0,W:W0,extT:0,legsT:0,src:(info.mat==='PM'?'poste de madera':'poste de concreto armado centrifugado')+' '+Hb+' m'+(info.hframe?' × 2 + viga y riostras':info.bt?' (CAC 8/200 – 9/200 + armado)':' + crucetas / aisladores')+(type!=='S'?' (estructura reforzada de '+(type==='A'?'ángulo':'retención')+')':'')}; }
    if(info&&info.mono){ W0=0.28*Math.pow(info.Hbody,1.1)*wt*0.9*(info.hframe?2.0:1); return {W0,W:W0*fE,extT:W0*(fE-1),legsT:0,src:'poste tubular de acero poligonal (ratio kg/m según altura y tipo)'+(info.hframe?' × 2 + viga':'')}; }
    return {W0,W:W0*fE*(1+0.008*legs),extT:W0*(fE-1),legsT:W0*fE*0.008*legs,src: fams.length? 'familias del módulo COES '+M.n : 'promedio del estimado'};
  }
  function autoSil(inp,M,circ){ if(Rcur.lite) return Rcur.sil||'poste'; if(M.struct==='POSTE') return 'poste'; if(String(M.struct).startsWith('ST-VSL')&&ctl.type==='S') return 'vsl'; if(inp.kv===500&&circ==='ST'&&ctl.type==='S'&&ctl.disp==='auto') return 'gato'; return 'celosia'; }
  function allowedSils(){ if(!Rcur) return TowerLOD.SILS.map(x=>x[0]); const inp=Rcur.inp; const circ= inp.struct==='DT'?'DT':'ST'; return TowerLOD.silsFor(inp.kv,circ,Rcur.mat); }
  function params(){ const inp=Rcur.inp, M=Rcur.M; const circ= inp.struct==='DT'?'DT':'ST'; const ok=allowedSils(); let sil= ctl.sil==='auto'? autoSil(inp,M,circ) : ctl.sil; if(!ok.includes(sil)) sil= ok.includes(autoSil(inp,M,circ))? autoSil(inp,M,circ) : ok[0]; if(sil==='vsl'&&ctl.type!=='S') sil='celosia'; if(sil==='gato'&&ctl.type!=='S'&&inp.kv<500) sil='celosia';
    const disp= ctl.disp==='auto' ? (circ==='DT'?'vertical': (inp.kv===500&&sil==='celosia')?'horizontal':'triangular') : ctl.disp;
    const nG=Rcur.lite? (Rcur.nGuard||0) : cgList(inp.cg).length; const nC=Rcur.lite? 1 : inp.cond.n;
    return {kv:inp.kv,type:ctl.type,circ,disp,ext:inp.ext,legs:ctl.legs,nGuard:nG,nCond:nC,sil,mat:Rcur.mat||(M.struct==='POSTE'?'PC':'TA'),mrt:!!Rcur.mrt,lum:Rcur.lum!==false,acom:Rcur.acom!==false,kind: sil==='vsl'?'vsl':'lattice'}; }
  function buildPole(p){ // poste de concreto (módulos 60 kV POSTE)
    const g=new THREE.Group(); const H=20+Math.max(0,p.ext)*0.5; const conc=new THREE.MeshStandardMaterial({color:0xb9b3a6,roughness:0.85});
    const pole=new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.32,H,14),conc); pole.position.y=H/2; g.add(pole);
    const ped=new THREE.Mesh(new THREE.CylinderGeometry(0.6,0.7,1.0,12),conc); ped.position.y=-0.5; g.add(ped);
    let yLow=Infinity; const lv=[H-1.6,H-4.6,H-7.6], side=[1,-1,1];
    lv.forEach((h,i)=>{ const s=side[i]; const arm=new THREE.Mesh(new THREE.BoxGeometry(0.12,0.14,1.7),mats.crucetas); arm.position.set(0,h,s*0.85); g.add(arm); const strut=new THREE.Mesh(new THREE.BoxGeometry(0.06,Math.hypot(1.0,1.6),0.06),mats.crucetas); strut.position.set(0,h-0.5,s*0.8); strut.rotation.x=s*Math.atan2(1.6,1.0); g.add(strut);
      const ins=new THREE.Mesh(new THREE.CylinderGeometry(0.06,0.06,0.8,8),mats.aisladores); ins.position.set(0,h-0.4,s*1.6); g.add(ins); const cd=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,14,8),mats.conductores); cd.rotation.z=Math.PI/2; cd.position.set(0,h-0.85,s*1.6); g.add(cd); yLow=Math.min(yLow,h-0.85); });
    const gw=new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,14,6),mats.conductores); gw.rotation.z=Math.PI/2; gw.position.set(0,H+0.3,0); g.add(gw);
    return {g,info:{H,H0:H,base:0.7,feet:[V(0,0,0)],yLow,armW:3.4,piezas:12,poste:true}};
  }
  function buildVSL(p,f){ // torre atirantada en V (500 kV)
    const g=new THREE.Group(); const H=f.H*0.95, D=f.D||12.5; const st=mats.cuerpo;
    const mast=(a,b,r)=>{ const d=new THREE.Vector3().subVectors(b,a); const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,d.length(),8),st); m.position.copy(a).add(d.clone().multiplyScalar(0.5)); m.quaternion.setFromUnitVectors(V(0,1,0),d.clone().normalize()); g.add(m); };
    mast(V(0,0,-1.2),V(0,H,-D*0.85),0.32); mast(V(0,0,1.2),V(0,H,D*0.85),0.32);
    for(let i=1;i<12;i++){ const t=i/12; mast(V(-0.7,H*t,-1.2-(D*0.85-1.2)*t),V(0.7,H*t,-1.2-(D*0.85-1.2)*t),0.06); mast(V(-0.7,H*t,1.2+(D*0.85-1.2)*t),V(0.7,H*t,1.2+(D*0.85-1.2)*t),0.06); }
    const beam=new THREE.Mesh(new THREE.BoxGeometry(2.2,2.2,2*(D+2.5)),st); beam.position.y=H; g.add(beam);
    const feet=[V(0,0,-1.2),V(0,0,1.2)];
    [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(([sx,sz])=>{ const from=V(0,H,sz*(D+2.5)), to=V(sx*H*0.45,0,sz*(D+2.5+H*0.55)); g.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([from,to]),new THREE.LineBasicMaterial({color:0x6b7c8c}))); const anc=new THREE.Mesh(new THREE.BoxGeometry(1.2,0.6,1.2),mats.fund); anc.position.set(to.x,0.3,to.z); g.add(anc); feet.push(to); });
    let yLow=Infinity; [-D,0,D].forEach((zz,i)=>{ const dz=f.ins*0.55; [[-1],[1]].forEach(([s])=>{ const rod=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,f.ins,6),mats.aisladores); const a=V(0,H-1.1,zz+s*dz), b=V(0,H-1.1-Math.sqrt(f.ins*f.ins-dz*dz),zz); const d=new THREE.Vector3().subVectors(b,a); rod.position.copy(a).add(d.clone().multiplyScalar(0.5)); rod.quaternion.setFromUnitVectors(V(0,1,0),d.clone().normalize()); g.add(rod); });
      const y=H-1.1-Math.sqrt(f.ins*f.ins-dz*dz); const n=p.nCond||1; const offs= n<=1?[[0,0]]:n===2?[[0,-0.225],[0,0.225]]:n===3?[[0.2,0],[-0.13,-0.225],[-0.13,0.225]]:[[0.225,-0.225],[0.225,0.225],[-0.225,-0.225],[-0.225,0.225]]; offs.forEach(([oy,oz])=>{ const c=new THREE.Mesh(new THREE.CylinderGeometry(0.055,0.055,f.LV,8),mats.conductores); c.rotation.z=Math.PI/2; c.position.set(0,y+oy,zz+oz); g.add(c); }); yLow=Math.min(yLow,y); });
    [-1,1].forEach(sz=>{ mast(V(0,H,sz*(D+2.5)),V(0,H+1.8,sz*(D+2.5)),0.08); const gw=new THREE.Mesh(new THREE.CylinderGeometry(0.028,0.028,f.LV,6),mats.conductores); gw.rotation.z=Math.PI/2; gw.position.set(0,H+1.7,sz*(D+2.5)); g.add(gw); });
    return {g,info:{H:H+1.8,H0:H+1.8,base:2.4,feet:feet.slice(0,2),yLow,armW:2*(D+2.5),piezas:40,vsl:true}};
  }
  function rebuild(){
    if(!inited||!Rcur) return;
    try{ rebuildInner(); }catch(e){ console.error('V3 rebuild',e); const h=$id('hud'); if(h) h.innerHTML='<span class="err">Error al generar la torre: '+esc(e.message)+'</span>'; }
  }
  function rebuildInner(){
    while(root.children.length) root.remove(root.children[0]);
    fillSil();
    const R=Rcur, inp=R.inp, p=params();
    let built;
    { const {B,info}=TowerLOD.build(p); const g=new THREE.Group();
      ['patas','cuerpo','crucetas','concreto','madera','aisladores','conductores','cond0','cond1','cond2'].forEach(k=>{ if(!B[k]) return; if(!ctl.ins&&(k!=='patas'&&k!=='cuerpo'&&k!=='crucetas'&&k!=='concreto'&&k!=='madera')) return; const geo=TowerLOD.merge(B[k]); if(geo){ const m=new THREE.Mesh(geo,mats[k]); m.name=k; g.add(m); } });
      if(ctl.fund) B.fund.forEach((arr,i)=>{ const geo=TowerLOD.merge(arr); if(geo){ const m=new THREE.Mesh(geo,mats.fund); m.name='fund_'+'ABCD'[i]; g.add(m); } });
      built={g,info}; }
    const info=built.info; lastInfo=info; root.add(built.g);
    const ter=terrain(info.feet,info.base); root.add(ter.mesh); root.add(ter.wire);
    const tc=themeColors(); const yMin=Math.min(...info.feet.map(f=>f.y));
    const grid=new THREE.GridHelper(Math.max(info.base*6.8,52),26,tc.grid1,tc.grid2); grid.material.transparent=true; grid.material.opacity=0.22; grid.position.y=yMin-0.35; root.add(grid);
    if(ctl.dims){ const g=new THREE.Group(); const Hs=info.H-yMin; const bx=info.base*0.5+Math.max(1.2,Hs*0.12); const k=Math.max(0.35,Math.min(1,Hs/40));
      dimension(g,V(-bx,yMin,-info.base/2-1*k),V(-bx,info.H,-info.base/2-1*k),`H = ${Hs.toFixed(1)} m`,V(-2.4*k,0,0),info.H);
      if(info.base>1.5) dimension(g,V(-info.base/2,yMin-1.6*k,info.base/2+1.5*k),V(info.base/2,yMin-1.6*k,info.base/2+1.5*k),`base ${info.base.toFixed(2)} m`,V(0,-1.6*k,0),info.H);
      if(info.armW&&info.armW>1) dimension(g,V(0,info.H+2.2*k,-info.armW/2),V(0,info.H+2.2*k,info.armW/2),`ancho ${info.armW.toFixed(1)} m`,V(0,1.6*k,0),info.H);
      if(!info.poste&&!info.vsl&&!info.mono&&!info.portico) info.feet.forEach((f,k)=>{ const e=ctl.legs[k]; g.add(label(`${'ABCD'[k]}${e?` ${e>0?'+':''}${e.toFixed(1)} m`:''}`,V(f.x*1.7,f.y+1.2,f.z*1.7),Math.max(0.9,info.H*0.026),'#2c5f8a')); });
      root.add(g); }
    buildRef(info);
    setCam(ctl.cam,info,true);
    const w=weightEstimate(R,ctl.type,info); lastW=w; lastP=p; lastTer=ter; const yLowG=info.yLow-yMin; const silN=SIL_NAMES[p.sil]||p.sil; const ternas= p.sil==='bt'?'red secundaria autoportante': p.mrt?'MRT (retorno por tierra)': inp.struct==='DT'?'doble terna':'simple terna'; const kvT= inp.kv<1?'380/220 V':inp.kv+' kV';
    const legsTxt=(info.mono||info.poste)?'':`Patas ${ctl.legs.map((e,i)=>'ABCD'[i]+(e>=0?'+':'')+e).join(' ')} m · `;
    $id('hud').innerHTML=`<b>${kvT} · ${ternas} · ${silN} · ${ctl.type==='S'?'suspensión':ctl.type==='A'?'ángulo':'anclaje / terminal'}</b><br>H ${info.H.toFixed(1)} m (ext. ${inp.ext>=0?'+':''}${inp.ext} m) · base ${info.base.toFixed(2)} m · ${info.piezas} piezas<br>${legsTxt}pendiente ${(ter.slope*100).toFixed(0)} %<br>Peso ≈ <b>${w.W.toFixed(1)} t</b> · conductor inferior a ${yLowG.toFixed(1)} m<br><span class="tiny">${R.lite? esc(R.label||'') : condLabel(inp.cond)+' · '+cgList(inp.cg).join('+')} · LOD 350 paramétrico</span>`;
    if(R.lite){ renderLiteCard(info,ter,w,p); return; }
    renderSideCards(info,ter,w);
    if(window.P2) P2.setTowerInfo({H:info.H,yLow:info.yLow,type:ctl.type,W:w.W});
  }
  function buildRef(info){
    while(refRoot.children.length) refRoot.remove(refRoot.children[0]);
    refRoot.visible=ctl.ref; if(!ctl.ref) return; const m=REFS[ctl.refIdx]; if(!m) return;
    const g=new THREE.Group(); const s=info.H0||info.H;
    if(m.object){ const o=m.object.clone(); const box=new THREE.Box3().setFromObject(o); const size=box.getSize(new THREE.Vector3()); o.scale.setScalar(s/(size.y||1)); box.setFromObject(o); o.position.set(-box.min.x-(box.max.x-box.min.x)/2,-box.min.y,-box.min.z-(box.max.z-box.min.z)/2); g.add(o);
      const meshes=[]; o.traverse(c=>{ if(c.isMesh) meshes.push(c); }); meshes.forEach(c=>{ c.material=new THREE.MeshPhysicalMaterial({color:0x7d8fa3,metalness:0.6,roughness:0.5,transparent:true,opacity:0.6}); try{ c.add(new THREE.LineSegments(new THREE.EdgesGeometry(c.geometry,25),new THREE.LineBasicMaterial({color:0x2c5f8a}))); }catch(e){} }); }
    else { const pos=new THREE.Float32BufferAttribute(m.v,3); if(m.f&&m.f.length){ const geo=new THREE.BufferGeometry(); geo.setAttribute('position',pos); geo.setIndex(m.f); geo.computeVertexNormals(); g.add(new THREE.Mesh(geo,new THREE.MeshPhysicalMaterial({color:0x7d8fa3,metalness:0.6,roughness:0.5,transparent:true,opacity:0.5,side:THREE.DoubleSide}))); } if(m.e&&m.e.length){ const geo=new THREE.BufferGeometry(); geo.setAttribute('position',pos); geo.setIndex(m.e); g.add(new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0x2c5f8a}))); } g.scale.setScalar(s); }
    g.position.x=info.base*1.8+10; refRoot.add(g); refRoot.add(label(m.name||'referencia',V(g.position.x,s+3,0),Math.max(1.4,s*0.05),'#2c5f8a'));
  }
  function setCam(mode,info,keepUser){
    const yMin=Math.min(...info.feet.map(f=>f.y)); const Ht=(info.H-yMin)+Math.max(3,(info.H-yMin)*0.19); const fov=camera.fov*Math.PI/180; const asp=camera.aspect||1.3; const dist=(Ht/2)/Math.tan(fov/2)*(asp<1.1?1.45:1.12); const cx= ctl.ref? info.base*0.9+5 : 0;
    const target=V(cx,yMin+Ht*0.46,0);
    if(mode==='iso') camera.position.set(cx-dist*0.66,yMin+Ht*0.58,dist*0.7);
    else if(mode==='front') camera.position.set(cx-dist,yMin+Ht*0.47,0.001);
    else if(mode==='side') camera.position.set(cx+0.001,yMin+Ht*0.47,dist);
    else camera.position.set(cx+0.001,yMin+dist*1.3,0.001);
    controls.target.copy(target); controls.update();
  }
  function renderSideCards(info,ter,w){
    const R=Rcur, inp=R.inp, M=R.M; const f=info.fam;
    const kv=[['Tensión',inp.kv+' kV'],['Silueta',SIL_NAMES[(f&&f.sil)||(info.vsl?'vsl':'celosia')]||'—'],['Tipo / ternas',(ctl.type==='S'?'Suspensión':ctl.type==='A'?'Ángulo':'Anclaje / terminal')+' · '+(inp.struct==='DT'?'doble terna':'simple terna')],['Disposición de fases',f?f.disp:(info.vsl?'horizontal (V atirantada)':'triangular')],['Altura total',info.H.toFixed(1)+' m (base '+(info.H0||info.H).toFixed(1)+' m + ext. '+inp.ext+' m)'],['Ancho de base (ejes de pata)',info.base.toFixed(2)+' m'],['Cuerpo recto',f&&f.hTronco?f.bR.toFixed(2)+' m desde '+f.hTronco.toFixed(1)+' m':(info.mono?`fuste Ø ${(2*info.r0).toFixed(2)} → ${(2*info.r1).toFixed(2)} m`:'—')],['Pendiente de cara',f&&f.tg?(f.tg*100).toFixed(1)+' % por lado':'—'],['Ménsulas (saliente)',f&&f.levels&&f.levels.length?f.levels.map(l=>l.l.toFixed(1)).join(' / ')+' m':(f&&f.D?`fases a ± ${f.D.toFixed(1)} m`:'—')],['Separación vertical entre fases',f&&f.dz?f.dz+' m':'—'],['Cadena de aisladores',f?f.ins.toFixed(2)+' m · '+f.nd+' discos':'—'],['Conductores por fase',inp.cond.n+' × '+condLabel({...inp.cond,n:1})],['Cables de guarda',cgList(inp.cg).join(' + ')],['Patas (A/B/C/D)',ctl.legs.map(e=>(e>=0?'+':'')+e+' m').join(' / ')],['Perfiles modelados',info.piezas]];
    const g=$id('geomKv'); if(g) g.innerHTML=kv.map(r=>`<dt>${r[0]}</dt><dd>${r[1]}</dd>`).join('');
    const fam=(M.fams||[]).filter(x=>x.count>0&&x.ton>0).map(x=>({label:x.name.replace(/^Estructuras?\s*(tipo|Tipo)?\s*/i,'').slice(0,26),value:x.ton/x.count,text:(x.ton/x.count).toFixed(1)+' t × '+x.count}));
    fam.push({label:'▶ Torre diseñada',value:w.W,text:w.W.toFixed(1)+' t',color:'var(--accent)',hi:true});
    const wc=$id('weightChart'); if(wc) wc.innerHTML=svgBars(fam,{lw:150,rh:20,w:420})+`<div class="tiny">Peso base por tipo según ${w.src}; +3 % por metro de extensión de cuerpo y +0.8 % por metro de pata.</div>`;
    const rw=$id('rsWeight'); if(rw) rw.innerHTML=`<div class="eyebrow" style="margin:10px 0 4px">Peso por familia del módulo ${M.n}</div>`+svgBars(fam,{lw:120,rh:18,w:360});
    const legs=(info.poste||info.vsl||info.mono)?[0,0,0,0]:ctl.legs; const dif=Math.max(...legs)-Math.min(...legs); const rows=[]; const ok=(c,t,d)=>rows.push({c,t,d});
    ok(dif<=6?'ok':'warn',`Desnivel entre patas ${dif.toFixed(1)} m`, dif<=6?'dentro del rango usual (escalones de 1.5 m, hasta ±3 m)':'supera 6 m: revisar ubicación, usar extensión de cuerpo o fundaciones especiales');
    const ext=inp.ext; ok(ext<=9?'ok':ext<=12?'warn':'bad',`Extensión de cuerpo ${ext>=0?'+':''}${ext} m`, ext<=9?'catálogos típicos: −6 / 0 / +3 / +6 / +9 m':'sobre +9 m se recomienda torre de mayor altura de catálogo');
    const rules=window.P2?P2.rules(inp.kv):null; const sag=ctl.sag/100*inp.span; const yLowG=info.yLow-Math.min(...info.feet.map(x=>x.y));
    if(rules){ const req=rules.clr.terreno; const hMid=yLowG-sag; ok(hMid>=req?'ok':'bad',`Altura a medio vano ≈ ${hMid.toFixed(1)} m (conductor a ${yLowG.toFixed(1)} m − flecha ${sag.toFixed(1)} m)`, hMid>=req?`cumple ${req.toFixed(1)} m (terreno, CNE Tabla 232-1 ref.)`:`no cumple ${req.toFixed(1)} m → extensión de cuerpo ≥ +${Math.ceil((req-hMid)/3)*3} m o vano menor`);
      const vmax=rules.max[ctl.type]; ok(inp.span<=vmax?'ok':'bad',`Vano promedio ${inp.span} m vs. vano máximo tipo ${ctl.type} ${vmax} m`, inp.span<=vmax?`rango recomendado ${rules.rec[0]}–${rules.rec[1]} m (promedio ${rules.avg} m)`:'reducir el vano o usar torre de anclaje / mayor altura'); }
    ok(ter.slope<=0.35?'ok':'warn',`Pendiente de terreno equivalente ${(ter.slope*100).toFixed(0)} %`, ter.slope<=0.35?'compatible con patas desiguales':'pendiente alta: verificar taludes y accesos');
    const cc=$id('checkCard'); if(cc) cc.innerHTML=`<ul class="chk-list">${rows.map(r=>`<li class="${r.c}"><b>${esc(r.t)}</b><div class="tiny">${esc(r.d)}</div></li>`).join('')}</ul>`;
    // ficha compacta del Resumen
    const rs=$id('rsFicha'); if(rs){ const bad=rows.filter(r=>r.c==='bad').length, warn=rows.filter(r=>r.c==='warn').length;
      rs.innerHTML=`<dl class="kv"><dt>Torre</dt><dd>${ctl.type==='S'?'Suspensión':ctl.type==='A'?'Ángulo':'Anclaje / terminal'} · ${inp.kv} kV ${inp.struct==='DT'?'DT':'ST'}</dd><dt>Altura / base</dt><dd>${info.H.toFixed(1)} m / ${info.base.toFixed(2)} m</dd><dt>Peso estimado</dt><dd><b>${w.W.toFixed(1)} t</b> (${w.W0.toFixed(1)} base${w.extT?` + ${w.extT.toFixed(1)} cuerpo`:''}${w.legsT?` + ${w.legsT.toFixed(1)} patas`:''})</dd><dt>Estructuras del proyecto</dt><dd>${fmt(R.nStruct)} · ${fmt(R.tons)} t (${fmt(R.tonKm,1)} t/km)</dd><dt>Costo estructuras (2.1)</dt><dd>USD ${fmt(R.items['2.1'].tot)} · ${fmt(R.items['2.1'].tot/Math.max(1,R.nStruct))} por estructura</dd><dt>Conductor inferior</dt><dd>${yLowG.toFixed(1)} m sobre el pie más bajo</dd><dt>Verificación</dt><dd>${bad?`<span class="tag" style="background:#F6D9D4;color:#8C2E22">${bad} crítica(s)</span> `:''}${warn?`<span class="tag" style="background:#FBEBD0;color:#8A5A12">${warn} aviso(s)</span> `:''}${!bad&&!warn?'<span class="tag vig">Sin observaciones</span>':''}</dd></dl><div class="tiny" style="margin-top:6px">Detalle, planta 2D y reglas de vanos en la pestaña “Diseño: torre y planta”.</div>`; }
  }
  function renderLiteCard(info,ter,w,p){
    const R=Rcur, inp=R.inp, f=info.fam; const el=$id('bFicha'); if(!el) return; const yLowG=info.yLow-Math.min(...info.feet.map(x=>x.y));
    const rules=window.P2?P2.rules(inp.kv):null; const rows=[]; const ok=(c,t,d)=>rows.push({c,t,d});
    if(rules){ const sag=ctl.sag/100*(inp.span||rules.avg); const req=rules.clr.terreno; const hMid=yLowG-sag; ok(hMid>=req?'ok':'bad',`Altura a medio vano ≈ ${hMid.toFixed(1)} m (conductor a ${yLowG.toFixed(1)} m − flecha ${sag.toFixed(1)} m)`, hMid>=req?`cumple ${req.toFixed(1)} m sobre terreno (CNE Tabla 232-1 ref.)`:`no cumple ${req.toFixed(1)} m → poste más alto o vano menor`); const vmax=rules.max[ctl.type]; ok((inp.span||0)<=vmax?'ok':'bad',`Vano ${inp.span} m vs. máximo tipo ${ctl.type} ${vmax} m`,`rango recomendado ${rules.rec[0]}–${rules.rec[1]} m (promedio ${rules.avg} m)`); }
    ok(ter.slope<=0.35?'ok':'warn',`Pendiente de terreno ${(ter.slope*100).toFixed(0)} %`, ter.slope<=0.35?'compatible':'verificar taludes / retenidas');
    el.innerHTML=`<dl class="kv"><dt>Estructura</dt><dd>${esc(R.label||'')}</dd><dt>Silueta</dt><dd>${SIL_NAMES[p.sil]||p.sil} · ${ctl.type==='S'?'suspensión / alineamiento':ctl.type==='A'?'ángulo':'anclaje / retención'}</dd><dt>Altura / base</dt><dd>${info.H.toFixed(1)} m / ${info.base.toFixed(2)} m${info.armW?` · ancho ${info.armW.toFixed(1)} m`:''}</dd><dt>Peso estimado</dt><dd><b>${w.W.toFixed(2)} t</b> <span class="tiny">(${esc(w.src)})</span></dd><dt>Conductor inferior</dt><dd>${yLowG.toFixed(1)} m sobre el pie</dd><dt>Estructuras del proyecto</dt><dd>${fmt(R.nStruct)} · ${fmt(R.nKm,2)}/km${R.ton?` · ${fmt(R.ton*R.nStruct,0)} t`:''}</dd><dt>Costo estructuras</dt><dd>${R.costStruct?`USD ${fmt(R.costStruct)} · ${fmt(R.costStruct/Math.max(1,R.nStruct))} por estructura`:'—'}</dd></dl><ul class="chk-list" style="margin-top:8px">${rows.map(r=>`<li class="${r.c}"><b>${esc(r.t)}</b><div class="tiny">${esc(r.d)}</div></li>`).join('')}</ul>`;
  }
  function exportOBJ(){ if(!lastInfo||!root) { if(window.toast) toast('Genera primero el modelo'); return; } const g=root.children[0]; if(!g) return; let out='# Estimador CAPEX Líneas — modelo BIM paramétrico (LOD 350), unidades: metros\n# '+(document.getElementById('hud')?document.getElementById('hud').innerText.replace(/\n/g,' | '):'')+'\n'; let off=1; g.updateMatrixWorld(true);
    g.traverse(m=>{ if(!m.isMesh||!m.geometry||!m.geometry.attributes.position) return; const pos=m.geometry.attributes.position; const idx=m.geometry.index; out+=`o ${m.name||'parte'}\n`; const v=new THREE.Vector3(); for(let i=0;i<pos.count;i++){ v.fromBufferAttribute(pos,i).applyMatrix4(m.matrixWorld); out+=`v ${v.x.toFixed(4)} ${v.y.toFixed(4)} ${v.z.toFixed(4)}\n`; } const n= idx? idx.count : pos.count; for(let i=0;i<n;i+=3){ const a= idx? idx.getX(i):i, b= idx? idx.getX(i+1):i+1, c= idx? idx.getX(i+2):i+2; out+=`f ${a+off} ${b+off} ${c+off}\n`; } off+=pos.count; });
    const inp=Rcur&&Rcur.inp; const name=`estructura_${inp?inp.kv:''}kV_${lastP?lastP.sil:''}_${ctl.type}.obj`; if(typeof download==='function') download(name,out,'text/plain'); }
  function fillSil(){ const ok=allowedSils(); if(ctl.sil!=='auto'&&!ok.includes(ctl.sil)) ctl.sil='auto'; ['v3Sil','rsSil','bSil'].forEach(id=>{ const s=$id(id); if(!s) return; const cur=s.value; s.innerHTML=TowerLOD.SILS.filter(([v])=>v==='auto'||ok.includes(v)).map(([v,l])=>`<option value="${v}">${l}</option>`).join(''); s.value=ctl.sil; }); }
  function syncSil(){ ['v3Sil','rsSil','bSil'].forEach(id=>{ const s=$id(id); if(s) s.value=ctl.sil; }); }
  function setSil(v){ ctl.sil=v; syncSil(); rebuild(); }
  function loadGLB(file){
    if(!THREE.GLTFLoader){ toast('GLTFLoader no disponible'); return; }
    const fr=new FileReader(); fr.onload=()=>{ try{ new THREE.GLTFLoader().parse(fr.result,'',gltf=>{ REFS.push({name:file.name.replace(/\.(glb|gltf)$/i,''),object:gltf.scene}); ctl.refIdx=REFS.length-1; ctl.ref=true; $id('v3Ref').classList.add('on'); refreshRefSelect(); rebuild(); toast('Modelo de referencia cargado: '+file.name); },err=>toast('No se pudo leer el .glb')); }catch(e){ toast('Error al cargar el modelo: '+e.message); } };
    fr.readAsArrayBuffer(file);
  }
  function refreshRefSelect(){ const s=$id('v3RefSel'); if(!s) return; s.innerHTML=REFS.length? REFS.map((m,i)=>`<option value="${i}" ${i===ctl.refIdx?'selected':''}>${esc(m.name)}${m.license?' · '+esc(m.license):''}</option>`).join('') : '<option value="">— ninguno (carga un .glb) —</option>'; }
  function mount(slotId){ const slot=$id(slotId), v=el(); if(!slot||!v) return; if(v.parentElement!==slot){ slot.appendChild(v); } mountedIn=slotId; ensure(); setTimeout(resize,30); }
  function ensure(){ if(!inited){ try{ init(); }catch(e){ const h=$id('hud'); if(h) h.innerHTML='<span class="err">No se pudo iniciar WebGL: '+esc(e.message)+'</span>'; } } else resize(); }
  function bind(){
    const q=$id; const legSel=['v3LegA','v3LegB','v3LegC','v3LegD'];
    q('v3Type').onchange=e=>{ ctl.type=e.target.value; const r=q('rsType'); if(r) r.value=ctl.type; rebuild(); };
    q('v3Disp').onchange=e=>{ ctl.disp=e.target.value; rebuild(); };
    q('v3Sag').oninput=e=>{ ctl.sag=parseFloat(e.target.value)||3.2; rebuild(); };
    q('v3Ext').onchange=e=>{ const s=q('inExt'); s.value=parseFloat(e.target.value); s.dispatchEvent(new Event('input',{bubbles:true})); };
    legSel.forEach((id,i)=>{ q(id).onchange=e=>{ ctl.legs[i]=parseFloat(e.target.value)||0; rebuild(); }; });
    q('v3Ins').onclick=e=>{ ctl.ins=!ctl.ins; e.target.classList.toggle('on',ctl.ins); rebuild(); };
    q('v3Dims').onclick=e=>{ ctl.dims=!ctl.dims; e.target.classList.toggle('on',ctl.dims); rebuild(); };
    q('v3Fund').onclick=e=>{ ctl.fund=!ctl.fund; e.target.classList.toggle('on',ctl.fund); rebuild(); };
    q('v3Ref').onclick=e=>{ ctl.ref=!ctl.ref; e.target.classList.toggle('on',ctl.ref); rebuild(); };
    q('v3Auto').onclick=e=>{ auto=!auto; e.target.classList.toggle('on',auto); };
    q('v3RefSel').onchange=e=>{ ctl.refIdx=parseInt(e.target.value)||0; if(!ctl.ref){ ctl.ref=true; q('v3Ref').classList.add('on'); } rebuild(); };
    q('v3File').onchange=e=>{ const f=e.target.files&&e.target.files[0]; if(f) loadGLB(f); e.target.value=''; };
    document.querySelectorAll('[data-cam]').forEach(b=>b.onclick=()=>{ document.querySelectorAll('[data-cam]').forEach(x=>x.classList.toggle('on',x.dataset.cam===b.dataset.cam)); ctl.cam=b.dataset.cam; if(lastInfo) setCam(ctl.cam,lastInfo); });
    document.querySelectorAll('#v3Circ button').forEach(b=>b.onclick=()=>{ const t=document.querySelector(`#segCirc button[data-v="${b.dataset.v}"]`); if(t) t.click(); });
    // controles compactos del Resumen
    const rt=q('rsType'); if(rt) rt.onchange=e=>{ ctl.type=e.target.value; q('v3Type').value=ctl.type; rebuild(); };
    const rl=q('rsLegs'); if(rl) rl.onchange=e=>{ const v=e.target.value.split(',').map(Number); ctl.legs=v; legSel.forEach((id,i)=>q(id).value=String(v[i])); rebuild(); };
    const ra=q('rsAuto'); if(ra) ra.onclick=e=>{ auto=!auto; e.target.classList.toggle('on',auto); q('v3Auto').classList.toggle('on',auto); };
    refreshRefSelect(); fillSil();
    ['v3Sil','rsSil','bSil'].forEach(id=>{ const s=q(id); if(s) s.onchange=e=>setSil(e.target.value); });
    const bt=q('bType'); if(bt) bt.onchange=e=>{ ctl.type=e.target.value; rebuild(); };
    const ba=q('bAuto'); if(ba) ba.onclick=e=>{ auto=!auto; e.target.classList.toggle('on',auto); };
    ['rsObj','bObj','v3Obj'].forEach(id=>{ const b=q(id); if(b) b.onclick=exportOBJ; });
  }
  function syncControls(inp){ const q=$id; if(!inp) return; if(q('v3Ext')) q('v3Ext').value=String(inp.ext); document.querySelectorAll('#v3Circ button').forEach(b=>b.classList.toggle('on',b.dataset.v===inp.struct||(b.dataset.v==='ST'&&inp.struct!=='DT'))); }
  document.addEventListener('DOMContentLoaded',bind);
  /* Espacio B: especificación ligera (sin módulo COES) */
  function updateSpec(sp){ if(!sp) return;
    Rcur={lite:true,inp:{kv:sp.kv,struct:sp.circ==='DT'?'DT':'ST',ext:sp.ext||0,span:sp.span||0,cond:{mat:'AAAC',n:1,size:sp.mm2||70,unit:'mm²'},cg:'CG0'},M:{zone:sp.zone||'Sierra',struct:sp.sil==='poste'?'POSTE':'ST',fams:[]},sil:sp.sil,mat:sp.mat,mrt:!!sp.mrt,lum:sp.lum!==false,acom:sp.acom!==false,nGuard:sp.nGuard||0,label:sp.label||'',nStruct:sp.nStruct||0,nKm:sp.nKm||0,ton:sp.ton||0,costStruct:sp.costStruct||0,tons:(sp.ton||0)*(sp.nStruct||0)};
    if(inited) rebuild(); }
  function snapshot(w,h){ if(!inited||!lastInfo) return null; try{ const W=w||900,H=h||560; const pr=renderer.getPixelRatio(); const s0=renderer.getSize(new THREE.Vector2()); renderer.setPixelRatio(1); renderer.setSize(W,H,false); camera.aspect=W/H; camera.updateProjectionMatrix(); setCam(ctl.cam,lastInfo); renderer.render(scene,camera); const url=renderer.domElement.toDataURL('image/png'); renderer.setPixelRatio(pr); renderer.setSize(s0.x,s0.y,false); camera.aspect=s0.x/s0.y; camera.updateProjectionMatrix(); setCam(ctl.cam,lastInfo); renderer.render(scene,camera); return url; }catch(e){ return null; } }
  function last(){ return {info:lastInfo,w:lastW,p:lastP,ter:lastTer,ctl}; }
  return { ensure, mount, update(R){ Rcur=R; syncControls(R.inp); if(inited) rebuild(); }, updateSpec, syncSil, snapshot, last, theme, rebuild, ctl, refs(){ return REFS; }, _dbg(){ return {renderer,scene,camera,controls,lastInfo}; } };
})();
