"""Añade a osi.json los kits paramétricos de redes secundarias BT (RD 031-2003-EM) y ajustes MT 13.2 kV.
Precios de mercado 2025 (USD sin IGV, ex-almacén Lima) — criterio experto; editables desde el modal de precios."""
import json
p='/home/claude/capex/osi.json'
o=json.load(open(p))
o['btKit']={
 'label':'Red secundaria aérea 380/220 V con conductor autoportante (CAAI) — DGE RD 031-2003-EM',
 'cond':{
   '3x35+16/25':{'usdKm':1350,'kgKm':520,'amp':110,'desc':'CAAI-S 3×35 + 16/25 mm² (portante Al-Al 25 mm²)'},
   '3x50+16/35':{'usdKm':1750,'kgKm':690,'amp':135,'desc':'CAAI-S 3×50 + 16/35 mm²'},
   '3x70+16/50':{'usdKm':2300,'kgKm':930,'amp':170,'desc':'CAAI-S 3×70 + 16/50 mm²'},
   '3x95+16/50':{'usdKm':2950,'kgKm':1180,'amp':210,'desc':'CAAI-S 3×95 + 16/50 mm²'},
   '2x25+16/25':{'usdKm':900,'kgKm':330,'amp':90,'desc':'CAAI 2×25 + 16/25 mm² (monofásico)'},
   '1x16+N25':{'usdKm':520,'kgKm':170,'amp':70,'desc':'CAAI 1×16 + N25 mm² (monofásico rural)'}},
 'structs':{
   'PC':{'label':'Postes CAC 8/200 (alineamiento), 8/300 y 9/200 (ángulo y anclaje) con armados E-S / E-A / E-T para CAAI','span':{'rural':50,'urbana':40},
         'S':{'sup':215,'code':'CAC 8/200 + armado de suspensión E-S + ferretería','mont':75,'oc':45},
         'A':{'sup':330,'code':'CAC 8/300 + armado de ángulo E-A + 1 retenida','mont':110,'oc':70},
         'T':{'sup':420,'code':'CAC 9/200 + armado de anclaje / fin de línea E-T + 2 retenidas','mont':130,'oc':85}},
   'PM':{'label':'Postes de madera tratada 8–9 m con armados para CAAI','span':{'rural':50,'urbana':40},
         'S':{'sup':170,'code':'PM 8 m + armado E-S','mont':60,'oc':35},
         'A':{'sup':270,'code':'PM 9 m + armado E-A + retenida','mont':95,'oc':55},
         'T':{'sup':350,'code':'PM 9 m + armado E-T + 2 retenidas','mont':110,'oc':70}}},
 'lum':{'usd':190,'mont':35,'desc':'Luminaria LED 40–60 W con pastoral, fotocélula y conductor de alumbrado'},
 'acom':{'usd':95,'mont':30,'desc':'Acometida domiciliaria: conductor concéntrico 2×6/4 mm² (≤ 25 m), caja portamedidor y accesorios; sin medidor'},
 'pat':{'usdStr':85,'every':5,'note':'puesta a tierra cada 5 estructuras, en anclajes y en luminarias alternas'},
 'montString':{'rural':700,'urbana':800},
 'other':{'rural':250,'urbana':350},
 'rules':{'avg':{'rural':50,'urbana':40},'rec':{'rural':[45,60],'urbana':[35,45]},'max':70,'min':20,'clr':5.5,'clrVia':6.0},
 'nota':'Kit paramétrico de mercado 2025 (USD sin IGV, ex-almacén Lima): postes CAC 8/200 ≈ 145 USD, 8/300 ≈ 170 USD, 9/200 ≈ 175 USD; CAAI 3×50+16/35 ≈ 1.75 USD/m; armados E-S/E-A/E-T con ferretería galvanizada; luminaria LED con pastoral; acometidas sin medidor. Osinergmin no incluye redes secundarias en la BDME de transmisión: calibrar con el VNR de distribución o cotizaciones del concesionario.'
}
mt=o['mtKit']
mt['rules']['13.2']=dict(mt['rules']['22.9']); mt['serv']['13.2']={'ancho':11,'usdKm':dict(mt['serv']['22.9']['usdKm'])}
mt['montString']['13.2']=mt['montString']['22.9']; mt['other']['13.2']=mt['other']['22.9']
for k in mt['structs'].values(): k['span']['13.2']=k['span']['22.9']
mt['insF']={'22.9':1.0,'13.2':0.95,'10':0.92}
json.dump(o,open(p,'w'),ensure_ascii=False)
print('ok', len(json.dumps(o)))
