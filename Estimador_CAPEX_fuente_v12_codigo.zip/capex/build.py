import json, os, re
base='/home/claude/capex'
P=lambda n: open(os.path.join(base,'parts',n),encoding='utf-8').read()
css=P('style.css'); body=P('body.html'); engine=P('engine.js'); ui=P('ui.js'); v3=P('viewer3d.js'); body2=P('body2.html'); engine2=P('engine2.js'); ui2=P('ui2.js'); p2=P('planta2d.js'); body3=P('body3.html'); engine3=P('engine3.js'); ui3=P('ui3.js')
gltf=open(os.path.join(base,'GLTFLoader.js'),encoding='utf-8').read()
bgu=open(os.path.join(base,'BufferGeometryUtils.js'),encoding='utf-8').read()
tlod=P('towerlod.js'); precios=P('precios.js'); informe=P('informe.js'); proyecto=P('proyecto.js'); escal=P('escal.js'); pertmap=P('pertmap.js'); refsjs=P('refs.js'); refsejs=P('refse.js'); intljs=P('intl.js'); guidejs=P('guide.js'); sub3d=P('sub3d.js')
import glob
refs=[]
for f in sorted(glob.glob(os.path.join(base,'refmodels','*.json'))):
    refs.append(json.load(open(f,encoding='utf-8')))
refs_safe=json.dumps(refs,separators=(',',':')).replace('</','<\\/')
# el espacio <= 60 kV se inserta antes del toast
assert '<div class="toast" id="toast"></div>' in body
body=body.replace('<div class="toast" id="toast"></div>', body2+'\n'+body3+'\n<div class="toast" id="toast"></div>')
db=open(os.path.join(base,'db.json'),encoding='utf-8').read()
db_safe=db.replace('</','<\\/').replace('<!--','<\\!--')
osi=open(os.path.join(base,'osi.json'),encoding='utf-8').read()
osi_safe=osi.replace('</','<\\/').replace('<!--','<\\!--')
sedb=open(os.path.join(base,'se_db.json'),encoding='utf-8').read()
sedb_safe=sedb.replace('</','<\\/').replace('<!--','<\\!--')
prefs=open(os.path.join(base,'refs.json'),encoding='utf-8').read().replace('</','<\\/').replace('<!--','<\\!--')
prefse=open(os.path.join(base,'refs_se.json'),encoding='utf-8').read().replace('</','<\\/').replace('<!--','<\\!--')
pintl=open(os.path.join(base,'intl_refs.json'),encoding='utf-8').read().replace('</','<\\/').replace('<!--','<\\!--')
three=open(os.path.join(base,'three.min.js'),encoding='utf-8').read()
orbit=open(os.path.join(base,'OrbitControls.js'),encoding='utf-8').read()
for s in (three,orbit,gltf,bgu,tlod,engine,ui,v3,engine2,ui2,p2,precios,informe,proyecto,escal,pertmap,engine3,ui3,refsjs,refsejs,intljs,guidejs,sub3d):
    assert '</script' not in s.lower(), 'script contains closing tag'

fonts='<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Semi+Condensed:wght@600;700&family=Source+Sans+3:wght@400;600;700&family=JetBrains+Mono:wght@400;700&display=swap">'

content = f"""<title>Estimador CAPEX Líneas y Subestaciones</title>
<meta name="description" content="Estimador paramétrico de CAPEX de líneas eléctricas (380/220 V a 500 kV) y subestaciones (60–500 kV, AIS/GIS) en USD sin IGV: bases COES 2025/26 (líneas y 318 módulos de subestaciones), Osinergmin BDME 2025 y referencias de mercado Perú (Invierte.pe y SEACE), marcas por componente, escalamiento, riesgo AACE con mapa PERT y BIM 3D.">
{fonts}
<style>
{css}
</style>
{body}
<script id="db" type="application/json">{db_safe}</script>
<script id="osi" type="application/json">{osi_safe}</script>
<script id="sedb" type="application/json">{sedb_safe}</script>
<script id="refmodels" type="application/json">{refs_safe}</script>
<script id="refs" type="application/json">{prefs}</script>
<script id="refse" type="application/json">{prefse}</script>
<script id="intl" type="application/json">{pintl}</script>
<script>{three}</script>
<script>{orbit}</script>
<script>{gltf}</script>
<script>{bgu}</script>
<script>
{precios}
{proyecto}
{escal}
{refsjs}
{refsejs}
{engine}
{ui}
{engine2}
{ui2}
{engine3}
{ui3}
{tlod}
{v3}
{p2}
{pertmap}
{informe}
{intljs}
{sub3d}
{guidejs}
</script>
"""
# artifact variant (no skeleton)
open(os.path.join(base,'artifact.html'),'w',encoding='utf-8').write(content)
# standalone
standalone = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<style>:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}} img{{max-width:100%}} [hidden]{{display:none!important}}</style>
{content}
</head>
<body></body>
</html>
"""
# In the standalone version the body content is inside <head>, which browsers would move; better to structure properly:
standalone = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Estimador CAPEX Líneas y Subestaciones</title>
<meta name="description" content="Estimador paramétrico de CAPEX de líneas eléctricas (380/220 V a 500 kV) y subestaciones (60–500 kV, AIS/GIS) en USD sin IGV: bases COES 2025/26 (líneas y 318 módulos de subestaciones), Osinergmin BDME 2025 y referencias de mercado Perú (Invierte.pe y SEACE), marcas por componente, escalamiento, riesgo AACE con mapa PERT y BIM 3D.">
{fonts}
<style>
:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}} img{{max-width:100%}} [hidden]{{display:none!important}}
{css}
</style>
</head>
<body>
{body}
<script id="db" type="application/json">{db_safe}</script>
<script id="osi" type="application/json">{osi_safe}</script>
<script id="sedb" type="application/json">{sedb_safe}</script>
<script id="refmodels" type="application/json">{refs_safe}</script>
<script id="refs" type="application/json">{prefs}</script>
<script id="refse" type="application/json">{prefse}</script>
<script id="intl" type="application/json">{pintl}</script>
<script>{three}</script>
<script>{orbit}</script>
<script>{gltf}</script>
<script>{bgu}</script>
<script>
{precios}
{proyecto}
{escal}
{refsjs}
{refsejs}
{engine}
{ui}
{engine2}
{ui2}
{engine3}
{ui3}
{tlod}
{v3}
{p2}
{pertmap}
{informe}
{intljs}
{sub3d}
{guidejs}
</script>
</body>
</html>
"""
os.makedirs('/mnt/user-data/outputs',exist_ok=True)
out='/mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html'
open(out,'w',encoding='utf-8').write(standalone)
print('artifact',len(content),'standalone',len(standalone),'->',out)
