import json,re,hashlib
from grid import *
exec(open('extract_all.py').read().split('DB={}')[0])
S=json.load(open('summary.json')); D=json.load(open('detail.json')); R=json.load(open('report_desc.json'))
def zone_of(code):
    z=code.split('-')[1]
    zones={'Co1':('Costa','rural','<3000'),'Co2':('Costa','urbana','<3000'),'Si1':('Sierra','rural','3000-4000'),'Si2':('Sierra','urbana','3000-4000'),
           'Si3':('Sierra','urbana','4000-4500'),'Si4':('Sierra','rural','4000-4500'),'Se1':('Selva','urbana','<3000'),'Se2':('Selva','rural','<3000')}
    return z,zones[z]
def struct_of(code):
    t=code.split('-')[2]
    return {'T1':'ST','T1.1':'ST-VSL','T1.2':'ST-VSL-CSL','T2':'DT','Pc1':'POSTE'}[t]
def cond_of(name):
    m=re.search(r'(ACAR|AAAC|ACSR)\s*(\d)?x?\s*(\d+)\s*(MCM|mm²|mm2)',name)
    if not m: return None
    return {'mat':m.group(1),'n':int(m.group(2)) if m.group(2) else 1,'size':int(m.group(3)),'unit':'MCM' if m.group(4)=='MCM' else 'mm²'}
apulib={}; 
def apu_id(a):
    key=json.dumps({'name':a['name'],'unit':a['unit'],'cu':a['cu'],'res':[(r['code'],r['qty'],r['price']) for r in a['res']]},sort_keys=True,ensure_ascii=False)
    h=hashlib.md5(key.encode()).hexdigest()[:8]
    if h not in apulib:
        apulib[h]={'c':a['code'],'n':a['name'],'u':a.get('unit2') or a['unit'],'r':a['rend'],'ru':a['unit'],'cu':a['cu'],
                   'res':[[(r['cat'] or '')[:3],r['code'],r['desc'],r['unit'],r['cuad'],r['qty'],r['price'],r['partial']] for r in a['res']]}
    return h
mods=[]
for n in sorted(S,key=int):
    s=S[n]; d=D[n]; r=R.get(n,{})
    code=s['code']; z,(zone,ru,alt)=zone_of(code)
    kv=int(re.match(r'L(\d+)',code).group(1))
    st=struct_of(code)
    cg=code.split('-')[-1]
    sm=d['sum']
    fams=[]
    for f in sm['families']:
        towers=[v for v in f['variants'] if not re.search(r'pata|stub|parrilla|rotula|perno|mensula|cruceta',v['name'],re.I)]
        fams.append({'name':f['name'],'count':f['count'] if f['count'] is not None else sum((v['qty'] or 0) for v in towers),'ton':f['ton'],
                     'var':[[v['name'],v['qty'],v['ton'],v['usd']] for v in f['variants']]})
    # steel tons: from summary 2.1 row weight -> obtain from suministro rows: find '2.1' Estructuras row weight
    steelTon=sum((f['ton'] or 0) for f in fams) if fams else None
    # obras compact
    obras=[[o['code'],o['desc'],o['unit'],o['qty'],o['pu'],o['total']] for o in d.get('obras',[])]
    apus=[apu_id(a) for k in ('apus_oc','apus_me','apus_vsl') for a in d.get(k,[]) if a['res'] or a['cu']]
    summ={k:[v['sum'],v['civ'],v['em'],v['tot']] for k,v in s['summary'].items()}
    structs={'susp':r.get('susp'),'ang':r.get('ang'),'ret':r.get('ret'),'anc':r.get('anc'),'angterm':r.get('angterm'),'vsl':r.get('vsl'),'csl':r.get('csl')}
    total=sum(v for v in [r.get('susp'),r.get('ang'),r.get('ret'),r.get('anc'),r.get('angterm'),r.get('vsl'),r.get('csl')] if v)
    structs['total']=total
    mods.append({'n':int(n),'code':code,'name':s['name'],'kv':kv,'zone':zone,'zoneCode':z,'rural':ru,'alt':alt,'struct':st,'circ':'DT' if st=='DT' else 'ST',
                 'cg':cg,'km':s['km'],'span':r.get('span'),'disp':r.get('disp'),'structs':structs,'cond':cond_of(s['name']) or cond_of(r.get('cond') or ''),
                 'condDesc':r.get('cond'),'guardDesc':r.get('guard'),'insDesc':r.get('ins'),'zoneTxt':r.get('zoneTxt'),
                 'sum':summ,'usdkm':s['summary']['10.0']['tot'],'usdkmSinServ':s['summary']['7.0']['tot'],
                 'steelTon':steelTon,'steelUsdTon':sm.get('steelUsdTon'),'fams':fams,
                 'conductor':sm.get('conductor'),'opgw':sm.get('opgw'),'ehs':sm.get('ehs'),'ins':sm.get('insulators'),'chains':sm.get('chains'),
                 'obras':obras,'apus':apus,'flete':(d.get('flete') or {}).get('usdTon'),'soil':s.get('soil'),'towerMix':s.get('towerMix'),'desc':r.get('body')})
# resources DB per region (from bdpu of modules 40 Costa, 34 Sierra, 36 Selva) using regex on raw text for robustness
def parse_res(text):
    out=[]
    for m in re.finditer(r',((?:MO|MAT|EQ|SC)-[A-Z0-9]+),+([^,]+),([^,]*),\s*([\d.]+)',text):
        out.append([m.group(1),clean(m.group(2)),clean(m.group(3)),num(m.group(4))])
    # dedupe by code
    seen={}; 
    for r in out:
        if r[0] not in seen: seen[r[0]]=r
    return list(seen.values())
resources={}
for reg,n in [('Costa',40),('Sierra',34),('Selva',36)]:
    c=load(n); sh=split_sheets(c); resources[reg]=parse_res(sh['bdpu'])
# cotizaciones
c=load(34); sh=split_sheets(c); t=sh['bdsum']
cot={'conductores':[],'opgw':None,'torre':None,'postes':[],'aisladores':[],'pat':[]}
for m in re.finditer(r'(ACAR|AAAC|ACSR) ([\d,\.]+ ?(?:MCM|mm²)),km,([\d.]*),([\d.]*),([\d.]*),([\d.]*),([\d.]*),([\d.]+)',t):
    cot['conductores'].append({'tipo':m.group(1),'seccion':m.group(2),'dfj':num(m.group(3)),'panghao':num(m.group(4)),'cif':num(m.group(5)),'arancel':num(m.group(6)),'aduana':num(m.group(7)),'final':num(m.group(8))})
m=re.search(r'OPGW - 36 Hilos - Aéreo,km,([\d.]*),([\d.]*),([\d.]*),([\d.]*),([\d.]*),([\d.]+)',t)
cot['opgw']={'desc':'OPGW 36 hilos','dfj':num(m.group(1)),'panghao':num(m.group(2)),'cif':num(m.group(3)),'arancel':num(m.group(4)),'aduana':num(m.group(5)),'final':num(m.group(6))}
m=re.search(r'Torre de Acero,ton,([\d.]+),([\d.]+),([\d.]+),([\d.]+),([\d.]+),([\d.]+)',t)
cot['torre']={'jiangsu':num(m.group(1)),'daji':num(m.group(2)),'cif':num(m.group(3)),'arancel':num(m.group(4)),'aduana':num(m.group(5)),'final':num(m.group(6)),'arancelPct':6.0,'aduanaPct':2.5}
for m in re.finditer(r'"(Poste de Concreto Armado [^"]+)",Und,([\d.]+)',t):
    cot['postes'].append({'desc':m.group(1),'usd':num(m.group(2))})
for m in re.finditer(r',(Aislador[^,]+),Und,([\d.]+)',t):
    cot['aisladores'].append({'desc':clean(m.group(1)),'usd':num(m.group(2))})
for m in re.finditer(r',"?(Cable cooperweld[^,"]+|Jabalina[^,"]+|Conector[^,"]+|Zuncho|Hidrosolta)"?,(km|Und),([\d.]+)',t):
    cot['pat'].append({'desc':clean(m.group(1)),'unit':m.group(2),'usd':num(m.group(3))})
db={'meta':{'fuente':'COES – Base de Datos de Costos de Sistemas de Transmisión (Consultor R. Andrade), módulos LT aéreas, fecha 3/9/2026, TC 3.479 S/./USD, precios sin IGV','tc':3.479,'fecha':'2026-09-03'},
    'modules':mods,'apus':apulib,'resources':resources,'cot':cot}
json.dump(db,open('db.json','w'),ensure_ascii=False,separators=(',',':'))
import os
print('modules',len(mods),'apus',len(apulib),'res',{k:len(v) for k,v in resources.items()},'cot',{k:(len(v) if isinstance(v,list) else 1) for k,v in cot.items()})
print('size',os.path.getsize('db.json'))
for m in mods[:3]+mods[20:22]+mods[-2:]:
    print(m['n'],m['code'],m['kv'],m['zone'],m['alt'],m['struct'],m['cond'],m['span'],m['structs'],m['steelTon'],m['usdkm'],len(m['apus']),len(m['obras']),m['flete'])
