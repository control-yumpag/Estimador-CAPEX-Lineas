from grid import *
import re,os,json
ANCH=[('modulo',r'(?:^|(?<= ))Módulo (?=,)','Módulo'),('suministro',r' Suministro (?=Suministro)','Suministro'),('obras',r' Obras (?=,?Obras [cC]iviles)','Obras'),
      ('apus_oc',r' APUS-OC ','APUS-OC'),('apus_me',r' APUS-ME ','APUS-ME'),('apus_vsl',r' APUS VSL ','APUS VSL'),('bdpu',r' BD P\.U\. ','BD P.U.'),
      ('codif',r' Codificación ','Codificación'),('flete',r' Flete (?=,)','Flete'),('fp',r' FP ','FP'),('bdsum',r' BD-SUM ','BD-SUM')]
def split_sheets(c):
    pos=[]
    for key,pat,name in ANCH:
        m=re.search(pat,c)
        if m:
            s=m.start()
            e=s+len(name)+1+(1 if c[s]==' ' else 0)
            pos.append((s,key,e))
    pos.sort()
    sheets={}
    for i,(s,key,e) in enumerate(pos):
        end=pos[i+1][0] if i+1<len(pos) else len(c)
        sheets[key]=c[e:end]
    return sheets
def grid(text):
    W=detect_W(text); return W,rows_from(text,W)
def clean(s): return re.sub(r'\s+',' ',s).strip()

def parse_suministro(rows):
    out={'families':[],'conductor':None,'opgw':None,'ehs':None,'insulators':[],'chains':[],'items':[]}
    # steel price: first numeric cell in first 3 rows
    for r in rows[:3]:
        for x in r:
            v=num(x)
            if v and v>1: out['steelUsdTon']=v; break
        if 'steelUsdTon' in out: break
    fam=None
    for r in rows:
        if len(r)<3: continue
        code=clean(r[0]); d=clean(r[1]); unit=clean(r[2]) if len(r)>2 else ''
        qty=num(r[3]) if len(r)>3 else None; wt=num(r[4]) if len(r)>4 else None
        uc=num(r[5]) if len(r)>5 else None; tot=num(r[6]) if len(r)>6 else None
        if re.match(r'2\.1\.\d+$',code) and re.match(r'Estructuras?\b',d,re.I) and 'Señal' not in d:
            fam={'code':code,'name':d,'count':qty,'ton':wt,'variants':[]}
            out['families'].append(fam); continue
        if fam is not None and code=='' and d and (qty is not None or uc is not None):
            fam['variants'].append({'name':d,'qty':qty,'ton':wt,'usd':uc,'total':tot}); continue
        if code and not re.match(r'2\.1\.\d+$',code): 
            if fam is not None and not d.startswith('Poste') : fam=None
        if unit=='km' and re.search(r'conductor',d,re.I) and out['conductor'] is None and not re.search(r'guarda|OPGW|copperweld|cooperweld|acero',d,re.I):
            out['conductor']={'desc':d,'km':qty,'kgkm':wt,'usdkm':uc,'total':tot}
        elif unit=='km' and re.search(r'OPGW',d) and out['opgw'] is None:
            out['opgw']={'desc':d,'km':qty,'kgkm':wt,'usdkm':uc,'total':tot}
        elif unit=='km' and re.search(r'EHS|Alumoweld|ACSR|Guarda',d,re.I) and out['ehs'] is None and not re.search(r'OPGW',d):
            out['ehs']={'desc':d,'km':qty,'kgkm':wt,'usdkm':uc,'total':tot}
        elif re.search(r'^Aislador',d,re.I) and unit and qty:
            out['insulators'].append({'desc':d,'qty':qty,'usd':uc,'total':tot})
        elif re.search(r'^Cadena de|^Ensamble de',d,re.I) and unit and (qty or 0)>0:
            out['chains'].append({'desc':d,'qty':qty,'usd':uc,'total':tot})
        # poles
        if d.startswith('Poste de Concreto') and unit=='Und' and fam is not None:
            pass
    return out

def parse_obras(rows):
    hdr=None
    for i,r in enumerate(rows[:6]):
        cells=[clean(x) for x in r]
        if any(x.startswith('Und') for x in cells) and any(x.startswith('Metrado') for x in cells):
            hdr=r; break
    if hdr is None: return []
    cells=[clean(x) for x in hdr]
    iu=[i for i,x in enumerate(cells) if x.startswith('Und')][0]
    im=[i for i,x in enumerate(cells) if x.startswith('Metrado')][0]
    ip=[i for i,x in enumerate(cells) if x.startswith('Precio')][0]
    it=[i for i,x in enumerate(cells) if x.startswith('Total')][0]
    out=[]
    for r in rows:
        if len(r)<3: continue
        code=clean(r[0]); d=clean(r[1])
        if not re.match(r'\d+(\.\d+)*$',code): continue
        out.append({'code':code,'desc':d,'unit':clean(r[iu]),'qty':num(r[im]),'pu':num(r[ip]),'total':num(r[it])})
    return out

def lastnum(s):
    m=re.findall(r'-?\d[\d,]*(?:\.\d+)?',s or '')
    if not m: return None
    return num(m[-1])
def parse_apus(rows,W):
    apus=[]
    # find all 'Partida:' cells
    blocks=[]
    for ri,r in enumerate(rows):
        for ci,x in enumerate(r):
            if clean(x)=='Partida:':
                blocks.append((ri,ci))
    # group blocks by column
    for (ri,p) in blocks:
        r=rows[ri]
        code=clean(r[p+1]) if p+1<W else ''
        name=clean(r[p+2]) if p+2<W else ''
        apu={'code':code,'name':name,'unit':'','rend':None,'cu':None,'res':[]}
        # scan following rows until next Partida in same column block
        cat=None
        for rj in range(ri+1,min(ri+80,len(rows))):
            rr=rows[rj]
            if p<len(rr) and clean(rr[p])=='Partida:': break
            g=lambda k: clean(rr[p+k]) if p+k<len(rr) and p+k>=0 else ''
            if g(0)=='Rendimiento':
                apu['rend']=lastnum(g(2)); apu['unit']=g(4)
                cells=[clean(x) for x in rr[p:p+16]]
                for ci,x in enumerate(cells):
                    if 'Costo unitario' in x or 'Costo Unitario' in x:
                        m=re.search(r'\(([^)]+)\)',x)
                        if m: apu['unit2']=m.group(1)
                        for y in cells[ci+1:ci+6]:
                            v=lastnum(y)
                            if v is not None: apu['cu']=v; break
                        break
                continue
            if g(0) in ('Mano de obra','Materiales','Equipos','Movilidades','Subcontratas'):
                cat=g(0); apu.setdefault('sub',{})[cat]=lastnum(g(8)); continue
            rc=g(-1)
            if re.match(r'(MO|MAT|EQ|SC|SUB|MA|HE)-',rc):
                apu['res'].append({'cat':cat,'code':rc,'desc':g(0),'unit':g(4),'cuad':num(g(5)),'qty':num(g(6)),'price':lastnum(g(7)),'partial':lastnum(g(8))})
            elif re.match(r'(Consumibles|Herramientas|Gastos varios)',g(0)):
                apu['res'].append({'cat':cat,'code':'','desc':g(0),'unit':'%','cuad':None,'qty':None,'price':None,'partial':lastnum(g(8))})
        if apu['name'] or apu['code']: apus.append(apu)
    return apus

def parse_bdpu(rows):
    out=[]
    for r in rows:
        cells=[clean(x) for x in r]
        for i,x in enumerate(cells):
            if re.match(r'^(MO|MAT|EQ|SC)-[A-Z0-9]+$',x):
                # next non-empty cells: desc, unit, price...
                rest=[y for y in cells[i+1:i+8]]
                desc=rest[0] if rest else ''
                unit=''; price=None
                for y in rest[1:]:
                    if unit=='' and y and num(y) is None: unit=y; continue
                    if y and num(y) is not None: price=num(y); break
                out.append({'code':x,'desc':desc,'unit':unit,'price':price})
                break
    return out

def parse_flete(text):
    m=re.search(r'FLETE AGOSTO 2025.*?US\$ x Ton,US\$ x Kg (.*?) ',text)
    # find the row that begins with a number after header
    m=re.search(r'US\$ x Ton,US\$ x Kg ,?([^ ]+)',text)
    vals=[num(x) for x in m.group(1).split(',')] if m else []
    usdton=None
    if vals:
        v=[x for x in vals if x]
        if len(v)>=2: usdton=v[-2]
    dist=re.search(r'Distancia Total Virtual \( km \),+([\d.]+)',text)
    return {'usdTon':usdton,'virtualKm':num(dist.group(1)) if dist else None,'row':vals}

DB={}
for n in sorted(int(x[4:6]) for x in os.listdir('.') if x.startswith('mod_')):
    c=load(n)
    sh=split_sheets(c)
    d={'n':n,'sheets':list(sh.keys())}
    if 'suministro' in sh:
        W,rows=grid(sh['suministro']); d['sum']=parse_suministro(rows); d['sumW']=W
    if 'obras' in sh:
        W,rows=grid(sh['obras']); d['obras']=parse_obras(rows); d['obrasW']=W
    for k in ('apus_oc','apus_me','apus_vsl'):
        if k in sh:
            W,rows=grid(sh[k]); d[k]=parse_apus(rows,W)
    if 'bdpu' in sh:
        W,rows=grid(sh['bdpu']); d['bdpu']=parse_bdpu(rows)
    if 'flete' in sh: d['flete']=parse_flete(sh['flete'])
    DB[n]=d
    s=d.get('sum',{})
    print(n,d['sheets'],'| fam',[(f['name'][-4:],f['count'],f['ton']) for f in s.get('families',[])][:8],'| cond',(s.get('conductor') or {}).get('desc','')[:30],(s.get('conductor') or {}).get('usdkm'),'| opgw',(s.get('opgw') or {}).get('usdkm'),'| steel',s.get('steelUsdTon'),'| obras',len(d.get('obras',[])),'| apus',len(d.get('apus_oc',[])),len(d.get('apus_me',[])),len(d.get('apus_vsl',[])),'| bdpu',len(d.get('bdpu',[])),'| flete',d.get('flete',{}).get('usdTon'))
json.dump(DB,open('detail.json','w'),ensure_ascii=False)
print(os.path.getsize('detail.json'))
