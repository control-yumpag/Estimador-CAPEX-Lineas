#!/usr/bin/env python3
"""
glb2three.py — convierte un modelo .glb / .gltf / .obj de torre de transmisión en geometría
compacta (JSON) lista para incrustar en el visor Three.js del Estimador CAPEX LT.

Uso:
  python glb2three.py torre.glb -o torre.json --name "Torre 220 kV (Poly Pizza, iPoly3D)" \
         --license CC0 --source "https://poly.pizza/m/TYK3rPu7E5" [--max-faces 40000] [--edge-angle 20]

Salida (JSON):
  { "name", "license", "source", "height": 1.0,      # modelo normalizado: base en y=0, altura 1, centrado en x/z
    "v": [x,y,z, ...],                                 # vértices (float, 4 decimales)
    "e": [i,j, ...],                                   # aristas "de rasgo" (para dibujar la celosía como líneas)
    "f": [a,b,c, ...] }                                # caras (opcional, para sombreado semitransparente)

Luego, en build.py, los JSON de la carpeta refmodels/ se concatenan en la etiqueta
<script id="refmodels" type="application/json"> y el visor los ofrece como "Modelo de referencia".
"""
import argparse, json, sys, os
import numpy as np

def load_mesh(path):
    import trimesh
    sc = trimesh.load(path, force='scene')
    if isinstance(sc, trimesh.Scene):
        geoms = []
        for name, geom in sc.geometry.items():
            # aplicar transformaciones de los nodos que usan esta geometría
            nodes = [n for n in sc.graph.nodes_geometry if sc.graph[n][1] == name]
            if not nodes:
                geoms.append(geom.copy()); continue
            for n in nodes:
                T, _ = sc.graph[n]
                g = geom.copy(); g.apply_transform(T); geoms.append(g)
        mesh = trimesh.util.concatenate([g for g in geoms if isinstance(g, trimesh.Trimesh)])
    else:
        mesh = sc
    return mesh

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('input'); ap.add_argument('-o', '--out', default=None)
    ap.add_argument('--name', default=None); ap.add_argument('--license', default=''); ap.add_argument('--source', default='')
    ap.add_argument('--max-faces', type=int, default=40000, help='si el modelo tiene más caras, se decima (requiere fast-simplification) o se omiten las caras')
    ap.add_argument('--edge-angle', type=float, default=20.0, help='ángulo diedro mínimo (grados) para conservar una arista como rasgo')
    ap.add_argument('--up', default='y', choices=['y', 'z'], help='eje vertical del modelo original')
    ap.add_argument('--no-faces', action='store_true')
    a = ap.parse_args()
    mesh = load_mesh(a.input)
    if a.up == 'z':
        mesh.apply_transform(np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, -1, 0, 0], [0, 0, 0, 1]], dtype=float))
    mesh.merge_vertices()
    mesh.remove_unreferenced_vertices()
    # normalizar: base en y=0, centrado en x/z, altura 1
    b = mesh.bounds; h = float(b[1][1] - b[0][1]) or 1.0
    mesh.apply_translation([-(b[0][0] + b[1][0]) / 2, -b[0][1], -(b[0][2] + b[1][2]) / 2])
    mesh.apply_scale(1.0 / h)
    nf0 = len(mesh.faces)
    if len(mesh.faces) > a.max_faces:
        try:
            mesh = mesh.simplify_quadric_decimation(face_count=a.max_faces)
            mesh.merge_vertices()
        except Exception as ex:
            print('decimación no disponible (%s); se conservan solo las aristas' % ex, file=sys.stderr)
    # aristas de rasgo: ángulo diedro alto o borde libre
    ang = np.degrees(mesh.face_adjacency_angles) if len(mesh.face_adjacency) else np.array([])
    feat = mesh.face_adjacency_edges[ang >= a.edge_angle] if len(ang) else np.zeros((0, 2), int)
    boundary = mesh.edges_unique[mesh.edges_unique_length > 0] if False else None
    edges = set(map(tuple, np.sort(feat, axis=1)))
    # bordes libres (aristas que pertenecen a una sola cara)
    eu, counts = np.unique(np.sort(mesh.edges, axis=1), axis=0, return_counts=True)
    for e in eu[counts == 1]:
        edges.add(tuple(e))
    edges = np.array(sorted(edges), dtype=int) if edges else np.zeros((0, 2), int)
    v = np.round(mesh.vertices, 4)
    out = dict(name=a.name or os.path.splitext(os.path.basename(a.input))[0], license=a.license, source=a.source, height=1.0,
               stats=dict(faces_in=nf0, faces=int(len(mesh.faces)), vertices=int(len(v)), edges=int(len(edges)), height_units=round(h, 3)),
               v=v.flatten().tolist(), e=edges.flatten().tolist())
    if not a.no_faces and len(mesh.faces) <= a.max_faces:
        out['f'] = mesh.faces.flatten().tolist()
    s = json.dumps(out, separators=(',', ':'))
    outp = a.out or os.path.splitext(a.input)[0] + '.json'
    open(outp, 'w').write(s)
    print('OK', outp, out['stats'], '%.0f KB' % (len(s) / 1024))

if __name__ == '__main__':
    main()
