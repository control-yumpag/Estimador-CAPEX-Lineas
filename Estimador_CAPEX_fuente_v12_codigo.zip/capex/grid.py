import json,re
def load(n):
    c=json.load(open(f'mod_{n:02d}.json'))['fileContent']
    i=c.find(' Módulo ,') if not c.startswith('Módulo') else 0
    return c[i:].lstrip()

def scan_cells(s):
    """Quote-aware scanner. Returns list of (text, quoted, boundary_after) where boundary_after=True
    if a quoted cell was followed by a space (explicit row boundary)."""
    out=[]; i=0; n=len(s)
    while i<=n:
        if i<n and s[i]=='"':
            j=i+1; buf=[]
            while j<n:
                if s[j]=='"':
                    if j+1<n and s[j+1]=='"': buf.append('"'); j+=2; continue
                    break
                buf.append(s[j]); j+=1
            j+=1  # past closing quote
            txt=''.join(buf)
            if j<n and s[j]==',': out.append((txt,True,False)); i=j+1
            elif j<n and s[j]==' ': out.append((txt,True,True)); i=j+1
            else: out.append((txt,True,False)); i=j+1
        else:
            j=s.find(',',i)
            if j<0: out.append((s[i:],False,False)); break
            out.append((s[i:j],False,False)); i=j+1
    return out

def rows_from(text, W):
    cells=scan_cells(text)
    rows=[]; cur=[]
    k=0
    while k<len(cells):
        txt,q,bnd=cells[k]
        if len(cur)==W-1:
            # this is the last cell of the row; may be merged with first cell of next row
            if q:
                cur.append(txt); rows.append(cur); cur=[]
                k+=1
                continue
            if ' ' in txt:
                last,first=txt.rsplit(' ',1)
            else:
                # ambiguous: if it looks like a code it's the first cell of next row with empty last
                last,first=('',txt) if re.fullmatch(r'|[a-zA-Z]{1,2}|\d+(\.\d+)*',txt.strip()) and txt==txt.lstrip() else (txt,'')
                if txt.startswith(' '): last,first='',txt.strip()
            cur.append(last); rows.append(cur); cur=[first]
            k+=1
            continue
        if len(cur)==0 and txt.startswith(' ') and not q:
            txt=txt[1:]
        cur.append(txt); k+=1
    if cur: rows.append(cur)
    return rows

def detect_W(text, maxW=120):
    runs=re.findall(r',+',text)
    mr=max(len(r) for r in runs) if runs else 0
    base=mr+1
    # refine: choose W in [base, base+10] that makes a frequent token column-stable
    cells=scan_cells(text)
    from collections import Counter
    cnt=Counter(t.strip() for t,q,b in cells if t.strip() and not re.match(r'^[\d.,\- %$]+$',t.strip()))
    if not cnt: return base
    tokens=[t for t,c in cnt.most_common(6) if c>=4]
    if not tokens: return base
    best=(None,None)
    for W in range(base,base+12):
        rows=rows_from(text,W)
        score=0
        for tok in tokens:
            cols=Counter()
            for r in rows:
                for ci,x in enumerate(r):
                    if x.strip()==tok: cols[ci]+=1
            if cols:
                score+=cols.most_common(1)[0][1]/sum(cols.values())
        score/=len(tokens)
        if best[0] is None or score>best[1]+1e-9: best=(W,score)
        if score>0.98: return W
    return best[0]

def codelike_frac(rows):
    ok=sum(1 for r in rows if re.fullmatch(r'|\d+(\.\d+)*|[a-zA-Z]{1,3}|[A-Z]{2,4}-[A-Z0-9]+',r[0].strip()))
    return ok/max(1,len(rows))

def get_sheet(c, name, nxt=None):
    i=c.find(name)
    if i<0: return None
    j=c.find(nxt,i+len(name)) if nxt else len(c)
    if j<0: j=len(c)
    return c[i+len(name.split(' ')[0])+1:j]

def num(s):
    if s is None: return None
    s=str(s).strip().replace('$','').replace('S/.','').replace('"','')
    if s in ('','-'): return None
    s=s.replace(' ','').replace(',','')
    try: return float(s)
    except: return None
