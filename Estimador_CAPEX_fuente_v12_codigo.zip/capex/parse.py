import json,re,os,csv,io
def load(n):
    c=json.load(open(f'mod_{n:02d}.json'))['fileContent']
    i=c.find(' Módulo ,') if not c.startswith('Módulo') else 0
    return c[i:]
def num(s):
    s=s.strip().replace('"','').replace(' ','')
    if s in ('','-'): return None
    # numbers like 1,347,420.32 or 1347420
    s=s.replace(',','')
    try: return float(s)
    except: return None
def cells(row):
    return next(csv.reader(io.StringIO(row)))
def summary(c):
    j=c.find('Total General')
    k=c.find('10.0,')
    seg=c[j:k+200]
    rows=re.split(r' (?=\d+\.\d,)',seg)
    out={}
    for r in rows[1:]:
        cs=cells(r)
        code=cs[0]; desc=cs[1]
        vals=[num(x) for x in cs[2:6]]
        out[code]={'desc':desc,'sum':vals[0],'civ':vals[1],'em':vals[2],'tot':vals[3]}
    return out
res={}
for n in sorted(int(x[4:6]) for x in os.listdir('.') if x.startswith('mod_')):
    c=load(n)
    head=c[:1200]
    name=re.search(r'(\d+)\.-\s*(Módulo de Línea de Transmisión[^,]*)',head).group(2).strip()
    code=re.search(r'C[oó]digo:\s*,([^,]+)',head).group(1).strip()
    L=float(re.search(r'[Ll]ongitud \(km\),([\d.]+)',head).group(1))
    s=summary(c)
    # tower mix
    mix={}
    m=re.search(r'Tipo de torres,Torres,% Participación,+ ,,(.*?)100\.00%',c[:6000])
    if m:
        for t in re.findall(r'(VSL|CSL|Autosoportadas),(\d+),',m.group(0)):
            mix[t[0]]=int(t[1])
    soil={}
    m=re.search(r'Tipo de suelo,Volumen.*?100\.00%',c[:7000])
    if m:
        for t in re.findall(r'(Arena|Normal|R\.fracturada/R\.sana),(\d+) m3,([\d.]+)%',m.group(0)):
            soil[t[0]]={'m3':int(t[1]),'pct':float(t[2])}
    res[n]={'n':n,'name':name,'code':code,'km':L,'summary':s,'towerMix':mix,'soil':soil}
json.dump(res,open('summary.json','w'),ensure_ascii=False,indent=1)
for n,r in res.items():
    s=r['summary']
    print(n,r['code'],r['km'],'tot/km',s.get('10.0',{}).get('tot'),'sinserv/km',s.get('7.0',{}).get('tot'),'| est',s['2.1']['tot'],'cond',s['2.2']['tot'], r['towerMix'])
