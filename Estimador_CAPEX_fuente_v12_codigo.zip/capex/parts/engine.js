/* ===================== ENGINE ===================== */
const DB = JSON.parse(document.getElementById('db').textContent);
const MODS = DB.modules;
const byN = Object.fromEntries(MODS.map(m => [m.n, m]));

const CLASSES = {
  5: {name:'Clase 5', uso:'Screening / conceptual', def:'0–2 %', lo:[-20,-50], hi:[30,100], cont:45, metodo:'Capacidad / analogía paramétrica'},
  4: {name:'Clase 4', uso:'Estudio de prefactibilidad', def:'1–15 %', lo:[-15,-30], hi:[20,50], cont:30, metodo:'Paramétrico por equipos / módulos'},
  3: {name:'Clase 3', uso:'Factibilidad / autorización de presupuesto', def:'10–40 %', lo:[-10,-20], hi:[10,30], cont:20, metodo:'Semidetallado, precios unitarios por partida'},
  2: {name:'Clase 2', uso:'Control / licitación', def:'30–75 %', lo:[-5,-15], hi:[5,20], cont:12, metodo:'Detallado con metrados de ingeniería'},
  1: {name:'Clase 1', uso:'Verificación / cambio de alcance', def:'65–100 %', lo:[-3,-10], hi:[3,15], cont:7, metodo:'Detallado, cotizaciones firmes'}
};
const STRUCT_LABELS = {'ST':'Torres autosoportadas', 'ST-VSL':'Autosoportadas + VSL (atirantadas)', 'ST-VSL-CSL':'Autosoportadas + VSL + CSL', 'DT':'Torres autosoportadas doble terna', 'POSTE':'Postes de concreto'};
const ITEMS = [
  ['1.1','Obras preliminares y provisionales','civ'],
  ['1.2','Caminos de acceso','civ'],
  ['1.3','Obras civiles (excavación, fundaciones, relleno)','civ'],
  ['2.1','Estructuras (suministro + montaje)','em'],
  ['2.2','Conductores de fase','em'],
  ['2.3','Cables de guarda (OPGW / EHS)','em'],
  ['2.4','Cadenas de aisladores y herrajes','em'],
  ['2.5','Sistema de puesta a tierra','em'],
  ['2.6','Transporte de materiales a obra','sum'],
  ['3.0','Inspección de línea construida','em'],
  ['4.0','Pruebas y puesta en servicio','em'],
  ['5.0','Expediente técnico, ingeniería, EIA, EO, concesión, CIRA','own']
];

function condLabel(c){ if(!c) return '—'; return `${c.mat} ${c.n>1? c.n+'×':''}${c.size} ${c.unit}`; }
function condKey(c){ return c ? `${c.mat}|${c.size}|${c.unit}` : ''; }
function condMm2(c){ return c.unit==='MCM' ? c.size*0.5067 : c.size; }
function condKgKm(c){
  // prefer module data
  for(const m of MODS){ if(m.cond && m.cond.mat===c.mat && m.cond.size===c.size && m.cond.unit===c.unit && m.conductor && m.conductor.kgkm) return m.conductor.kgkm; }
  return Math.round(condMm2(c)*2.76);
}
function condUsdKm(c){
  const sec = c.unit==='MCM' ? `${c.size} MCM` : `${c.size} mm²`;
  const q = DB.cot.conductores.find(x => x.tipo===c.mat && x.seccion.replace(/\s+/g,' ').trim()===sec);
  if(q) return {usd:q.final, src:'cotización COES ('+(q.dfj&&q.panghao?'DFJ/Panghao':q.dfj?'DFJ':'Panghao')+')'};
  for(const m of MODS){ if(m.cond && m.cond.mat===c.mat && m.cond.size===c.size && m.cond.unit===c.unit && m.conductor) return {usd:m.conductor.usdkm, src:'módulo COES '+m.n}; }
  // interpolate by mm2 within same material
  const same = DB.cot.conductores.filter(x=>x.tipo===c.mat).map(x=>({mm2: /MCM/.test(x.seccion)? parseFloat(x.seccion)*0.5067: parseFloat(x.seccion), usd:x.final})).sort((a,b)=>a.mm2-b.mm2);
  const mm=condMm2(c);
  if(same.length){ let lo=same[0],hi=same[same.length-1]; for(const s of same){ if(s.mm2<=mm) lo=s; } for(let i=same.length-1;i>=0;i--){ if(same[i].mm2>=mm) hi=same[i]; }
    const usd = lo===hi? lo.usd : lo.usd + (hi.usd-lo.usd)*(mm-lo.mm2)/(hi.mm2-lo.mm2); return {usd, src:'interpolado de cotizaciones'}; }
  return {usd: mm*9.5, src:'estimado por sección'};
}
function cgList(cg){ return {CG1:['OPGW'],CG2:['EHS'],CG3:['OPGW','EHS'],CG4:['OPGW','ALUMOWELD']}[cg]||['OPGW']; }
function guardUsdKm(kind, M){
  if(kind==='OPGW') return (M.opgw && M.opgw.usdkm) || DB.cot.opgw.final;
  if(kind==='EHS') return (M.ehs && /EHS/i.test(M.ehs.desc||'') && M.ehs.usdkm) || 1535.47;
  return (M.ehs && /alumoweld|acsr/i.test(M.ehs.desc||'') && M.ehs.usdkm) || 1842.56;
}

/* ---- module selection ---- */
function structOptions(kv){
  const s = new Set(MODS.filter(m=>m.kv===kv).map(m=>m.struct));
  const order=['ST','ST-VSL','ST-VSL-CSL','DT','POSTE'];
  return order.filter(x=>s.has(x));
}
function scoreModule(m, inp){
  if(m.kv!==inp.kv) return -1;
  let s=0;
  if(m.struct===inp.struct) s+=400; else if((m.struct==='DT')===(inp.struct==='DT') && (m.struct==='POSTE')===(inp.struct==='POSTE')) s+=150;
  if(m.zone===inp.zone) s+=120;
  if(m.alt===inp.alt) s+=60; else if(inp.zone==='Sierra' && m.zone==='Sierra') s+=20;
  if(m.rural===inp.rural) s+=25;
  if(m.cond){ if(m.cond.mat===inp.cond.mat) s+=15; if(m.cond.n===inp.cond.n) s+=25; s+= Math.max(0, 20 - Math.abs(condMm2(m.cond)-condMm2(inp.cond))/10); }
  if(m.cg===inp.cg) s+=10;
  return s;
}
function pickModule(inp){
  let best=null, bs=-2;
  for(const m of MODS){ const sc=scoreModule(m,inp); if(sc>bs){bs=sc;best=m;} }
  return best;
}
function moduleMix(M){
  const st=M.structs; const susp=(st.susp||0)+(st.vsl||0)+(st.csl||0);
  const ang=(st.ang||0); const anc=(st.ret||0)+(st.anc||0)+(st.angterm||0);
  const t=susp+ang+anc||1;
  return {susp:susp/t*100, ang:ang/t*100, anc:anc/t*100, total:t};
}
function moduleSoil(M){
  // from soil table if present else from obras excavation rows
  let nor=0,are=0,roc=0;
  const rows=(M.obras||[]).filter(r=>/^Excavaci/i.test(r[1]));
  for(const r of rows){ const q=r[3]||0; if(/arena/i.test(r[1])) are+=q; else if(/roca/i.test(r[1])) roc+=q; else nor+=q; }
  const t=nor+are+roc;
  if(t>0) return {nor:nor/t*100, are:are/t*100, roc:roc/t*100};
  return {nor:60,are:10,roc:30};
}
function excavPU(M){
  const pu={nor:null,are:null,roc:null,share:0};
  const rows=(M.obras||[]).filter(r=>/^Excavaci/i.test(r[1]) && r[4]);
  let exc=0;
  for(const r of rows){ if(/arena/i.test(r[1])) pu.are=pu.are||r[4]; else if(/roca fract/i.test(r[1])) pu.roc=pu.roc||r[4]; else if(/roca/i.test(r[1])) {pu.roc=pu.roc||r[4];} else pu.nor=pu.nor||r[4]; exc+=r[5]||0; }
  pu.nor=pu.nor||40.24; pu.are=pu.are||53.95; pu.roc=pu.roc||97.37;
  const civ=(M.sum['1.3']&&M.sum['1.3'][3])||1;
  pu.share=Math.min(0.6, exc/civ);
  return pu;
}

/* ---- main estimate ---- */
function estimate(inp, M){
  const L=inp.km, L0=M.km;
  const S=inp.span, S0=M.span||400;
  const fL=L/L0;
  const fix=inp.fix/100;
  const fFixed = v => v*(fix + (1-fix)*fL);
  // structures
  const nBase = M.structs.total||Math.round(L0*1000/S0);
  const fCount = S0/S;                       // estructuras por km relativo
  const baseMix = moduleMix(M);
  const W={susp:1.0, ang:1.9, anc:3.4};      // índice de peso relativo por tipo (derivado de familias COES)
  const mixUser = normMix(inp.pSusp,inp.pAng,inp.pAnc);
  const wUser = (mixUser.susp*W.susp+mixUser.ang*W.ang+mixUser.anc*W.anc)/100;
  const wBase = (baseMix.susp*W.susp+baseMix.ang*W.ang+baseMix.anc*W.anc)/100;
  const fMix = wUser/wBase;
  const kgBase = (M.conductor&&M.conductor.kgkm)||condKgKm(M.cond||inp.cond);
  const nB = (M.cond&&M.cond.n)||1;
  const kgUser = condKgKm(inp.cond);
  const fCondW = Math.pow((kgUser*inp.cond.n)/(kgBase*nB), inp.expC);
  const fExt = 1 + 0.033*inp.ext;
  const fW = Math.pow(S/S0, inp.expW)*fCondW*fExt*fMix;   // peso por torre relativo
  const fStruct = fCount*fW;                               // costo de estructuras por km relativo
  // soil
  const pu=excavPU(M); const sb=moduleSoil(M); const su=normMix(inp.sNor,inp.sAre,inp.sRoc,'nor','are','roc');
  const puB=(sb.nor*pu.nor+sb.are*pu.are+sb.roc*pu.roc)/100, puU=(su.nor*pu.nor+su.are*pu.are+su.roc*pu.roc)/100;
  const fSoil = 1 + pu.share*(puU/puB-1);
  // conductor price
  const cpU = condUsdKm(inp.cond); const cpB = (M.conductor&&M.conductor.usdkm)||condUsdKm(M.cond||inp.cond).usd;
  const fCondP = (cpU.usd*inp.cond.n)/(cpB*nB);
  const fCondN = inp.cond.n/nB;
  // guard cables
  const gB = cgList(M.cg).reduce((a,k)=>a+guardUsdKm(k,M),0);
  const gU = cgList(inp.cg).reduce((a,k)=>a+guardUsdKm(k,M),0);
  const fCG = gU/gB;
  const fSteel = (M.steelUsdTon? inp.steel/M.steelUsdTon : 1);
  const acc = inp.access;

  const g = k => { const r=M.sum[k]||[null,null,null,null]; return {sum:r[0]||0, civ:r[1]||0, em:r[2]||0, tot:r[3]||0}; };
  const items={};
  const put=(k,sum,civ,em)=>{ items[k]={sum,civ,em,tot:sum+civ+em}; };
  let b;
  b=g('1.1'); put('1.1',0,fFixed(b.civ),0);
  b=g('1.2'); put('1.2',0,b.civ*fL*acc,0);
  b=g('1.3'); put('1.3',0,b.civ*fL*fStruct*fSoil,0);
  b=g('2.1'); put('2.1',b.sum*fL*fStruct*fSteel,0,b.em*fL*fStruct);
  b=g('2.2'); put('2.2',b.sum*fL*fCondP,0,b.em*fL*fCondN);
  b=g('2.3'); put('2.3',b.sum*fL*fCG,0,b.em*fL*fCG);
  b=g('2.4'); put('2.4',b.sum*fL*fCount*Math.sqrt(fMix)*Math.sqrt(fCondN),0,b.em*fL*fCount*Math.sqrt(fMix));
  b=g('2.5'); put('2.5',b.sum*fL*fCount,0,b.em*fL*fCount);
  b=g('2.6'); put('2.6',b.sum*fL*(0.7*fStruct+0.3*fCondW),0,0);
  b=g('3.0'); put('3.0',0,0,fFixed(b.tot));
  b=g('4.0'); put('4.0',0,0,fFixed(b.tot));
  // escalamiento de precios al año objetivo y factores de marca (USD sin IGV)
  const PF = window.PRICE ? PRICE.applyItems(items, M.struct==='POSTE', cgList(inp.cg)) : {escF:1,f:{}};
  const fSvc = window.PRICE ? PRICE.factor('svc','coes') : 1, fLand = window.PRICE ? PRICE.factor('land','coes') : 1;
  b=g('5.0'); const est=fFixed(b.tot)*(1+inp.eng/100)*fSvc;
  b=g('8.0'); const servMod=b.tot*fL*fLand; const serv = 0; // servidumbre excluida del estimado (supuesto: gestión predial es específica del sitio y se trata aparte); servMod queda como referencia informativa

  const sumSup=['2.1','2.2','2.3','2.4','2.5','2.6'].reduce((a,k)=>a+items[k].sum,0);
  const sumCiv=['1.1','1.2','1.3'].reduce((a,k)=>a+items[k].civ,0);
  const sumEm=['2.1','2.2','2.3','2.4','2.5'].reduce((a,k)=>a+items[k].em,0);
  const sumPP=items['3.0'].em+items['4.0'].em;
  const F = sumSup+sumCiv+sumEm+sumPP;                 // directo contratista
  const G = (sumCiv+sumEm+sumPP)*inp.gg/100;           // distribuibles GG+U sobre obras
  const allowQ = (F+G)*inp.allowQ/100, allowP=(F+G)*inp.allowP/100;
  const directo = F+G+allowQ+allowP;                    // 1. costo directo (contratista + GG&U + allowances)
  const ind = directo*inp.ind/100;                      // gerencia de construcción, supervisión, facilidades temporales, servicios de terceros
  const owner = directo*inp.owner/100;                  // costo del dueño (gestión, permisos, seguros)
  const indirecto = ind+owner+est;                      // 2. costo indirecto = gerencia/supervisión + dueño + ingeniería/estudios (COES 5.0)
  const A = directo+indirecto;                          // A. estimado neto = 1 + 2
  // pesos de A por grupo de costo → escalamiento de la fecha base de precios al periodo de ejecución (ESC)
  const hasOPGW = cgList(inp.cg).some(t=>/OPGW/.test(t));
  const gmap={'2.1':M.struct==='POSTE'?'conc':'steelT','2.2':'alu','2.3':hasOPGW?'opgw':'steelW','2.4':'ins','2.5':'cu','2.6':'eq'};
  const EW={}; const addW=(g,v)=>{ if(v>0) EW[g]=(EW[g]||0)+v; };
  for(const k of Object.keys(items)){ const it=items[k]; addW(gmap[k]||'civ',it.sum); addW('civ',it.civ); addW(/^[34]\./.test(k)?'svc':'lab',it.em); }
  const obras=sumCiv+sumEm+sumPP; if(obras>0){ addW('civ',G*sumCiv/obras); addW('lab',G*(sumEm+sumPP)/obras); }
  { const kA=(F+G)>0? directo/(F+G) : 1; Object.keys(EW).forEach(g=>EW[g]*=kA); }
  addW('svc',ind+owner+est);
  { const sW=Object.values(EW).reduce((a,b)=>a+b,0)||1; Object.keys(EW).forEach(g=>EW[g]*=A/sW); }
  const escDet = (window.ESC && window.PROJ) ? ESC.forEstimate(EW) : null;
  const esc = escDet ? escDet.esc : A*inp.esc/100, risk=A*inp.risk/100;   // 3. escalamiento · 4. provisión por eventos de riesgo
  const B = A+esc+risk;                                 // B. estimado base
  const cont = B*inp.cont/100;                          // 5. contingencia
  const C = B+cont;                                     // C. costo de ejecución
  const D = C*inp.phase/100;                            // D. costo de la fase (estudios de la siguiente etapa)
  const E = C+D;                                        // E. monto total de inversión
  const igv = E*inp.igv/100;
  const nStruct = Math.round(L*1000/S)+1;
  const tonBase = M.steelTon||0; const tonKmBase = tonBase/L0;
  const tons = tonKmBase*L*fStruct;
  const coesEq = F + est;   // equivalente al "Total costo sin IGV" COES, sin servidumbre
  return {
    M, inp, items, est, serv, servMod, sumSup,sumCiv,sumEm,sumPP, F,G,allowQ,allowP, directo, ind, indirecto, owner, A, esc, escDet, escW:EW, risk, B, cont, C, D, E, igv, ET:E+igv,
    nStruct, tons, tonKm: tons/L, coesEq, coesEqKm: coesEq/L, usdKm: E/L, dirKm: directo/L,
    escF:PF.escF, priceF:PF.f, priceYear: window.PRICE? PRICE.year : 2026,
    factors:{fL,fCount,fMix,fCondW,fExt,fW,fStruct,fSoil,fCondP,fCondN,fCG,fSteel,acc,cpU,cpB,gU,gB,kgUser,kgBase,puB,puU,share:pu.share,baseMix,mixUser,sb,su}
  };
}
function normMix(a,b,c,ka='susp',kb='ang',kc='anc'){ const t=(a||0)+(b||0)+(c||0)||1; const o={}; o[ka]=(a||0)/t*100; o[kb]=(b||0)/t*100; o[kc]=(c||0)/t*100; return o; }

/* ---- risk packages ---- */
function riskPackages(R){
  const it=R.items;
  const mult = 1 + R.inp.gg/100; // aproximación: los paquetes de obra incluyen GG+U
  const scaleD = R.directo/(R.F+R.G); // reparte allowances proporcionalmente
  const pk=[
    {k:'estr', name:'Estructuras metálicas (suministro)', base: it['2.1'].sum*scaleD},
    {k:'cond', name:'Conductores, cables de guarda y aisladores (suministro)', base:(it['2.2'].sum+it['2.3'].sum+it['2.4'].sum+it['2.5'].sum+it['2.6'].sum)*scaleD},
    {k:'civ', name:'Obras civiles, accesos y fundaciones', base:(it['1.1'].civ+it['1.2'].civ+it['1.3'].civ)*mult*scaleD},
    {k:'em', name:'Montaje electromecánico, pruebas y puesta en servicio', base:(R.sumEm+R.sumPP)*mult*scaleD},
    {k:'ind', name:'Costos indirectos y del dueño', base:R.ind+R.owner},
    {k:'est', name:'Estudios, ingeniería, EIA y permisos', base:R.est},
    {k:'esc', name:'Escalamiento y provisión por riesgos', base:R.esc+R.risk}
  ];
  return pk;
}
const RISK_DEFAULT = {
  5:{estr:[-20,50],cond:[-20,45],civ:[-25,80],em:[-20,60],ind:[-15,50],est:[-15,60],serv:[-35,150],esc:[-30,80],sys:[-15,45]},
  4:{estr:[-15,35],cond:[-15,30],civ:[-20,55],em:[-15,45],ind:[-12,35],est:[-12,45],serv:[-30,110],esc:[-25,60],sys:[-12,32]},
  3:{estr:[-10,25],cond:[-10,22],civ:[-15,40],em:[-12,32],ind:[-10,25],est:[-10,30],serv:[-25,75],esc:[-20,40],sys:[-8,20]},
  2:{estr:[-6,14],cond:[-6,12],civ:[-10,22],em:[-8,18],ind:[-6,14],est:[-6,18],serv:[-15,45],esc:[-15,28],sys:[-5,11]},
  1:{estr:[-3,7],cond:[-3,7],civ:[-5,12],em:[-4,10],ind:[-3,8],est:[-3,9],serv:[-10,28],esc:[-10,16],sys:[-3,6]}
};
const SYS_NAME='Riesgo sistémico (mercado, productividad, definición del alcance)';
function triangular(a,m,b){ if(b<=a) return m; const u=Math.random(); const F=(m-a)/(b-a); return u<F ? a+Math.sqrt(u*(b-a)*(m-a)) : b-Math.sqrt((1-u)*(b-a)*(b-m)); }
/* normal estándar (Box–Muller) y gamma (Marsaglia–Tsang) para muestrear la beta-PERT */
function randn(){ let u=0,v=0; while(u===0) u=Math.random(); while(v===0) v=Math.random(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v); }
function randGamma(k){ if(k<1){ return randGamma(k+1)*Math.pow(Math.random(),1/k); } const d=k-1/3, c=1/Math.sqrt(9*d); for(;;){ let x,v; do{ x=randn(); v=1+c*x; }while(v<=0); v=v*v*v; const u=Math.random(); if(u<1-0.0331*x*x*x*x) return d*v; if(Math.log(u)<0.5*x*x+d*(1-v+Math.log(v))) return d*v; } }
/* beta-PERT (λ = 4): media (a + 4m + b)/6, igual que el esperado PERT determinístico de la tabla de rangos */
function betaPert(a,m,b){ if(b<=a) return m; const al=1+4*(m-a)/(b-a), be=1+4*(b-m)/(b-a); const x=randGamma(al), y=randGamma(be); return a+(b-a)*x/(x+y); }
function monteCarlo(pk, ranges, N, dist){
  dist = dist==='tri' ? 'tri' : 'pert'; const draw = dist==='tri' ? triangular : betaPert;
  const out=new Float64Array(N); const rs=ranges.sys||[0,0];
  for(let i=0;i<N;i++){ let t=0; for(const p of pk){ const r=ranges[p.k]||[0,0]; t+=draw(p.base*(1+r[0]/100), p.base, p.base*(1+r[1]/100)); } t*=draw(1+rs[0]/100,1,1+rs[1]/100); out[i]=t; }
  const s=Array.from(out).sort((a,b)=>a-b);
  const P=p=>s[Math.min(N-1,Math.max(0,Math.floor(p/100*N)))];
  const mean=s.reduce((a,b)=>a+b,0)/N;
  const sd=Math.sqrt(s.reduce((a,b)=>a+(b-mean)**2,0)/N);
  return {s,P,mean,sd,min:s[0],max:s[N-1],dist};
}
