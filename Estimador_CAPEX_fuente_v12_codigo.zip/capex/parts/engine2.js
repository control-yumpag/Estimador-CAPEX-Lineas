/* ===================== ENGINE 2 · Redes <= 60 kV (Osinergmin BDME) ===================== */
const OSI = JSON.parse(document.getElementById('osi').textContent);
const OMODS = OSI.mods;
const OMOD60 = OMODS.filter(m=>m.kv===60);
const ZC = {Costa:'COR', Sierra:'SIR', Selva:'SER'};
const ALT_IDX = {'0-1000':0,'1000-3000':0,'3001-4500':1};
const STRUCT2 = {TA:'Torres de acero autosoportadas (módulo BDME)', PA:'Postes de acero autosoportados', PC:'Postes de concreto armado', PM:'Postes de madera tratada'};

function trafoPrice(mva, kv, wind, mode){
  const T=OSI.trafo;
  if(mode==='bdme'){ // valor consolidado BDME más cercano en MVA
    const fam = kv===33 ? 'TPD-033MT' : (wind===3 ? 'TPT-060MTMT' : 'TPD-060MT');
    const cands=Object.entries(T.bdme).filter(([c,v])=>c.startsWith(fam)).map(([c,v])=>({c,...v}));
    if(cands.length){ cands.sort((a,b)=>Math.abs(a.mva-mva)-Math.abs(b.mva-mva)); const b=cands[0]; return {usd:b.usd*Math.pow(mva/b.mva,0.55), src:`BDME ${b.c} (${b.mva} MVA, ${fmt(b.usd)} USD${b.y?', fuente '+b.y:''}) escalado por (MVA/${b.mva})^0.55`}; }
  }
  let usd, src;
  if(kv===33){ if(mva<=12){ usd=T.tpd033.a*Math.pow(mva,T.tpd033.b); src=`curva 33/MT: ${fmt(T.tpd033.a)}·MVA^${T.tpd033.b} (n=${T.tpd033.n}, fuentes ≥ ${T.tpd033.ymin})`; } else { usd=0.85*T.tpd060.a*Math.pow(mva,T.tpd060.b); src='0.85 × curva 60/MT (> 12 MVA)'; } }
  else { usd=T.tpd060.a*Math.pow(mva,T.tpd060.b); src=`curva 60/MT: ${fmt(T.tpd060.a)}·MVA^${T.tpd060.b} (n=${T.tpd060.n}, fuentes ≥ ${T.tpd060.ymin})`; if(wind===3){ usd*=T.tpt060.factor; src+=` × ${T.tpt060.factor} (3 devanados)`; } }
  return {usd, src};
}

function pickOsiModule(inp){
  // módulo BDME LT-060 más cercano: zona/altitud/terna/conductor
  const zc = inp.zone==='Sierra' ? 'SIR' : 'SER'; // BDME 60 kV solo tiene SER0, SIR0, SIR1 (Costa → SIR0 con flete costa)
  const alt = inp.zone==='Sierra' ? ALT_IDX[inp.alt] : 0;
  const mm2 = inp.condMm2<=150 ? 120 : 240;
  let m = OMOD60.find(x=>x.zc===zc && x.alt===alt && x.terna===inp.terna && x.condMm2===mm2);
  if(!m) m = OMOD60.find(x=>x.zc===zc && x.terna===inp.terna) || OMOD60[0];
  return m;
}

function servCode(inp){ const kv=inp.kv===60?'060':'033'; const z=(inp.zone==='Costa'?'CO':inp.zone==='Sierra'?'SI':'SE')+(inp.env==='urbana'?'U':'R'); const a=inp.zone==='Sierra'?ALT_IDX[inp.alt]:0; return `${kv}${z}${a}`; }
function servGeo(inp){ return (ZC[inp.zone]||'SIR')+(inp.zone==='Sierra'?ALT_IDX[inp.alt]:0); }

/* Grupos de precio (escalamiento) y marcas por fila: grp ∈ {steelT, conc, wood, alu, steelW, opgw, ins, cu, eq, lab, civ, svc, land}; brand ∈ {cond, opgw, tower, spole, cpole, wpole, ins, hw} */
const MAT_GRP={TA:'steelT',PA:'steelT',PC:'conc',PM:'wood'}, MAT_BRAND={TA:'tower',PA:'spole',PC:'cpole',PM:'wpole'};
function finishRows(rows,inp){
  const esc=window.PRICE? PRICE.applyRows(rows,'bdme') : {escF:1};
  const sum=k=>rows.reduce((a,r)=>a+(r[k]||0),0);
  const equipos=sum('sum'), montaje=sum('mont'), oc=sum('oc');
  const byBrand=b=>rows.filter(r=>r.brand===b).reduce((a,r)=>a+r.sum,0);
  const parts={estructuras:rows.filter(r=>/^(tower|spole|cpole|wpole)$/.test(r.brand||'')).reduce((a,r)=>a+r.sum,0), conductor:byBrand('cond'), guarda:byBrand('opgw'), aisladores:byBrand('ins'), pat:rows.filter(r=>r.grp==='cu').reduce((a,r)=>a+r.sum,0), accesorios:byBrand('hw'), otros:0};
  parts.otros=equipos-parts.estructuras-parts.conductor-parts.guarda-parts.aisladores-parts.pat-parts.accesorios;
  return {equipos,montaje,oc,parts,escF:esc.escF};
}
function estimateLine(inp){
  if(inp.kv<1) return estimateBTLine(inp);
  if(isMT(inp.kv)) return estimateMTLine(inp);
  const K=OSI.lineKit, P=OSI.pct, kv=inp.kv, nT=inp.terna==='D'?2:1;
  const nKm=1000/inp.span, N=Math.max(2,Math.round(nKm*inp.km));
  const mix=normMix(inp.pS,inp.pA,inp.pT,'S','A','T');
  const cnt={S:Math.round(N*mix.S/100), A:Math.round(N*mix.A/100)}; cnt.T=Math.max(2,N-cnt.S-cnt.A);
  const acc=inp.access, fSoil=(1+0.35*inp.rock/100)/(1+0.35*0.3);
  const rows=[]; let M=null, kit=null, towerUnit=0, note='';
  const grpS=MAT_GRP[inp.mat]||'conc', brS=MAT_BRAND[inp.mat]||'cpole';
  if(inp.mat==='TA'){
    M=pickOsiModule(inp); const d=M.decomp;
    const kgBase = K.conductors[M.condMm2].kgKm, kgU=K.conductors[inp.condMm2].kgKm;
    const fMix=(mix.S*1+mix.A*1.9+mix.T*3.4)/100/1.42;
    towerUnit=d.towerUnit*Math.pow(inp.span/d.span,0.6)*Math.pow(kgU/kgBase,0.35)*fMix;
    note=`Torres: módulo BDME ${M.code} (${fmt(d.towerUnit)} USD/torre a vano ${d.span} m; montaje ${fmt(d.montTower)} y OC ${fmt(d.ocTower)} USD/torre) ajustado por vano^0.6, conductor^0.35 y mezcla ×${fMix.toFixed(2)}.`;
    rows.push({k:'Torres de acero galvanizado (suministro)',code:M.code,qty:N,unit:'und',pu:towerUnit,sum:towerUnit*N,mont:d.montTower*N*acc*Math.pow(towerUnit/d.towerUnit,0.5),oc:d.ocTower*N*fSoil*acc,grp:'steelT',brand:'tower'});
  } else {
    kit=K.structKits[`${kv}|${inp.terna}|${inp.mat}`] || K.structKits[`${kv}|S|${inp.mat}`];
    if(!kit){ kit=K.structKits[`${kv}|S|PC`]; note='Sin kit BDME para esta combinación: se usa postes de concreto.'; }
    ['S','A','T'].forEach(t=>{ const st=kit[t]; const n=cnt[t];
      rows.push({k:({S:'Estructuras de suspensión',A:'Estructuras de ángulo',T:'Estructuras de anclaje / terminal'})[t],code:st.code,qty:n,unit:'und',pu:st.sup,sum:st.sup*n,mont:st.mont*n*acc,oc:st.oc*n*fSoil*acc,grp:grpS,brand:brS}); });
    if(inp.terna==='D' && !K.structKits[`${kv}|D|${inp.mat}`]) note='Doble terna sin kit específico: estructuras simple terna ×1 (revisar).';
  }
  const c=K.conductors[inp.condMm2]; const condKm=c.usdKm*3*nT*1.03;
  rows.push({k:`Conductor AAAC ${inp.condMm2} mm² (3 × ${nT} terna${nT>1?'s':''}, +3 % flechas)`,code:c.code,qty:3*nT*inp.km*1.03,unit:'km',pu:c.usdKm,sum:condKm*inp.km,mont:0,oc:0,grp:'alu',brand:'cond'});
  const g=K.guards[inp.guard]; if(g.usdKm>0) rows.push({k:g.desc+' (+3 %)',code:g.code,qty:inp.km*1.03,unit:'km',pu:g.usdKm,sum:g.usdKm*1.03*inp.km,mont:0,oc:0,grp:'steelW',brand:'opgw'});
  const ins=K.insulators[kv][inp.ins]; const nSus=cnt.S*3*nT, nAnc=(cnt.A+cnt.T)*6*nT;
  const insSum=nSus*ins.S.price+nAnc*ins.A.price;
  rows.push({k:`Aisladores ${inp.ins==='chain'?(kv===60?'(cadenas vidrio/porcelana)':'poliméricos'):'poliméricos'}: ${nSus} suspensión + ${nAnc} anclaje`,code:`${ins.S.code} / ${ins.A.code}`,qty:nSus+nAnc,unit:'cjto',pu:(insSum/(nSus+nAnc)),sum:insSum,mont:insSum*K.montaje.insulPct,oc:0,flag:ins.S.flag,note:ins.S.note,grp:'ins',brand:'ins'});
  rows.push({k:'Puesta a tierra (contrapeso copperweld + electrodo por estructura)',code:K.pat.code,qty:N,unit:'und',pu:K.pat.usdStr,sum:N*K.pat.usdStr,mont:0,oc:0,grp:'cu',brand:'hw'});
  const supStruct=rows.filter(r=>r.brand===brS).reduce((a,r)=>a+r.sum,0); const acce=(supStruct+condKm*inp.km+g.usdKm*1.03*inp.km)*K.accesorios.pct;
  rows.push({k:'Accesorios, juntas, amortiguadores, señalización (3 %)',code:'—',qty:1,unit:'glb',pu:acce,sum:acce,mont:0,oc:0,grp:'ins',brand:'hw'});
  const montString=K.montaje.stringUsdKmTerna[kv]*nT*inp.km*acc*(g.usdKm>0?1.08:1); const montOther=K.montaje.otherUsdKm[kv]*inp.km*acc;
  rows.push({k:'Tendido y regulado de conductores y cable de guarda',code:'I-401 (n.d.)',qty:inp.km*nT,unit:'km-terna',pu:montString/(inp.km*nT),sum:0,mont:montString,oc:0,grp:'lab'});
  rows.push({k:'Trabajos complementarios: PAT, numeración, inspección, pruebas y puesta en servicio',code:'—',qty:inp.km,unit:'km',pu:montOther/inp.km,sum:0,mont:montOther,oc:0,grp:'lab'});
  const F=finishRows(rows,inp); const equipos=F.equipos, montaje=F.montaje, oc=F.oc;
  const imp=inp.imp/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana;
  const fletePct=P.flete[inp.zone]*(inp.mat==='PC'?2.2:1)*(inp.mat==='PM'?1.4:1); const fletes=equipos*fletePct;
  const directo=equipos+aranc+aduana+fletes+montaje+oc;
  const sc=servCode(inp); const sv=OSI.serv[sc]; const servAuto=sv? sv.usdKm*inp.km : 0;
  const serv=0; // servidumbre excluida del estimado (supuesto documentado); servAuto queda como referencia BDME
  const ingInfo=(kv===60?1241:900)*inp.km;
  return {kind:'line',rows,N,cnt,nKm,mix,M,kit,towerUnit,note,equipos,aranc,aduana,fletes,fletePct,montaje,oc,directo,serv,servAuto,servCode:sc,servRow:sv,ingInfo,km:inp.km,parts:F.parts,escF:F.escF};
}

function estimateSet(inp){
  if(isMT(inp.kv)) return estimateSED(inp);
  const S=OSI.setKit, P=OSI.pct, kv=inp.kv, gis=inp.setType==='GIS'&&kv===60, dbl=inp.bar==='doble';
  const rows=[]; let equipos=0, montaje=0, oc=0;
  const bayItems=(kitKey,extraSBC)=>{ const k=S[kitKey]; let sup=k.items.reduce((a,i)=>a+i.price,0)+(k.barras||0); if(extraSBC){ sup+=OSI.setKit.bay60.items.find(i=>i.code==='SBC060ES0325').bdme+625; } return {sup,mont:k.mont,oc:k.oc,label:k.label,items:k.items}; };
  const add=(label,code,qty,unit,pu,sup,mont,o,flag,note)=>{ rows.push({k:label,code,qty,unit,pu,sum:sup,mont,oc:o,flag,note}); equipos+=sup; montaje+=mont; oc+=o; };
  // bahías AT
  const keyL = gis ? (dbl?'gis60D':'gis60') : (kv===60?'bay60':'bay33');
  const keyT = gis ? (dbl?'gis60D':'gis60') : (kv===60?'bay60T':'bay33T');
  const bL=bayItems(keyL, !gis&&dbl&&kv===60), bT=bayItems(keyT, !gis&&dbl&&kv===60);
  let nBays=0;
  if(inp.nLines>0){ add(`${bL.label} × ${inp.nLines}${dbl&&!gis?' (+1 seccionador de barra por doble barra)':''}`,keyL,inp.nLines,'bahía',bL.sup,bL.sup*inp.nLines,bL.mont*inp.nLines*inp.access,bL.oc*inp.nLines*inp.ocF); nBays+=inp.nLines; }
  if(inp.nTr>0){ add(`${bT.label} × ${inp.nTr}`,keyT,inp.nTr,'bahía',bT.sup,bT.sup*inp.nTr,bT.mont*inp.nTr*inp.access,bT.oc*inp.nTr*inp.ocF); nBays+=inp.nTr; }
  if(dbl){ const kc=gis?'gis60C':(kv===60?'bay60C':'bay33T'); const bc=bayItems(kc); add(`${bc.label} × 1`,kc,1,'bahía',bc.sup,bc.sup,bc.mont*inp.access,bc.oc*inp.ocF); nBays+=1; }
  if(!gis && kv===60){ const nb=dbl?2:1; const bm=bayItems('bus60'); add(`Medición de barra 60 kV × ${nb}`,'bus60',nb,'barra',bm.sup,bm.sup*nb,bm.mont*nb*inp.access,bm.oc*nb*inp.ocF); }
  // transformadores
  const tp=trafoPrice(inp.mva,kv,inp.wind,inp.trMode);
  add(`Transformador de potencia ${kv}/${inp.mt}${inp.wind===3?'/'+(inp.mt===22.9?'10':'22.9'):''} kV, ${inp.mva} MVA ONAN/ONAF, con OLTC × ${inp.nTr}`,inp.wind===3?'TPT-060MTMT':(kv===33?'TPD-033MT':'TPD-060MT'),inp.nTr,'und',tp.usd,tp.usd*inp.nTr,(S.trafoMont.fixed+S.trafoMont.perMva*inp.mva)*inp.nTr*inp.access,(S.oc.trafoFix+S.oc.trafoPerMva*inp.mva)*inp.nTr*inp.ocF,'curve',tp.src);
  add(`Tablero regulador de tensión (AVR) × ${inp.nTr}`,S.avr.code,inp.nTr,'und',S.avr.price,S.avr.price*inp.nTr,1200*inp.nTr,0,S.avr.flag);
  // celdas MT
  const ck=`${inp.mt===22.9?23:inp.mt===10?10:33}|${inp.cell}`; const cells=S.cells[ck]||S.cells['23|CMC'];
  const nSM=inp.nTr>1?2:1, nDC=inp.nTr>1?1:0, nCap=inp.capMvar>0?1:0, nCells=inp.nFeed+inp.nTr+nSM+nDC+nCap;
  const cellRow=(it,n,label)=>{ if(n>0) add(`${label} × ${n}`,it.code,n,'und',it.price,it.price*n,S.cellMont*n*inp.access,S.cellOc*n*inp.ocF,it.flag,it.note); };
  cellRow(cells.ST,inp.nTr,`${cells.label}: llegada de transformador`); cellRow(cells.SA,inp.nFeed,`${cells.label}: salida alimentador`); cellRow(cells.SM,nSM,`${cells.label}: medición de barra`); cellRow(cells.DC,nDC,`${cells.label}: acoplamiento`); cellRow(cells.SA,nCap,`${cells.label}: banco de capacitores`);
  // capacitores
  if(inp.capMvar>0){ const cp=S.caps[inp.mt===22.9?23:inp.mt===10?10:33]; add(`Banco de capacitores ${inp.mt} kV, ${inp.capMvar} MVAR`,cp.src,inp.capMvar,'MVAR',cp.usdMvar,cp.usdMvar*inp.capMvar,cp.usdMvar*inp.capMvar*0.06,4000*inp.ocF,cp.flag); }
  // SS.AA., SCADA, malla
  const sa=S.ssaa[kv]; const saSup=sa.items.reduce((a,i)=>a+i.price,0)+sa.extra.reduce((a,e)=>a+e[1],0);
  add('Servicios auxiliares CA/CC: transformador SS.AA., bancos de baterías 110/48 Vcc, cargadores, tableros, UPS',sa.items.map(i=>i.code).join(' + ')+' + lotes',1,'glb',saSup,saSup,sa.mont*inp.access,0,'mix');
  const sc=S.scada[kv]; add('SCADA, RTU y comunicaciones',`criterio experto`,1,'glb',sc.usd,sc.usd,sc.mont,0,'exp',sc.desc);
  // áreas
  const ar= gis? S.area.gis60 : (kv===60? S.area.ais60 : S.area.ais33);
  const patioAuto=ar.base+ar.perBay*nBays+ar.perTrafo*inp.nTr; const patio= inp.patioAuto? patioAuto : inp.patio;
  const earthSup=patio*S.earth.usdM2; add('Malla de puesta a tierra',`${S.earth.usdM2} USD/m²`,patio,'m²',S.earth.usdM2,earthSup,earthSup*S.earth.montPct,0,'exp');
  // obras civiles paramétricas
  const O=S.oc; const ocRows=[];
  const ocAdd=(k,q,u,pu)=>{ const v=q*pu*inp.ocF; ocRows.push({k,qty:q,unit:u,pu,tot:v}); oc+=v; };
  ocAdd('Explanación, nivelación, relleno compactado y grava del patio',patio,'m²',O.patioM2);
  const ctlM2=O.controlBaseM2[kv]+O.cellM2*nCells; ocAdd('Casa de control y sala de celdas MT (estructura, arquitectura, IIEE/IISS)',ctlM2,'m²',O.controlM2);
  if(gis) ocAdd('Edificio GIS (sala de módulos SF6)',O.gisBaseM2+O.gisPerBay*nBays,'m²',O.gisM2);
  ocAdd('Canalizaciones, buzones y ductos de cables',nBays,'bahía',O.canalBay); ocAdd('Canalizaciones a celdas MT',nCells,'celda',O.canalCell);
  const perim=4*Math.sqrt(patio*1.25); ocAdd('Cerco perimétrico y portón',perim,'m',O.fenceUsdM);
  ocAdd('Vías internas, veredas, drenaje pluvial e iluminación exterior',patio,'m²',O.roadsM2);
  ocAdd('Acceso vehicular externo (afirmado)',inp.accessM,'m',O.accessUsdM);
  const pruebas=equipos*0.015; montaje+=pruebas; rows.push({k:'Pruebas funcionales y puesta en servicio de la subestación (1.5 % del suministro)',code:'—',qty:1,unit:'glb',pu:pruebas,sum:0,mont:pruebas,oc:0});
  const imp=inp.impSet/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana;
  const fletes=equipos*P.flete[inp.zone]*1.3;
  const ing=(equipos+aranc+aduana+fletes+montaje+oc)*P.ingSet;
  const directo=equipos+aranc+aduana+fletes+montaje+oc+ing;
  const land=(patio*1.25)*inp.landP;
  const mvaTot=inp.mva*inp.nTr;
  return {kind:'set',rows,ocRows,equipos,aranc,aduana,fletes,montaje,oc,ing,directo,land,patio,patioAuto,nBays,nCells,mvaTot,trafo:tp,gis,dbl,cells,
          parts:{trafos:tp.usd*inp.nTr+S.avr.price*inp.nTr, bahias:rows.filter(r=>/bay|gis|bus/.test(r.code)).reduce((a,r)=>a+r.sum,0), celdas:rows.filter(r=>/^C(MC|EN)/.test(r.code)).reduce((a,r)=>a+r.sum,0), otros:0}};
}

function estimateExt(inp){
  if(!inp.nExt||isMT(inp.kv)) return null;
  const S=OSI.setKit, P=OSI.pct, kv=inp.kv;
  const k= kv===60 ? S.bay60 : S.bay33; const sup=(k.items.reduce((a,i)=>a+i.price,0)+(k.barras||0))*inp.nExt;
  const montaje=k.mont*inp.nExt*inp.access*1.15, oc=k.oc*inp.nExt*inp.ocF*1.3; // integración en SET existente: +15 % montaje, +30 % OC
  const aranc=sup*0.8*P.arancel, aduana=sup*0.8*P.aduana, fletes=sup*P.flete[inp.zone];
  const ing=(sup+aranc+aduana+fletes+montaje+oc)*P.ingSet; const directo=sup+aranc+aduana+fletes+montaje+oc+ing;
  return {kind:'ext',equipos:sup,aranc,aduana,fletes,montaje,oc,ing,directo,n:inp.nExt,label:`${k.label} en subestación existente × ${inp.nExt}`};
}

function estimateOsi(inp){
  const P=OSI.pct;
  const L= estimateLine(inp);
  const S= null;
  const X= null;
  const blocks=[L,S,X].filter(Boolean);
  const gg=inp.gg/100, ut=inp.ut/100, sup=inp.sup/100, fin=inp.fin/100;
  blocks.forEach(b=>{ b.ggU=(b.montaje+b.oc)*(gg+ut); b.tg=b.directo+b.ggU; b.supv=b.tg*sup; b.adm=b.tg*(b.kind==='line'?P.adminLT:P.adminSET); b.finc=b.tg*fin; b.reg=b.tg+b.supv+b.adm+b.finc+(b.serv||0)+(b.land||0); });
  const sum=k=>blocks.reduce((a,b)=>a+(b[k]||0),0);
  const equipos=sum('equipos'), aranc=sum('aranc'), aduana=sum('aduana'), fletes=sum('fletes'), montaje=sum('montaje'), oc=sum('oc'), ing=sum('ing'), directo=sum('directo');
  const ggU=sum('ggU'), tg=sum('tg'), supv=sum('supv'), adm=sum('adm'), finc=sum('finc'), serv=L?L.serv:0, land=S?S.land:0;
  const reg=tg+supv+adm+finc; // valor regulatorio (Osinergmin) sin servidumbre, sin IGV
  const eng=directo*inp.eng/100, owner=directo*inp.owner/100;
  const d1=tg;                                  // 1. costo directo (suministro + fletes + montaje + OC + GG&U del contratista)
  const d2=supv+adm+finc+eng+owner;             // 2. costo indirecto (supervisión, administrativos, financieros, ingeniería/estudios y costo del dueño)
  const A=d1+d2;
  // pesos de A por grupo de costo → escalamiento de la fecha base de precios al periodo de ejecución (ESC)
  const W={}; const addW=(g,v)=>{ if(v>0) W[g]=(W[g]||0)+v; };
  if(L){ const sumSup=L.rows.reduce((a,r)=>a+(r.sum||0),0)||1; const kImp=1+((L.aranc||0)+(L.aduana||0)+(L.fletes||0))/sumSup;
    L.rows.forEach(r=>{ addW(r.grp||'eq',(r.sum||0)*kImp); addW('lab',r.mont||0); addW('civ',r.oc||0); });
    const rm=L.rows.reduce((a,r)=>a+(r.mont||0),0), ro=L.rows.reduce((a,r)=>a+(r.oc||0),0); addW('lab',Math.max(0,(L.montaje||0)-rm)); addW('civ',Math.max(0,(L.oc||0)-ro)); addW('svc',L.ing||0); }
  { const mo=(montaje+oc)||1; addW('lab',ggU*montaje/mo); addW('civ',ggU*oc/mo); addW('svc',supv+adm+finc+eng+owner); }
  { const sW=Object.values(W).reduce((a,b)=>a+b,0)||1; Object.keys(W).forEach(g=>W[g]*=A/sW); }
  const escDet=(window.ESC&&window.PROJ)? ESC.forEstimate(W) : null;
  const esc= escDet? escDet.esc : A*inp.esc/100, risk=A*inp.risk/100; const B=A+esc+risk; const cont=B*inp.cont/100; const C=B+cont; const D=C*inp.phase/100; const E=C+D;
  const igv=E*inp.igv/100, ET=E+igv, regIgv=reg*(1+inp.igv/100);
  return {inp,L,S,X,blocks,equipos,aranc,aduana,fletes,montaje,oc,ing,directo,ggU,tg,supv,adm,finc,serv,land,reg,regIgv,eng,owner,d1,d2,A,esc,escDet,escW:W,risk,B,cont,C,D,E,igv,ET,escF:L?L.escF:1,
          usdKm: L? (L.reg)/inp.km : null, usdKmProj: L? (E*(L.reg/reg))/inp.km : null, usdMva: S? S.reg/S.mvaTot : null, usdBay: S? S.reg/Math.max(1,S.nBays) : null};
}

/* ---- riesgo (paquetes) ---- */
function riskPackagesOsi(R){
  const L=R.L,S=R.S,X=R.X; const f=1+(R.inp.gg+R.inp.ut)/100; const pk=[];
  if(L){ pk.push({k:'lsum',name:'Línea: suministro de estructuras, conductores y aisladores',base:L.equipos+L.aranc+L.aduana+L.fletes});
         pk.push({k:'lobra',name:'Línea: montaje, obras civiles y accesos (con GG+U)',base:(L.montaje+L.oc)*f}); }
  if(S){ pk.push({k:'tr',name:'Subestación: transformadores de potencia',base:S.parts.trafos*(1+0.061*R.inp.impSet/100)});
         pk.push({k:'at',name:'Subestación: bahías AT, celdas MT, SS.AA., SCADA (suministro)',base:S.equipos-S.parts.trafos+S.aranc+S.aduana+S.fletes-S.parts.trafos*0.061*R.inp.impSet/100});
         pk.push({k:'sobra',name:'Subestación: montaje, obras civiles e ingeniería (con GG+U)',base:(S.montaje+S.oc)*f+S.ing}); pk.push({k:'land',name:'Terreno de la subestación',base:S.land}); }
  if(X){ pk.push({k:'ext',name:'Ampliación en subestación existente',base:X.directo+X.ggU}); }
  pk.push({k:'ind',name:'Supervisión, gastos administrativos, financieros, ingeniería y costo del dueño',base:R.supv+R.adm+R.finc+R.eng+R.owner});
  pk.push({k:'esc',name:'Escalamiento y provisión por riesgos',base:R.esc+R.risk});
  return pk.filter(p=>p.base>0);
}
const RISK2_DEFAULT = {
  5:{lsum:[-20,45],lobra:[-25,70],serv:[-35,150],tr:[-20,40],at:[-15,40],sobra:[-25,70],land:[-40,150],ext:[-20,50],ind:[-15,45],esc:[-30,80],sys:[-15,45]},
  4:{lsum:[-15,32],lobra:[-20,50],serv:[-30,110],tr:[-15,30],at:[-12,30],sobra:[-20,50],land:[-35,110],ext:[-15,38],ind:[-12,35],esc:[-25,60],sys:[-12,32]},
  3:{lsum:[-10,22],lobra:[-15,36],serv:[-25,75],tr:[-10,22],at:[-8,20],sobra:[-15,36],land:[-25,75],ext:[-10,26],ind:[-10,25],esc:[-20,40],sys:[-8,20]},
  2:{lsum:[-6,12],lobra:[-10,20],serv:[-15,45],tr:[-6,12],at:[-5,12],sobra:[-10,20],land:[-15,45],ext:[-6,15],ind:[-6,14],esc:[-15,28],sys:[-5,11]},
  1:{lsum:[-3,7],lobra:[-5,11],serv:[-10,28],tr:[-3,7],at:[-3,7],sobra:[-5,11],land:[-10,28],ext:[-3,8],ind:[-3,8],esc:[-10,16],sys:[-3,6]}
};

/* ===================== MT (22.9 / 10 kV): líneas bottom-up y subestaciones de distribución MT/BT ===================== */
const MTKV=[22.9,10];
function isMT(kv){ return kv<30&&kv>=1; }
function estimateMTLine(inp){
  const K=OSI.mtKit, P=OSI.pct, kv=inp.kv; const kk= kv>=13? 22.9 : 10; const mat= K.structs[inp.mat]? inp.mat : 'PC'; const kit=K.structs[mat];
  const mrt= inp.terna==='M'; const nKm=1000/inp.span, N=Math.max(2,Math.round(nKm*inp.km));
  const mix=normMix(inp.pS,inp.pA,inp.pT,'S','A','T'); const cnt={S:Math.round(N*mix.S/100),A:Math.round(N*mix.A/100)}; cnt.T=Math.max(2,N-cnt.S-cnt.A);
  const acc=inp.access, fSoil=(1+0.35*inp.rock/100)/(1+0.35*0.3); const fS=(mrt? K.mrt.structF : 1)*((K.insF&&K.insF[String(kv)])||1);
  const rows=[]; const grpS=MAT_GRP[mat], brS=MAT_BRAND[mat];
  ['S','A','T'].forEach(t=>{ const st=kit[t]; const n=cnt[t];
    rows.push({k:({S:'Estructuras de alineamiento (PS)',A:'Estructuras de ángulo (PA)',T:'Estructuras de retención / terminal (PR)'})[t]+(mrt?' · MRT':''),code:st.code,qty:n,unit:'und',pu:st.sup*fS,sum:st.sup*fS*n,mont:st.mont*acc*n,oc:st.oc*fSoil*acc*n,flag:'exp',grp:grpS,brand:brS}); });
  const mm2=K.cond[inp.condMm2]? inp.condMm2 : 70; const c=K.cond[mm2]; const nc= mrt?1:3;
  rows.push({k:`Conductor AAAC ${mm2} mm² (${nc} × ${inp.km} km, +3 %)`,code:'AAAC 3.38 USD/kg',qty:nc*inp.km*1.03,unit:'km',pu:c.usdKm,sum:c.usdKm*nc*1.03*inp.km,mont:0,oc:0,flag:'vig',grp:'alu',brand:'cond'});
  const nPat=Math.round(N/K.pat.every)+cnt.T; rows.push({k:`Puestas a tierra (${nPat} und: cada ${K.pat.every} estructuras + anclajes${mrt?'; MRT reforzada':''})`,code:'—',qty:nPat,unit:'und',pu:K.pat.usdStr,sum:nPat*K.pat.usdStr,mont:0,oc:0,flag:'exp',grp:'cu',brand:'hw'});
  const acce=rows.reduce((a,r)=>a+(r.brand===brS||r.brand==='cond'?r.sum:0),0)*0.03; rows.push({k:'Accesorios, señalización y ferretería menor (3 %)',code:'—',qty:1,unit:'glb',pu:acce,sum:acce,mont:0,oc:0,grp:'ins',brand:'hw'});
  const montString=K.montString[String(kk)]*(mrt?0.5:1)*inp.km*acc, montOther=K.other[String(kk)]*inp.km*acc;
  rows.push({k:'Tendido y regulado de conductores',code:'—',qty:inp.km,unit:'km',pu:montString/inp.km,sum:0,mont:montString,oc:0,flag:'exp',grp:'lab'});
  rows.push({k:'Pruebas, puesta en servicio y señalización',code:'—',qty:inp.km,unit:'km',pu:montOther/inp.km,sum:0,mont:montOther,oc:0,flag:'exp',grp:'lab'});
  const F=finishRows(rows,inp); const equipos=F.equipos, montaje=F.montaje, oc=F.oc;
  const imp=inp.imp/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana; const fletePct=P.flete[inp.zone]*1.5; const fletes=equipos*fletePct;
  const directo=equipos+aranc+aduana+fletes+montaje+oc;
  const sv=K.serv[String(kk)]; const servAuto= inp.env==='urbana'? 0 : (sv.usdKm[inp.zone]||0)*inp.km; const serv=0; // servidumbre excluida (referencia: servAuto)
  return {kind:'line',mt:true,rows,N,cnt,nKm,mix,M:null,kit,towerUnit:0,note:`Línea ${kv} kV ${mrt?'MRT (1 conductor)':'trifásica'} con ${kit.label.toLowerCase()}; vano ${inp.span} m.`,equipos,aranc,aduana,fletes,fletePct,montaje,oc,directo,serv,servAuto,servCode:`MT ${kv} kV ${inp.zone} ${inp.env}`,servRow:{ancho:sv.ancho,usdKm:sv.usdKm[inp.zone]||0,zona:inp.zone+' '+inp.env},ingInfo:600*inp.km,km:inp.km,parts:F.parts,escF:F.escF};
}
/* ===================== BT (380/220 V): redes secundarias aéreas con conductor autoportante ===================== */
function estimateBTLine(inp){
  const K=OSI.btKit, P=OSI.pct; const env=inp.env==='urbana'?'urbana':'rural'; const mat= K.structs[inp.mat]? inp.mat : 'PC'; const kit=K.structs[mat];
  const nKm=1000/inp.span, N=Math.max(2,Math.round(nKm*inp.km));
  const mix=normMix(inp.pS,inp.pA,inp.pT,'S','A','T'); const cnt={S:Math.round(N*mix.S/100),A:Math.round(N*mix.A/100)}; cnt.T=Math.max(2,N-cnt.S-cnt.A);
  const acc=inp.access, fSoil=(1+0.35*inp.rock/100)/(1+0.35*0.3);
  const rows=[]; const grpS=MAT_GRP[mat], brS=MAT_BRAND[mat];
  ['S','A','T'].forEach(t=>{ const st=kit[t]; const n=cnt[t];
    rows.push({k:({S:'Estructuras de alineamiento (E-S)',A:'Estructuras de ángulo (E-A)',T:'Estructuras de anclaje / fin de línea (E-T)'})[t],code:st.code,qty:n,unit:'und',pu:st.sup,sum:st.sup*n,mont:st.mont*acc*n,oc:st.oc*fSoil*acc*n,flag:'exp',grp:grpS,brand:brS}); });
  const ck=K.cond[inp.condBT]? inp.condBT : '3x50+16/35'; const c=K.cond[ck];
  rows.push({k:`${c.desc} (+3 % flechas y empalmes)`,code:'CAAI NTP 370.259',qty:inp.km*1.03,unit:'km',pu:c.usdKm,sum:c.usdKm*1.03*inp.km,mont:0,oc:0,flag:'exp',grp:'alu',brand:'cond'});
  const nLum=Math.round(inp.btLum*inp.km); if(nLum>0) rows.push({k:`Alumbrado público: ${K.lum.desc} × ${nLum}`,code:'—',qty:nLum,unit:'und',pu:K.lum.usd,sum:K.lum.usd*nLum,mont:K.lum.mont*nLum*acc,oc:0,flag:'exp',grp:'eq',brand:'hw'});
  const nAc=Math.round(inp.btAcom*inp.km); if(nAc>0) rows.push({k:`Acometidas domiciliarias: ${K.acom.desc} × ${nAc}`,code:'—',qty:nAc,unit:'und',pu:K.acom.usd,sum:K.acom.usd*nAc,mont:K.acom.mont*nAc*acc,oc:0,flag:'exp',grp:'eq',brand:'hw'});
  const nPat=Math.round(N/K.pat.every)+cnt.T+Math.round(nLum/2); rows.push({k:`Puestas a tierra (${nPat} und: cada ${K.pat.every} estructuras, anclajes y luminarias alternas)`,code:'—',qty:nPat,unit:'und',pu:K.pat.usdStr,sum:nPat*K.pat.usdStr,mont:0,oc:0,flag:'exp',grp:'cu',brand:'hw'});
  const acce=rows.reduce((a,r)=>a+(r.brand===brS||r.brand==='cond'?r.sum:0),0)*0.03; rows.push({k:'Ferretería menor, señalización y numeración (3 %)',code:'—',qty:1,unit:'glb',pu:acce,sum:acce,mont:0,oc:0,grp:'ins',brand:'hw'});
  const montString=K.montString[env]*inp.km*acc, montOther=K.other[env]*inp.km*acc;
  rows.push({k:'Tendido y regulado del conductor autoportante',code:'—',qty:inp.km,unit:'km',pu:montString/inp.km,sum:0,mont:montString,oc:0,flag:'exp',grp:'lab'});
  rows.push({k:'Pruebas, puesta en servicio, señalización y permisos municipales',code:'—',qty:inp.km,unit:'km',pu:montOther/inp.km,sum:0,mont:montOther,oc:0,flag:'exp',grp:'lab'});
  const F=finishRows(rows,inp); const equipos=F.equipos, montaje=F.montaje, oc=F.oc;
  const imp=inp.imp/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana; const fletePct=P.flete[inp.zone]*1.5; const fletes=equipos*fletePct;
  const directo=equipos+aranc+aduana+fletes+montaje+oc;
  return {kind:'line',bt:true,rows,N,cnt,nKm,mix,M:null,kit,towerUnit:0,note:`Red secundaria ${env} 380/220 V con ${kit.label.toLowerCase()}; vano ${inp.span} m; ${nLum} luminarias y ${nAc} acometidas.`,equipos,aranc,aduana,fletes,fletePct,montaje,oc,directo,serv:0,servAuto:0,servCode:'BT vía pública',servRow:{ancho:0,usdKm:0,zona:inp.zone+' '+env},ingInfo:400*inp.km,km:inp.km,parts:F.parts,escF:F.escF};
}
function sedTrafoPrice(kv,kva){ const pts=OSI.sedKit.trafo[kv===22.9?22.9:10]; const ks=Object.keys(pts).map(Number).sort((a,b)=>a-b); if(kva<=ks[0]) return pts[ks[0]]*Math.pow(kva/ks[0],0.75); for(let i=0;i<ks.length-1;i++){ if(kva<=ks[i+1]){ const t=(kva-ks[i])/(ks[i+1]-ks[i]); return pts[ks[i]]*(1-t)+pts[ks[i+1]]*t; } } return pts[ks[ks.length-1]]*Math.pow(kva/ks[ks.length-1],0.75); }
function estimateSED(inp){
  const K=OSI.sedKit, P=OSI.pct; const kv=inp.kv===22.9?22.9:10; const n=Math.max(1,inp.nSed||1), kva=Math.max(25,inp.kva||100);
  const type= inp.sedType==='auto' ? (kva<=100?'mono':kva<=400?'bi':'caseta') : inp.sedType; const T=K.types[type];
  const rows=[]; let equipos=0, montaje=0, oc=0;
  const add=(k,code,q,u,pu,sup,mo,o,flag,note)=>{ rows.push({k,code,qty:q,unit:u,pu,sum:sup,mont:mo,oc:o,flag,note}); equipos+=sup; montaje+=mo; oc+=o; };
  const tp=sedTrafoPrice(kv,kva); add(`Transformador de distribución ${kv}/0.4-0.23 kV, ${kva} kVA × ${n}`,`TP${kv===22.9?'023':'010'}-${kva}`,n,'und',tp,tp*n,0,0,kva<=400?'vig':'curve',kva>400?'extrapolado con exponente 0.75':null);
  Object.entries(T.sup).forEach(([k,v])=>{ if(!v) return; const lbl={postes:'Postes CAC 13/400 y estructura',herrajes:'Herrajes, crucetas, aisladores y plataforma',seccfus:'Seccionadores fusibles tipo cut-out (3)',parar:'Pararrayos MT (3)',tableroBT:'Tablero de distribución BT con medición',pat:'Puesta a tierra (MT y BT)',celdaMT:'Celda MT de protección (fusible / interruptor)',obraCaseta:'Caseta'}[k]||k; add(`${lbl} × ${n}`,'—',n,'und',v,v*n,0,0,'exp'); });
  montaje+=T.mont*n*inp.access; oc+=T.oc*n*inp.ocF; rows.push({k:`Montaje y pruebas (${T.label})`,code:'—',qty:n,unit:'und',pu:T.mont,sum:0,mont:T.mont*n*inp.access,oc:0,flag:'exp'}); rows.push({k:`Obras civiles: excavación, cimentación, plataforma${type==='caseta'?' y caseta':''}`,code:'—',qty:n,unit:'und',pu:T.oc,sum:0,mont:0,oc:T.oc*n*inp.ocF,flag:'exp'});
  const kmBT=inp.kmBT||0; if(kmBT>0){ const bt=K.redBT.usdKm*kmBT; add(`Red de baja tensión asociada (${kmBT} km)`,'—',kmBT,'km',K.redBT.usdKm,bt*0.55,bt*0.3,bt*0.15,'exp',K.redBT.desc); }
  const imp=inp.impSet/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana; const fletes=equipos*P.flete[inp.zone]*1.2; const ing=(equipos+aranc+aduana+fletes+montaje+oc)*0.02; const directo=equipos+aranc+aduana+fletes+montaje+oc+ing;
  return {kind:'set',sed:true,rows,ocRows:[],equipos,aranc,aduana,fletes,montaje,oc,ing,directo,land:0,patio:0,patioAuto:0,nBays:0,nCells:0,mvaTot:kva*n/1000,trafo:{usd:tp,src:`BDME TP${kv===22.9?'023':'010'} interpolado a ${kva} kVA`},gis:false,dbl:false,cells:{label:T.label},nSed:n,kva,sedType:type,
          parts:{trafos:tp*n,bahias:0,celdas:0,otros:equipos-tp*n}};
}

/* ===================== Subestaciones AT / EAT (138 / 220 / 500 kV) — espacio COES ===================== */
function trafoPriceAT(kv,mva,wind,secKv){
  const T=OSI.atKit[kv].trafo;
  if(kv===500){ const u=T.auto; const per=mva/3; const usd=u.a*Math.pow(per/u.ref,u.b); return {usd:usd*3,unit:usd,src:`${u.src}; ${mva} MVA → 3 × ${fmt(usd)} USD`}; }
  if(kv===220){ const two=T.two; let usd=two.a*Math.pow(mva,two.b); let src=`curva 220 kV 2 dev.: ${fmt(two.a)}·MVA^${two.b} (n=${two.n}, ≥ ${two.ymin})`; if(wind===3){ usd*=T.three.factor; src+=` × ${T.three.factor} (3 devanados)`; } return {usd,src}; }
  const two=T.two; if(wind===3){ const th=T.three; return {usd:th.a*Math.pow(mva,th.b),src:`curva 138 kV 3 dev.: ${fmt(th.a)}·MVA^${th.b} (n=${th.n})`}; } return {usd:two.a*Math.pow(mva,two.b),src:two.src};
}
function estimateSetAT(a){
  const K=OSI.atKit[a.kv]; if(!K||!a.nSet) return null; const P=OSI.pct; const kv=a.kv; const gis=a.setType==='GIS'; const im= kv===500 || a.bar==='im'; const dbl=a.bar==='doble'&&!im;
  const rows=[]; let equipos=0, montaje=0, oc=0; const add=(k,code,q,u,pu,sup,mo,o,flag,note)=>{ rows.push({k,code,qty:q,unit:u,pu,sum:sup,mont:mo,oc:o,flag,note}); equipos+=sup; montaje+=mo; oc+=o; };
  const kitSum=k=>k.items.reduce((s,i)=>s+i.price,0)+(k.barras||0);
  let nBays=0;
  const bayL= gis? (kv===500? K.gis : (dbl? K.gisD : K.gis)) : K.bay; const bayT= gis? (kv===500? K.gis : K.gisT) : K.bayT;
  const nL=a.nLines, nT=a.nTr;
  if(kv===500&&gis){ const nDiam=Math.ceil((nL+nT)/2); add(`${K.gis.label} × ${nDiam}`,'MGC500IM',nDiam,'diámetro',kitSum(K.gis),kitSum(K.gis)*nDiam,K.gis.mont*nDiam*a.access,K.gis.oc*nDiam*a.ocF,'vig'); nBays=nDiam*2; }
  else { if(nL>0){ const s=kitSum(bayL)+(dbl&&!gis? OSI.atKit[kv].bay.items.find(i=>/^SBC/.test(i.code)).bdme : 0); add(`${bayL.label} × ${nL}${dbl&&!gis?' (+1 seccionador por doble barra)':''}`,gis?'GIS':'AIS',nL,'bahía',s,s*nL,bayL.mont*nL*a.access,bayL.oc*nL*a.ocF,'vig'); nBays+=nL; }
    if(nT>0){ const s=kitSum(bayT); add(`${bayT.label} × ${nT}`,gis?'GIS':'AIS',nT,'bahía',s,s*nT,bayT.mont*nT*a.access,bayT.oc*nT*a.ocF,'vig'); nBays+=nT; }
    if(dbl&&(gis?K.gisC:K.bayC)){ const kc=gis?K.gisC:K.bayC; add(`${kc.label} × 1`,gis?'GIS':'AIS',1,'bahía',kitSum(kc),kitSum(kc),kc.mont*a.access,kc.oc*a.ocF,'vig'); nBays+=1; }
    if(!gis){ const nb=dbl?2:1; add(`${K.bus.label} × ${nb}`,'AIS',nb,'barra',kitSum(K.bus),kitSum(K.bus)*nb,K.bus.mont*nb*a.access,K.bus.oc*nb*a.ocF,'vig'); } }
  // transformadores
  const tp=trafoPriceAT(kv,a.mva,a.wind,a.sec);
  const trLabel= kv===500? `Banco de autotransformadores monofásicos 500/220/${a.sec||'33'} kV, ${a.mva} MVA (3 × ${(a.mva/3).toFixed(0)} MVA) × ${nT}` : `Transformador de potencia ${kv}/${a.sec}${a.wind===3?'/MT':''} kV, ${a.mva} MVA ONAN/ONAF con OLTC × ${nT}`;
  add(trLabel,kv===500?'TMT-500MATMT':(kv===220?'TPD/TPT-220':'TPD/TPT-138'),nT,'und',tp.usd,tp.usd*nT,(K.trafoMont.fixed+K.trafoMont.perMva*a.mva)*nT*a.access,(K.trafoOc.fixed+K.trafoOc.perMva*a.mva)*nT*a.ocF,'curve',tp.src);
  if(K.avr) add(`Tablero regulador de tensión (AVR) × ${nT}`,K.avr.code,nT,'und',K.avr.price,K.avr.price*nT,1500*nT,0,K.avr.flag);
  // bahías de secundario (AT/MT) del transformador: se estiman con el kit del nivel secundario cuando es 138/60 kV; para MT, celdas
  if(a.sec===138||a.sec===60){ const sk= a.sec===138? OSI.atKit[138].bayT : OSI.setKit.bay60T; const s=kitSum(sk); add(`Bahía de transformador ${a.sec} kV AIS (lado secundario) × ${nT}`,'AIS',nT,'bahía',s,s*nT,sk.mont*nT*a.access,sk.oc*nT*a.ocF,'vig'); nBays+=nT; }
  else if(a.sec===220){ const sk=OSI.atKit[220].bayT; const s=kitSum(sk); add(`Bahía de transformador 220 kV AIS (lado secundario) × ${nT}`,'AIS',nT,'bahía',s,s*nT,sk.mont*nT*a.access,sk.oc*nT*a.ocF,'vig'); nBays+=nT; }
  else { const cells=OSI.setKit.cells['23|CMC']; const nC=nT+4+1; add(`Celdas MT 22.9 kV (llegada ×${nT}, salidas ×4, medición ×1)`,'CMC023',nC,'und',cells.SA.price,cells.SA.price*nC,OSI.setKit.cellMont*nC*a.access,OSI.setKit.cellOc*nC*a.ocF,'vig'); }
  // reactores
  if(a.react>0&&K.reactor){ if(kv===500){ const per=a.react/3; const ks=Object.keys(K.reactor.pts).map(Number); const kk=ks.reduce((b,x)=>Math.abs(x-per)<Math.abs(b-per)?x:b,ks[0]); const u=K.reactor.pts[kk]*Math.pow(per/kk,0.6); add(`Banco de reactores de línea 500 kV ${a.react} MVAr (3 × ${per.toFixed(0)} MVAr) + reactor de neutro`,'RMC500 + RMN500',1,'banco',u*3+K.reactor.neutral,u*3+K.reactor.neutral,90000*a.access,120000*a.ocF,'vig',K.reactor.note); add('Bahía de reactor 500 kV (interruptor y medio)','AIS',1,'bahía',kitSum(K.bayT),kitSum(K.bayT),K.bayT.mont*a.access,K.bayT.oc*a.ocF,'vig'); nBays+=1; }
    else { const ks=Object.keys(K.reactor.pts).map(Number); const kk=ks.reduce((b,x)=>Math.abs(x-a.react)<Math.abs(b-a.react)?x:b,ks[0]); const u=K.reactor.pts[kk]*Math.pow(a.react/kk,0.6); add(`Reactor trifásico ${kv} kV ${a.react} MVAr`,K.reactor.unit,1,'und',u,u,25000*a.access,35000*a.ocF,'nd',K.reactor.note); } }
  add('Servicios auxiliares CA/CC',`lote ${kv} kV`,1,'glb',K.ssaa.sup,K.ssaa.sup,K.ssaa.mont*a.access,0,'mix',K.ssaa.desc);
  add('Automatización, protección de barras, teleprotección y comunicaciones',`lote ${kv} kV`,1,'glb',K.scada.sup,K.scada.sup,K.scada.mont,0,'exp',K.scada.desc);
  const ar= gis? K.area.gis : K.area.ais; const patio=ar.base+ar.perBay*nBays+ar.perTrafo*nT; const earth=patio*K.earthM2; add('Malla de puesta a tierra',`${K.earthM2} USD/m²`,patio,'m²',K.earthM2,earth,earth*0.6,0,'exp');
  const O=K.oc; const ocRows=[]; const ocAdd=(k,q,u,pu)=>{ const v=q*pu*a.ocF; ocRows.push({k,qty:q,unit:u,pu,tot:v}); oc+=v; };
  ocAdd('Explanación, nivelación, relleno y grava del patio',patio,'m²',O.patioM2); ocAdd('Casa de control y sala de tableros / celdas',O.controlBase,'m²',O.controlM2); if(gis) ocAdd('Edificio GIS',O.gisBase+O.gisPerBay*nBays,'m²',O.gisM2);
  ocAdd('Canalizaciones, buzones y ductos',nBays,'bahía',O.canalBay); ocAdd('Cerco perimétrico y portón',4*Math.sqrt(patio*1.3),'m',O.fenceUsdM); ocAdd('Vías internas, drenaje e iluminación',patio,'m²',O.roadsM2); ocAdd('Acceso vehicular externo',a.accessM||300,'m',O.accessUsdM);
  const pruebas=equipos*0.012; montaje+=pruebas; rows.push({k:'Pruebas funcionales y puesta en servicio (1.2 %)',code:'—',qty:1,unit:'glb',pu:pruebas,sum:0,mont:pruebas,oc:0});
  const imp=a.impSet/100; const aranc=equipos*imp*P.arancel, aduana=equipos*imp*P.aduana; const fletes=equipos*P.flete[a.zone]*1.4; const ing=(equipos+aranc+aduana+fletes+montaje+oc)*P.ingSet;
  const directo1=equipos+aranc+aduana+fletes+montaje+oc+ing; const land1=patio*1.3*a.landP;
  const n=a.nSet; const mul=v=>v*n;
  return {kind:'setAT',kv,n,rows,ocRows,equipos:mul(equipos),aranc:mul(aranc),aduana:mul(aduana),fletes:mul(fletes),montaje:mul(montaje),oc:mul(oc),ing:mul(ing),directo:mul(directo1),land:mul(land1),patio,nBays,mvaTot:a.mva*nT*n,trafo:tp,gis,dbl,im,perSet:directo1,label:`SET ${kv}/${a.sec} kV ${gis?'GIS':'AIS'} · ${nT}×${a.mva} MVA · ${nL} línea(s)${n>1?` × ${n} subestaciones`:''}`};
}
function estimateExtAT(a){
  if(!a.nExt) return null; const K=OSI.atKit[a.kv]; const P=OSI.pct; const k=K.bay; const sup=(k.items.reduce((s,i)=>s+i.price,0)+(k.barras||0))*a.nExt;
  const montaje=k.mont*a.nExt*a.access*1.15, oc=k.oc*a.nExt*a.ocF*1.3; const aranc=sup*0.8*P.arancel, aduana=sup*0.8*P.aduana, fletes=sup*P.flete[a.zone]*1.4; const ing=(sup+aranc+aduana+fletes+montaje+oc)*P.ingSet;
  return {kind:'extAT',equipos:sup,aranc,aduana,fletes,montaje,oc,ing,directo:sup+aranc+aduana+fletes+montaje+oc+ing,n:a.nExt,label:`${k.label} en subestación existente × ${a.nExt}`};
}
window.estimateSetAT=estimateSetAT; window.estimateExtAT=estimateExtAT;
