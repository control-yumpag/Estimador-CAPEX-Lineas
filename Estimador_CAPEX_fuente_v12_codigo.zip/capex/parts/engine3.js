/* ===================== ENGINE SE: subestaciones con módulos COES (celdas AIS/GIS 60–500 kV, transformadores, bancos y reactores) ===================== */
const SE_DB = JSON.parse(document.getElementById('sedb').textContent);
const SE_MODS = SE_DB.mods;
const SE_BY_ID = Object.fromEntries(SE_MODS.map(m => [m.id, m]));
const SE_TYPES = {L:'Celda de línea', T:'Celda de transformación', A:'Celda de acople', RB:'Celda reactor de barra', MB:'Celda de medición de barras', RL:'Celda reactor de línea'};
const SE_CFG_LABEL = {SB:'Simple barra', DB:'Doble barra', DT:'Doble barra + seccionador de transferencia', IM1:'1/3 (interruptor y medio, 1 interruptor)', IM2:'2/3 (interruptor y medio, 2 interruptores)'};
function seCfgKey(cfg){ if(!cfg) return null; if(/^1\/3/.test(cfg)) return 'IM1'; if(/^2\/3/.test(cfg)) return 'IM2'; if(/transferencia/.test(cfg)) return 'DT'; if(/^Doble/.test(cfg)) return 'DB'; if(/^Simple/.test(cfg)) return 'SB'; return null; }
/* configuraciones disponibles por nivel (según la base COES) */
const SE_CFGS = {60:['SB','DB'], 138:['SB','DB'], 220:['SB','DB','DT'], 500:['IM1','IM2']};
const SE_KA = {220:[31.5,40,63]};
/* grupos de escalamiento por ítem del módulo (PRICE.GROUPS): equipos AT, transformadores, estructuras, PAT, OC, montaje, servicios */
function seGroupOf(code){
  if(/^2\.1/.test(code)) return 'trafo';          // transformadores, bancos y reactores
  if(/^2\.2/.test(code)) return 'hv';             // interruptores, seccionadores, TC/TT, pararrayos, trampas, aisladores, módulos GIS
  if(/^2\.3\.1/.test(code)) return 'eq';          // control, protección y medición
  if(/^2\.3\.2/.test(code)) return 'steelT';      // estructuras metálicas, barras y cable de guarda
  if(/^2\.3\.3/.test(code)) return 'cu';          // puesta a tierra
  return 'eq';                                     // contraincendio, transporte, otros
}
function seItemGroup(code, desc){ const d=(desc||'').toLowerCase(); if(/estructuras|barras|cable de guarda/.test(d)) return 'steelT'; if(/puesta a tierra/.test(d)) return 'cu'; if(/contraincendio/.test(d)) return 'eq'; return seGroupOf(code); }

/* ---- selección de módulos ---- */
function seScore(m, q){
  if(m.kv!==q.kv || m.type!==q.type) return -1;
  let s=0;
  if(m.tech===q.tech) s+=500; else s+=0;
  if(q.zone && m.zone===q.zone) s+=120;
  const mc=seCfgKey(m.cfg); if(q.cfg && mc===q.cfg) s+=200; else if(q.cfg && mc && ((q.cfg==='DT'&&mc==='DB')||(q.cfg==='DB'&&mc==='DT'))) s+=90; else if(q.cfg&&mc&&q.cfg.startsWith('IM')&&mc.startsWith('IM')) s+=90;
  if(q.ka!=null && m.ka!=null){ s+= m.ka===q.ka? 60 : Math.max(0,40-Math.abs(m.ka-q.ka)); } else if(q.ka==null && m.ka==null) s+=20; else if(m.ka==null) s+=10;
  return s;
}
function seFindCell(q){ let best=null,bs=-1; for(const m of SE_MODS){ if(!/^Celda/.test(m.type)) continue; const sc=seScore(m,q); if(sc>bs){ bs=sc; best=m; } } return best; }
/* transformadores: módulos trifásicos (T3) y bancos monofásicos (T1) por kV, secundario y MVA; interpolación log-lineal por MVA entre módulos vecinos */
function seTrafoCands(kv, kind, sec){ return SE_MODS.filter(m=> (kind==='bank'? m.type==='Banco de transformadores' : m.type==='Transformador') && m.kv===kv && (sec==null || m.sec==null || m.sec===sec)); }
function seUnitMva(m){ return m.type==='Banco de transformadores' ? 3*(m.bank||m.mva||0) : (m.mva||0); }
function seScaleByCap(cands, cap, zone, capOf, expo){
  const same=cands.filter(m=>m.zone===zone); const pool= same.length? same : cands; if(!pool.length) return null;
  const srt=[...pool].sort((a,b)=>capOf(a)-capOf(b));
  let lo=null,hi=null; for(const m of srt){ if(capOf(m)<=cap) lo=m; if(capOf(m)>=cap&&!hi) hi=m; }
  const base= lo&&hi? (Math.abs(capOf(lo)-cap)<=Math.abs(capOf(hi)-cap)? lo: hi) : (lo||hi);
  let f;
  if(lo&&hi&&lo!==hi){ const x0=Math.log(capOf(lo)), x1=Math.log(capOf(hi)), x=Math.log(cap); const y0=Math.log(lo.tot), y1=Math.log(hi.tot); const y=y0+(y1-y0)*(x-x0)/(x1-x0); f=Math.exp(y)/base.tot; }
  else { f=Math.pow(cap/capOf(base), expo); }
  return {mod:base, f, lo, hi, exact: capOf(base)===cap};
}
function seFindTrafo(q){ const c=seTrafoCands(q.kv,q.kind,q.sec); if(!c.length) return null; return seScaleByCap(c, q.mva, q.zone, seUnitMva, 0.55); }
function seFindReactor(q){ const c=SE_MODS.filter(m=>m.type==='Reactor'&&m.kv===q.kv); if(!c.length) return null; return seScaleByCap(c, q.mvar, q.zone, m=>m.bank? 3*m.bank : (m.mvar||0), 0.6); }

/* ---- costo de un módulo con factor de escala para los equipos principales (2.1 y su transporte) ---- */
function seModuleCost(m, fMain){
  fMain = fMain||1;
  const out={sup:0,oc:0,em:0,insp:0,prueb:0,est:0,perm:0,tot:0,groups:{}};
  const add=(g,v)=>{ if(v>0) out.groups[g]=(out.groups[g]||0)+v; };
  for(const [k,v] of Object.entries(m.it)){
    const [sup,oc,em,tot,d]=v; if(k==='7.0'||/^\d\.0$/.test(k)&&!/^[3456]\.0$/.test(k)) continue;
    if(/^1\./.test(k)){ const c=oc||tot||0; out.oc+=c; add('civ',c); continue; }
    if(/^2\./.test(k)){ if(k==='2.2'||k==='2.3'||k==='2.1') continue; const f=(/^2\.1/.test(k)||k==='2.4')? fMain : 1;
      if(sup){ out.sup+=sup*f; add(seItemGroup(k,d),sup*f); } if(em){ out.em+=em*f; add('lab',em*f); } if(oc){ out.oc+=oc; add('civ',oc); } continue; }
    if(k==='3.0'){ out.insp+=tot||0; add('svc',tot||0); } else if(k==='4.0'){ out.prueb+=tot||0; add('svc',tot||0); }
    else if(k==='5.0'){ out.est+=tot||0; add('svc',tot||0); } else if(k==='6.0'){ out.perm+=tot||0; add('svc',tot||0); }
  }
  out.tot=out.sup+out.oc+out.em+out.insp+out.prueb+out.est+out.perm;
  return out;
}

/* ---- obras comunes (referencias 4.x de los módulos COES) ---- */
const SE_COM = SE_DB.comunes;
function seComunesUnit(){
  const c=SE_COM;
  const pick=(items,re)=>items.find(i=>re.test(i.d)); const pu=(items,re)=>{ const i=pick(items,re); return i? i.pu : 0; };
  return {
    corte: pu(c.plataforma.items,/Corte masivo/i), relleno: pu(c.plataforma.items,/Relleno con material propio/i), prestamo: pu(c.plataforma.items,/préstamo/i), elim: pu(c.plataforma.items,/Eliminaci/i),
    ripioM2: pu(c.ripio.items,/ripio/i),
    accesoM2: c.acceso.tot/817.61,                 // camino de acceso afirmado + sub base + base + cunetas, por m² de vía
    cercoMl: c.cerco.tot/c.cerco.ml,               // muro de ladrillo caravista completo (cimiento, columnas, vigas, tarrajeo, pintura, puertas, concertina)
    canalMl: c.canaletas.tot/c.canaletas.ml,       // canaletas de cables y buzones con tapas
    viasM2: c.vias.tot/c.vias.m2,                  // vías internas asfaltadas (sub base, base, bicapa, sardineles)
    patMl: c.pat.tot/c.pat.ml,                     // montaje de malla (sin conductor)
    edifM2: c.edificio.tot/c.edificio.m2,          // edificio de control, obra civil
    caseta: c.caseta.tot,
    inst: c.inst.tot
  };
}
function seComunes(inp, nBays, nTr, kv){
  const U=seComunesUnit(); const rows=[];
  const add=(k,name,u,q,pu,g,note)=>{ const tot=q*pu; rows.push({k,name,u,q,pu,tot,g,note}); return tot; };
  if(!inp.nueva) return {rows,tot:0,area:0,U};
  const area=inp.areaAuto? seAreaAuto(kv,inp.tech,nBays,nTr) : inp.area;
  const per=Math.sqrt(Math.max(1,area))*4*1.05;
  const hCut=inp.hCut, hFill=inp.hFill;                       // alturas medias de corte / relleno (m)
  add('corte','Corte masivo de plataforma en terreno normal','m³',area*hCut,U.corte,'civ','precio COES; volumen = área × altura media de corte');
  add('relleno','Relleno compactado con material propio','m³',area*hFill,U.relleno,'civ','');
  add('elim','Eliminación de material excedente','m³',Math.max(0,area*(hCut-hFill*0.8)),U.elim,'civ','excedente = corte − 80 % del relleno');
  add('ripio','Capa de ripio e = 10 cm en patio','m²',area*0.9,U.ripioM2,'civ','90 % del área de plataforma');
  add('cerco',inp.cerco==='muro'?'Cerco perimétrico de albañilería (muro caravista, puertas, concertina)':'Cerco perimétrico de malla galvanizada con concertina','m',per,inp.cerco==='muro'?U.cercoMl:U.cercoMl*0.22,'civ',inp.cerco==='muro'?'precio COES por metro':'≈ 22 % del muro (juicio de experto)');
  add('vias','Vías internas y patio de maniobras (asfalto bicapa, bases y sardineles)','m²',area*inp.viasPct/100,U.viasM2,'civ',`${inp.viasPct} % del área`);
  add('canal','Canaletas de cables y buzones con tapas','m',inp.canalMl>0? inp.canalMl : 60*nBays+40*nTr+120,U.canalMl,'civ','60 m por celda + 40 m por transformador + 120 m');
  add('pat','Malla de puesta a tierra: excavación, tendido y soldaduras (sin conductor)','m',area*0.35,U.patMl,'civ','≈ 0.35 m de conductor por m² de patio');
  add('patCu','Conductor de cobre desnudo 120 mm² para malla','m',area*0.35,11.85,'cu','precio COES del conductor');
  add('acceso','Camino de acceso afirmado (6 m de ancho) con cunetas','m²',inp.accesoM*6,U.accesoM2,'civ','longitud × 6 m');
  add('edif',kv>=138?'Edificio de control (obra civil completa)':'Edificio / sala de control (obra civil completa)','m²',inp.edifM2,U.edifM2,'civ','m² de edificio');
  if(inp.caseta) add('caseta','Caseta de campo / sala de tableros','glb',1,U.caseta,'civ','');
  add('inst','Instalaciones eléctricas de patio y edificio (iluminación, tomacorrientes, ductos)','glb',1,U.inst+22000,'eq','referencia COES + iluminación de patio (juicio de experto)');
  const tot=rows.reduce((a,r)=>a+r.tot,0);
  return {rows,tot,area,per,U};
}
function seAreaAuto(kv,tech,nBays,nTr){ const base= kv===500? (tech==='GIS'?6000:25000) : kv===220? (tech==='GIS'?3500:12000) : kv===138? (tech==='GIS'?2500:7000) : (tech==='GIS'?1800:4500); const perBay= kv===500? (tech==='GIS'?400:3000) : kv===220? (tech==='GIS'?250:1800) : kv===138? (tech==='GIS'?180:1100) : (tech==='GIS'?120:700); const perTr= kv===500? 2500 : kv===220? 1200 : 800; return base+perBay*nBays+perTr*nTr; }

/* ---- estimado de la subestación ---- */
function estimateSe(inp){
  const kv=inp.kv, zone=inp.zone, tech=inp.tech; const cfg=inp.cfg; const ka=inp.ka;
  const rows=[]; const EW={}; const addW=(g,v)=>{ if(v>0) EW[g]=(EW[g]||0)+v; };
  const addMod=(key,label,m,n,f,note)=>{ if(!m||!(n>0)) return null; const c=seModuleCost(m,f); const row={key,label,mod:m,n,f:f||1,unit:'celda',c,sup:c.sup*n,oc:c.oc*n,em:c.em*n,insp:c.insp*n,prueb:c.prueb*n,est:c.est*n,perm:c.perm*n,tot:c.tot*n,note:note||''}; rows.push(row); for(const [g,v] of Object.entries(c.groups)) addW(g,v*n); return row; };
  const cells=[['L',inp.nL,'Celdas de línea'],['T',inp.nT,'Celdas de transformación (lado '+kv+' kV)'],['A',inp.nA,'Celdas de acople / seccionamiento'],['RB',inp.nRB,'Celdas de reactor de barra'],['MB',inp.nMB,'Celdas de medición de barras'],['RL',inp.nRL,'Celdas de reactor de línea']];
  const missing=[];
  cells.forEach(([k,n,label])=>{ if(!(n>0)) return; const m=seFindCell({kv,tech,type:SE_TYPES[k],zone,cfg,ka}); if(!m){ missing.push(label); return; } const alt= m.tech!==tech? ` (sin módulo ${tech} en la base: se usa ${m.tech})` : ''; addMod(k,label,m,n,1,alt); });
  // transformadores (COES ≥ 138 kV; para 60 kV, o sin módulo COES, transformador BDME Osinergmin + montaje y OC paramétricos)
  let trSel=null;
  if(inp.nTr>0 && (kv===60 || !seTrafoCands(kv,inp.trKind,inp.sec).length) && typeof trafoPrice==='function' && typeof OSI!=='undefined'){
    const tp=trafoPrice(inp.mva, kv===33?33:60, inp.wind||2, 'bdme'); const S=OSI.setKit; const mont=(S.trafoMont.fixed+S.trafoMont.perMva*inp.mva), ocT=(S.oc.trafoFix+S.oc.trafoPerMva*inp.mva); const avr=(S.avr&&S.avr.price)||0; const sup=tp.usd*(1+(inp.impSet||0)/100*0.061)+avr;
    const row={key:'TR',label:`Transformador de potencia ${kv}/${inp.sec||'MT'} kV · ${inp.mva} MVA (BDME Osinergmin)`,mod:null,n:inp.nTr,f:1,unit:'und',sup:sup*inp.nTr,oc:ocT*inp.nTr,em:mont*inp.nTr,insp:0,prueb:0,est:0,perm:0,tot:(sup+ocT+mont)*inp.nTr,note:tp.src+'; montaje y obras civiles paramétricos BDME'};
    rows.push(row); addW('trafo',sup*inp.nTr); addW('lab',mont*inp.nTr); addW('civ',ocT*inp.nTr); trSel={osi:true,src:tp.src};
  } else if(inp.nTr>0){ trSel=seFindTrafo({kv,kind:inp.trKind,sec:inp.sec,mva:inp.mva,zone}); if(trSel){ const kind= inp.trKind==='bank'?'Banco de 3 transformadores monofásicos':'Transformador trifásico'; addMod('TR',`${kind} ${kv}/${inp.sec||'—'} kV · ${inp.mva} MVA`,trSel.mod,inp.nTr,trSel.f,trSel.exact?'':`escalado desde ${seUnitMva(trSel.mod)} MVA (interpolación log-lineal ${trSel.lo&&trSel.hi&&trSel.lo!==trSel.hi?'entre módulos vecinos':'exponente 0.55'})`); } else missing.push('transformadores '+kv+' kV'); }
  // reactores
  let rxSel=null;
  if(inp.nRx>0){ rxSel=seFindReactor({kv,mvar:inp.mvar,zone}); if(rxSel){ addMod('RX',`Reactor ${kv} kV · ${inp.mvar} MVAr`,rxSel.mod,inp.nRx,rxSel.f,rxSel.exact?'':`escalado desde ${rxSel.mod.bank?3*rxSel.mod.bank:rxSel.mod.mvar} MVAr`); } else missing.push('reactores '+kv+' kV'); }
  // celdas MT (lado secundario, kits Osinergmin)
  let mt=null;
  if(inp.nMT>0 && typeof OSI!=='undefined' && OSI.setKit && OSI.setKit.cells){ const key= inp.mtKv===22.9? '23|CMC' : (Object.keys(OSI.setKit.cells).find(k=>k.startsWith('10'))||'23|CMC'); const cells2=OSI.setKit.cells[key]; if(cells2){ const unit=(cells2.SA&&cells2.SA.price)||0; const mont=(OSI.setKit.cellMont||1500), oc=(OSI.setKit.cellOc||800); mt={n:inp.nMT,unit,mont,oc,tot:inp.nMT*(unit+mont+oc),label:`Celdas MT ${inp.mtKv} kV (BDME ${key.split('|')[1]})`}; rows.push({key:'MT',label:mt.label,mod:null,n:inp.nMT,f:1,unit:'celda',sup:inp.nMT*unit,oc:inp.nMT*oc,em:inp.nMT*mont,insp:0,prueb:0,est:0,perm:0,tot:mt.tot,note:'kit Osinergmin BDME (celda metal-clad con interruptor, protección y medición)'}); addW('eq',inp.nMT*unit); addW('lab',inp.nMT*mont); addW('civ',inp.nMT*oc); } }
  const nBays=rows.filter(r=>/^(L|T|A|RB|MB|RL)$/.test(r.key)).reduce((a,r)=>a+r.n,0);
  // obras comunes
  const com=seComunes(inp,nBays,inp.nTr,kv); com.rows.forEach(r=>addW(r.g,r.tot));
  // precios y marcas (actualización de cotizaciones a la fecha base) por grupo
  const PF = window.PRICE ? {f:Object.fromEntries(Object.keys(EW).map(g=>[g,PRICE.factor(g,'coes')]))} : {f:{}};
  const fOf=g=>PF.f[g]||1;
  let escF=1; { const num=Object.entries(EW).reduce((a,[g,v])=>a+v*fOf(g),0), den=Object.values(EW).reduce((a,v)=>a+v,0)||1; escF=num/den; }
  // aplicar factores de precio a filas (aprox.: factor medio ponderado del módulo por grupo)
  const fRow=r=>{ if(!r.c) return 1; const grs=r.c.groups; const num=Object.entries(grs).reduce((a,[g,v])=>a+v*fOf(g),0), den=Object.values(grs).reduce((a,v)=>a+v,0)||1; return num/den; };
  rows.forEach(r=>{ const f= r.key==='MT'? 1 : fRow(r); r.pf=f; ['sup','oc','em','insp','prueb','est','perm','tot'].forEach(k=>{ r[k+'0']=r[k]; r[k]*=f; }); });
  com.rows.forEach(r=>{ const f=fOf(r.g); r.pf=f; r.tot0=r.tot; r.tot*=f; }); com.tot=com.rows.reduce((a,r)=>a+r.tot,0);
  Object.keys(EW).forEach(g=>EW[g]*=fOf(g));
  const sumSup=rows.reduce((a,r)=>a+r.sup,0), sumOc=rows.reduce((a,r)=>a+r.oc,0)+com.rows.filter(r=>r.g==='civ').reduce((a,r)=>a+r.tot,0), sumEm=rows.reduce((a,r)=>a+r.em,0), sumPP=rows.reduce((a,r)=>a+r.insp+r.prueb,0);
  const comOther=com.rows.filter(r=>r.g!=='civ').reduce((a,r)=>a+r.tot,0);
  const estMod=rows.reduce((a,r)=>a+r.est+r.perm,0);          // 5.0 + 6.0 de los módulos: expediente técnico, ingeniería, EO, concesión, permisos ambientales, CIRA
  const F=sumSup+sumOc+sumEm+sumPP+comOther;                   // directo contratista (APU sin GG/U)
  const obras=sumOc+sumEm+sumPP;
  const G=obras*inp.gg/100;                                    // GG + U sobre obras (suministros con precios de mercado)
  const allowQ=(F+G)*inp.allowQ/100, allowP=(F+G)*inp.allowP/100;
  const directo=F+G+allowQ+allowP;                             // 1
  const ind=directo*inp.ind/100, owner=directo*inp.owner/100;
  const est=estMod*(1+inp.eng/100);                            // ingeniería/estudios/permisos (COES 5.0 + 6.0) + extra del dueño
  const indirecto=ind+owner+est;                               // 2
  const A=directo+indirecto;
  // pesos de escalamiento: distribuir G, allowances e indirectos
  { const kA=(F+G)>0? directo/(F+G):1; if(obras>0){ addW('civ',G*sumOc/obras); addW('lab',G*(sumEm+sumPP)/obras); } Object.keys(EW).forEach(g=>EW[g]*=kA); addW('svc',ind+owner+est); const sW=Object.values(EW).reduce((a,b)=>a+b,0)||1; Object.keys(EW).forEach(g=>EW[g]*=A/sW); }
  const escDet=(window.ESC&&window.PROJ)? ESC.forEstimate(EW) : null;
  const esc= escDet? escDet.esc : A*inp.esc/100, risk=A*inp.risk/100;
  const B=A+esc+risk; const cont=B*inp.cont/100; const C=B+cont; const D=C*inp.phase/100; const E=C+D; const igv=E*inp.igv/100;
  const coesEq=rows.reduce((a,r)=>a+r.tot,0);                  // suma de módulos COES (equivale al "total costo" de los módulos, con 5.0 y 6.0)
  const mvaTot=inp.nTr*inp.mva;
  const land= inp.nueva? com.area*inp.landFactor*inp.landUsd : 0;   // terreno: referencia, excluido del estimado
  return {inp,rows,com,missing,trSel,rxSel,mt,nBays,EW,escW:EW,escF,priceF:PF.f,priceYear:window.PRICE?PRICE.year:2026,
    sumSup,sumOc,sumEm,sumPP,comOther,estMod,F,G,allowQ,allowP,directo,ind,owner,est,indirecto,A,esc,escDet,risk,B,cont,C,D,E,igv,ET:E+igv,
    coesEq,mvaTot,land,usdBay: nBays? E/nBays : null, usdMva: mvaTot? E/mvaTot : null, directBay: nBays? directo/nBays : null};
}

/* ---- paquetes de riesgo (PERT / Monte Carlo) ---- */
function riskPackagesSe(R){
  const mult=1+R.inp.gg/100; const scaleD=(R.F+R.G)>0? R.directo/(R.F+R.G) : 1;
  const trRows=R.rows.filter(r=>r.key==='TR'||r.key==='RX'), cellRows=R.rows.filter(r=>r.key!=='TR'&&r.key!=='RX');
  const pk=[
    {k:'eq', name:'Equipos de patio y celdas (suministro)', base: cellRows.reduce((a,r)=>a+r.sup,0)*scaleD},
    {k:'tr', name:'Transformadores y reactores (suministro)', base: trRows.reduce((a,r)=>a+r.sup,0)*scaleD},
    {k:'civ', name:'Obras civiles, plataforma, edificios y comunes', base:(R.sumOc*mult+R.comOther)*scaleD},
    {k:'em', name:'Montaje electromecánico, pruebas y puesta en servicio', base:(R.sumEm+R.sumPP)*mult*scaleD},
    {k:'ind', name:'Costos indirectos y del dueño', base:R.ind+R.owner},
    {k:'est', name:'Expediente técnico, ingeniería, EO, concesión y permisos', base:R.est},
    {k:'esc', name:'Escalamiento y provisión por riesgos', base:R.esc+R.risk}
  ];
  return pk.filter(p=>p.base>0);
}
const RISK3_DEFAULT = {
  5:{eq:[-20,45],tr:[-15,45],civ:[-25,80],em:[-20,60],ind:[-15,50],est:[-15,60],esc:[-30,80],sys:[-15,45]},
  4:{eq:[-15,30],tr:[-12,35],civ:[-20,55],em:[-15,45],ind:[-12,35],est:[-12,45],esc:[-25,60],sys:[-12,32]},
  3:{eq:[-10,22],tr:[-8,25],civ:[-15,40],em:[-12,32],ind:[-10,25],est:[-10,30],esc:[-20,40],sys:[-8,20]},
  2:{eq:[-6,12],tr:[-5,15],civ:[-10,22],em:[-8,18],ind:[-6,14],est:[-6,18],esc:[-15,28],sys:[-5,11]},
  1:{eq:[-3,7],tr:[-3,8],civ:[-5,12],em:[-4,10],ind:[-3,8],est:[-3,9],esc:[-10,16],sys:[-3,6]}
};
window.estimateSe=estimateSe; window.riskPackagesSe=riskPackagesSe;
