/* ===================== ESCALAMIENTO: de la fecha base de precios al año (o años) de ejecución — ítem 3 de la EDT ===================== */
window.ESC=(function(){
  const Y0=2025;
  /* Conjunto alternativo de índices: CRU – CAPEX & Construction Escalation, Table 1 Construction Escalation Index (abril 2025), tabla aportada por el
     usuario (valores nominales, 2025 = 100, 2025–2036). Fuera del rango se extrapola con la última tasa anual. */
  const CRU={src:'CRU International – CAPEX & Construction Escalation (abril 2025), Table 1: Construction Escalation Index, valores nominales 2025 = 100 (tabla aportada por el usuario)',
    years:[2025,2026,2027,2028,2029,2030,2031,2032,2033,2034,2035,2036],
    items:{
      pm:    {label:'Project management',              v:[100,101.97,104.05,106.28,108.44,111.16,114.23,117.52,120.97,124.57,128.28,132.12]},
      cons:  {label:'Construction & installation cost',v:[100,101.95,104.88,107.78,109.99,113.19,116.26,119.74,123.52,127.51,131.71,136.01]},
      lab:   {label:'Construction labour cost',        v:[100,104.75,110.88,117.12,122.93,130.17,138.16,146.81,156.09,166.01,176.59,187.85]},
      eq:    {label:'Construction equipment',          v:[100,100.23,101.48,103.57,105.63,108.39,111.59,115.08,118.82,122.85,126.35,130.04]},
      steel: {label:'Structural steel price',          v:[100,104.33,109.42,111.11,111.63,116.20,128.30,137.59,145.25,151.78,157.83,163.81]},
      rebar: {label:'Steel rebar',                     v:[100,98.14,97.36,97.16,99.12,103.17,113.92,122.17,128.97,134.76,140.14,145.45]},
      hrc:   {label:'Steel hot-rolled coil (HRC)',     v:[100,97.98,95.92,97.11,97.70,106.07,109.97,113.61,117.27,120.52,123.96,127.90]},
      cu:    {label:'Copper cable',                    v:[100,103.27,113.30,126.95,143.49,125.03,124.00,122.83,121.56,120.11,123.14,127.87]},
      cem:   {label:'Cement index',                    v:[100,102.20,104.66,108.23,110.64,113.94,117.49,121.25,125.20,129.20,133.38,137.67]},
      diesel:{label:'Diesel (USD/L)',                  v:[100,99.42,100.87,116.44,120.37,127.61,134.56,141.02,147.68,152.96,158.87,164.59]}
    }};
  /* grupo de costo del estimador → serie CRU (null = sin serie CRU; se usa el índice compuesto del estimador, p. ej. aluminio LME) */
  const CRU_MAP={steelT:'steel',steelW:'steel',opgw:null,conc:'cem',wood:'cons',alu:null,ins:'cons',cu:'cu',eq:'eq',lab:'lab',civ:'cons',svc:'pm',land:'pm'};
  const SETS={est:'Índices del estimador (LME, BLS CPI-U, INEI) con tasas anuales futuras editables en «Precios y marcas»',cru:CRU.src};

  function estIndex(g,y){ const G=PRICE.GROUPS[g]||PRICE.GROUPS.eq; let f=0; for(const [k,w] of Object.entries(G.comp)) f+=w*PRICE.idxVal(k,y)/PRICE.idxVal(k,Y0); return 100*f; }
  function cruIndex(g,y){ const key=CRU_MAP[g]; if(!key) return estIndex(g,y); const s=CRU.items[key].v; const i=Math.round(y)-Y0;
    if(i<=0) return s[0]*Math.pow(s[1]/s[0],i); if(i<s.length) return s[i]; const gr=s[s.length-1]/s[s.length-2]; return s[s.length-1]*Math.pow(gr,i-(s.length-1)); }
  /* índice anual (promedio del año) del grupo g, 2025 = 100 */
  function index(g,y,set){ return set==='cru'? cruIndex(g,y) : estIndex(g,y); }
  function srcLabel(g,set){ if(set==='cru'){ const key=CRU_MAP[g]; if(key) return `CRU · ${CRU.items[key].label}`; return 'LME aluminio + CPI-U (sin serie CRU)'; } const G=PRICE.GROUPS[g]||PRICE.GROUPS.eq; return Object.entries(G.comp).map(([i,w])=>`${Math.round(w*100)} % ${PRICE.IDX[i].label.split(' (')[0]}`).join(' + '); }
  /* años de ejecución y peso de cada año = meses de ejecución que caen en ese año / meses totales */
  function yearWeights(start,n){ const [y0,m0]=start.split('-').map(Number); const cnt={}; for(let i=0;i<n;i++){ const idx=y0*12+(m0-1)+i; const y=Math.floor(idx/12); cnt[y]=(cnt[y]||0)+1; } return Object.keys(cnt).map(y=>({y:+y,months:cnt[y],w:cnt[y]/n})); }

  /* weights: {grupo: USD} cuya suma es el estimado neto A · opt: {baseYear,start:'YYYY-MM',months,set} */
  function compute(weights,opt){
    const set=opt.set||'est'; const base=opt.baseYear; const years=yearWeights(opt.start,opt.months);
    const groups=Object.entries(weights).filter(([g,v])=>v>0); const A=groups.reduce((a,[g,v])=>a+v,0)||1;
    const byGroup=groups.map(([g,W])=>{ const i0=index(g,base,set); const iy=years.map(Y=>({y:Y.y,w:Y.w,i:index(g,Y.y,set),r:index(g,Y.y,set)/i0*100})); const f=iy.reduce((a,q)=>a+q.w*q.i/i0,0)-1; return {g,label:(PRICE.GROUPS[g]||{label:g}).label,src:srcLabel(g,set),W,share:W/A,i0,iy,f,esc:W*f,escalado:W*(1+f)}; }).sort((a,b)=>b.W-a.W);
    const esc=byGroup.reduce((a,r)=>a+r.esc,0);
    const byYear=years.map((Y,j)=>({y:Y.y,w:Y.w,months:Y.months,A:A*Y.w,esc:byGroup.reduce((a,r)=>a+r.W*Y.w*(r.iy[j].i/r.i0-1),0)}));
    const iWE=byGroup.reduce((a,r)=>a+r.share*(1+r.f)*100,0);
    return {set,base,start:opt.start,months:opt.months,years,A,byGroup,byYear,esc,pct:esc/A*100,pctAuto:esc/A*100,iWE,manual:false,before:years[0].y<base};
  }
  function forEstimate(weights){ const p=PROJ.get(); const r=compute(weights,{baseYear:PRICE.year,start:p.start,months:p.months,set:p.set});
    const man=PROJ.manualPct(); if(man!==null){ r.manual=true; r.pct=man; r.esc=r.A*man/100; r.byYear.forEach(Y=>{ Y.esc=r.A*Y.w*man/100; }); } return r; }

  function norm(R){ if(!R) return null; const A=R.d1!==undefined? {directo:R.d1,indirecto:R.d2} : {directo:R.directo,indirecto:R.indirecto}; return {...A,esc:R.esc,risk:R.risk,cont:R.cont,A:R.A,B:R.B,C:R.C,D:R.D,E:R.E,escDet:R.escDet,escF:R.escF,inp:R.inp}; }
  const E=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const yearsTxt=d=>d.years.map(Y=>`${Y.y}: ${(Y.w*100).toFixed(0)} %`).join(' · ');

  function timelineHTML(R,space){ const d=R.escDet; const base=PRICE.year; const cot= space==='A'? 'COES · cotizaciones 2025/26 (base setiembre 2026)' : space==='C'? 'COES · módulos de subestaciones (precios marzo 2026)' : 'Osinergmin BDME · precios 2025 (I-402/I-403)'; const upd=R.escF||1;
    return `<div class="esc-tl">
      <div class="esc-node"><div class="esc-k">Fecha de cotización</div><div class="esc-t">${E(cot)}</div><div class="esc-s">precios de la base de datos, USD sin IGV</div></div>
      <div class="esc-arrow"><span>actualización de precios<br>×${upd.toFixed(3)} (índices por grupo)</span></div>
      <div class="esc-node on"><div class="esc-k">Fecha base del estimado</div><div class="esc-t">precios ${base} (índice = 100)</div><div class="esc-s">A = 1 + 2 = USD ${fmt(d.A)}</div></div>
      <div class="esc-arrow"><span>escalamiento al año de ejecución<br>${d.manual?'manual ':''}+${d.pct.toFixed(2)} % de A</span></div>
      <div class="esc-node end"><div class="esc-k">Ejecución</div><div class="esc-t">${E(PROJ.describe())}</div><div class="esc-s">${E(yearsTxt(d))} · ${d.set==='cru'?'índices CRU':'índices del estimador'}</div></div>
    </div>`; }
  /* tabla principal al estilo de la hoja «Escalam»: ítem · índice · USD · índice base = 100 · índice por año de ejecución · factor · escalamiento · monto escalado */
  function groupTable(R){ const d=R.escDet; const ys=d.years;
    return `<div class="tbl-wrap"><table class="tbl small esc-tbl"><thead><tr><th>Grupo de costo (ítem del estimado)</th><th>Índice de referencia</th><th class="n">USD (precios ${d.base})</th><th class="n">%</th><th class="n">Índice ${d.base}</th>${ys.map(Y=>`<th class="n">Índice ${Y.y}<div class="tiny">${(Y.w*100).toFixed(0)} % ejec.</div></th>`).join('')}<th class="n">Factor</th><th class="n">Escalamiento (USD)</th><th class="n">Monto escalado (USD)</th></tr></thead><tbody>
      ${d.byGroup.map(r=>{ const f= d.manual? 1+d.pct/100 : 1+r.f; return `<tr><td>${E(r.label)}</td><td class="tiny muted">${E(r.src)}</td><td class="n">${fmt(r.W)}</td><td class="n">${(r.share*100).toFixed(1)} %</td><td class="n">100.0</td>${r.iy.map(q=>`<td class="n">${q.r.toFixed(1)}</td>`).join('')}<td class="n">${f.toFixed(4)}</td><td class="n">${fmt(r.W*(f-1))}</td><td class="n">${fmt(r.W*f)}</td></tr>`; }).join('')}
      <tr class="tot"><td>Estimado neto A (1 + 2)</td><td></td><td class="n">${fmt(d.A)}</td><td class="n">100 %</td><td class="n">100.0</td>${ys.map((Y,j)=>`<td class="n">${(d.byGroup.reduce((a,r)=>a+r.share*r.iy[j].r,0)).toFixed(1)}</td>`).join('')}<td class="n">${(1+d.pct/100).toFixed(4)}</td><td class="n">${fmt(d.esc)}</td><td class="n">${fmt(d.A+d.esc)}</td></tr></tbody></table></div>`; }
  function yearTable(R){ const d=R.escDet; return `<div class="tbl-wrap"><table class="tbl small"><thead><tr><th>Año de ejecución</th><th class="n">Meses</th><th class="n">% del estimado</th><th class="n">A ejecutado (USD)</th><th class="n">Escalamiento (USD)</th><th class="n">% de A del año</th></tr></thead><tbody>${d.byYear.map(Y=>`<tr><td>${Y.y}</td><td class="n">${Y.months}</td><td class="n">${(Y.w*100).toFixed(1)} %</td><td class="n">${fmt(Y.A)}</td><td class="n">${fmt(Y.esc)}</td><td class="n">${(Y.esc/Y.A*100).toFixed(2)} %</td></tr>`).join('')}<tr class="tot"><td>Total</td><td class="n">${d.months}</td><td class="n">100 %</td><td class="n">${fmt(d.A)}</td><td class="n">${fmt(d.esc)}</td><td class="n">${d.pct.toFixed(2)} %</td></tr></tbody></table></div>`; }
  function methodText(R){ const d=R.escDet;
    return `<b>Método:</b> cada grupo de costo del estimado neto A tiene un índice de referencia (${d.set==='cru'?'CRU Construction Escalation Index, abril 2025':'índices del estimador: LME, BLS CPI-U e INEI con tasas anuales futuras'}). El índice de la fecha base de precios (${d.base}) se toma como 100 y el de cada año de ejecución se expresa sobre esa base; el factor del grupo es el promedio de los índices de los años de ejecución ponderado por los meses que caen en cada año: 3 = Σ<sub>g</sub> A<sub>g</sub>·(Σ<sub>y</sub> w<sub>y</sub>·I<sub>g</sub>(y)/I<sub>g</sub>(base) − 1). Es el mismo procedimiento de la hoja «Escalam» del CAPEX detallado (ítem × índice × factor año base → año de ejecución). ${d.manual?`<b>Se aplica un escalamiento manual de ${d.pct} % de A (el calculado es ${d.pctAuto.toFixed(2)} %).</b>`:''}${d.before?' <b>Atención:</b> la ejecución empieza antes de la fecha base de precios; el escalamiento puede resultar negativo.':''} La fecha base y la actualización de las cotizaciones se definen en «Precios y marcas»; el inicio y la duración de la ejecución en «Proyecto».`; }
  function indexTable(R){ const d=R.escDet; const y0=Math.min(d.base,d.years[0].y); const y1=Math.max(d.years[d.years.length-1].y,y0+1,d.base+1); const ys=[]; for(let y=y0;y<=y1;y++) ys.push(y);
    return `<div class="tbl-wrap"><table class="tbl small"><thead><tr><th>Grupo</th><th>Índice de referencia</th>${ys.map(y=>`<th class="n">${y}</th>`).join('')}</tr></thead><tbody>${d.byGroup.map(r=>`<tr><td>${E(r.label.split(' (')[0])}</td><td class="tiny muted">${E(r.src)}</td>${ys.map(y=>`<td class="n">${index(r.g,y,d.set).toFixed(1)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="tiny muted" style="margin-top:6px">Valores anuales promedio, 2025 = 100. ${d.set==='cru'?'Los grupos sin serie CRU (aluminio, OPGW) usan el índice compuesto del estimador.':'Tasas futuras y valores observados editables en «Precios y marcas».'}</div>`; }

  function render(el,R0,space){ if(!el) return; const R=norm(R0); if(!R||!R.escDet){ el.innerHTML='<div class="tiny">Sin datos de escalamiento.</div>'; return; } const d=R.escDet;
    el.innerHTML=`<div class="grid g3">
      <div class="card kpi accent"><div class="l">3 · Escalamiento (USD sin IGV)</div><div class="v">${fmt(d.esc)}<small>USD</small></div><div class="d">${d.pct.toFixed(2)} % del estimado neto A${d.manual?' · manual':' · calculado'} · índice ponderado 100 → ${d.iWE.toFixed(1)}</div></div>
      <div class="card kpi"><div class="l">Ejecución</div><div class="v" style="font-size:22px">${E(PROJ.describe())}</div><div class="d">${E(yearsTxt(d))}</div></div>
      <div class="card kpi"><div class="l">A + 3 · estimado neto escalado</div><div class="v">${fmt(d.A+d.esc)}<small>USD</small></div><div class="d">B = A + 3 + 4 = ${fmt(R.B)} · C = ${fmt(R.C)} · E = ${fmt(R.E)}</div></div>
    </div>
    <div class="card" style="margin-top:12px"><div class="head"><h3>Concepto: de la fecha de cotización al año de ejecución</h3><span class="tiny">USD sin IGV · programa en «Proyecto», fecha base en «Precios y marcas»</span></div>${timelineHTML(R,space)}<p class="small" style="margin:10px 0 0">${methodText(R)}</p></div>
    <div class="card" style="margin-top:12px"><div class="head"><h3>Escalamiento por grupo de costo</h3><span class="tiny">${d.set==='cru'?'CRU abr-2025':'índices del estimador'} · índice base ${d.base} = 100</span></div>${groupTable(R)}</div>
    <div class="grid g2" style="margin-top:12px">
      <div class="card"><div class="head"><h3>Distribución por año de ejecución</h3><span class="tiny">peso = meses del programa en cada año</span></div>${yearTable(R)}</div>
      <div class="card"><div class="head"><h3>Índices anuales de referencia (2025 = 100)</h3><span class="tiny">${E(SETS[d.set].split(',')[0])}</span></div>${indexTable(R)}</div>
    </div>`;
  }
  /* sección para el informe imprimible */
  function report(R0,space){ const R=norm(R0); if(!R||!R.escDet) return ''; return `<div class="esc-blk"><h2>Escalamiento al año de ejecución</h2>${timelineHTML(R,space)}<p class="small">${methodText(R)}</p></div><div class="esc-blk"><h3>Escalamiento por grupo de costo</h3>${groupTable(R)}</div><div class="esc-blk"><h3>Distribución por año de ejecución</h3>${yearTable(R)}</div>`; }
  function scopeText(R0){ const R=norm(R0); const d=R&&R.escDet; if(!d) return ''; return `Variación de precios desde la fecha base (precios ${d.base}) hasta el año de ejecución (${PROJ.describe()}; ${yearsTxt(d)}), por índices según grupo de costo${d.set==='cru'?' (CRU abr-2025)':''}: ${d.pct.toFixed(2)} % de A${d.manual?' (manual)':''}`; }
  function supuestoText(R0){ const R=norm(R0); const d=R&&R.escDet; if(!d) return ''; return `${d.pct.toFixed(2)} % del estimado neto: de la fecha base de precios (${d.base}) al año de ejecución (${PROJ.describe()}; ${yearsTxt(d)}), factor por grupo de costo = índice del año de ejecución / índice del año base, ${d.set==='cru'?'CRU Construction Escalation Index (abr-2025)':'índices LME / CPI-U / INEI con tasas anuales futuras'}${d.manual?' (valor manual)':''}.`; }
  function exportState(R0){ const R=norm(R0); const d=R&&R.escDet; if(!d) return null; return {fechaBase:d.base,inicio:d.start,meses:d.months,indices:d.set,manual:d.manual,pct:+d.pct.toFixed(4),escalamiento:Math.round(d.esc),porAnio:d.byYear.map(Y=>({anio:Y.y,meses:Y.months,peso:+Y.w.toFixed(4),A:Math.round(Y.A),escalamiento:Math.round(Y.esc)})),porGrupo:d.byGroup.map(r=>({grupo:r.g,indice:r.src,USD:Math.round(r.W),indiceBase:100,indiceEjecucion:r.iy.map(q=>({anio:q.y,indice:+q.r.toFixed(2)})),factor:+(1+r.f).toFixed(4),escalamiento:Math.round(r.esc)}))}; }
  return {CRU,CRU_MAP,SETS,index,yearWeights,compute,forEstimate,norm,render,report,scopeText,supuestoText,export:exportState};
})();
