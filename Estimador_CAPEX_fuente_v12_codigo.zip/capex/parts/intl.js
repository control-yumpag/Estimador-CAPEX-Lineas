/* ===================== REFERENCIAS INTERNACIONALES: costos unitarios de líneas y subestaciones (MISO, ACER, CNMC, NEP, CSG, CREG, Banco Mundial, Osinergmin, ProInversión) ===================== */
window.INTL=(function(){
  let D={meta:{fx:{},cpi:{}},lineas:[],subestaciones:[],clases:[]}; try{ const el=document.getElementById('intl'); if(el) D=JSON.parse(el.textContent||'{}'); }catch(e){}
  const FX=D.meta.fx||{}, CPI=D.meta.cpi||{};
  const nf=v=>v==null||isNaN(v)?'—':Math.round(v).toLocaleString('en-US');
  const nk=v=>v==null||isNaN(v)?'—':Math.abs(v)>=1e6?(v/1e6).toLocaleString('en-US',{maximumFractionDigits:2})+' M':Math.abs(v)>=1e3?(v/1e3).toLocaleString('en-US',{maximumFractionDigits:0})+' k':nf(v);
  const E=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  /* moneda del año de la fuente → USD del mismo año */
  function toUsd(v,cur,year){ if(v==null) return null; if(cur==='USD') return v; const key=cur+String(year); const k2=cur+(year>=2026?'2026':year>=2024?'2025':'2023');
    if(cur==='EUR'){ const f=FX[key]||FX[k2]||FX.EUR2023||1.08; return v*f; } if(cur==='GBP') return v*(FX[key]||FX.GBP2011||1.6);
    if(cur==='CNY'){ const f=FX[key]||FX.CNY2023||7.1; return v/f; } if(cur==='COP') return v/(FX[key]||FX.COP2008||1967); if(cur==='BRL') return v/(FX[key]||FX.BRL2014||2.35); if(cur==='PEN') return v/(FX[key]||3.5); return v; }
  function cpiF(year){ const y=Math.max(2008,Math.min(2026,year||2026)); const keys=Object.keys(CPI).map(Number).sort((a,b)=>a-b); let best=keys[0]; for(const k of keys){ if(k<=y) best=k; } return (CPI['2026']||331)/(CPI[String(best)]||CPI['2026']||331); }
  /* valor de la fuente → USD 2026 por km (líneas) o por unidad (subestaciones) */
  function perKm(v,r){ if(v==null) return null; const u=r.unit||''; let x=v;
    if(/M\$\/mi/.test(u)) x=v*1e6/1.609; else if(/^M.*\/km/.test(u)||/^M\$\/km/.test(u)||/^M€\/km/.test(u)||/^£M\/km/.test(u)||/^M CNY\/km/.test(u)) x=v*1e6; else x=v;
    return toUsd(x,r.cur,r.year)*cpiF(r.year); }
  function perUnit(v,r){ if(v==null) return null; const u=r.unit||''; let x=v; if(/^M/.test(u)) x=v*1e6; return toUsd(x,r.cur,r.year)*cpiF(r.year); }
  const GRP=kv=> kv>=300?[380,400,500]: kv>=200?[220,230,275]: kv>=100?[110,132,138,161]: [60,66,110];
  function lines(kv,circ){ const g=GRP(kv); const out=[];
    D.lineas.forEach(r=>{ if(!g.includes(r.kv)) return; let lo=r.lo, hi=r.hi, med=r.med; let c=r.circ;
      if(r.dcf&&circ===2&&r.circ===1){ lo=lo!=null?lo*r.dcf:null; hi=hi!=null?hi*r.dcf:null; med=med!=null?med*r.dcf:null; c=2; }
      if(circ&&c!==circ) return;
      const o={...r, circ:c, usdLo:perKm(lo,r), usdHi:perKm(hi,r), usdMed:perKm(med,r)}; if(o.usdMed==null&&o.usdLo!=null&&o.usdHi!=null) o.usdMed=Math.sqrt(o.usdLo*o.usdHi); if(o.usdLo==null&&o.usdMed!=null){ o.usdLo=o.usdMed; o.usdHi=o.usdHi==null?o.usdMed:o.usdHi; } if(o.usdHi==null) o.usdHi=o.usdLo;
      if(r.cont){ o.baseLo=o.usdLo/r.cont; o.baseHi=o.usdHi/r.cont; o.baseMed=o.usdMed/r.cont; }
      out.push(o); });
    return out.sort((a,b)=>a.usdMed-b.usdMed); }
  function se(kv,item){ const g=GRP(kv); return D.subestaciones.filter(r=>(r.kv===0||g.includes(r.kv))&&(!item||r.item===item)).map(r=>{ const o={...r, usdLo:perUnit(r.lo,r), usdHi:perUnit(r.hi,r), usdMed:perUnit(r.med,r)}; if(o.usdMed==null&&o.usdLo!=null&&o.usdHi!=null) o.usdMed=Math.sqrt(o.usdLo*o.usdHi); if(o.usdLo==null&&o.usdMed!=null) o.usdLo=o.usdMed; if(o.usdHi==null) o.usdHi=o.usdMed; if(o.item==='seMva'){ /* CNY/kVA → USD/MVA */ o.usdLo*=1000; o.usdHi*=1000; o.usdMed*=1000; } if(r.cont){ o.baseMed=o.usdMed/r.cont; o.baseLo=o.usdLo/r.cont; o.baseHi=o.usdHi/r.cont; } return o; }).sort((a,b)=>a.usdMed-b.usdMed); }
  /* franja de rangos en escala logarítmica: filas {label, lo, hi, med, color, note} y la marca del estimado */
  function strip(rows,mine,opt){ opt=opt||{}; const w=opt.w||760, rh=opt.rh||22, lw=opt.lw||230, pad=10; const vals=rows.flatMap(r=>[r.lo,r.hi]).concat(mine?[mine]:[]).filter(v=>v>0); if(!vals.length) return '<div class="tiny muted">Sin referencias comparables.</div>';
    const lo=Math.min(...vals)/1.35, hi=Math.max(...vals)*1.35; const X=v=>lw+pad+(w-lw-2*pad)*(Math.log(v)-Math.log(lo))/(Math.log(hi)-Math.log(lo)); const top=18; const H=rows.length*rh+top+20;
    let h=`<svg class="chart" viewBox="0 0 ${w} ${H}" style="width:100%;max-width:980px;height:auto;display:block">`;
    const ticks=[]; let t=Math.pow(10,Math.floor(Math.log10(lo))); while(t<=hi){ [1,2,5].forEach(m=>{ if(t*m>=lo&&t*m<=hi) ticks.push(t*m); }); t*=10; }
    ticks.forEach(v=>{ h+=`<line x1="${X(v)}" x2="${X(v)}" y1="${top}" y2="${H-18}" stroke="var(--line)" stroke-dasharray="2 3"/><text x="${X(v)}" y="${H-5}" text-anchor="middle" font-size="10" fill="var(--ink-3)">${nk(v)}</text>`; });
    rows.forEach((r,i)=>{ const y=i*rh+rh/2+top; const c=r.color||'var(--c2)'; h+=`<text x="${lw-4}" y="${y+4}" text-anchor="end" font-size="11" fill="var(--ink-2)">${E(r.label)}</text>`;
      if(r.lo>0&&r.hi>0&&r.hi>r.lo*1.001) h+=`<rect x="${X(r.lo)}" y="${y-6}" width="${Math.max(2,X(r.hi)-X(r.lo))}" height="12" rx="3" fill="${c}" fill-opacity=".35" stroke="${c}"><title>${E(r.note||'')}</title></rect>`;
      if(r.med>0) h+=`<circle cx="${X(r.med)}" cy="${y}" r="4.5" fill="${c}" stroke="#fff" stroke-width="1"><title>${E(r.note||'')}</title></circle>`;
      if(r.text) h+=`<text x="${X(Math.max(r.hi||r.med,r.med||r.hi))+6}" y="${y+4}" font-size="10" fill="var(--ink-3)">${E(r.text)}</text>`; });
    if(mine>0){ const mx=X(mine); const anchor= mx>w-150?'end': mx<lw+120?'start':'middle'; h+=`<line x1="${mx}" x2="${mx}" y1="${top-4}" y2="${H-18}" stroke="var(--accent)" stroke-width="2.5" stroke-dasharray="5 3"/><text x="${mx}" y="11" text-anchor="${anchor}" font-size="10.5" font-weight="700" fill="var(--accent-ink)">${E(opt.mineLabel||'Tu estimado')} ${nk(mine)}</text>`; }
    h+=`</svg><div class="tiny muted" style="text-align:right;margin-top:-2px">${E(opt.unit||'USD 2026 por km · escala log')}</div>`; return h; }
  const COLORS={'EE. UU. (MISO)':'var(--c1)','Europa (ACER)':'var(--c5)','España (CNMC)':'var(--c5)','España (MINETUR)':'var(--c5)','Alemania (NEP)':'var(--c5)','Reino Unido (IET/PB)':'var(--c5)','China (CSG)':'var(--c3)','Colombia (CREG)':'var(--c4)','Global (Banco Mundial)':'var(--c7)','Perú (Osinergmin)':'var(--good)','Perú (ProInversión)':'var(--good)'};
  function rowsLines(kv,circ,useBase){ return lines(kv,circ).map(r=>{ const lo=useBase&&r.baseLo?r.baseLo:r.usdLo, hi=useBase&&r.baseHi?r.baseHi:r.usdHi, med=useBase&&r.baseMed?r.baseMed:r.usdMed; return {label:`${r.region} · ${r.kv} kV ${r.circ===2?'2 circ.':'1 circ.'}${r.year?' · '+r.year:''}`,lo,hi,med,color:COLORS[r.region]||'var(--c2)',note:`${r.src}: ${r.scope}`}; }); }
  function benchLinesHTML(kv,circ,mine,opt){ opt=opt||{}; const rows=rowsLines(kv,circ,false); if(!rows.length) return `<div class="tiny muted">Sin referencias internacionales para ${kv} kV.</div>`;
    const pos= mine? (()=>{ const meds=rows.map(r=>r.med).filter(v=>v>0).sort((a,b)=>a-b); const below=meds.filter(v=>v<mine).length; return `${below} de ${meds.length} referencias quedan por debajo de tu estimado`; })() : '';
    return strip(rows,mine,{unit:'USD 2026 por km (sin IGV donde la fuente lo indica) · escala log',mineLabel:opt.mineLabel||'Tu estimado'})+`<div class="tiny muted">${rows.length} referencias de ${GRP(kv).join('/')} kV ${circ===2?'doble circuito':'simple circuito'}: valores llevados a USD 2026 con el tipo de cambio del año de la fuente y el CPI-U. ${pos}. Las cifras de MISO incluyen contingencia 30 % y AFUDC 7.5 %, terreno e impuestos; ACER y Banco Mundial son costos realizados; CNMC, CREG y Osinergmin son valores regulatorios o de planificación; CSG es la inversión de control del cuerpo de obra. ${opt.note||''}</div>`; }
  function benchSeHTML(kv,ctx){ ctx=ctx||{}; const bays=se(kv,'bay').map(r=>({label:`${r.region} · bahía ${r.kv} kV${r.year?' · '+r.year:''}`,lo:r.usdLo,hi:r.usdHi,med:r.usdMed,color:COLORS[r.region]||'var(--c2)',note:`${r.src}: ${r.scope}`}));
    const trs=se(kv,'trafo').map(r=>({label:`${r.region} · trafo ${r.kv} kV${r.year?' · '+r.year:''}`,lo:r.usdLo,hi:r.usdHi,med:r.usdMed,color:COLORS[r.region]||'var(--c2)',note:`${r.src}: ${r.scope}`}));
    const full=se(kv,'seMva').map(r=>({label:`${r.region} · SE completa ${r.kv} kV${r.year?' · '+r.year:''}`,lo:r.usdLo,hi:r.usdHi,med:r.usdMed,color:COLORS[r.region]||'var(--c2)',note:`${r.src}: ${r.scope}`}));
    let h='';
    if(bays.length) h+=`<div class="eyebrow" style="margin:4px 0 2px">Costo por bahía / celda</div>`+strip(bays,ctx.bay,{unit:'USD 2026 por bahía · escala log',mineLabel:'Tu celda COES promedio'});
    if(trs.length) h+=`<div class="eyebrow" style="margin:8px 0 2px">Transformadores por MVA</div>`+strip(trs,ctx.trMva,{unit:'USD 2026 por MVA (equipo) · escala log',mineLabel:'Tu transformador'});
    if(full.length) h+=`<div class="eyebrow" style="margin:8px 0 2px">Subestación completa por MVA instalado</div>`+strip(full,ctx.seMva,{unit:'USD 2026 por MVA instalado · escala log',mineLabel:'Tu subestación (E / MVA)'});
    return h||`<div class="tiny muted">Sin referencias internacionales para ${kv} kV.</div>`; }
  function tableHTML(kv,kind){ let rows; if(kind==='se'){ rows=D.subestaciones.filter(r=>r.kv===0||GRP(kv).includes(r.kv)).map(r=>{ const o=se(kv).find(x=>x.id===r.id)||{}; return [r.region,r.src,r.year,r.kv||'—',r.item==='bay'?'Bahía':r.item==='trafo'?'Transformador (USD/MVA)':r.item==='trafoU'?'Transformador (unidad)':r.item==='seMva'?'SE completa (por MVA)':'Subestación',(r.lo!=null?nk(r.lo)+' – ':'')+(r.med!=null?nk(r.med):'')+(r.hi!=null&&r.lo==null?' – '+nk(r.hi):r.hi!=null&&r.med==null?nk(r.hi):'')+' '+r.unit,o.usdMed?nk(o.usdMed):'—',r.scope,r.url]; }); }
    else { rows=D.lineas.filter(r=>GRP(kv).includes(r.kv)).map(r=>{ const o=lines(kv,null).find(x=>x.id===r.id)||{}; return [r.region,r.src,r.year,`${r.kv} kV ${r.circ===2?'2 circ.':'1 circ.'}${r.dcf?' (×'+r.dcf+' para 2 circ.)':''}`,'Línea',(r.lo!=null?nk(r.lo)+' – ':'')+(r.med!=null?nk(r.med):'')+(r.hi!=null&&r.med==null&&r.lo!=null?nk(r.hi):r.hi!=null&&r.med!=null?' ('+nk(r.hi)+')':'')+' '+r.unit,o.usdMed?nk(o.usdMed):'—',r.scope,r.url]; }); }
    return `<div class="tbl-wrap"><table class="tbl small refs"><thead><tr><th>Región</th><th>Fuente</th><th class="n">Año</th><th>Ítem</th><th>Tipo</th><th>Valor original</th><th class="n">USD 2026 (aprox.)</th><th>Alcance</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${E(r[0])}</td><td class="tiny"><a href="${E(r[8])}" target="_blank" rel="noopener">${E(r[1])}</a></td><td class="n">${r[2]}</td><td class="tiny">${E(r[3])}</td><td class="tiny">${E(r[4])}</td><td class="n">${E(r[5])}</td><td class="n"><b>${r[6]}</b></td><td class="tiny" style="min-width:260px">${E(r[7])}</td></tr>`).join('')}</tbody></table></div><div class="tiny muted" style="margin-top:6px">${E(D.meta.nota||'')} Tipos de cambio: ${Object.entries(FX).filter(([k])=>k!=='USD').map(([k,v])=>k+' '+v).join(' · ')}.</div>`; }
  function classesHTML(){ return (D.clases||[]).map(c=>`<div class="tiny" style="margin-bottom:6px"><b>${E(c.src)}</b>: ${c.rows.map(r=>r.join(' · ')).join(' | ')} <a href="${E(c.url)}" target="_blank" rel="noopener">fuente</a></div>`).join(''); }
  return {data:D, lines, se, strip, benchLinesHTML, benchSeHTML, tableHTML, classesHTML, GRP, cpiF, toUsd};
})();
