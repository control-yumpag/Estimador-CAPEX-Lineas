/* ===================== VISTA EN PLANTA 2D · trazo, vanos y ángulos ===================== */
window.P2=(function(){
  // Reglas de prediseño por nivel de tensión (torres autosoportadas). Fuentes: módulos COES 2025 (vanos de los tramos de referencia),
  // SEAL LT 138 kV Socabaya (vano máximo por altura de estructura, desvío ≤ 3° en suspensión), CNEL 69 kV (TSL ≤ 2°, A-30/A-60),
  // clasificación por ángulo (0–2 / 2–15 / 15–30 / 30–60°), CNE Suministro 2011 Tabla 232-1 (+10 mm/kV sobre 23 kV; +3 % por 300 m sobre 1000 msnm).
  const RULES={
    60:{avg:300,rec:[250,350],max:{S:420,A:390,T:380},min:80,ang:{S:3,A:30,T:90},sect:8,clr:{terreno:5.9,cultivo:6.9,carretera:7.4,ferro:9.5},coes:'módulos COES 60 kV: 229–300 m'},
    138:{avg:350,rec:[300,420],max:{S:500,A:460,T:450},min:100,ang:{S:3,A:30,T:90},sect:10,clr:{terreno:6.6,cultivo:7.7,carretera:8.1,ferro:10.5},coes:'módulos COES 138 kV: 350 m · SEAL 138 kV: torre 30 m → 366 m, 33 m → 420 m'},
    220:{avg:450,rec:[400,500],max:{S:600,A:560,T:540},min:120,ang:{S:2,A:30,T:90},sect:10,clr:{terreno:7.5,cultivo:8.5,carretera:8.5,ferro:11.0},coes:'módulos COES 220 kV: 460–488 m'},
    500:{avg:480,rec:[450,550],max:{S:650,A:610,T:590},min:150,ang:{S:2,A:30,T:90},sect:10,clr:{terreno:10.3,cultivo:11.3,carretera:11.8,ferro:14.5},coes:'módulos COES 500 kV: 456–509 m'},
    33:{avg:150,rec:[120,200],max:{S:280,A:250,T:230},min:40,ang:{S:5,A:30,T:90},sect:6,clr:{terreno:6.0,cultivo:6.5,carretera:7.0,ferro:9.0},coes:'postes CAC 21 m; servidumbre BDME 33 kV: 7 estructuras/km (≈ 150 m)'},
    22.9:{avg:150,rec:[120,200],max:{S:260,A:240,T:220},min:40,ang:{S:5,A:30,T:90},sect:5,clr:{terreno:6.0,cultivo:6.5,carretera:7.0,ferro:9.0},coes:'DGE RD 018-2003-EM: postes CAC 13 m, vano básico 120–200 m rural'},
    13.2:{avg:140,rec:[110,180],max:{S:240,A:220,T:200},min:40,ang:{S:5,A:30,T:90},sect:5,clr:{terreno:6.0,cultivo:6.5,carretera:7.0,ferro:9.0},coes:'redes primarias 13.2 kV: postes CAC 13 m (DGE RD 018-2003-EM)'},
    10:{avg:110,rec:[80,140],max:{S:200,A:180,T:170},min:30,ang:{S:5,A:30,T:90},sect:4,clr:{terreno:5.5,cultivo:6.0,carretera:6.5,ferro:8.5},coes:'redes primarias 10 kV: postes CAC 12–13 m'},
    0.38:{avg:45,rec:[40,60],max:{S:70,A:65,T:60},min:20,ang:{S:10,A:45,T:90},sect:1,clr:{terreno:5.5,cultivo:5.5,carretera:6.0,ferro:7.0},coes:'redes secundarias BT (DGE RD 031-2003-EM): postes CAC 8/200 – 9/200, vano 40–60 m'}
  };
  const st={pis:[], kv:220, km:60, span:450, tower:null, sel:-1};
  let R=null;
  const q=id=>document.getElementById(id);
  function rules(kv){ return RULES[kv]||RULES[220]; }
  function typeFor(ang,kv,i,n){ const r=rules(kv); if(i===0||i===n-1) return 'T'; const a=Math.abs(ang); return a<=r.ang.S?'S':a<=r.ang.A?'A':'T'; }
  // generación determinística "tipo proyecto": vanos alrededor del promedio, ángulos según la mezcla del estimado
  function generate(){
    const inp=R.inp, mix=R.factors.mixUser, r=rules(inp.kv); const L=inp.km*1000, S=inp.span; const n=Math.max(3,Math.round(L/S)+1);
    const pis=[]; let seed=7, heading=0, sinceT=0;
    const rnd=()=>{ seed=(seed*9301+49297)%233280; return seed/233280; };
    const sign=()=> heading>3 ? -1 : heading<-3 ? 1 : (rnd()<0.5?-1:1); // rumbo con reversión a la media
    for(let i=0;i<n;i++){
      const lo=Math.max(r.rec[0],S*0.85), hi=Math.min(r.rec[1],S*1.15); const span= i<n-1 ? Math.round((lo<hi? lo+(hi-lo)*rnd() : S*(0.9+0.2*rnd()))/5)*5 : 0;
      let ang=0; const t=rnd()*100;
      if(i===0||i===n-1) ang=0;
      else if(sinceT>=r.sect*1000*0.85){ ang=Math.round(rnd()*25+30)*sign(); }
      else if(t<mix.susp) ang=Math.round((rnd()-0.5)*2*r.ang.S*0.8*10)/10;
      else if(t<mix.susp+mix.ang) ang=Math.round(rnd()*20+5)*sign();
      else ang=Math.round(rnd()*40+30)*sign();
      heading+=ang; if(Math.abs(ang)>r.ang.A||i===0) sinceT=0; sinceT+=span;
      pis.push({L:span,ang});
    }
    const tot=pis.reduce((a,p)=>a+p.L,0); const f=L/tot; pis.forEach(p=>p.L=Math.round(p.L*f/5)*5);
    st.pis=pis; st.sel=-1;
  }
  function geometry(){
    const pts=[]; let x=0,y=0,h=0; const kv=st.kv, n=st.pis.length;
    st.pis.forEach((p,i)=>{ h+=p.ang*Math.PI/180; pts.push({x,y,h,i,type:typeFor(p.ang,kv,i,n),ang:p.ang,L:p.L}); x+=Math.cos(h)*p.L; y+=Math.sin(h)*p.L; });
    return pts;
  }
  function analyze(pts){
    const r=rules(st.kv); const warns=[]; const over=[], under=[]; const spans=st.pis.slice(0,-1).map(p=>p.L);
    const cnt={S:0,A:0,T:0}; pts.forEach(p=>cnt[p.type]++);
    const tot=spans.reduce((a,b)=>a+b,0); const avg=tot/Math.max(1,spans.length); const vr=Math.sqrt(spans.reduce((a,v)=>a+v*v*v,0)/Math.max(1,tot));
    pts.forEach((p,i)=>{ const nx=pts[i+1]; if(!nx) return; const L=p.L;
      const lim=Math.min(r.max[p.type],r.max[nx.type]);
      if(L>lim) warns.push({k:'bad',t:`Vano ${i+1}–${i+2}: ${L} m supera el vano máximo ${lim} m (torres ${p.type}/${nx.type})`,d:'reducir el vano, intercalar una estructura o usar torres de mayor altura / anclaje'});
      else if(L>r.rec[1]) over.push(L);
      else if(L<r.min) warns.push({k:'bad',t:`Vano ${i+1}–${i+2}: ${L} m es menor que el mínimo práctico ${r.min} m`,d:'riesgo de levantamiento (uplift) y cadenas en ángulo; reubicar estructura'});
      else if(L<r.rec[0]) under.push(L);
      // vano viento / peso por estructura
      const vv=(p.L+(pts[i-1]?pts[i-1].L:0))/2; if(vv>r.max[p.type]*0.95) warns.push({k:'warn',t:`Estructura ${i+1} (${p.type}): vano viento ${vv.toFixed(0)} m cerca del límite de la familia`,d:'verificar árbol de cargas de la torre'});
    });
    pts.forEach((p,i)=>{ const a=Math.abs(p.ang); if(i>0&&i<pts.length-1){ if(p.type==='S'&&a>r.ang.S*0.8) warns.push({k:'warn',t:`Estructura ${i+1}: ${a}° cerca del límite de suspensión (${r.ang.S}°)`,d:'considerar torre de ángulo'}); if(a>90) warns.push({k:'bad',t:`Estructura ${i+1}: deflexión ${a}° supera 90°`,d:'no es un vértice válido para una torre terminal/anclaje estándar'}); } });
    if(over.length) warns.push({k:'warn',t:`${over.length} vano(s) sobre el rango recomendado ${r.rec[0]}–${r.rec[1]} m (máx. ${Math.max(...over)} m)`,d:'admisibles con verificación de flechas, distancias de seguridad y vano peso de la familia de torres'});
    if(under.length) warns.push({k:'warn',t:`${under.length} vano(s) bajo el rango recomendado (mín. ${Math.min(...under)} m)`,d:'encarecen la línea (más estructuras por km); revisar si responden a cruces o quiebres obligados'});
    // secciones de tendido entre anclajes
    let run=0, maxRun=0; pts.forEach((p,i)=>{ if(p.type==='T'){ maxRun=Math.max(maxRun,run); run=0; } run+=p.L||0; }); maxRun=Math.max(maxRun,run);
    if(maxRun>r.sect*1000) warns.push({k:'warn',t:`Sección sin anclaje de ${(maxRun/1000).toFixed(1)} km (recomendado ≤ ${r.sect} km)`,d:'intercalar torres de anclaje para tendido, seguridad ante cascada y mantenimiento'});
    const ratio={S:cnt.S/pts.length*100,A:cnt.A/pts.length*100,T:cnt.T/pts.length*100};
    return {warns,cnt,ratio,tot,avg,vr,max:Math.max(...spans,0),min:Math.min(...spans,1e9),maxRun,n:pts.length};
  }
  function draw(pts,an){
    const host=q('planSvg'); if(!host) return;
    const xs=pts.map(p=>p.x), ys=pts.map(p=>p.y); const minx=Math.min(...xs), maxx=Math.max(...xs), miny=Math.min(...ys), maxy=Math.max(...ys);
    const W=900, Hh=Math.max(320,Math.min(560,(maxy-miny+400)/(maxx-minx+400)*900)); const pad=60;
    const sc=Math.min((W-2*pad)/Math.max(1,maxx-minx),(Hh-2*pad)/Math.max(1,maxy-miny)); const X=x=>pad+(x-minx)*sc, Y=y=>Hh-pad-(y-miny)*sc;
    const col={S:'var(--c1)',A:'var(--c3)',T:'var(--crit)'}; const dense=pts.length>40; const rr=dense?3.5:5;
    let s=`<svg class="chart plan" viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Vista en planta del trazo">`;
    // faja de servidumbre
    const fw=({60:16,138:20,220:25,500:64})[st.kv]*sc/2;
    for(let i=0;i<pts.length-1;i++){ const a=pts[i],b=pts[i+1]; const dx=X(b.x)-X(a.x), dy=Y(b.y)-Y(a.y); const l=Math.hypot(dx,dy)||1; const nx=-dy/l*fw, ny=dx/l*fw;
      s+=`<polygon points="${X(a.x)+nx},${Y(a.y)+ny} ${X(b.x)+nx},${Y(b.y)+ny} ${X(b.x)-nx},${Y(b.y)-ny} ${X(a.x)-nx},${Y(a.y)-ny}" fill="var(--blue-soft)" opacity=".6"></polygon>`; }
    // ejes
    s+=`<polyline points="${pts.map(p=>X(p.x)+','+Y(p.y)).join(' ')}" fill="none" stroke="var(--ink-2)" stroke-width="1.6"></polyline>`;
    // vanos
    const rl=rules(st.kv);
    for(let i=0;i<pts.length-1;i++){ const a=pts[i],b=pts[i+1]; const mx=(X(a.x)+X(b.x))/2, my=(Y(a.y)+Y(b.y))/2; const lim=Math.min(rl.max[a.type],rl.max[b.type]); const bad=a.L>lim||a.L<rl.min; const wr=!bad&&(a.L>rl.rec[1]||a.L<rl.rec[0]);
      if(dense&&!bad&&!wr) continue;
      s+=`<text x="${mx}" y="${my-7}" text-anchor="middle" class="num" style="font-size:10px;fill:${bad?'var(--crit)':wr?'var(--warn)':'var(--ink-3)'};font-weight:${bad||wr?700:400}">${a.L} m</text>`; }
    // estructuras
    pts.forEach((p,i)=>{ const x=X(p.x), y=Y(p.y); const c=col[p.type]; const sel=i===st.sel; const r2=sel?rr+2:rr;
      if(p.type==='S') s+=`<circle cx="${x}" cy="${y}" r="${r2}" fill="${c}" stroke="var(--surface)" stroke-width="1.2" data-i="${i}" class="pi"><title>${i+1} · suspensión · vano ${p.L} m</title></circle>`;
      else if(p.type==='A') s+=`<rect x="${x-r2-0.5}" y="${y-r2-0.5}" width="${2*r2+1}" height="${2*r2+1}" fill="${c}" stroke="var(--surface)" stroke-width="1.2" data-i="${i}" class="pi"><title>${i+1} · ángulo ${p.ang}° · vano ${p.L} m</title></rect>`;
      else s+=`<polygon points="${x},${y-r2-2} ${x+r2+2},${y} ${x},${y+r2+2} ${x-r2-2},${y}" fill="${c}" stroke="var(--surface)" stroke-width="1.2" data-i="${i}" class="pi"><title>${i+1} · anclaje/terminal ${p.ang}° · vano ${p.L} m</title></polygon>`;
      const showLbl = !dense || i===0 || i===pts.length-1 || p.type==='T' || (i%10===9) || sel;
      if(showLbl) s+=`<text x="${x+8}" y="${y-8}" style="font-size:10px;fill:var(--ink-2)">${i+1}${p.ang&&i>0&&i<pts.length-1?` · ${p.ang>0?'+':''}${p.ang}°`:''}</text>`; });
    // escala
    const sl=[100,200,500,1000,2000,5000].find(v=>v*sc>90)||1000; s+=`<line x1="${pad}" x2="${pad+sl*sc}" y1="${Hh-18}" y2="${Hh-18}" stroke="var(--ink)" stroke-width="2"></line><text x="${pad}" y="${Hh-24}" style="font-size:10px">${sl>=1000?(sl/1000)+' km':sl+' m'}</text>`;
    s+=`<g transform="translate(${W-40},${40})"><line x1="0" y1="18" x2="0" y2="-14" stroke="var(--ink)" stroke-width="1.5"></line><polygon points="0,-18 -5,-8 5,-8" fill="var(--ink)"></polygon><text x="0" y="32" text-anchor="middle" style="font-size:10px">N</text></g>`;
    host.innerHTML=s+'</svg>';
    host.querySelectorAll('.pi').forEach(e=>e.onclick=()=>{ st.sel=parseInt(e.dataset.i); render(); });
  }
  function renderTable(pts){
    const host=q('planTbl'); const r=rules(st.kv);
    let h=`<table><thead><tr><th>#</th><th>Tipo</th><th class="n">Deflexión °</th><th class="n">Vano al sig. (m)</th><th class="n">Vano viento</th><th class="n">Progresiva</th><th></th></tr></thead><tbody>`;
    let prog=0;
    pts.forEach((p,i)=>{ const vv=((p.L||0)+(pts[i-1]?pts[i-1].L:0))/2; const last=i===pts.length-1;
      h+=`<tr class="${i===st.sel?'sel':''}"><td class="num">${i+1}</td><td><span class="tag ${p.type==='S'?'sum':p.type==='A'?'civ':'em'}">${p.type==='S'?'Susp.':p.type==='A'?'Ángulo':'Anclaje'}</span></td><td class="n"><input type="number" class="pa" data-i="${i}" value="${p.ang}" step="1" min="-90" max="90" style="width:64px;text-align:right" ${i===0||last?'disabled':''}></td><td class="n">${last?'—':`<input type="number" class="pl" data-i="${i}" value="${p.L}" step="5" min="0" style="width:74px;text-align:right">`}</td><td class="n">${vv.toFixed(0)}</td><td class="n">${(prog/1000).toFixed(2)} km</td><td><button class="btn sm ghost pins" data-i="${i}" title="Insertar estructura después">＋</button><button class="btn sm ghost pdel" data-i="${i}" title="Eliminar" ${pts.length<=3?'disabled':''}>✕</button></td></tr>`; prog+=p.L||0; });
    host.innerHTML=h+'</tbody></table>';
    host.querySelectorAll('.pa').forEach(e=>e.onchange=()=>{ st.pis[parseInt(e.dataset.i)].ang=Math.max(-90,Math.min(90,parseFloat(e.value)||0)); setTimeout(render,0); });
    host.querySelectorAll('.pl').forEach(e=>e.onchange=()=>{ st.pis[parseInt(e.dataset.i)].L=Math.max(0,parseFloat(e.value)||0); setTimeout(render,0); });
    host.querySelectorAll('.pins').forEach(e=>e.onclick=()=>{ const i=parseInt(e.dataset.i); const p=st.pis[i]; const half=Math.round((p.L||r.avg)/2/5)*5; if(i===st.pis.length-1){ st.pis.push({L:0,ang:0}); p.L=r.avg; } else { st.pis.splice(i+1,0,{L:half,ang:0}); p.L=half; } render(); });
    host.querySelectorAll('.pdel').forEach(e=>e.onclick=()=>{ const i=parseInt(e.dataset.i); if(st.pis.length<=3) return; if(i<st.pis.length-1&&i>0){ st.pis[i-1].L+=st.pis[i].L; } st.pis.splice(i,1); if(i===st.pis.length){ st.pis[st.pis.length-1].L=0; st.pis[st.pis.length-1].ang=0; } st.pis[0].ang=0; render(); });
  }
  function renderSummary(an){
    const r=rules(st.kv); const host=q('planSum');
    host.innerHTML=`<dl class="kv"><dt>Longitud del trazo</dt><dd>${(an.tot/1000).toFixed(2)} km (proyecto: ${st.km} km)</dd><dt>Estructuras</dt><dd>${an.n} · S ${an.cnt.S} / A ${an.cnt.A} / T ${an.cnt.T} (${an.ratio.S.toFixed(0)} / ${an.ratio.A.toFixed(0)} / ${an.ratio.T.toFixed(0)} %)</dd><dt>Vano promedio</dt><dd>${an.avg.toFixed(0)} m (estimado: ${st.span} m · recomendado ${r.rec[0]}–${r.rec[1]} m)</dd><dt>Vano regulador</dt><dd>${an.vr.toFixed(0)} m</dd><dt>Vano máx. / mín.</dt><dd>${an.max} / ${an.min===1e9?'—':an.min} m</dd><dt>Sección máx. sin anclaje</dt><dd>${(an.maxRun/1000).toFixed(1)} km (≤ ${r.sect} km)</dd></dl>
      <div class="chk-list-wrap"><ul class="chk-list">${an.warns.length? an.warns.slice(0,12).map(w=>`<li class="${w.k}"><b>${esc(w.t)}</b><div class="tiny">${esc(w.d)}</div></li>`).join('') : '<li class="ok"><b>Sin observaciones</b><div class="tiny">vanos y ángulos dentro de los rangos recomendados</div></li>'}${an.warns.length>12?`<li class="warn"><b>… ${an.warns.length-12} observaciones más</b></li>`:''}</ul></div>`;
  }
  function renderRules(){
    const host=q('planRules'); if(!host) return; const kv=st.kv;
    let h=`<table><thead><tr><th>kV</th><th class="n">Vano promedio</th><th class="n">Rango recomendado</th><th class="n">Máx. S / A / T</th><th class="n">Mín.</th><th class="n">Ángulo S / A / T</th><th class="n">Sección tendido</th><th class="n">Altura mín. terreno / vía / FF.CC.</th><th>Referencia</th></tr></thead><tbody>`;
    [60,138,220,500].forEach(k=>{ const r=RULES[k]; h+=`<tr class="${k===kv?'sel':''}"><td><b>${k}</b></td><td class="n">${r.avg} m</td><td class="n">${r.rec[0]}–${r.rec[1]} m</td><td class="n">${r.max.S} / ${r.max.A} / ${r.max.T} m</td><td class="n">${r.min} m</td><td class="n">≤ ${r.ang.S}° / ≤ ${r.ang.A}° / ≤ ${r.ang.T}°</td><td class="n">≤ ${r.sect} km</td><td class="n">${r.clr.terreno} / ${r.clr.carretera} / ${r.clr.ferro} m</td><td class="tiny">${esc(r.coes)}</td></tr>`; });
    host.innerHTML=h+'</tbody></table>';
  }
  function render(){
    if(!R) return; st.kv=R.inp.kv; st.km=R.inp.km; st.span=R.inp.span;
    if(!st.pis.length) generate();
    const pts=geometry(); const an=analyze(pts); draw(pts,an); renderTable(pts); renderSummary(an); renderRules();
    st.an=an;
  }
  function useInEstimate(){
    if(!st.an) return; const an=st.an;
    q('inSpan').value=Math.round(an.avg); q('inKm').value=(an.tot/1000).toFixed(1);
    q('inPSusp').value=Math.round(an.ratio.S); q('inPAng').value=Math.round(an.ratio.A); q('inPAnc').value=Math.round(an.ratio.T);
    q('inSpan').dispatchEvent(new Event('input',{bubbles:true})); toast('Vano, longitud y mezcla del trazo aplicados al estimado');
  }
  function csv(){ const pts=geometry(); const rows=[['#','Tipo','Deflexión (°)','Vano al siguiente (m)','X (m)','Y (m)']]; pts.forEach((p,i)=>rows.push([i+1,p.type,p.ang,p.L,p.x.toFixed(1),p.y.toFixed(1)])); return rows.map(r=>r.join(',')).join('\n'); }
  function bind(){
    if(!q('planGen')) return;
    q('planGen').onclick=()=>{ generate(); render(); toast('Trazo generado desde el estimado'); };
    q('planUse').onclick=useInEstimate;
    q('planCsv').onclick=()=>download('trazo_planta.csv',csv(),'text/csv');
    q('planClear').onclick=()=>{ const r=rules(st.kv); st.pis=[{L:r.avg,ang:0},{L:r.avg,ang:0},{L:0,ang:0}]; st.sel=-1; render(); };
  }
  document.addEventListener('DOMContentLoaded',bind);
  return { update(Rn){ const changed=R&&(R.inp.kv!==Rn.inp.kv||R.M.n!==Rn.M.n); R=Rn; if(changed) st.pis=[]; render(); }, rules, setTowerInfo(t){ st.tower=t; }, state:st };
})();
