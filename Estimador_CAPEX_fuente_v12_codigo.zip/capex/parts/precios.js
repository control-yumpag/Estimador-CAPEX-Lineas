/* ===================== PRECIOS: base de datos, escalamiento a años futuros y marcas (USD sin IGV) ===================== */
window.PRICE=(function(){
  const YEARS=[2019,2020,2021,2022,2023,2024,2025,2026];
  const LAST=2026;               // último año con índice observado (promedio enero–setiembre 2026)
  const BASE={coes:2026,bdme:2025}; // año base de cada base de datos
  /* Índices anuales de referencia (promedios; 2026 = enero–setiembre). Fuentes: LME (aluminio, cobre, zinc), precios de exportación
     de perfiles/ángulos de acero (China), CPI-U (BLS), INEI (materiales de construcción y mano de obra de construcción, base 2019 = 100),
     terrenos rústicos (criterio experto). Editables por el usuario; los valores futuros usan la tasa anual de cada índice. */
  const IDX={
    al:   {label:'Aluminio LME (USD/t)',        v:{2019:1794,2020:1704,2021:2473,2022:2705,2023:2256,2024:2419,2025:2632,2026:3050}, fwd:3.0, src:'LME cash, promedio anual; 2026 promedio ene–set (spot 3,264 USD/t el 23-09-2026)'},
    cu:   {label:'Cobre LME (USD/t)',           v:{2019:6010,2020:6181,2021:9317,2022:8822,2023:8490,2024:9147,2025:9550,2026:10600}, fwd:3.5, src:'LME cash, promedio anual'},
    zn:   {label:'Zinc LME (USD/t)',            v:{2019:2546,2020:2267,2021:3004,2022:3481,2023:2651,2024:2779,2025:2760,2026:2900}, fwd:2.5, src:'LME cash, promedio anual (galvanizado)'},
    steel:{label:'Acero estructural (USD/t)',   v:{2019:560,2020:545,2021:880,2022:760,2023:615,2024:530,2025:495,2026:520}, fwd:3.0, src:'perfiles / ángulos de acero, precio de exportación China (referencial)'},
    cpi:  {label:'CPI-U EE. UU. (índice)',      v:{2019:255.7,2020:258.8,2021:271.0,2022:292.7,2023:304.7,2024:313.7,2025:322.3,2026:331.0}, fwd:2.5, src:'BLS, promedio anual; equipos, fabricación y servicios en USD'},
    pemat:{label:'Materiales de construcción Perú (2019 = 100)', v:{2019:100,2020:101.0,2021:109.6,2022:116.2,2023:117.4,2024:119.0,2025:121.4,2026:124.4}, fwd:3.0, src:'INEI, índice de precios de materiales de construcción (referencial)'},
    pelab:{label:'Mano de obra construcción Perú (2019 = 100)', v:{2019:100,2020:101.0,2021:104.0,2022:109.2,2023:115.8,2024:120.4,2025:125.2,2026:130.2}, fwd:4.0, src:'INEI / CAPECO, costo hora-hombre construcción civil (referencial)'},
    land: {label:'Terrenos rústicos y servidumbre (2019 = 100)', v:{2019:100,2020:102,2021:105,2022:110,2023:115,2024:120,2025:125,2026:130}, fwd:4.0, src:'valores arancelarios rústicos (MEF) y criterio experto'}
  };
  /* Grupos de costo: composición en índices */
  const GROUPS={
    steelT:{label:'Torres de celosía y postes de acero (fabricados, galvanizados)', comp:{steel:0.55,zn:0.12,cpi:0.33}},
    steelW:{label:'Cables de guarda de acero (EHS, alumoweld)', comp:{steel:0.55,zn:0.10,cpi:0.35}},
    conc:  {label:'Postes de concreto armado centrifugado', comp:{pemat:1.0}},
    wood:  {label:'Postes de madera tratada', comp:{cpi:1.0}},
    alu:   {label:'Conductores de aluminio (AAAC, ACAR, ACSR, CAAI)', comp:{al:0.70,cpi:0.30}},
    opgw:  {label:'OPGW y cables ópticos', comp:{al:0.30,steel:0.20,cpi:0.50}},
    ins:   {label:'Aisladores, herrajes y accesorios', comp:{steel:0.15,cpi:0.85}},
    cu:    {label:'Puesta a tierra (cobre / copperweld)', comp:{cu:0.60,cpi:0.40}},
    eq:    {label:'Equipos, luminarias, transporte', comp:{cpi:1.0}},
    hv:    {label:'Equipos de patio AT/EAT y módulos GIS (interruptores, seccionadores, TC/TT, pararrayos)', comp:{cpi:0.75,steel:0.10,cu:0.15}},
    trafo: {label:'Transformadores de potencia, bancos y reactores', comp:{cu:0.35,steel:0.25,cpi:0.40}},
    lab:   {label:'Montaje electromecánico y mano de obra', comp:{pelab:1.0}},
    civ:   {label:'Obras civiles, fundaciones y accesos', comp:{pemat:0.5,pelab:0.5}},
    svc:   {label:'Ingeniería, estudios, permisos, supervisión', comp:{cpi:1.0}},
    land:  {label:'Servidumbre y terrenos', comp:{land:1.0}}
  };
  /* Catálogo de marcas / fabricantes por componente. Factor = precio relativo a la referencia de la base de datos (1.00);
     valores referenciales de mercado 2025/26, editables — calibrar con cotizaciones vigentes. */
  const BRANDS={
    cond:{label:'Conductores de aluminio (AAAC / ACAR / ACSR / CAAI)',opts:[['base','Referencia de la base (cotizaciones DFJ / Panghao, China)',1.00],['dfj','DFJ – Hebei (China)',1.00],['panghao','Panghao (China)',1.02],['midal','Midal Cables (Bahréin)',1.06],['ceper','Ceper Cables (Perú)',1.10],['indeco','Indeco by Nexans (Perú)',1.12],['nexans','Nexans / Prysmian (Europa)',1.18],['southwire','Southwire (EE. UU.)',1.20]]},
    opgw:{label:'Cable de guarda (OPGW / EHS / alumoweld)',opts:[['base','Referencia de la base (DFJ / Panghao, China)',1.00],['ztt','ZTT (China)',1.00],['furukawa','Furukawa (Brasil)',1.10],['prysmian','Prysmian (Europa)',1.20],['afl','AFL (EE. UU.)',1.22],['fujikura','Fujikura (Japón)',1.25]]},
    tower:{label:'Torres de celosía (acero galvanizado)',opts:[['base','Referencia COES (promedio Jiangsu 1,400 / Daji 1,300 USD/t CIF)',1.00],['daji','Daji Towers (China) · 1,300 USD/t',0.963],['jiangsu','Jiangsu (China) · 1,400 USD/t',1.037],['kec','KEC International (India)',1.02],['sae','SAE Towers (Brasil / México)',1.12],['nacional','Fabricante nacional (Perú)',1.15]]},
    spole:{label:'Postes de acero poligonales',opts:[['base','Referencia BDME (estructuras compuestas I-403)',1.00],['import','Importado (China)',0.88],['nacional','Fabricante nacional (Perú)',1.00],['valmont','Valmont (EE. UU. / Brasil)',1.25]]},
    cpole:{label:'Postes de concreto armado centrifugado',opts:[['base','Referencia (BDME / mercado Lima)',1.00],['postessac','Postes S.A.C. (Lima)',1.00],['ccp','Concreto Centrifugado Perú',1.00],['magra','Magra S.A.C.',1.02],['teccontec','Teccontec (Lima)',0.98],['lurin','Postes Lurín S.A.C.',1.00],['innova','Corporación Innova Total',0.98],['regional','Planta regional cercana a la obra',0.95]]},
    wpole:{label:'Postes de madera tratada',opts:[['base','Referencia (importado, pino tratado)',1.00],['chile','Madera tratada importada (Chile)',1.00],['brasil','Madera tratada importada (Brasil)',0.97],['nacional','Madera nacional tratada (eucalipto)',0.90]]},
    ins:{label:'Aisladores y cadenas',opts:[['base','Referencia (vidrio / polimérico de las cotizaciones COES-BDME)',1.00],['orient','Vidrio templado – Orient / Dalian (China)',1.00],['sediver','Vidrio templado – Sediver (Francia / Brasil)',1.15],['ngk','Porcelana – NGK (Japón)',1.35],['lapp','Porcelana – Lapp (EE. UU.)',1.30],['polychina','Polimérico – fabricantes chinos',0.90],['maclean','Polimérico – MacLean / Hubbell (EE. UU.)',1.20]]},
    hw:{label:'Herrajes, grapas, puesta a tierra y accesorios',opts:[['base','Referencia (importado China / nacional)',1.00],['china','Herrajes importados (China)',1.00],['nacional','Herrajes nacionales (Perú)',1.10],['premium','Herrajes europeos / norteamericanos',1.30]]}
  };
  const GRP_BRAND={steelT:null,alu:'cond',opgw:'opgw',steelW:'opgw',ins:'ins',cu:'hw',conc:'cpole',wood:'wpole'};
  const st={year:2026, fwd:Object.fromEntries(Object.entries(IDX).map(([k,v])=>[k,v.fwd])), over:{}, brands:Object.fromEntries(Object.keys(BRANDS).map(k=>[k,{id:'base',f:1}]))};
  try{ const s=JSON.parse(localStorage.getItem('capexlt.price')||'null'); if(s&&s.year){ st.year=s.year; Object.assign(st.fwd,s.fwd||{}); st.over=s.over||{}; Object.keys(BRANDS).forEach(k=>{ if(s.brands&&s.brands[k]) st.brands[k]=s.brands[k]; }); } }catch(e){}
  function save(){ try{ localStorage.setItem('capexlt.price',JSON.stringify({year:st.year,fwd:st.fwd,over:st.over,brands:st.brands})); }catch(e){} }
  function idxVal(k,y){ const I=IDX[k]; if(y<=LAST) return I.v[Math.max(YEARS[0],y)]; return I.v[LAST]*Math.pow(1+(st.fwd[k]||0)/100, y-LAST); }
  function ratio(k,base,year){ return idxVal(k,year)/idxVal(k,base); }
  /* factor de escalamiento de un grupo desde el año base de la BD al año objetivo */
  function factor(grp,base){ if(st.over[grp]>0) return st.over[grp]; const G=GROUPS[grp]; if(!G) return 1; const b=BASE[base||'bdme']; let f=0; for(const [k,w] of Object.entries(G.comp)) f+=w*ratio(k,b,st.year); return f; }
  function brandF(key){ const b=st.brands[key]; if(!b) return 1; return b.f||1; }
  function brandName(key){ const b=st.brands[key]; const o=BRANDS[key].opts.find(x=>x[0]===(b?b.id:'base')); return o?o[1]:'referencia'; }
  /* filas del motor Osinergmin (base BDME 2025): sum × esc(grp) × marca; mont × esc(lab); oc × esc(civ) */
  function applyRows(rows,base){
    let before=0, after=0;
    rows.forEach(r=>{ const b0=(r.sum||0)+(r.mont||0)+(r.oc||0); const g=r.grp||'eq'; const bk= r.brand&&BRANDS[r.brand]? r.brand : GRP_BRAND[g]; const fS=factor(g,base)*(bk? brandF(bk):1); const fM=factor('lab',base), fO=factor('civ',base);
      r.sum=(r.sum||0)*fS; r.pu=(r.pu||0)*fS; r.mont=(r.mont||0)*fM; r.oc=(r.oc||0)*fO; r.fS=fS; r.fM=fM; r.fO=fO; before+=b0; after+=r.sum+r.mont+r.oc; });
    return {escF: before>0? after/before : 1};
  }
  /* ítems del motor COES (base 09/2026): {sum,civ,em} por ítem LE2 */
  function applyItems(items,poste,cgTypes){
    const base='coes'; const map={'2.1':[poste?'conc':'steelT', poste?'cpole':'tower'],'2.2':['alu','cond'],'2.3':['opgw','opgw'],'2.4':['ins','ins'],'2.5':['cu','hw'],'2.6':['eq',null]};
    let before=0, after=0; const f={};
    for(const k of Object.keys(items)){ const it=items[k]; const b0=it.tot; let fS=1;
      if(map[k]){ const [g,bk]=map[k]; fS= k==='2.3' ? ((cgTypes||[]).some(t=>/OPGW/.test(t))?factor('opgw',base):factor('steelW',base))*brandF('opgw') : factor(g,base)*(bk?brandF(bk):1); }
      it.sum*=fS; it.civ*=factor('civ',base); it.em*=factor('lab',base); it.tot=it.sum+it.civ+it.em; f[k]=fS; before+=b0; after+=it.tot; }
    return {escF: before>0? after/before:1, f};
  }
  function summaryRows(base){ return Object.entries(GROUPS).map(([k,G])=>({k,label:G.label,comp:Object.entries(G.comp).map(([i,w])=>`${Math.round(w*100)} % ${IDX[i].label.split(' (')[0]}`).join(' + '),f:factor(k,base),over:st.over[k]||''})); }
  function brandSummary(){ const parts=[]; for(const k of ['cond','opgw','tower','spole','cpole','wpole','ins','hw']){ const b=st.brands[k]; if(b&&b.id!=='base') parts.push(`${BRANDS[k].label.split(' (')[0].replace(/^Cable de guarda.*/,'Guarda').replace(/^Conductores.*/,'Conductor').replace(/^Torres.*/,'Torres').replace(/^Postes de acero.*/,'Postes acero').replace(/^Postes de concreto.*/,'Postes concreto').replace(/^Postes de madera.*/,'Postes madera').replace(/^Aisladores.*/,'Aisladores').replace(/^Herrajes.*/,'Herrajes')}: ${brandName(k).split(' (')[0]} ×${(b.f||1).toFixed(2)}`); } return parts.length? parts.join(' · ') : 'marcas de referencia de la base de datos'; }
  function basesText(space){ const base= space==='B'?'bdme':'coes'; const by=BASE[base]; const fs=['alu','steelT','conc','ins','lab','civ'].map(k=>`${GROUPS[k].label.split(' (')[0].toLowerCase()} ×${factor(k,base).toFixed(3)}`).join(', ');
    return `cotizaciones de la base ${base==='coes'?'COES (setiembre 2026)':'Osinergmin BDME (2025)'} actualizadas a la fecha base del estimado (${st.year}) en USD sin IGV por grupo de costo con índices de referencia (${fs}); tasas anuales futuras editables (aluminio ${st.fwd.al} %, acero ${st.fwd.steel} %, CPI ${st.fwd.cpi} %, materiales Perú ${st.fwd.pemat} %, mano de obra ${st.fwd.pelab} %). Marcas: ${brandSummary()}.`; }
  function exportState(){ return {anioPrecios:st.year, aniosBase:BASE, tasasFuturas:st.fwd, factoresManuales:st.over, marcas:Object.fromEntries(Object.entries(st.brands).map(([k,b])=>[k,{id:b.id,nombre:brandName(k),factor:b.f}])), factoresBDME:Object.fromEntries(Object.keys(GROUPS).map(k=>[k,+factor(k,'bdme').toFixed(4)])), factoresCOES:Object.fromEntries(Object.keys(GROUPS).map(k=>[k,+factor(k,'coes').toFixed(4)]))}; }
  /* ---------- modal ---------- */
  let modal=null;
  function ensureModal(){ if(modal) return modal; modal=document.createElement('div'); modal.className='modal'; modal.id='priceModal'; modal.innerHTML='<div class="modal-card"><div class="modal-head"><h3>Precios y marcas · USD sin IGV</h3><span class="tiny">Fecha base de precios, actualización de cotizaciones por grupo de costo y fabricante por componente</span><button class="btn sm" id="pmClose">Cerrar</button></div><div class="modal-body" id="pmBody"></div><div class="modal-foot"><button class="btn sm" id="pmReset">Restablecer</button><span class="spacer" style="flex:1"></span><button class="btn primary" id="pmApply">Aplicar al estimado</button></div></div>'; document.body.appendChild(modal);
    modal.addEventListener('click',e=>{ if(e.target===modal) close(); }); modal.querySelector('#pmClose').onclick=close; modal.querySelector('#pmReset').onclick=()=>{ st.year=2026; Object.keys(IDX).forEach(k=>st.fwd[k]=IDX[k].fwd); st.over={}; Object.keys(BRANDS).forEach(k=>st.brands[k]={id:'base',f:1}); render(); }; modal.querySelector('#pmApply').onclick=()=>{ save(); close(); recalcAll(); if(window.toast) toast(`Precios escalados a ${st.year} · ${brandSummary()}`); }; return modal; }
  function recalcAll(){ const hasR=()=>{ try{ return typeof R!=='undefined'&&!!R; }catch(e){ return false; } }; const hasR2=()=>{ try{ return typeof R2!=='undefined'&&!!R2; }catch(e){ return false; } }; const hasR3=()=>{ try{ return typeof R3!=='undefined'&&!!R3; }catch(e){ return false; } }; const A=()=>{ if(typeof recalc==='function'&&hasR()) recalc(); }, B=(force)=>{ if(typeof oRecalc==='function'&&(force||hasR2())) oRecalc(); }, C=()=>{ if(typeof sRecalc==='function'&&hasR3()) sRecalc(); };
    /* se recalculan los tres espacios; el activo va al final para que la cabecera (chips, tensión) refleje su estimado */
    if(window.APP_MODE==='osi'){ A(); C(); B(true); } else if(window.APP_MODE==='se'){ A(); B(false); C(); } else { B(false); C(); A(); } }
  function years(){ const a=[]; for(let y=2025;y<=2035;y++) a.push(y); return a; }
  function render(){ const b=ensureModal().querySelector('#pmBody'); const f2=v=>v.toFixed(3);
    let h=`<div class="pm-grid">
      <div class="card flat"><div class="eyebrow">Fecha base del estimado (año de precios)</div>
        <div class="row2" style="align-items:end"><div class="field"><label for="pmYear">Año base de precios del estimado</label><select id="pmYear">${years().map(y=>`<option value="${y}" ${y===st.year?'selected':''}>${y}${y>LAST?' (proyección)':y===LAST?' (actual)':''}</option>`).join('')}</select></div><div class="small muted">Base COES: setiembre 2026 · Base Osinergmin BDME: 2025 · IGV excluido. Los índices hasta ${LAST} son observados (2026: promedio enero–setiembre); de ${LAST+1} en adelante se proyectan con la tasa anual de cada índice. Las cotizaciones de la base se actualizan a esta fecha base; el escalamiento del ítem 3 (de la fecha base al periodo de ejecución) se define en el panel «Proyecto» y se detalla en la pestaña «Escalamiento».</div></div></div>
      <div class="card flat"><div class="eyebrow">Índices de referencia y tasa anual futura</div><div class="tbl-wrap"><table class="tbl small"><thead><tr><th>Índice</th>${YEARS.map(y=>`<th class="num">${y}</th>`).join('')}<th class="num">Tasa ${LAST+1}+ (%/año)</th></tr></thead><tbody>
        ${Object.entries(IDX).map(([k,I])=>`<tr><td>${I.label}<div class="tiny muted">${I.src}</div></td>${YEARS.map(y=>`<td class="num">${I.v[y]<200?I.v[y].toFixed(1):Math.round(I.v[y]).toLocaleString('en-US')}</td>`).join('')}<td class="num"><input type="number" class="pm-fwd" data-k="${k}" value="${st.fwd[k]}" step="0.5" style="width:70px;text-align:right"></td></tr>`).join('')}</tbody></table></div></div>
      <div class="card flat"><div class="eyebrow">Factores de actualización de cotizaciones por grupo de costo → fecha base ${st.year}</div><div class="tbl-wrap"><table class="tbl small"><thead><tr><th>Grupo</th><th>Composición</th><th class="num">Base BDME 2025</th><th class="num">Base COES 2026</th><th class="num">Factor manual</th></tr></thead><tbody>
        ${Object.entries(GROUPS).map(([k,G])=>`<tr><td>${G.label}</td><td class="tiny muted">${Object.entries(G.comp).map(([i,w])=>`${Math.round(w*100)} % ${IDX[i].label.split(' (')[0]}`).join(' + ')}</td><td class="num">${f2(factor(k,'bdme'))}</td><td class="num">${f2(factor(k,'coes'))}</td><td class="num"><input type="number" class="pm-over" data-k="${k}" value="${st.over[k]||''}" placeholder="auto" step="0.01" min="0.2" max="5" style="width:80px;text-align:right"></td></tr>`).join('')}</tbody></table></div><div class="tiny muted" style="margin-top:6px">El factor manual (p. ej. 1.08) reemplaza al calculado para ese grupo en ambas bases. Suministros se escalan con su grupo; montaje con mano de obra; obras civiles con materiales + mano de obra; servidumbre con terrenos.</div></div>
      <div class="card flat"><div class="eyebrow">Marca / fabricante por componente</div><div class="tbl-wrap"><table class="tbl small"><thead><tr><th>Componente</th><th>Fabricante</th><th class="num">Factor de precio</th></tr></thead><tbody>
        ${Object.entries(BRANDS).map(([k,B])=>{ const cur=st.brands[k]||{id:'base',f:1}; return `<tr><td>${B.label}</td><td><select class="pm-brand" data-k="${k}">${B.opts.map(o=>`<option value="${o[0]}" ${o[0]===cur.id?'selected':''}>${o[1]} (×${o[2].toFixed(2)})</option>`).join('')}</select></td><td class="num"><input type="number" class="pm-bf" data-k="${k}" value="${(cur.f||1).toFixed(2)}" step="0.01" min="0.5" max="2" style="width:80px;text-align:right"></td></tr>`; }).join('')}</tbody></table></div><div class="tiny muted" style="margin-top:6px">Factor 1.00 = precio de la referencia de la base de datos (cotizaciones COES: conductores y OPGW DFJ / Panghao, torres Jiangsu / Daji; BDME: precios consolidados I-402/I-403). Los factores por marca son referenciales de mercado 2025/26 y deben calibrarse con cotizaciones vigentes; se aplican sobre el suministro del componente antes de aranceles, aduana y fletes.</div></div>
    </div>`;
    b.innerHTML=h;
    b.querySelector('#pmYear').onchange=e=>{ st.year=parseInt(e.target.value); render(); };
    b.querySelectorAll('.pm-fwd').forEach(i=>i.onchange=()=>{ st.fwd[i.dataset.k]=parseFloat(i.value)||0; render(); });
    b.querySelectorAll('.pm-over').forEach(i=>i.onchange=()=>{ const v=parseFloat(i.value); if(v>0) st.over[i.dataset.k]=v; else delete st.over[i.dataset.k]; render(); });
    b.querySelectorAll('.pm-brand').forEach(sel=>sel.onchange=()=>{ const o=BRANDS[sel.dataset.k].opts.find(x=>x[0]===sel.value); st.brands[sel.dataset.k]={id:sel.value,f:o?o[2]:1}; render(); });
    b.querySelectorAll('.pm-bf').forEach(i=>i.onchange=()=>{ const k=i.dataset.k; st.brands[k]={id:(st.brands[k]||{}).id||'base',f:parseFloat(i.value)||1}; });
  }
  function open(){ ensureModal(); render(); modal.classList.add('on'); document.body.style.overflow='hidden'; }
  function close(){ if(modal){ modal.classList.remove('on'); document.body.style.overflow=''; } }
  document.addEventListener('DOMContentLoaded',()=>{ const b=document.getElementById('btnPrecios'); if(b) b.onclick=open; document.addEventListener('keydown',e=>{ if(e.key==='Escape') close(); }); });
  return {get year(){ return st.year; }, BASE, IDX, GROUPS, BRANDS, LAST, idxVal, factor, brandF, brandName, applyRows, applyItems, summaryRows, brandSummary, basesText, export:exportState, open, close, recalcAll, state:st};
})();
