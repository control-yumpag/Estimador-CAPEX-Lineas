/* ===================== SUBESTACIÓN 3D PARAMÉTRICA (Three.js): plataforma, barras, celdas AIS/GIS, transformadores, edificio y cerco =====================
   Dimensiones típicas por tensión (anchos de bahía, alturas de barras y pórticos, equipos, transformadores, GIS) tomadas de estándares y proyectos públicos
   (Energy Queensland STNW3013, REE/SEA Chile, BHEL/REC-PDCL India, Siemens/Hitachi GIS, EirGrid AIS vs GIS, JICA) — ver notas v12. */
window.SUB3D=(function(){
  const DIM={ /* w: ancho de bahía AIS · ph: separación de fases · hLow/hHigh/hGantry: alturas de barra baja, barra alta y pórtico · L: largo de bahía doble barra · L15: largo de diámetro interruptor y medio · eq: alturas totales CB/CT/VT/DS · gisW: ancho de bahía GIS · gisH: altura de sala · tr: L×W×H del transformador por MVA de referencia */
    60:{w:8,ph:2.0,hLow:4.0,hHigh:6.0,hGantry:9,L:20,L15:40,eq:{cb:4.65,ct:4.3,vt:4.2,ds:3.6,sa:3.2},gisW:0.9,gisH:8,hall:10},
    138:{w:10.5,ph:2.75,hLow:4.7,hHigh:7.5,hGantry:11,L:28,L15:50,eq:{cb:5.2,ct:4.6,vt:4.6,ds:4.4,sa:3.6},gisW:1.0,gisH:8.5,hall:11},
    220:{w:16,ph:4.0,hLow:5.75,hHigh:10.5,hGantry:15,L:40,L15:75,eq:{cb:6.7,ct:5.6,vt:5.7,ds:5.2,sa:4.6},gisW:1.5,gisH:9.5,hall:12},
    500:{w:28,ph:7.5,hLow:10,hHigh:18,hGantry:27,L:55,L15:120,eq:{cb:9.5,ct:8.5,vt:8.6,ds:7.0,sa:7.2},gisW:3.1,gisH:12,hall:14.5}};
  function trDims(mva,kv){ const m=Math.max(5,mva||25); const s=Math.pow(m/50,0.33); return {L:Math.min(13,6.5*s+1.5),W:Math.min(7.5,4.0*s+0.8),H:Math.min(8,4.6*s+0.6),rad:Math.min(4,1.2+m/60),bush:kv>=400?3.2:kv>=200?2.4:kv>=100?1.7:1.1}; }
  let inited=false, scene, camera, renderer, controls, root, last=null, mountedIn=null, viewIdx=0, onScreen=true, Rcur=null, hostEl=null, grpMats=null;
  const $id=id=>document.getElementById(id);
  const isDark=()=>{ const r=document.documentElement.getAttribute('data-theme'); return r? r==='dark' : matchMedia('(prefers-color-scheme: dark)').matches; };
  function el(){ let v=$id('subviewer'); if(!v){ v=document.createElement('div'); v.className='viewer'; v.id='subviewer'; v.innerHTML='<div class="hud" id="subhud"></div>'; } return v; }
  function mats(){ if(grpMats) return grpMats; const M=(c,o)=>new THREE.MeshStandardMaterial(Object.assign({color:c,metalness:0.1,roughness:0.8},o||{}));
    grpMats={gravel:M(0xb9b2a4,{roughness:0.98}),road:M(0x6d6d6d,{roughness:0.95}),steel:new THREE.MeshPhysicalMaterial({color:0xb3bcc3,metalness:0.9,roughness:0.5}),steelD:M(0x8d969c,{metalness:0.8,roughness:0.55}),conc:M(0xd4cfc4,{roughness:0.92}),ins:new THREE.MeshPhysicalMaterial({color:0x6b4c3b,metalness:0.05,roughness:0.5,clearcoat:0.4}),insG:new THREE.MeshPhysicalMaterial({color:0x4d6b55,metalness:0.05,roughness:0.45,clearcoat:0.4}),bus:M(0x9fa6ab,{metalness:0.85,roughness:0.4}),cond:M(0x7f8589,{metalness:0.8,roughness:0.5}),trafo:M(0x5f6b73,{metalness:0.5,roughness:0.6}),radiator:M(0x4e585f,{metalness:0.5,roughness:0.7}),oil:M(0x80604a),bld:M(0xe8e2d5,{roughness:0.9}),roof:M(0x7b8a99),glass:new THREE.MeshPhysicalMaterial({color:0xbfd6ea,transparent:true,opacity:0.35,metalness:0.2,roughness:0.1}),fence:new THREE.MeshStandardMaterial({color:0x8b949b,transparent:true,opacity:0.35,side:THREE.DoubleSide}),wall:M(0xcfc3a8),gis:M(0xa7b0b7,{metalness:0.6,roughness:0.45}),gisB:M(0x2f6f9f,{metalness:0.5,roughness:0.5}),label:null}; return grpMats; }
  function init(){ const host=el(); hostEl=host; const w=host.clientWidth||800, h=host.clientHeight||520;
    renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'}); renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1)); renderer.setSize(w,h); renderer.outputEncoding=THREE.sRGBEncoding; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=0.9; renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    host.insertBefore(renderer.domElement,host.firstChild);
    scene=new THREE.Scene(); camera=new THREE.PerspectiveCamera(42,w/h,0.5,6000);
    controls=new THREE.OrbitControls(camera,renderer.domElement); controls.enableDamping=true; controls.dampingFactor=0.09; controls.maxPolarAngle=Math.PI/2-0.03; controls.screenSpacePanning=true; controls.minDistance=8; controls.maxDistance=1500;
    scene.add(new THREE.AmbientLight(0xdde8f5,0.55)); const hemi=new THREE.HemisphereLight(0xbcd6f2,0x6b6250,0.5); scene.add(hemi);
    const sun=new THREE.DirectionalLight(0xffffff,1.2); sun.position.set(180,260,120); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.near=10; sun.shadow.camera.far=1200; sun.shadow.bias=-0.0006; scene.add(sun); scene.userData.sun=sun;
    root=new THREE.Group(); scene.add(root); inited=true; theme();
    new ResizeObserver(resize).observe(host); try{ new IntersectionObserver(es=>{ onScreen=es.some(e=>e.isIntersecting); },{threshold:0}).observe(host); }catch(e){ onScreen=true; }
    loop(); if(Rcur) rebuild(); }
  function theme(){ if(!inited) return; const c= isDark()? {bg:0x101820,fog:0x101820}:{bg:0xe4edf4,fog:0xe4edf4}; renderer.setClearColor(new THREE.Color(c.bg),1); scene.background=new THREE.Color(c.bg); scene.fog=new THREE.Fog(c.fog,600,3000); }
  function resize(){ if(!inited) return; const host=el(); const w=host.clientWidth||600, h=host.clientHeight||400; camera.aspect=w/h; camera.updateProjectionMatrix(); renderer.setSize(w,h); }
  function loop(){ requestAnimationFrame(loop); if(!inited) return; const hv=el(); if(document.hidden||!onScreen||!hv||hv.offsetParent===null) return; controls.update(); renderer.render(scene,camera); }
  function mount(slotId){ const slot=$id(slotId), v=el(); if(!slot) return; if(v.parentElement!==slot) slot.appendChild(v); mountedIn=slotId; if(!inited){ try{ init(); }catch(e){ const h=$id('subhud'); if(h) h.innerHTML='<span class="err">No se pudo iniciar WebGL: '+(e&&e.message||e)+'</span>'; } } else setTimeout(resize,30); }
  /* ---------- primitivas ---------- */
  const box=(w,h,d,m,x,y,z)=>{ const g=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m); g.position.set(x,y+h/2,z); g.castShadow=true; g.receiveShadow=true; return g; };
  const cyl=(r,h,m,x,y,z,r2)=>{ const g=new THREE.Mesh(new THREE.CylinderGeometry(r2!=null?r2:r,r,h,14),m); g.position.set(x,y+h/2,z); g.castShadow=true; return g; };
  function latticeColumn(w,h,m,x,z){ const g=new THREE.Group(); const t=Math.max(0.08,w*0.06); [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([a,b])=>g.add(box(t,h,t,m,x+a*w/2,0,z+b*w/2))); const n=Math.max(2,Math.round(h/Math.max(1.5,w*1.2))); for(let i=1;i<=n;i++){ const y=h*i/n; g.add(box(w,t*0.8,t*0.8,m,x,y-t*0.4,z-w/2)); g.add(box(w,t*0.8,t*0.8,m,x,y-t*0.4,z+w/2)); g.add(box(t*0.8,t*0.8,w,m,x-w/2,y-t*0.4,z)); g.add(box(t*0.8,t*0.8,w,m,x+w/2,y-t*0.4,z)); } return g; }
  function gantry(span,H,m,x,z,axis){ const g=new THREE.Group(); const cw=Math.max(0.6,H*0.07); if(axis==='z'){ g.add(latticeColumn(cw,H,m,x,z-span/2)); g.add(latticeColumn(cw,H,m,x,z+span/2)); g.add(box(cw*1.1,cw*0.9,span+cw,m,x,H-cw*0.9,z)); } else { g.add(latticeColumn(cw,H,m,x-span/2,z)); g.add(latticeColumn(cw,H,m,x+span/2,z)); g.add(box(span+cw,cw*0.9,cw*1.1,m,x,H-cw*0.9,z)); } return g; }
  function insulatorStack(h,r,m,x,y,z){ const g=new THREE.Group(); const n=Math.max(3,Math.round(h/0.35)); for(let i=0;i<n;i++){ const d=cyl(r*(i%2?0.75:1),0.3,m,x,y+i*(h/n),z); g.add(d); } g.add(cyl(r*0.45,h,m,x,y,z)); return g; }
  function apparatus(kind,D,M,kv,x,z,y0){ const g=new THREE.Group(); const supH=2.5, r= kv>=400?0.36:kv>=200?0.3:kv>=100?0.24:0.18; const H=D.eq[kind]||4;
    g.add(box(0.5,supH,0.5,M.steelD,x,y0,z)); g.add(box(1.2,0.15,1.2,M.conc,x,y0-0.15,z));
    if(kind==='cb'){ g.add(insulatorStack(H-supH-0.5,r*1.1,M.ins,x,y0+supH,z)); g.add(cyl(r*1.25,0.5,M.steel,x,y0+H-0.5,z)); }
    else if(kind==='ds'){ g.add(insulatorStack(H-supH-0.3,r,M.ins,x,y0+supH,z)); g.add(box(1.6,0.12,0.12,M.bus,x,y0+H-0.3,z)); }
    else if(kind==='sa'){ g.add(insulatorStack(H-supH-0.2,r*0.9,M.insG,x,y0+supH,z)); }
    else { g.add(insulatorStack(H-supH-0.7,r,M.ins,x,y0+supH,z)); g.add(cyl(r*1.6,0.7,M.steel,x,y0+H-0.7,z)); }
    return g; }
  function busbar(D,M,kv,x0,x1,z,h,r){ const g=new THREE.Group(); const len=x1-x0; const b=new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,10),M.bus); b.rotation.z=Math.PI/2; b.position.set((x0+x1)/2,h,z); b.castShadow=true; g.add(b); return g; }
  function transformer(M,kv,mva,x,z,sec){ const d=trDims(mva,kv); const g=new THREE.Group(); g.add(box(d.L+2,0.35,d.W+2,M.conc,x,-0.05,z)); g.add(box(d.L+1.6,0.1,d.W+1.6,M.oil,x,0.3,z)); g.add(box(d.L,d.H,d.W,M.trafo,x,0.4,z));
    [-1,1].forEach(s=>{ for(let i=0;i<4;i++){ g.add(box(d.L*0.16,d.H*0.85,0.35,M.radiator,x-d.L*0.32+i*d.L*0.21,0.6,z+s*(d.W/2+0.4))); } });
    const cv=cyl(d.W*0.22,d.L*0.8,M.trafo,x,d.H+0.4+d.W*0.22,z+d.W*0.15); cv.rotation.z=Math.PI/2; cv.position.y=d.H+0.4+d.W*0.3; g.add(cv);
    for(let i=0;i<3;i++){ const bx=x-d.L*0.3+i*d.L*0.3; g.add(cyl(0.22,d.bush,M.ins,bx,d.H+0.4,z-d.W*0.25,0.14)); g.add(cyl(0.16,d.bush*0.55,M.ins,bx,d.H+0.4,z+d.W*0.3,0.1)); }
    return {g,d}; }
  function building(M,w,d,h,x,z){ const g=new THREE.Group(); g.add(box(w,h,d,M.bld,x,0,z)); g.add(box(w+0.8,0.3,d+0.8,M.roof,x,h,z)); for(let i=1;i<Math.floor(w/4);i++){ g.add(box(1.4,1.2,0.1,M.glass,x-w/2+i*4,1.3,z+d/2+0.02)); g.add(box(1.4,1.2,0.1,M.glass,x-w/2+i*4,1.3,z-d/2-0.02)); } return g; }
  function fence(M,W,Dp,x0,z0,h){ const g=new THREE.Group(); const posts=[]; const np=Math.max(2,Math.round(W/3)), nq=Math.max(2,Math.round(Dp/3));
    for(let i=0;i<=np;i++){ posts.push([x0+W*i/np,z0],[x0+W*i/np,z0+Dp]); } for(let j=1;j<nq;j++){ posts.push([x0,z0+Dp*j/nq],[x0+W,z0+Dp*j/nq]); }
    posts.forEach(([x,z])=>g.add(box(0.12,h,0.12,M.steelD,x,0,z)));
    const panel=(cx,cz,len,rotY)=>{ const p=new THREE.Mesh(new THREE.PlaneGeometry(len,h-0.1),M.fence); p.position.set(cx,h/2,cz); p.rotation.y=rotY; g.add(p); };
    panel(x0+W/2,z0,W,0); panel(x0+W/2,z0+Dp,W,0); panel(x0,z0+Dp/2,Dp,Math.PI/2); panel(x0+W,z0+Dp/2,Dp,Math.PI/2);
    const wire=(cx,cz,len,rotY)=>{ for(let k=0;k<3;k++){ const c=new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,len,5),M.steelD); c.rotation.z=Math.PI/2; c.rotation.y=rotY; c.position.set(cx,h+0.15+k*0.18,cz); g.add(c); } }; wire(x0+W/2,z0,W,0); wire(x0+W/2,z0+Dp,W,0); wire(x0,z0+Dp/2,Dp,Math.PI/2); wire(x0+W,z0+Dp/2,Dp,Math.PI/2);
    return g; }
  function label(text,x,y,z,scale){ const cv=document.createElement('canvas'); cv.width=256; cv.height=64; const c=cv.getContext('2d'); c.fillStyle= isDark()?'rgba(23,31,39,0.9)':'rgba(255,255,255,0.92)'; c.fillRect(0,0,256,64); c.strokeStyle='#d9731a'; c.lineWidth=5; c.strokeRect(2,2,252,60); c.fillStyle= isDark()?'#e6ebf0':'#16212b'; c.font='600 30px "Source Sans 3", Arial'; c.textAlign='center'; c.textBaseline='middle'; c.fillText(text,128,33);
    const t=new THREE.CanvasTexture(cv); t.encoding=THREE.sRGBEncoding; const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,depthTest:false,transparent:true})); s.position.set(x,y,z); s.scale.set(scale*4,scale,1); s.renderOrder=10; return s; }
  /* ---------- modelo ---------- */
  const LS=kv=>Math.min(3.2,Math.max(2,kv/80));
  function layout(R){ const inp=R.inp; const kv=inp.kv>=400?500:inp.kv>=200?220:inp.kv>=100?138:60; const D=DIM[kv]; const gis=inp.tech==='GIS'; const cfg=inp.cfg||'DB'; const im=/^IM/.test(cfg)||kv===500;
    const bays=[]; for(let i=0;i<(inp.nL||0);i++) bays.push({t:'L',n:'L'+(i+1)}); for(let i=0;i<(inp.nT||0);i++) bays.push({t:'T',n:'T'+(i+1)}); for(let i=0;i<(inp.nA||0);i++) bays.push({t:'A',n:'A'+(i+1)}); for(let i=0;i<(inp.nRB||0);i++) bays.push({t:'RB',n:'RB'+(i+1)}); for(let i=0;i<(inp.nMB||0);i++) bays.push({t:'MB',n:'MB'+(i+1)}); for(let i=0;i<(inp.nRL||0);i++) bays.push({t:'RL',n:'RL'+(i+1)});
    const nB=Math.max(1,bays.length); const nTr=inp.nTr||0; const mva=inp.mva||25; const td=trDims(mva,kv);
    const wB= gis? D.gisW : D.w; const Lb= im? D.L15 : D.L; const yardW= gis? Math.max(12,nB*wB+8) : nB*wB+2*wB*0.6; const yardL= gis? D.hall : Lb;
    const trZone= nTr? (td.W+6) : 0; const bldW=Math.min(30,12+nB*1.6), bldD=10;
    const margin= gis? 8 : Math.max(8,D.w*0.6); const platW=Math.max(yardW+2*margin+(gis? bldW+8 : 0), nTr*(td.L+8)+2*margin); const platL=yardL+trZone+bldD+3*margin+(gis? Math.max(8,D.w*0.5)+D.ph*2+8 : 8);
    return {kv,D,gis,cfg,im,bays,nB,nTr,mva,td,wB,Lb,yardW,yardL,trZone,bldW,bldD,margin,platW,platL}; }
  function rebuild(){ if(!inited||!Rcur) return; try{ build(); }catch(e){ console.error('SUB3D',e); const h=$id('subhud'); if(h) h.innerHTML='<span class="err">Error al generar la subestación: '+(e&&e.message||e)+'</span>'; } }
  function build(){ while(root.children.length) root.remove(root.children[0]); const R=Rcur, inp=R.inp; const M=mats(); const Ly=layout(R); const {kv,D,gis,im,bays,nB,nTr,mva,td,wB,Lb,yardW,yardL,trZone,bldW,bldD,margin,platW,platL}=Ly;
    const nueva= inp.nueva!==false; const x0=-platW/2, z0=-platL/2;
    /* plataforma, cerco, vías */
    const plat=box(platW,0.6,platL,M.gravel,0,-0.6,0); plat.receiveShadow=true; root.add(plat);
    const ground=new THREE.Mesh(new THREE.PlaneGeometry(platW*4,platL*4),new THREE.MeshStandardMaterial({color: isDark()?0x2f3b33:(inp.zone==='Costa'?0xc9bd97:inp.zone==='Selva'?0x6f9a63:0x9aa77a),roughness:0.97})); ground.rotation.x=-Math.PI/2; ground.position.y=-0.62; ground.receiveShadow=true; ground.userData.noFit=true; root.add(ground);
    if(nueva){ root.add(fence(M,platW,platL,x0,z0,2.4)); const ring=new THREE.Group(); const rw=Math.min(6,Math.max(4,D.w*0.35)); ring.add(box(platW-2*margin*0.5,0.05,rw,M.road,0,0,z0+margin*0.5)); ring.add(box(rw,0.05,platL-margin,M.road,x0+margin*0.5,0,0)); ring.add(box(rw,0.05,platL-margin,M.road,-x0-margin*0.5,0,0)); ring.add(box(platW-2*margin*0.5,0.05,rw,M.road,0,0,-z0-margin*0.5)); root.add(ring); }
    /* patio de celdas */
    const yardX0=-yardW/2+(gis?-(bldW+8)/2:0); const zBus=z0+margin+trZone+bldD+margin; /* las barras se ubican hacia el fondo del patio */
    const info={cells:[],H:D.hGantry,ton:0};
    if(!gis){ const zGantry=zBus+Lb; const zMain=zBus+Lb*0.22, zTrans=zBus+Lb*0.08; const r= kv>=400?0.09:kv>=200?0.07:0.05;
      /* barras principales (doble barra o barras de interruptor y medio) */
      const xa=yardX0+wB*0.2, xb=yardX0+yardW-wB*0.2; for(let p=0;p<3;p++){ const dz=(p-1)*D.ph; root.add(busbar(D,M,kv,xa,xb,zMain+dz,D.hLow,r)); if(!im) root.add(busbar(D,M,kv,xa,xb,zTrans+dz-D.ph*1.2,D.hLow,r)); else root.add(busbar(D,M,kv,xa,xb,zGantry-Lb*0.08+dz,D.hLow,r)); }
      /* soportes de barra */ for(let k=0;k<=nB;k++){ const x=yardX0+wB*0.6+k*wB; for(let p=0;p<3;p++){ const dz=(p-1)*D.ph; root.add(box(0.4,D.hLow-0.8,0.4,M.steelD,x,0,zMain+dz)); root.add(insulatorStack(0.8,0.18,M.ins,x,D.hLow-0.8,zMain+dz)); } }
      bays.forEach((b,i)=>{ const x=yardX0+wB*0.6+i*wB+wB/2; const zs=[]; const seq= b.t==='L'? ['ds','ds','cb','ct','ds','vt','sa'] : b.t==='T'? ['ds','ds','cb','ct','ds','sa'] : b.t==='A'? ['ds','cb','ct','ds'] : ['ds','cb','ct','sa'];
        const step=(Lb-Lb*0.25)/(seq.length+1); seq.forEach((k,j)=>{ const z=zMain+D.ph*1.6+step*(j+1); zs.push(z); for(let p=0;p<3;p++){ const dx=(p-1)*D.ph; root.add(apparatus(k,D,M,kv,x+dx,z,0)); } });
        /* conductores aéreos de la bahía (barra alta → pórtico) */ for(let p=0;p<3;p++){ const dx=(p-1)*D.ph; const c=new THREE.Mesh(new THREE.CylinderGeometry(0.03,0.03,Lb*0.75,6),M.cond); c.rotation.x=Math.PI/2; c.position.set(x+dx,D.hHigh-0.4,zMain+Lb*0.45); root.add(c); }
        if(b.t==='L'||b.t==='RL'){ root.add(gantry(wB*0.9,D.hGantry,M.steel,x,zGantry,'x')); for(let p=0;p<3;p++){ const dx=(p-1)*D.ph; root.add(insulatorStack(Math.min(4.5,kv/120+1.2),0.16,M.insG,x+dx,D.hGantry-0.5-Math.min(4.5,kv/120+1.2),zGantry)); const c=new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.035,Lb*0.6,6),M.cond); c.rotation.x=Math.PI/2+0.1; c.position.set(x+dx,D.hGantry-2.2,zGantry+Lb*0.3); c.userData.noFit=true; root.add(c); } }
        root.add(label(b.n,x,D.hGantry+3,zMain+Lb*0.5,LS(kv)));
        info.cells.push(b.n); });
      /* barra alta (strain bus) a lo largo del patio, con pórticos en ambos extremos */ for(let p=0;p<3;p++){ const dz=(p-1)*D.ph; root.add(busbar(D,M,kv,yardX0,yardX0+yardW,zMain+Lb*0.12+dz,D.hHigh,r*0.8)); } root.add(gantry(D.ph*5,D.hHigh+1.2,M.steel,yardX0,zMain+Lb*0.12,'z')); root.add(gantry(D.ph*5,D.hHigh+1.2,M.steel,yardX0+yardW,zMain+Lb*0.12,'z'));
      info.area=Math.round(platW*platL); }
    else { /* sala GIS: edificio con bahías visibles */ const hallW=yardW, hallD=D.hall, hallH=D.gisH; const hx=yardX0+hallW/2, hz=zBus+hallD/2; root.add(box(hallW,0.3,hallD,M.conc,hx,-0.3,hz));
      const walls=new THREE.Group(); walls.add(box(hallW,hallH,0.3,M.glass,hx,0,hz-hallD/2)); walls.add(box(hallW,hallH,0.3,M.glass,hx,0,hz+hallD/2)); walls.add(box(0.3,hallH,hallD,M.bld,hx-hallW/2,0,hz)); walls.add(box(0.3,hallH,hallD,M.bld,hx+hallW/2,0,hz)); walls.add(box(hallW+1,0.4,hallD+1,M.roof,hx,hallH,hz)); root.add(walls);
      bays.forEach((b,i)=>{ const x=yardX0+4+i*wB+wB/2; const mod=new THREE.Group(); mod.add(box(wB*0.9,1.2,hallD*0.6,M.gisB,x,0,hz)); for(let p=0;p<3;p++){ const dz=(p-1)*Math.max(0.8,wB*0.45); const t=new THREE.Mesh(new THREE.CylinderGeometry(wB*0.28,wB*0.28,hallD*0.55,16),M.gis); t.rotation.x=Math.PI/2; t.position.set(x,2.2+p*0.0,hz+dz); mod.add(t); mod.add(cyl(wB*0.22,2.4,M.gis,x,2.2,hz+dz)); } mod.add(box(wB*0.6,0.9,0.5,M.gisB,x,1.2,hz-hallD*0.3)); root.add(mod);
        /* bushings de salida al exterior (celdas de línea) */ if(b.t==='L'||b.t==='RL'){ for(let p=0;p<3;p++){ const dx=(p-1)*Math.min(D.ph,wB*0.4); root.add(cyl(0.2,D.eq.vt*0.5,M.ins,x+dx,hallH+0.4,hz+hallD/2-1.5,0.12)); } root.add(gantry(Math.max(wB*2,D.ph*3),D.hGantry,M.steel,x,hz+hallD/2+Math.max(8,D.w*0.5),'x')); }
        info.cells.push(b.n); });
      root.add(label(`Sala GIS · ${nB} celdas`,hx,hallH+3.5,hz,LS(kv)*1.2));
      info.area=Math.round(platW*platL); }
    /* transformadores */
    const zTr=z0+margin+bldD+margin+trZone/2; for(let i=0;i<nTr;i++){ const x=-platW/2+margin+td.L*0.7+i*(td.L+8); const {g,d}=transformer(M,kv,mva,x,zTr,inp.sec); root.add(g); if(nTr>1&&i<nTr-1) root.add(box(0.4,d.H+1.0,d.W+3,M.wall,x+(td.L+8)/2,0,zTr)); root.add(label(`T${i+1} · ${mva} MVA`,x,td.H+4.5,zTr,LS(kv))); }
    /* edificio de control */ root.add(building(M,bldW,bldD,4.2,platW/2-margin-bldW/2,z0+margin+bldD/2)); root.add(label('Edificio de control',platW/2-margin-bldW/2,7.5,z0+margin+bldD/2,LS(kv)));
    /* escala humana */ root.add(cyl(0.22,1.75,M.ins,x0+margin*0.5+3,0,z0+margin*0.5+3));
    last={info,layout:Ly}; setView(viewIdx,true);
    const h=$id('subhud'); if(h) h.innerHTML=`<b>Subestación ${inp.kv} kV ${inp.tech} · ${nB} celdas · ${nTr?nTr+' × '+mva+' MVA':'sin transformación'}</b><br>Plataforma modelada ≈ ${Math.round(platW)} × ${Math.round(platL)} m (${(platW*platL/1e4).toFixed(2)} ha) · estimado ${R.com&&R.com.area?Math.round(R.com.area).toLocaleString('en-US')+' m²':'—'}<br>${gis?`Sala GIS ${Math.round(yardW)} × ${D.hall} m, bahías de ${wB} m`:`Bahías de ${D.w} m, barras a ${D.hLow} / ${D.hHigh} m, pórticos ${D.hGantry} m`} · ${im?'interruptor y medio':(inp.cfg==='SB'?'simple barra':'doble barra')}`; }
  function setView(i,keep){ if(!last||!root) return; const bb=new THREE.Box3(); root.updateMatrixWorld(true); root.traverse(o=>{ if(o.isMesh&&!o.userData.noFit&&!o.isSprite){ o.geometry.computeBoundingBox(); const b2=o.geometry.boundingBox.clone().applyMatrix4(o.matrixWorld); bb.union(b2); } }); if(bb.isEmpty()) bb.setFromObject(root); const size=bb.getSize(new THREE.Vector3()); const ctr=bb.getCenter(new THREE.Vector3()); const views=[[0.8,0.55,0.9],[0.02,1.6,0.25],[1.2,0.35,0.001],[0.001,0.35,1.2]]; const v=views[i%views.length]; const fov=camera.fov*Math.PI/180; const asp=camera.aspect||1.4; const W=Math.max(size.x,size.z)*(i===1?1.0:0.95), Hh=Math.max(size.y*1.4,W*0.45); const d=Math.max((W/2)/(Math.tan(fov/2)*asp),(Hh/2)/Math.tan(fov/2))*1.02; const dir=new THREE.Vector3(v[0],v[1],v[2]).normalize(); camera.position.copy(ctr).add(dir.multiplyScalar(d)); camera.near=Math.max(0.5,d/200); camera.far=d*8; camera.updateProjectionMatrix(); controls.target.set(ctr.x,Math.min(ctr.y,size.y*0.35),ctr.z); controls.update(); }
  function cycleView(){ viewIdx=(viewIdx+1)%4; setView(viewIdx); }
  function update(R){ Rcur=R; if(inited) rebuild(); }
  function snapshot(w,h){ if(!inited||!last) return null; try{ const W=w||900,H=h||520; const pr=renderer.getPixelRatio(); const s0=renderer.getSize(new THREE.Vector2()); renderer.setPixelRatio(1); renderer.setSize(W,H,false); camera.aspect=W/H; camera.updateProjectionMatrix(); renderer.render(scene,camera); const url=renderer.domElement.toDataURL('image/png'); renderer.setPixelRatio(pr); renderer.setSize(s0.x,s0.y,false); camera.aspect=s0.x/s0.y; camera.updateProjectionMatrix(); renderer.render(scene,camera); return url; }catch(e){ return null; } }
  function exportOBJ(){ if(!root) return; let out='# Estimador CAPEX — subestación 3D paramétrica, unidades: metros\n'; let off=1; root.updateMatrixWorld(true); root.traverse(m=>{ if(!m.isMesh||!m.geometry||!m.geometry.attributes.position||m.isSprite) return; const pos=m.geometry.attributes.position; const idx=m.geometry.index; out+=`o parte_${off}\n`; const v=new THREE.Vector3(); for(let i=0;i<pos.count;i++){ v.fromBufferAttribute(pos,i).applyMatrix4(m.matrixWorld); out+=`v ${v.x.toFixed(3)} ${v.y.toFixed(3)} ${v.z.toFixed(3)}\n`; } const n= idx? idx.count : pos.count; for(let i=0;i<n;i+=3){ const a= idx? idx.getX(i) : i, b= idx? idx.getX(i+1) : i+1, c= idx? idx.getX(i+2) : i+2; out+=`f ${a+off} ${b+off} ${c+off}\n`; } off+=pos.count; }); if(typeof download==='function') download(`subestacion_${Rcur?Rcur.inp.kv:''}kV_${Rcur?Rcur.inp.tech:''}.obj`,out,'text/plain'); }
  return {mount,update,rebuild,cycleView,setView,snapshot,exportOBJ,theme,DIM,trDims,layout,get last(){ return last; },_dbg(){ return {renderer,scene,camera,root}; }};
})();
