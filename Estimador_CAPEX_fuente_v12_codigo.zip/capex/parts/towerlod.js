/* ===================== TORRE PARAMÉTRICA LOD 350 =====================
   Anatomía tomada de planos de torres de celosía (referencia ME_TS2 138 kV: stub, V de patas,
   cuerpo troncopiramidal con paneles en X, cuerpo recto, ménsulas en celosía triangular, cúpula
   de guarda) y escalada por nivel de tensión, tipo (S/A/T), ternas y disposición de fases.
   Cota 0 = cara superior del pedestal de la pata de referencia (sin extensión). */
window.TowerLOD=(function(){
  const V=(x,y,z)=>new THREE.Vector3(x,y,z);
  const UP=new THREE.Vector3(0,1,0);
  // ---- familias base por tensión (ST triangular / DT vertical) ----
  const K={
    60:{H:{ST:24,DT:30},dz:3.0,arm:[2.0,2.6,2.0],guard:2.0,bR:1.0,tg:0.055,ins:0.85,nd:5,dcyl:0.115,LV:14,D:0},
    138:{H:{ST:36,DT:44.3},dz:5.5,arm:[3.2,4.2,3.2],guard:2.7,bR:1.3,tg:0.061,ins:1.45,nd:11,dcyl:0.125,LV:16,D:0},
    220:{H:{ST:40,DT:52},dz:6.5,arm:[4.5,5.5,4.5],guard:3.2,bR:1.8,tg:0.075,ins:2.3,nd:16,dcyl:0.14,LV:18,D:0},
    500:{H:{ST:46,DT:66},dz:10,arm:[7.0,8.5,7.0],guard:4.5,bR:2.6,tg:0.09,ins:4.4,nd:28,dcyl:0.16,LV:22,D:12.5}
  };
  function fam(p){
    const k=K[p.kv]||K[220]; const f={kv:p.kv,type:p.type,circ:p.circ,disp:p.disp};
    const tT= p.type==='T'?1.35:p.type==='A'?1.15:1.0;
    f.bR=k.bR*(p.type==='T'?1.3:p.type==='A'?1.12:1); f.tg=k.tg*tT; f.dz=k.dz; f.guard=k.guard; f.ins=k.ins; f.nd=k.nd; f.dcyl=k.dcyl; f.LV=k.LV; f.D=k.D||k.arm[1]*1.8;
    const s=f.bR/1.3; f.s=s;
    let H=(p.circ==='DT'?k.H.DT:k.H.ST)+(p.type==='T'?-1:0)+(p.ext||0);
    f.H=H; f.ext=p.ext||0;
    f.sil=p.sil||'celosia';
    // niveles de ménsulas
    if(f.sil==='gato'&&p.circ!=='DT'){ // cabeza de gato: hombros con fases laterales, ventana con fase central, dos orejas con guarda
      const D=k.D||k.arm[1]*1.6; f.D=D; const hS=1.2*s; const yS=H-1.5*f.ins-2.0; f.hTronco=yS-2.2; f.bridge=null; f.levels=[]; f.gato={yS,D,hS,ear:f.bR*0.5,yTop:H}; f.yBodyTop=yS+hS; }
    else if(f.sil==='tonel'&&p.circ==='DT'){ const y1=H-f.guard-2*f.dz-1.0; f.hTronco=y1; const a=k.arm; f.levels=[{y:y1,l:a[0]*0.75},{y:y1+f.dz,l:a[1]*1.35},{y:y1+2*f.dz,l:a[2]*0.65}]; f.prof=[[y1,f.bR/2],[y1+f.dz,f.bR*0.85],[y1+2*f.dz,f.bR*0.42],[H,f.bR*0.34]]; }
    else if(f.sil==='portico'){ const D=k.D||k.arm[1]*1.6; f.D=D; H=Math.round(H*0.8); f.H=H; f.hTronco=H-2.4; f.levels=[]; f.bridge=null; f.portico={D,yB:H-1.2,dep:Math.max(1.6,0.9*s+0.9)}; }
    else if(f.sil==='bandera'&&p.circ!=='DT'){ const y1=H-f.guard-2*f.dz-1.0; f.hTronco=y1; f.levels=[{y:y1,l:k.arm[1]},{y:y1+f.dz,l:k.arm[1]},{y:y1+2*f.dz,l:k.arm[1]}]; f.bandera=true; f.disp='vertical (bandera)'; }
    else if(f.sil==='danubio'&&p.circ==='DT'){ const y1=H-f.guard-f.dz*1.15-1.0; f.hTronco=y1; f.levels=[{y:y1,l:k.arm[1]*1.55,two:true},{y:y1+f.dz*1.15,l:k.arm[0]*0.95}]; f.danubio=true; f.disp='Danubio (2 niveles)'; f.H=H=H-f.dz; }
    else if(p.disp==='horizontal'){ const dep=Math.max(1.8,1.0*s+1.0); const yb=H-dep; const hD=Math.max(6,0.2*H); const yD=yb-hD; f.hTronco=yD-1.5; f.yBodyTop=yD; f.bridge={y:yb,dep,D:f.D,yD,hD}; f.levels=[]; f.disp='horizontal (cabeza en delta)'; }
    else if(p.circ==='DT'||p.disp==='vertical'){ const y1=H-f.guard-2*f.dz-1.0; f.hTronco=y1; f.levels=[{y:y1,l:k.arm[0]},{y:y1+f.dz,l:k.arm[1]},{y:y1+2*f.dz,l:k.arm[2]}]; }
    else { const y1=H-f.guard-f.dz-1.0; f.hTronco=y1; f.levels=[{y:y1,l:k.arm[1]},{y:y1+f.dz,l:k.arm[0]}]; }
    f.hStub=1.8*Math.max(0.8,s); f.hPatas=Math.max(4.5,f.hTronco*0.21); f.hCierre=f.hPatas+1.0;
    // nodos del tronco: progresión hasta hTronco
    const nodos=[f.hPatas,f.hCierre]; let y=f.hCierre; const n=Math.max(3,Math.round((f.hTronco-f.hCierre)/(6*Math.max(0.8,s)))); const step=(f.hTronco-f.hCierre);
    for(let i=1;i<=n;i++){ nodos.push(f.hCierre+step*Math.pow(i/n,1.15)); }
    f.nodos=nodos;
    return f;
  }
  function semi(f,y){ if(f.prof&&y>=f.hTronco){ const P=f.prof; if(y>=P[P.length-1][0]) return P[P.length-1][1]; for(let i=0;i<P.length-1;i++){ if(y<=P[i+1][0]){ const t=(y-P[i][0])/Math.max(1e-6,P[i+1][0]-P[i][0]); return P[i][1]+(P[i+1][1]-P[i][1])*t; } } return P[0][1]; } return y>=f.hTronco ? f.bR/2 : f.bR/2+f.tg*(f.hTronco-y); }
  function node(f,y,sx,sz){ const h=semi(f,y); return V(sx*h,y,sz*h); }
  function bar(out,p0,p1,w,h){ const d=new THREE.Vector3().subVectors(p1,p0); const L=d.length(); if(L<1e-4) return; const g=new THREE.BoxGeometry(w,L,h||w); g.translate(0,L/2,0); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().normalize()); g.applyMatrix4(new THREE.Matrix4().compose(p0,q,new THREE.Vector3(1,1,1))); out.push(g); }
  const lerp=(a,b,t)=>a.clone().lerp(b,t);
  function panels(f){ const ys=[f.hStub]; const main=f.nodos.slice(); for(let i=0;i<main.length;i++){ const y0=ys[ys.length-1], y1=main[i]; if(y1<=y0+1e-6) continue; const Hh=y1-y0, w=2*semi(f,(y0+y1)/2); const n=Math.max(1,Math.round(Hh/Math.max(1.35*f.s,w*0.55))); for(let k=1;k<=n;k++) ys.push(y0+Hh*k/n); } return ys; }

  /* ---- ménsula en celosía triangular hacia un lado (sx) a la cota ya, saliente l desde la cara ---- */
  function arm(B,f,ya,l,sx,vol){
    const hb=semi(f,ya), tipX=hb+l, y2=ya+(vol||0.9*f.s); const tip=V(0,ya,sx*tipX);
    const i0= sx<0? [ -1,-1 ] : [ -1, 1 ], i1= sx<0? [1,-1]:[1,1]; // patas de ese lado (z = sx)
    const l0=V(-hb,ya,sx*hb), l1=V(hb,ya,sx*hb), u0=V(-semi(f,y2),y2,sx*semi(f,y2)), u1=V(semi(f,y2),y2,sx*semi(f,y2));
    const w=0.085*f.s, w2=0.05*f.s;
    bar(B.crucetas,l0,tip,w,w); bar(B.crucetas,l1,tip,w,w); bar(B.crucetas,u0,tip,w*0.9,w*0.9); bar(B.crucetas,u1,tip,w*0.9,w*0.9);
    const nT=Math.max(2,Math.round(l/(2.2*f.s)));
    for(let i=1;i<=nT;i++){ const t=i/(nT+1); const p0=lerp(l0,tip,t), p1=lerp(l1,tip,t); bar(B.crucetas,p0,p1,w2,w2); const q=lerp(lerp(u0,tip,t),lerp(u1,tip,t),0.5); bar(B.crucetas,lerp(p0,p1,0.5),q,w2,w2); if(i<nT){ const t2=(i+1)/(nT+1); bar(B.crucetas,p0,lerp(lerp(u0,tip,t2),lerp(u1,tip,t2),0.5),w2*0.9,w2*0.9); } }
    return {x:0,y:ya,z:sx*tipX,tip};
  }
  /* ---- cúpula / peak de guarda ---- */
  function peak(B,f,yBase,z,hgt){ const hb=semi(f,yBase); const top=V(0,yBase+hgt,z); const w=0.07*f.s; const zz=z===0?0:z;
    const c=[V(-hb,yBase,-hb+zz),V(hb,yBase,-hb+zz),V(hb,yBase,hb+zz),V(-hb,yBase,hb+zz)]; c.forEach(p=>bar(B.cuerpo,p,top,w,w));
    for(let k=0;k<4;k++){ const a=lerp(c[k],top,0.5), b=lerp(c[(k+1)%4],top,0.5); bar(B.cuerpo,a,b,w*0.7,w*0.7); }
    return top; }
  /* ---- aislador de suspensión (cadena) desde un punto hacia abajo ---- */
  function chain(B,f,from,dir,len){ const nd=f.nd, rr=f.dcyl; const d=dir.clone().normalize(); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().negate()); const RQ=new THREE.Matrix4().makeRotationFromQuaternion(q);
    const rod=new THREE.CylinderGeometry(0.03*Math.max(1,f.s),0.03*Math.max(1,f.s),len,6); rod.translate(0,-len/2,0); rod.applyMatrix4(RQ); rod.translate(from.x,from.y,from.z); B.aisladores.push(rod);
    const pitch=(len-0.35)/Math.max(1,nd-1);
    for(let i=0;i<nd;i++){ const disc=new THREE.CylinderGeometry(rr,rr*0.9,0.04,14); disc.translate(0,-(0.2+i*pitch),0); disc.applyMatrix4(RQ); disc.translate(from.x,from.y,from.z); B.aisladores.push(disc); }
    const end=from.clone().add(d.clone().multiplyScalar(len)); const clamp=new THREE.BoxGeometry(0.32*f.s,0.1,0.12); clamp.translate(end.x,end.y-0.05,end.z); B.aisladores.push(clamp); return end; }
  /* ---- tramo pasante de conductor (haz) en un punto de amarre, a lo largo de x ---- */
  function conductor(B,f,p,n,rad,isGuard,ph){ const L=f.LV; const out= isGuard? B.conductores : B['cond'+((ph||0)%3)]; const offs= n<=1?[[0,0]]:n===2?[[0,-0.225],[0,0.225]]:n===3?[[0.2,0],[-0.13,-0.225],[-0.13,0.225]]:[[0.225,-0.225],[0.225,0.225],[-0.225,-0.225],[-0.225,0.225]];
    const span=p.span||0, sagF=p.sagF||0;
    offs.forEach(([oy,oz])=>{ if(span>0&&sagF>0){ /* catenaria (parábola) hacia el medio vano a cada lado: y = y0 − s·(2u − u²), u = x / (vano/2) */ const Lh=span/2, sag=sagF*span; [-1,1].forEach(side=>{ const pts=[]; const N=14; for(let i=0;i<=N;i++){ const u=i/N; pts.push(new THREE.Vector3(p.x+side*u*Lh,p.y+oy-sag*(2*u-u*u),p.z+oz)); } const tube=new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),N,rad,6,false); out.push(tube); }); }
      else { const c=new THREE.CylinderGeometry(rad,rad,L,8); c.rotateZ(Math.PI/2); c.translate(p.x,p.y+oy,p.z+oz); out.push(c); } });
    if(n>1){ [-L*0.3,L*0.3].forEach(x=>{ const sp=new THREE.BoxGeometry(0.06,0.55,0.55); sp.translate(p.x+x,p.y,p.z); out.push(sp); }); }
    if(!isGuard){ const grapa=new THREE.BoxGeometry(0.4*f.s,0.16,0.16); grapa.translate(p.x,p.y+0.1,p.z); out.push(grapa); } }

  /* ---- amarres compartidos: cable de guarda, fase en cadena (S: I o V; A/T: tracción + puente) y fase sobre aislador rígido ---- */
  function attachGuard(B,f,a,rad){ const c=new THREE.BoxGeometry(0.16,0.22,0.16); c.translate(a.x,a.y-0.14,a.z); B.aisladores.push(c); conductor(B,f,V(a.x,a.y-0.3,a.z),1,rad||0.028,true); }
  function bundleOffs(n){ return n<=1?[[0,0]]:n===2?[[0,-0.225],[0,0.225]]:n===3?[[0.2,0],[-0.13,-0.225],[-0.13,0.225]]:[[0.225,-0.225],[0.225,0.225],[-0.225,-0.225],[-0.225,0.225]]; }
  function attachPhase(B,f,a,type,n,rad,ph,sag0){
    const from=V(a.x,a.y,a.z);
    if(type==='S'){
      if(a.v){ const dz=f.ins*0.55; const e1=chain(B,f,V(a.x,a.y,a.z-dz),V(0,-1,dz/f.ins),f.ins); chain(B,f,V(a.x,a.y,a.z+dz),V(0,-1,-dz/f.ins),f.ins); conductor(B,f,e1,n,rad,false,ph); return e1.y; }
      const e=chain(B,f,from,V(0,-1,0),f.ins); conductor(B,f,e,n,rad,false,ph); return e.y; }
    // ángulo / anclaje: cadenas de tracción a lo largo de la línea (dobles con yugo en 500 kV), tramos de conductor salientes y puente flojo bajo el amarre
    const drop= type==='A'?0.16:0.1; const offs= f.kv>=500? [-0.3,0.3] : [0]; let eL=null,eR=null;
    offs.forEach(oz=>{ const fr=V(a.x,a.y,a.z+oz); const l=chain(B,f,fr,V(-1,-drop,0),f.ins), r=chain(B,f,fr,V(1,-drop,0),f.ins); if(!eL){ eL=l; eR=r; } });
    if(offs.length>1){ [eL,eR].forEach(e=>{ const y=new THREE.BoxGeometry(0.12,0.12,0.75); y.translate(e.x,e.y,a.z); B.aisladores.push(y); }); }
    const out=B['cond'+(ph%3)]; const L=f.LV/2;
    bundleOffs(n).forEach(([oy,oz])=>{ [[eL,-1],[eR,1]].forEach(([e,sx])=>{ const c=new THREE.CylinderGeometry(rad,rad,L,8); c.rotateZ(Math.PI/2); c.translate(e.x+sx*L/2,e.y+oy,a.z+oz); out.push(c); }); });
    const sag= sag0||Math.max(0.6,f.ins*0.9+0.9*(f.s||0.7));
    bundleOffs(n).forEach(([oy,oz])=>{ const cv=new THREE.QuadraticBezierCurve3(V(eL.x,eL.y+oy,a.z+oz),V(a.x,a.y-sag+oy,a.z+0.15+oz),V(eR.x,eR.y+oy,a.z+oz)); out.push(new THREE.TubeGeometry(cv,14,rad*0.9,6,false)); });
    return a.y-sag;
  }
  function attachPin(B,f,a,type,ph,rad,withPin,insL){
    const out=B['cond'+(ph%3)]; const r=rad||0.02;
    if(type!=='T'){ if(withPin){ const pin=new THREE.CylinderGeometry(0.06,0.08,0.3,10); pin.translate(a.x,a.y+0.15,a.z); B.aisladores.push(pin); } const yc=a.y+(withPin?0.32:0.05); conductor(B,f,V(a.x,yc,a.z),1,r,false,ph); return yc; }
    // retención / terminal: aisladores de tracción horizontales a cada lado + conductor saliente + puente flojo por encima del apoyo
    const L=insL||Math.max(0.35,f.ins*1.2); const y=a.y+0.12; const x0=0.12;
    [-1,1].forEach(sx=>{ const rod=new THREE.CylinderGeometry(0.03,0.03,L,8); rod.rotateZ(Math.PI/2); rod.translate(a.x+sx*(x0+L/2),y,a.z); B.aisladores.push(rod); const nsh=Math.max(2,Math.round(L/0.11)); for(let j=0;j<nsh;j++){ const d=new THREE.CylinderGeometry(0.06,0.055,0.02,10); d.rotateZ(Math.PI/2); d.translate(a.x+sx*(x0+0.06+j*(L-0.12)/nsh),y,a.z); B.aisladores.push(d); }
      const q0=a.x+sx*(x0+L), Lc=f.LV/2; const c=new THREE.CylinderGeometry(r,r,Lc,6); c.rotateZ(Math.PI/2); c.translate(q0+sx*Lc/2,y,a.z); out.push(c); });
    const cv=new THREE.QuadraticBezierCurve3(V(a.x-(x0+L),y,a.z),V(a.x,y+0.55,a.z+0.06),V(a.x+(x0+L),y,a.z)); out.push(new THREE.TubeGeometry(cv,10,r*0.9,5,false));
    return y;
  }
  function guyWire(B,top,anc,fundArr,feet){ const d=new THREE.Vector3().subVectors(anc,top); const g=new THREE.CylinderGeometry(0.012,0.012,d.length(),5); g.translate(0,d.length()/2,0); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().normalize()); g.applyMatrix4(new THREE.Matrix4().compose(top,q,new THREE.Vector3(1,1,1))); B.conductores.push(g); const blk=new THREE.BoxGeometry(0.5,0.5,0.5); blk.translate(anc.x,anc.y-0.4,anc.z); fundArr.push(blk); if(feet) feet.push(V(anc.x,-0.8,anc.z)); const ai=new THREE.CylinderGeometry(0.045,0.045,0.3,8); const mid=top.clone().lerp(anc,0.25); ai.translate(mid.x,mid.y,mid.z); B.aisladores.push(ai); }

  function build(p){
    if(p.sil==='mono') return buildMono(p);
    if(p.sil==='vsl') return buildVSL(p);
    if(p.sil==='hpole'||p.sil==='hmono') return buildHFrame(p);
    if(p.sil==='bt') return buildBT(p);
    if(p.sil==='poste'||p.sil==='compacto') return buildPoste(p);
    const f=fam(p); const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    if(f.portico) return buildPortico(p,f,B);
    const S=[[-1,1],[-1,-1],[1,-1],[1,1]]; // A B C D
    const N=(y,i)=>node(f,y,S[i][0],S[i][1]);
    const s=f.s, legs=p.legs||[0,0,0,0];
    const wLeg=0.13*s, wStub=0.14*s, wDiag=0.06*s, wTrav=0.075*s;
    /* --- patas: pedestal a la cota -e_k, stub, empalme, montante hasta el cierre de la V --- */
    const feet=[];
    for(let i=0;i<4;i++){ const e=Math.max(0,legs[i]||0); const yPed=-e+0.3; const yStubTop=Math.max(yPed+0.6,f.hStub-e*0); // el stub llega a hStub medido desde la base de referencia
      const p0=N(yPed,i), p1=N(f.hStub,i), p2=N(f.hPatas,i);
      bar(B.patas,p0,p1,wStub,wStub); bar(B.patas,p1,p2,wLeg,wLeg);
      const dirL=new THREE.Vector3().subVectors(p2,p0).normalize(); bar(B.patas,p1.clone().addScaledVector(dirL,-0.28*s),p1.clone().addScaledVector(dirL,0.28*s),wStub*1.5,wStub*1.5);
      const rad=new THREE.Vector3(S[i][0],0,S[i][1]).normalize();
      for(let y=f.hStub+0.9*s;y<f.hPatas-0.5;y+=1.25*s){ const a=N(y,i), q=N(y+0.55*s,i).addScaledVector(rad,-0.42*s); bar(B.patas,a,q,0.045*s,0.045*s); bar(B.patas,N(y+0.55*s,i),q,0.045*s,0.045*s); }
      // arriostres de la extensión de pata (si es larga) hacia el interior
      if(e>2){ for(let y=yPed+1.0;y<f.hStub-0.5;y+=1.5*s){ const a=N(y,i), q=N(y+0.7*s,i).addScaledVector(rad,-0.5*s); bar(B.patas,a,q,0.045*s,0.045*s); bar(B.patas,N(y+0.7*s,i),q,0.045*s,0.045*s); } }
      // cimentación: zapata + pedestal + capitel, centrados en el eje de pata a la cota del pedestal
      const hf=semi(f,yPed); const cx=S[i][0]*hf, cz=S[i][1]*hf; const zap=new THREE.BoxGeometry(2.4*s,0.6*s,2.4*s); zap.translate(cx,yPed-0.3-1.0*s-0.3*s,cz); const ped=new THREE.BoxGeometry(0.6*s,1.0*s+0.3,0.6*s); ped.translate(cx,yPed-(1.0*s+0.3)/2,cz); const cap=new THREE.ConeGeometry(0.6*s*0.7071,0.1,4); cap.rotateY(Math.PI/4); cap.translate(cx,yPed+0.05,cz);
      B.fund[i].push(zap,ped,cap); feet.push(V(cx,yPed-0.3,cz)); }
    /* --- cierre de la V --- */
    [[0,1],[1,2],[2,3],[3,0]].forEach(([a,b])=>{ const pa=N(f.hPatas,a), pb=N(f.hPatas,b); bar(B.patas,pa,pb,wTrav,wTrav); const mid=lerp(pa,pb,0.5); const qa=lerp(pa,N(f.hStub,a),0.62), qb=lerp(pb,N(f.hStub,b),0.62); bar(B.patas,mid,qa,0.07*s,0.07*s); bar(B.patas,mid,qb,0.07*s,0.07*s); bar(B.patas,qa,qb,0.055*s,0.055*s); });
    /* --- cuerpo: montantes + X por panel --- */
    const ys=panels(f); const wBar=y=>0.185*s-0.085*s*Math.max(0,Math.min(1,(y-f.hStub)/(f.hTronco-f.hStub)));
    for(let k=0;k<ys.length-1;k++){ const y0=ys[k], y1=ys[k+1]; if(y1<=f.hPatas+1e-6) continue; const bucket= y1<=f.hCierre+1e-6? B.patas : B.cuerpo; const w=wBar(y0);
      for(let i=0;i<4;i++) bar(bucket,N(y0,i),N(y1,i),w,w);
      [[0,1],[1,2],[2,3],[3,0]].forEach(([a,b])=>{ bar(bucket,N(y0,a),N(y1,b),wDiag,wDiag); bar(bucket,N(y1,a),N(y0,b),wDiag,wDiag); }); }
    f.nodos.forEach(y=>{ if(y<=f.hPatas+1e-6) return; [[0,1],[1,2],[2,3],[3,0]].forEach(([a,b])=>bar(B.cuerpo,N(y,a),N(y,b),wTrav,wTrav)); if(y>=f.hTronco-1e-6) bar(B.cuerpo,N(y,0),N(y,2),0.05*s,0.05*s); });
    /* --- cuerpo recto: paneles hasta la cúspide --- */
    const yTop=f.yBodyTop||f.H; const rectoYs=[f.hTronco]; { let y=f.hTronco; const step=Math.max(1.4*s,f.bR*0.9); while(y+step<yTop-0.01){ y+=step; rectoYs.push(y); } rectoYs.push(yTop); }
    for(let k=0;k<rectoYs.length-1;k++){ const y0=rectoYs[k], y1=rectoYs[k+1]; for(let i=0;i<4;i++) bar(B.cuerpo,N(y0,i),N(y1,i),0.1*s,0.1*s); [[0,1],[1,2],[2,3],[3,0]].forEach(([a,b])=>{ bar(B.cuerpo,N(y0,a),N(y1,b),wDiag*0.9,wDiag*0.9); bar(B.cuerpo,N(y1,a),N(y0,b),wDiag*0.9,wDiag*0.9); bar(B.cuerpo,N(y1,a),N(y1,b),0.06*s,0.06*s); }); }
    /* --- ménsulas y amarres --- */
    const anclas=[]; const ng=p.nGuard||1;
    if(f.gato){ // ---- cabeza de gato ----
      const G=f.gato, yS=G.yS, D=G.D, hS=G.hS, hb=semi(f,yS), wB=0.11*s, e=G.ear; const zTip=D+1.5;
      // hombros: viga en celosía a ambos lados, cordón superior desde yS+hS (cara del cuerpo) hasta yS+0.8 (extremo)
      const yTopAt=z=>{ const t=Math.max(0,Math.min(1,(Math.abs(z)-hb)/(zTip-hb))); return yS+hS*(1-t)+0.8*t; };
      [-1,1].forEach(sz=>{ const tipZ=sz*zTip; for(const t of [0,1]){ const x=t?hb*0.9:-hb*0.9; bar(B.crucetas,V(x,yS,sz*hb),V(x,yS,tipZ),wB,wB); bar(B.crucetas,V(x,yS+hS,sz*hb),V(x,yS+0.8,tipZ),wB*0.8,wB*0.8); }
        const n=Math.max(3,Math.round(D/2.4)); for(let i=1;i<=n;i++){ const t=i/(n+1); const z=sz*(hb+(zTip-hb)*t); const yt=yTopAt(z); bar(B.crucetas,V(-hb*0.9,yS,z),V(hb*0.9,yS,z),wDiag,wDiag); bar(B.crucetas,V(-hb*0.9,yS,z),V(hb*0.9,yt,z),wDiag,wDiag); bar(B.crucetas,V(hb*0.9,yS,z),V(-hb*0.9,yt,z),wDiag,wDiag); bar(B.crucetas,V(-hb*0.9,yt,z),V(hb*0.9,yt,z),wDiag,wDiag); }
        anclas.push({k:'cond',x:0,y:yS-0.2,z:sz*D,v:p.kv>=500}); });
      // orejas: dos columnas en celosía (sección e×e) apoyadas sobre los hombros, inclinadas hacia adentro hasta la cúspide
      const yT=G.yTop; const ears=[]; const zin=e*0.9;
      [-1,1].forEach(sz=>{ const z0=sz*(hb+0.22*D), z1=sz*(hb+0.15*D); const y0=yTopAt(z0); const nP=Math.max(3,Math.round((yT-y0)/(1.3*s)));
        const P=(x,t,dz)=>V(x,y0+(yT-y0)*t,z0+(z1-z0)*t+(dz||0));
        for(let k=0;k<nP;k++){ const t0=k/nP,t1=(k+1)/nP; for(const dz of [0,-sz*zin]){ [-e/2,e/2].forEach(x=>bar(B.cuerpo,P(x,t0,dz),P(x,t1,dz),0.09*s,0.09*s)); bar(B.cuerpo,P(-e/2,t0,dz),P(e/2,t1,dz),wDiag,wDiag); bar(B.cuerpo,P(e/2,t0,dz),P(-e/2,t1,dz),wDiag,wDiag); bar(B.cuerpo,P(-e/2,t1,dz),P(e/2,t1,dz),0.05*s,0.05*s); }
          [-e/2,e/2].forEach(x=>{ bar(B.cuerpo,P(x,t0,0),P(x,t1,-sz*zin),wDiag*0.9,wDiag*0.9); bar(B.cuerpo,P(x,t1,0),P(x,t1,-sz*zin),0.05*s,0.05*s); }); }
        ears.push({z:z1,sz}); });
      // cúspides de guarda sobre cada oreja
      ears.forEach(er=>{ const zz=er.z, sz=er.sz; const w=0.07*s; const cs=[V(-e/2,yT,zz-sz*zin),V(e/2,yT,zz-sz*zin),V(e/2,yT,zz),V(-e/2,yT,zz)]; const tp=V(0,yT+f.guard*0.7,zz-sz*zin*0.5); cs.forEach(pp=>bar(B.cuerpo,pp,tp,w,w)); anclas.push({k:'guard',x:0,y:tp.y,z:tp.z}); });
      // dintel de la ventana (cúspide) y viga intermedia entre orejas
      const zl=ears[0].z+zin, zr=ears[1].z-zin;
      [yT-0.2].forEach((yy,i)=>{ const wv=0.1*s; for(const x of [-e/2,e/2]){ bar(B.crucetas,V(x,yy,zl),V(x,yy,zr),wv,wv); bar(B.crucetas,V(x,yy-0.9*s,zl),V(x,yy-0.9*s,zr),wv*0.8,wv*0.8); } const n=Math.max(2,Math.round(Math.abs(zr-zl)/(1.6*s))); for(let k=1;k<n;k++){ const z=zl+(zr-zl)*k/n; bar(B.crucetas,V(-e/2,yy,z),V(e/2,yy,z),wDiag,wDiag); bar(B.crucetas,V(-e/2,yy,z),V(e/2,yy-0.9*s,z),wDiag,wDiag); bar(B.crucetas,V(e/2,yy,z),V(-e/2,yy-0.9*s,z),wDiag,wDiag); } if(i===0) anclas.push({k:'cond',x:0,y:yy-0.9*s-0.15,z:0,v:p.kv>=500}); });
    } else if(f.bridge){ // horizontal: cabeza en delta (torre de cintura) — dos montantes inclinados en celosía desde la cintura hasta la viga continua; fase central en la ventana, laterales en los voladizos
      const Bd=f.bridge, D=Bd.D, yb=Bd.y, dep=Bd.dep, yD=Bd.yD; const hb=semi(f,yD); const zL=D*0.7; const hwB=Math.max(0.5,0.45*s);
      // montantes del delta: loft continuo desde cada mitad del rectángulo superior del cuerpo hasta la sección bajo la viga
      [-1,1].forEach(sz=>{ const q0=[V(-hb,yD,0),V(hb,yD,0),V(hb,yD,sz*hb),V(-hb,yD,sz*hb)]; const q1=[V(-hwB*0.9,yb,sz*zL-sz*hwB*0.9),V(hwB*0.9,yb,sz*zL-sz*hwB*0.9),V(hwB*0.9,yb,sz*zL+sz*hwB*0.9),V(-hwB*0.9,yb,sz*zL+sz*hwB*0.9)]; latticeLoft(B,q0,q1,s,B.cuerpo); });
      latticeBeam(B,-(D+1.8),D+1.8,yb+dep,dep,hwB,s,B.crucetas);
      [[0,1],[1,2],[2,3],[3,0]].forEach(([a,b])=>bar(B.cuerpo,N(yD,a),N(yD,b),wTrav,wTrav));
      for(let i=1;i<=2;i++){ const t=i/3; const y=yD+(yb-yD)*t; const z=hb+(zL-hb)*t; [-hb*0.9,hb*0.9].forEach(x=>bar(B.cuerpo,V(x,y,-z),V(x,y,z),wDiag,wDiag)); if(i===1){ [-hb*0.9,hb*0.9].forEach(x=>{ bar(B.cuerpo,V(x,y,-z),V(x,yD+(yb-yD)*2/3,0),wDiag*0.9,wDiag*0.9); bar(B.cuerpo,V(x,y,z),V(x,yD+(yb-yD)*2/3,0),wDiag*0.9,wDiag*0.9); }); } }
      [-D,0,D].forEach(z=>anclas.push({k:'cond',x:0,y:yb-0.2,z,v:p.kv>=500}));
      [-1,1].forEach(sz=>{ const zz=sz*zL; const tp=V(0,yb+dep+f.guard*0.7,zz); [[-hwB,-0.8],[hwB,-0.8],[hwB,0.8],[-hwB,0.8]].forEach(([x,dz])=>bar(B.cuerpo,V(x,yb+dep,zz+dz),tp,0.07*s,0.07*s)); anclas.push({k:'guard',x:0,y:tp.y,z:zz}); });
    } else {
      f.levels.forEach((lv,i)=>{ const sides = f.bandera ? [1] : (p.circ==='DT') ? [-1,1] : (p.disp==='vertical' ? [i%2?-1:1] : (i===0?[-1,1]:[1])); sides.forEach(sx=>{ const a=arm(B,f,lv.y,lv.l,sx,0.9*s); anclas.push({k:'cond',x:0,y:a.y,z:a.z}); if(lv.two){ const hb=semi(f,lv.y); anclas.push({k:'cond',x:0,y:a.y,z:sx*(hb+lv.l*0.5)}); } }); });
      const yc=f.levels[f.levels.length-1].y; const hc=semi(f,yc);
      if(ng>=2){ [-1,1].forEach(sz=>{ const zz=sz*(hc+1.6*s); bar(B.crucetas,V(-hc,yTop,sz*hc),V(0,yTop,zz),0.08*s,0.08*s); bar(B.crucetas,V(hc,yTop,sz*hc),V(0,yTop,zz),0.08*s,0.08*s); bar(B.crucetas,V(-hc,yTop-0.9*s,sz*hc),V(0,yTop,zz),0.06*s,0.06*s); bar(B.crucetas,V(hc,yTop-0.9*s,sz*hc),V(0,yTop,zz),0.06*s,0.06*s); anclas.push({k:'guard',x:0,y:yTop-0.15,z:zz}); }); }
      else { const top=peak(B,f,yTop,0,f.guard*0.6); anclas.push({k:'guard',x:0,y:top.y,z:0}); }
    }
    /* --- aisladores y conductores --- */
    const type=p.type, n=p.nCond||1; let yLow=Infinity; let phi=0;
    anclas.forEach(a=>{ if(a.k==='guard'){ attachGuard(B,f,a,0.028); return; } const ph=phi++; yLow=Math.min(yLow,attachPhase(B,f,a,type,n,0.055,ph,f.ins*0.9+1.1*s)); });
    const Htop=Math.max(f.H,...anclas.map(a=>a.y)); const info={H:Htop,Hbody:f.H,H0:Htop-f.ext,base:2*semi(f,0),bR:f.bR,hTronco:f.hTronco,feet,yLow,anclas,fam:f,levels:f.levels,armW: f.gato? 2*(f.gato.D+1.5) : f.bridge? 2*(f.bridge.D+1.8) : 2*(semi(f,f.levels[0].y)+Math.max(...f.levels.map(l=>l.l)))};
    let piezas=0; for(const k in B){ if(k==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[k].length; }
    info.piezas=piezas;
    return {B,info};
  }
  /* ===================== PÓRTICO EN CELOSÍA (H-frame) ===================== */
  function latticeColumn(B,cx,cz,hw,y0,y1,s,bucket){ const c=[[-1,-1],[1,-1],[1,1],[-1,1]]; const P=(y,i)=>V(cx+c[i][0]*hw,y,cz+c[i][1]*hw); const n=Math.max(2,Math.round((y1-y0)/Math.max(1.3*s,hw*1.6))); const w=0.11*s, wd=0.055*s;
    for(let k=0;k<n;k++){ const a=y0+(y1-y0)*k/n, b=y0+(y1-y0)*(k+1)/n; for(let i=0;i<4;i++) bar(bucket,P(a,i),P(b,i),w,w); [[0,1],[1,2],[2,3],[3,0]].forEach(([i,j])=>{ bar(bucket,P(a,i),P(b,j),wd,wd); bar(bucket,P(b,i),P(a,j),wd,wd); bar(bucket,P(b,i),P(b,j),0.05*s,0.05*s); }); } }
  function latticeBeam(B,z0,z1,y,dep,hw,s,bucket){ const w=0.1*s, wd=0.055*s; const n=Math.max(3,Math.round(Math.abs(z1-z0)/(1.6*s)));
    for(const x of [-hw,hw]) for(const yy of [y,y-dep]) bar(bucket,V(x,yy,z0),V(x,yy,z1),w,w);
    for(let k=0;k<=n;k++){ const z=z0+(z1-z0)*k/n, zn=z0+(z1-z0)*Math.min(n,k+1)/n; for(const x of [-hw,hw]) bar(bucket,V(x,y,z),V(x,y-dep,z),wd,wd); bar(bucket,V(-hw,y,z),V(hw,y,z),wd,wd); bar(bucket,V(-hw,y-dep,z),V(hw,y-dep,z),wd,wd); if(k<n){ for(const x of [-hw,hw]) bar(bucket,V(x,y,z),V(x,y-dep,zn),wd,wd); bar(bucket,V(-hw,y,z),V(hw,y,zn),wd,wd); } } }
  function buildPortico(p,f,B){ const s=f.s, P=f.portico, D=P.D, yB=P.yB, dep=P.dep, hw=Math.max(0.55,f.bR*0.5); const legs=p.legs||[0,0,0,0]; const feet=[]; const anclas=[];
    const cZ=D*0.55; // columnas entre la fase central y las laterales; la viga vuela hasta ±(D+1.5) para las fases exteriores
    [-1,1].forEach((sz,ci)=>{ const e=Math.max(0,(legs[ci*2]||0)+(legs[ci*2+1]||0))/2; const yPed=-e+0.3; const cz=sz*cZ; latticeColumn(B,0,cz,hw,yPed,yB-dep,s,B.patas); latticeColumn(B,0,cz,hw,yB-dep,yB+0.6*s,s,B.cuerpo);
      [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([x,z])=>{ const cx=x*hw, czz=cz+z*hw; const zap=new THREE.BoxGeometry(1.4*s,0.5*s,1.4*s); zap.translate(cx,yPed-0.3-0.8*s,czz); const ped=new THREE.BoxGeometry(0.45*s,0.8*s+0.3,0.45*s); ped.translate(cx,yPed-(0.8*s+0.3)/2,czz); B.fund[ci*2+(z>0?1:0)].push(zap,ped); });
      feet.push(V(0,yPed-0.3,cz-hw),V(0,yPed-0.3,cz+hw));
      // cúspide de guarda sobre cada columna
      const tp=V(0,yB+0.6*s+f.guard*0.6,cz); [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(([x,z])=>bar(B.cuerpo,V(x*hw,yB+0.6*s,cz+z*hw),tp,0.07*s,0.07*s)); anclas.push({k:'guard',x:0,y:tp.y,z:cz}); });
    latticeBeam(B,-(D+1.5),-cZ-hw,yB,dep,hw*0.9,s,B.crucetas); latticeBeam(B,-cZ+hw,cZ-hw,yB,dep,hw*0.9,s,B.crucetas); latticeBeam(B,cZ+hw,D+1.5,yB,dep,hw*0.9,s,B.crucetas);
    // riostras en K entre columna y viga (interior) y tornapuntas de los voladizos
    [-1,1].forEach(sz=>{ bar(B.crucetas,V(0,yB-dep-2.2*s,sz*(cZ-hw)),V(0,yB-dep,sz*(cZ-hw-1.8*s)),0.07*s,0.07*s); bar(B.crucetas,V(0,yB-dep-2.0*s,sz*(cZ+hw)),V(0,yB-dep,sz*(D+0.8)),0.07*s,0.07*s); });
    [-D,0,D].forEach(z=>anclas.push({k:'cond',x:0,y:yB-dep-0.15,z,v:p.kv>=500}));
    const type=p.type, n=p.nCond||1; let yLow=Infinity; let phi=0;
    anclas.forEach(a=>{ if(a.k==='guard'){ attachGuard(B,f,a,0.028); return; } const ph=phi++; yLow=Math.min(yLow,attachPhase(B,f,a,type,n,0.055,ph,f.ins*0.9+1.1*s)); });
    const Htop=Math.max(...anclas.map(a=>a.y)); const info={H:Htop,Hbody:f.H,H0:Htop-f.ext,base:2*cZ+2*hw,bR:2*hw,hTronco:yB-dep,feet,yLow,anclas,fam:f,levels:[],armW:2*(D+1.5),portico:true};
    let piezas=0; for(const k in B){ if(k==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[k].length; } info.piezas=piezas; return {B,info}; }

  /* ===================== POSTE TUBULAR DE ACERO (monoposte con ménsulas davit) ===================== */
  const MONO={60:{H:{ST:22,DT:26},r0:0.42,r1:0.16,arm:2.2,dz:2.4},138:{H:{ST:28,DT:34},r0:0.6,r1:0.22,arm:3.2,dz:4.2},220:{H:{ST:34,DT:42},r0:0.8,r1:0.28,arm:4.2,dz:5.6},500:{H:{ST:44,DT:56},r0:1.15,r1:0.4,arm:6.8,dz:9.5}};
  function tube(out,p0,p1,r0,r1,seg){ const d=new THREE.Vector3().subVectors(p1,p0); const L=d.length(); const g=new THREE.CylinderGeometry(r1,r0,L,seg||12); g.translate(0,L/2,0); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().normalize()); g.applyMatrix4(new THREE.Matrix4().compose(p0,q,new THREE.Vector3(1,1,1))); out.push(g); }
  function buildMono(p){ const k=MONO[p.kv]||MONO[220]; const kk=K[p.kv]||K[220]; const f={kv:p.kv,type:p.type,circ:p.circ,disp:'vertical',ins:kk.ins,nd:kk.nd,dcyl:kk.dcyl,LV:kk.LV,s:kk.bR/1.3,guard:kk.guard,sil:'mono',bR:2*k.r0,tg:0,hTronco:0,levels:[]};
    const tT=p.type==='T'?1.25:p.type==='A'?1.12:1; const H=(p.circ==='DT'?k.H.DT:k.H.ST)+(p.ext||0); f.H=H; f.ext=p.ext||0; const r0=k.r0*tT, r1=k.r1*tT;
    const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    // fuste poligonal en 2–3 tramos telescópicos (traslape) + placa base + pernos + pedestal
    const nT=H>30?3:2; for(let i=0;i<nT;i++){ const y0=H*i/nT, y1=H*(i+1)/nT+(i<nT-1?1.2:0); const ra=r0+(r1-r0)*(y0/H), rb=r0+(r1-r0)*(Math.min(H,y1)/H); tube(B.cuerpo,V(0,y0,0),V(0,y1,0),ra*(i?1.04:1),rb,12); }
    const plate=new THREE.CylinderGeometry(r0*1.6,r0*1.6,0.06,12); plate.translate(0,0.03,0); B.patas.push(plate); for(let i=0;i<12;i++){ const a=i/12*Math.PI*2; const b=new THREE.CylinderGeometry(0.03,0.03,0.35,6); b.translate(Math.cos(a)*r0*1.35,0.2,Math.sin(a)*r0*1.35); B.patas.push(b); }
    const ped=new THREE.CylinderGeometry(r0*1.9,r0*1.9,0.4,12); ped.translate(0,-0.2,0); const pile=new THREE.CylinderGeometry(r0*1.7,r0*1.7,Math.max(4,H*0.14),12); pile.translate(0,-0.4-Math.max(4,H*0.14)/2,0); B.fund[0].push(ped,pile);
    const feet=[V(-r0*1.6,-0.4,-r0*1.6),V(r0*1.6,-0.4,-r0*1.6),V(r0*1.6,-0.4,r0*1.6),V(-r0*1.6,-0.4,r0*1.6)];
    // ménsulas davit: brazo curvo (3 tramos) que sale del fuste y sube ligeramente
    const anclas=[]; const arm=k.arm*(p.type==='T'?1.1:1); const yTop=H; const lv= p.circ==='DT'||p.disp==='vertical'||true ? [yTop-f.guard-2*k.dz-0.6, yTop-f.guard-k.dz-0.6, yTop-f.guard-0.6] : [];
    const sides= p.circ==='DT'? [[-1,1],[-1,1],[-1,1]] : (p.disp==='triangular'? [[-1,1],[1]] : [[-1],[1],[-1]]);
    const levels= p.circ==='DT'? lv : (p.disp==='triangular'? [lv[1],lv[2]] : lv);
    levels.forEach((y,i)=>{ const rr=r0+(r1-r0)*(y/H); (sides[i]||[1]).forEach(sx=>{ const p0=V(0,y,sx*rr*0.9), p1=V(0,y+0.35*arm,sx*(rr+arm*0.45)), p2=V(0,y+0.5*arm,sx*(rr+arm*0.8)), p3=V(0,y+0.5*arm,sx*(rr+arm)); tube(B.crucetas,p0,p1,0.16*tT,0.13*tT,8); tube(B.crucetas,p1,p2,0.13*tT,0.1*tT,8); tube(B.crucetas,p2,p3,0.1*tT,0.08*tT,8); const gus=new THREE.BoxGeometry(0.5,0.9,0.12); gus.translate(0,y-0.35,sx*rr*0.95); B.crucetas.push(gus); anclas.push({k:'cond',x:0,y:p3.y-0.05,z:p3.z}); f.levels.push({y,l:arm}); }); });
    // cúspide de guarda: horquilla en la cima
    const ng=p.nGuard||1; if(ng>=2){ [-1,1].forEach(sz=>{ tube(B.crucetas,V(0,yTop-0.2,0),V(0,yTop+0.5,sz*(r1+1.4)),0.09,0.06,8); anclas.push({k:'guard',x:0,y:yTop+0.45,z:sz*(r1+1.4)}); }); } else { tube(B.crucetas,V(0,yTop,0),V(0,yTop+f.guard*0.35,0),0.1,0.05,8); anclas.push({k:'guard',x:0,y:yTop+f.guard*0.35,z:0}); }
    const type=p.type, n=p.nCond||1; let yLow=Infinity, phi=0;
    anclas.forEach(a=>{ if(a.k==='guard'){ attachGuard(B,f,a,0.028); return; } const ph=phi++; yLow=Math.min(yLow,attachPhase(B,f,a,type,n,0.055,ph,f.ins*0.9+0.8)); });
    const Htop=Math.max(...anclas.map(a=>a.y)); const info={H:Htop,Hbody:H,H0:Htop-f.ext,base:2*r0,bR:2*r1,hTronco:0,feet,yLow,anclas,fam:f,levels:f.levels,armW:2*(r0+arm),mono:true,r0,r1};
    let piezas=0; for(const kx in B){ if(kx==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[kx].length; } info.piezas=piezas; return {B,info}; }

  /* ===================== POSTE DE CONCRETO / MADERA CON CRUCETAS (60–33 kV y MT 22.9/10 kV) ===================== */
  const POSTE={60:{H:18,r0:0.24,r1:0.11,cru:4.6,dz:2.2,ins:0.85,nd:5,pin:false},33:{H:15,r0:0.2,r1:0.1,cru:3.0,dz:1.6,ins:0.55,nd:3,pin:false},22.9:{H:13,r0:0.19,r1:0.09,cru:2.4,dz:1.2,ins:0.35,nd:0,pin:true},10:{H:12,r0:0.18,r1:0.09,cru:2.0,dz:1.0,ins:0.3,nd:0,pin:true}};
  function buildPoste(p){ const kv=POSTE[p.kv]?p.kv:(p.kv>=45?60:p.kv>=25?33:p.kv>=15?22.9:10); const k=POSTE[kv]; const kk=K[p.kv]||K[60];
    const f={kv:p.kv,type:p.type,circ:p.circ,disp:p.circ==='DT'?'vertical':'horizontal',ins:k.ins,nd:k.nd||1,dcyl:0.1,LV:12,s:0.7,guard:1.2,sil:'poste',bR:2*k.r0,tg:0,hTronco:0,levels:[],pin:k.pin};
    const H=k.H-1.6+(p.ext||0); f.H=H; f.ext=p.ext||0; const mat=p.mat||'PC'; const wood=mat==='PM';
    const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    const mrt=p.mrt||p.circ==='MRT'; const dbl= p.type!=='S'; // ángulo / retención: cruceta doble
    const poleR=(y)=>k.r0+(k.r1-k.r0)*(y/H);
    const compact=p.sil==='compacto'; tube(wood?B.madera:B.concreto,V(0,-1.6,0),V(0,H,0),k.r0*1.15,k.r1,wood?10:14);
    const emp=new THREE.CylinderGeometry(k.r0*2.2,k.r0*2.6,1.7,12); emp.translate(0,-1.65,0); B.fund[0].push(emp); const feet=[V(-k.r0*2,-0.8,-k.r0*2),V(k.r0*2,-0.8,-k.r0*2),V(k.r0*2,-0.8,k.r0*2),V(-k.r0*2,-0.8,k.r0*2)];
    const anclas=[]; const cw=0.1, ch=0.12; const cru=k.cru*(p.type==='S'?1:1.05);
    function crossarm(y,len,both){ const r=poleR(y); const zs= both? [-len/2,len/2] : [-len/2,len/2]; const xs= dbl? [-r-0.09,r+0.09] : [r+0.09]; xs.forEach(x=>{ const g=new THREE.BoxGeometry(cw,ch,len); g.translate(x,y,0); B.crucetas.push(g); }); // tornapuntas
      [-1,1].forEach(sz=>{ const x=xs[xs.length-1]; bar(B.crucetas,V(x,y-0.06,sz*len*0.42),V(x,y-len*0.32,0),0.045,0.045); }); if(dbl){ const cl=new THREE.BoxGeometry(2*r+0.3,ch,0.14); cl.translate(0,y,0); B.crucetas.push(cl); } return xs[xs.length-1]; }
    const yTop=H-0.15;
    if(mrt){ // MRT: un conductor en la cima sobre aislador pin (retención: aisladores de tracción sobre la cima)
      if(p.type!=='T'){ const pin=new THREE.CylinderGeometry(0.07,0.09,0.32,10); pin.translate(0,yTop+0.16,0); B.aisladores.push(pin); anclas.push({k:'condpin',x:0,y:yTop+0.34,z:0,pin:false}); }
      else { const cap=new THREE.BoxGeometry(0.34,0.12,0.2); cap.translate(0,yTop+0.06,0); B.crucetas.push(cap); anclas.push({k:'condpin',x:0,y:yTop+0.06,z:0,pin:false}); } }
    else if(compact){ // línea compacta: aisladores line-post horizontales (poliméricos) sin cruceta, disposición vertical alternada (o bandera en DT)
      const lp=Math.max(0.45,k.ins*1.6); const lv=[yTop-0.5,yTop-0.5-k.dz*0.9,yTop-0.5-1.8*k.dz]; const sides= p.circ==='DT'? [[-1,1],[-1,1],[-1,1]] : [[1],[-1],[1]]; const anch= p.type==='T';
      lv.forEach((y,i)=>{ const r=poleR(y); sides[i].forEach(sz=>{ const base=new THREE.BoxGeometry(0.22,0.28,0.12); base.translate(0,y,sz*(r+0.06)); B.crucetas.push(base);
        if(anch){ // retención: ménsula corta con aisladores de tracción (attachPin) en lugar del line post
          bar(B.crucetas,V(0,y,sz*(r+0.06)),V(0,y,sz*(r+0.6)),0.08,0.08); bar(B.crucetas,V(0,y-0.5,sz*r),V(0,y-0.05,sz*(r+0.55)),0.05,0.05); anclas.push({k:'condpin',x:0,y:y-0.12,z:sz*(r+0.6),pin:false}); }
        else { const rod=new THREE.CylinderGeometry(0.035,0.035,lp,8); rod.rotateX(Math.PI/2); rod.translate(0,y,sz*(r+0.1+lp/2)); B.aisladores.push(rod); const nsh=Math.max(3,Math.round(lp/0.12)); for(let j=0;j<nsh;j++){ const d=new THREE.CylinderGeometry(0.075,0.07,0.02,12); d.rotateX(Math.PI/2); d.translate(0,y,sz*(r+0.16+j*(lp-0.2)/nsh)); B.aisladores.push(d); } anclas.push({k:'condpin',x:0,y:y-0.3,z:sz*(r+0.1+lp),pin:false}); } }); f.levels.push({y,l:anch?0.6:lp}); });
      if(p.nGuard){ const gp=new THREE.CylinderGeometry(0.03,0.04,0.9,8); gp.translate(0,yTop+0.45,0); B.crucetas.push(gp); anclas.push({k:'guard',x:0,y:yTop+0.9,z:0}); } }
    else if(p.circ==='DT'){ const lv=[yTop-0.3,yTop-0.3-k.dz,yTop-0.3-2*k.dz]; lv.forEach((y,i)=>{ const x=crossarm(y,cru*0.9,true); [-1,1].forEach(sz=>anclas.push({k:k.pin?'condpin':'cond',x,y:y+(k.pin?0.06:-0.06),z:sz*cru*0.9*0.5*0.92,pin:true})); f.levels.push({y,l:cru*0.45}); }); if(p.nGuard) { const gp=new THREE.CylinderGeometry(0.03,0.04,0.9,8); gp.translate(0,yTop+0.45,0); B.crucetas.push(gp); anclas.push({k:'guard',x:0,y:yTop+0.9,z:0}); } }
    else { // simple terna: cruceta simétrica (PS3) – 2 fases en la cruceta + 1 en la cima (disposición triangular MT) o 3 en cruceta (60 kV)
      if(k.pin){ const y=yTop-0.9; const x=crossarm(y,cru,true); [-1,1].forEach(sz=>anclas.push({k:'condpin',x,y:y+0.06,z:sz*cru*0.5*0.92,pin:true}));
        if(p.type!=='T'){ const pin=new THREE.CylinderGeometry(0.07,0.09,0.32,10); pin.translate(0,yTop+0.16,0); B.aisladores.push(pin); anclas.push({k:'condpin',x:0,y:yTop+0.34,z:0,pin:false}); }
        else { const cap=new THREE.BoxGeometry(0.34,0.12,0.2); cap.translate(0,yTop+0.06,0); B.crucetas.push(cap); anclas.push({k:'condpin',x:0,y:yTop+0.06,z:0,pin:false}); }
        f.levels.push({y,l:cru/2}); }
      else { // 60 / 33 kV: disposición triangular — dos fases en cadenas en la cruceta + fase superior sobre aislador rígido (line post)
        const y=yTop-1.0; const x=crossarm(y,cru,true); [-1,1].forEach(sz=>anclas.push({k:'cond',x,y:y-0.06,z:sz*cru*0.5*0.92})); f.levels.push({y,l:cru/2}); const lp=k.ins*1.15; const disc=(cx,cy,cz,horiz)=>{ for(let j=0;j<Math.round(lp/0.12);j++){ const d=new THREE.CylinderGeometry(0.075,0.07,0.02,12); if(horiz){ d.rotateX(Math.PI/2); d.translate(cx,cy,cz+0.06+j*0.12); } else d.translate(cx,cy+0.08+j*0.12,cz); B.aisladores.push(d); } };
        if(p.type==='T'){ // terminal / retención: fase superior en aisladores de tracción sobre una ménsula corta
          const yl=yTop+0.2; bar(B.crucetas,V(0,yTop-0.4,0),V(0,yl,0.5),0.06,0.06); anclas.push({k:'cond',x:0,y:yl,z:0.5,top:true}); }
        else if(p.nGuard){ // extensión de acero para el cable de guarda y fase superior en line post horizontal lateral
          const ext=1.6; tube(B.crucetas,V(0,yTop-0.3,0),V(0,yTop+ext,0),0.06,0.05,8); anclas.push({k:'guard',x:0,y:yTop+ext,z:0});
          const yl=yTop+0.15; const base=new THREE.BoxGeometry(0.2,0.26,0.12); base.translate(0,yl,0.1); B.crucetas.push(base); const rod=new THREE.CylinderGeometry(0.035,0.035,lp,8); rod.rotateX(Math.PI/2); rod.translate(0,yl,0.14+lp/2); B.aisladores.push(rod); disc(0,yl,0.14,true); anclas.push({k:'condpin',x:0,y:yl-0.3,z:0.14+lp,pin:false}); }
        else { // aislador rígido vertical sobre la cima
          const rod=new THREE.CylinderGeometry(0.035,0.035,lp,8); rod.translate(0,yTop+lp/2,0); B.aisladores.push(rod); disc(0,yTop,0,false); anclas.push({k:'condpin',x:0,y:yTop+lp-0.3,z:0,pin:false}); } } }
    // retenidas en ángulo / retención
    // retenidas: ángulo → 1 (bisectriz), retención / terminal → 2 (en la dirección de la línea)
    if(p.type!=='S'){ const nR= p.type==='T'?2:1; for(let i=0;i<nR;i++){ const sx= i? 1:-1; const top=V(0,H-0.5,0), anc= p.type==='T'? V(sx*H*0.62,-0.6,0) : V(-H*0.45,-0.6,-H*0.45); guyWire(B,top,anc,B.fund[1],feet); } }
    const type=p.type, n=1; let yLow=Infinity, phi=0;
    anclas.forEach(a=>{ if(a.k==='guard'){ conductor(B,f,V(a.x,a.y-0.05,a.z),1,0.02,true); return; } const ph=phi++;
      if(a.k==='condpin'){ yLow=Math.min(yLow,attachPin(B,f,a,type,ph,0.02,!!a.pin,Math.max(0.35,k.ins*1.2))); return; }
      yLow=Math.min(yLow,attachPhase(B,f,a,type,n,0.03,ph,f.ins*0.8+0.5)); });
    const Htop=Math.max(...anclas.map(a=>a.y+0.3)); const info={H:Htop,Hbody:H,H0:Htop-f.ext,base:2*k.r0,bR:2*k.r1,hTronco:0,feet:feet.slice(0,4),yLow,anclas,fam:f,levels:f.levels,armW:compact?2*(k.r0+Math.max(0.45,k.ins*1.6)):cru+0.3,poste:true,mat,compact};
    let piezas=0; for(const kx in B){ if(kx==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[kx].length; } info.piezas=piezas; return {B,info}; }


  /* ===================== PÓRTICO DE DOS POSTES (H-frame): concreto / madera (BT–60 kV) o acero tubular (60–220 kV) ===================== */
  const HF={0.38:{H:8,D:2.0,ins:0.2,r0:0.13,r1:0.08,pin:true},10:{H:11,D:2.2,ins:0.3,r0:0.18,r1:0.09,pin:true},13.2:{H:11.5,D:2.4,ins:0.32,r0:0.18,r1:0.09,pin:true},22.9:{H:12,D:2.6,ins:0.35,r0:0.19,r1:0.09,pin:true},33:{H:13,D:3.2,ins:0.55,r0:0.2,r1:0.1,pin:false},60:{H:16,D:5.0,ins:0.85,r0:0.24,r1:0.12,pin:false},138:{H:22,D:7.0,ins:1.45,r0:0.42,r1:0.2,pin:false},220:{H:27,D:9.0,ins:2.3,r0:0.55,r1:0.26,pin:false},500:{H:36,D:13,ins:4.4,r0:0.8,r1:0.36,pin:false}};
  function buildHFrame(p){ const kvk= HF[p.kv]? p.kv : (p.kv>=300?500:p.kv>=150?220:p.kv>=100?138:p.kv>=45?60:p.kv>=25?33:p.kv>=15?22.9:p.kv>=5?10:0.38); const k=HF[kvk]; const kk=K[p.kv]||K[60];
    const steel= p.sil==='hmono' || p.mat==='PA'; const wood= !steel && p.mat==='PM'; const bucket= steel? B0=>B0.cuerpo : wood? B0=>B0.madera : B0=>B0.concreto;
    const f={kv:p.kv,type:p.type,circ:p.circ,disp:'horizontal (pórtico)',ins:k.ins,nd:kk.nd||5,dcyl:kk.dcyl||0.115,LV:Math.max(12,kk.LV||14),s:Math.max(0.6,(kk.bR||1)/1.3),guard:1.5,sil:p.sil,bR:2*k.r0,tg:0,hTronco:0,levels:[],pin:k.pin};
    const tT=p.type==='T'?1.15:p.type==='A'?1.08:1; const H=k.H+(p.ext||0); f.H=H; f.ext=p.ext||0; const D=k.D, ext=D*0.42; const r0=k.r0*tT, r1=k.r1*tT;
    const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    const feet=[]; [-1,1].forEach((sz,i)=>{ const z=sz*D/2; tube(bucket(B),V(0,-1.5,z),V(0,H,z),r0*1.12,r1,steel?12:14); const emp=new THREE.CylinderGeometry(r0*2.2,r0*2.5,1.6,12); emp.translate(0,-1.6,z); B.fund[i].push(emp); feet.push(V(-r0*1.5,-0.8,z),V(r0*1.5,-0.8,z)); });
    // viga (cruceta) del pórtico
    const yB=H-0.5; const rB=poleRad(r0,r1,yB,H); const z0=-(D/2+ext), z1=(D/2+ext);
    if(steel){ tube(B.crucetas,V(0,yB,z0),V(0,yB,z1),Math.max(0.08,r1*0.8),Math.max(0.08,r1*0.8),10); [-1,1].forEach(sz=>{ tube(B.crucetas,V(0,yB-1.4,sz*D/2),V(0,yB-0.1,sz*(D/2+ext*0.9)),0.05,0.05,8); }); }
    else { const bw=wood?0.16:0.14, bh=wood?0.2:0.18; const beam=new THREE.BoxGeometry(bw,bh,z1-z0); beam.translate(rB+bw/2+0.02,yB,0); B.crucetas.push(beam); if(p.type!=='S'){ const beam2=new THREE.BoxGeometry(bw,bh,z1-z0); beam2.translate(-(rB+bw/2+0.02),yB,0); B.crucetas.push(beam2); }
      // riostras en X entre postes y tornapuntas de la viga
      bar(B.crucetas,V(0,yB-1.2,-D/2+r1),V(0,yB-4.2,D/2-r1),0.09,0.09); bar(B.crucetas,V(0,yB-1.2,D/2-r1),V(0,yB-4.2,-D/2+r1),0.09,0.09); bar(B.crucetas,V(0,yB-1.2,-D/2+r1),V(0,yB-1.2,D/2-r1),0.09,0.09);
      [-1,1].forEach(sz=>{ bar(B.crucetas,V(rB+0.1,yB-0.1,sz*(D/2+ext*0.9)),V(rB*0.9,yB-1.1,sz*D/2),0.05,0.05); }); }
    const anclas=[]; const zs= p.circ==='DT'? [-(D/2+ext*0.8),-D/4,D/4,(D/2+ext*0.8)] : [-(D/2+ext*0.8),0,(D/2+ext*0.8)];
    zs.forEach(z=>anclas.push({k:k.pin?'condpin':'cond',x:0,y:yB-(k.pin?-0.1:0.1),z}));
    f.levels.push({y:yB,l:ext});
    // cable(s) de guarda sobre los postes
    const ng=p.nGuard||0; if(ng>0){ [-1,1].slice(0,ng>=2?2:1).forEach((sz,i)=>{ const z= ng>=2? sz*D/2 : 0; if(ng<2){ tube(B.crucetas,V(0,H-0.2,-D/2),V(0,H+1.2,0),0.06,0.05,8); tube(B.crucetas,V(0,H-0.2,D/2),V(0,H+1.2,0),0.06,0.05,8); anclas.push({k:'guard',x:0,y:H+1.2,z:0}); } else { tube(B.crucetas,V(0,H,z),V(0,H+0.9,z),0.05,0.04,8); anclas.push({k:'guard',x:0,y:H+0.9,z}); } }); }
    // retenidas en ángulo / anclaje
    if(p.type!=='S'){ [-1,1].forEach(sx=>{ if(p.type==='A'&&sx>0) return; [-1,1].forEach(sz=>{ const top=V(0,H-0.6,sz*D/2), anc=V(sx*H*0.6,-0.6,sz*D/2); const d=new THREE.Vector3().subVectors(anc,top); const g=new THREE.CylinderGeometry(0.014,0.014,d.length(),5); g.translate(0,d.length()/2,0); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().normalize()); g.applyMatrix4(new THREE.Matrix4().compose(top,q,new THREE.Vector3(1,1,1))); B.conductores.push(g); const blk=new THREE.BoxGeometry(0.5,0.5,0.5); blk.translate(anc.x,anc.y-0.4,anc.z); B.fund[sz>0?3:2].push(blk); }); }); }
    let yLow=Infinity, phi=0; const n=p.nCond||1; const rr=p.kv>=100?0.055:0.03;
    anclas.forEach(a=>{ if(a.k==='guard'){ conductor(B,f,V(a.x,a.y-0.05,a.z),1,0.022,true); return; } const ph=phi++;
      if(a.k==='condpin'){ yLow=Math.min(yLow,attachPin(B,f,a,p.type,ph,0.02,true,Math.max(0.35,k.ins*1.2))); return; }
      yLow=Math.min(yLow,attachPhase(B,f,a,p.type,n,rr,ph,f.ins*0.9+0.8)); });
    const Htop=Math.max(...anclas.map(a=>a.y+0.3),H); const info={H:Htop,Hbody:H,H0:Htop-f.ext,base:D+2*r0,bR:2*r1,hTronco:0,feet,yLow,anclas,fam:f,levels:f.levels,armW:z1-z0,poste:!steel,mono:steel,hframe:true,mat:steel?'PA':(wood?'PM':'PC'),r0,r1};
    let piezas=0; for(const kx in B){ if(kx==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[kx].length; } info.piezas=piezas; return {B,info}; }
  function poleRad(r0,r1,y,H){ return r0+(r1-r0)*Math.max(0,Math.min(1,y/H)); }

  /* ===================== RED SECUNDARIA BT: poste CAC 8/200 – 9/200 con conductor autoportante, pastoral y acometida ===================== */
  function buildBT(p){ const wood=p.mat==='PM'; const Hp= p.type==='S'? 8 : 9; const emb=1.3; const H=Hp-emb+(p.ext||0); const r0=wood?0.12:0.13, r1=wood?0.09:0.075;
    const f={kv:p.kv,type:p.type,circ:'ST',disp:'autoportante (haz trenzado)',ins:0.2,nd:1,dcyl:0.06,LV:12,s:0.5,guard:0,sil:'bt',bR:2*r0,tg:0,hTronco:0,levels:[],H,ext:p.ext||0};
    const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    tube(wood?B.madera:B.concreto,V(0,-emb,0),V(0,H,0),r0*1.1,r1,wood?10:14); const emp=new THREE.CylinderGeometry(r0*2.0,r0*2.3,1.4,12); emp.translate(0,-emb-0.1,0); B.fund[0].push(emp);
    const feet=[V(-r0*1.6,-0.8,-r0*1.6),V(r0*1.6,-0.8,-r0*1.6),V(r0*1.6,-0.8,r0*1.6),V(-r0*1.6,-0.8,r0*1.6)];
    // armado: abrazadera + soporte de suspensión (E-S) o de anclaje (E-A / E-T) a 0.4 m de la cima
    const yA=H-0.45; const rA=poleRad(r0,r1,yA,H); const abr=new THREE.CylinderGeometry(rA+0.03,rA+0.03,0.08,14); abr.translate(0,yA,0); B.crucetas.push(abr);
    const sides= p.type==='T'? [-1,1] : [1]; const anclas=[];
    sides.forEach(sx=>{ const brk=new THREE.BoxGeometry(0.12,0.16,0.1); brk.translate(sx*(rA+0.06),yA,0); B.crucetas.push(brk); const ins=new THREE.CylinderGeometry(0.035,0.035,0.16,8); ins.translate(sx*(rA+0.06),yA-0.16,0); B.aisladores.push(ins); anclas.push({x:sx*(rA+0.06),y:yA-0.26,z:0,sx}); });
    if(p.type==='A'){ const brk=new THREE.BoxGeometry(0.12,0.16,0.1); brk.translate(0,yA,rA+0.06); B.crucetas.push(brk); }
    // haz autoportante: portante + 3 fases + alumbrado, trenzados (aprox. 5 cilindros paralelos con ligero giro)
    const bundle=(x0,y0,len,xc)=>{ const L=len||f.LV; const nC=5; for(let i=0;i<nC;i++){ const a=i/nC*Math.PI*2; const oy=Math.cos(a)*0.028, oz=Math.sin(a)*0.028; const r= i===0?0.012:i===4?0.006:0.009; const c=new THREE.CylinderGeometry(r,r,L,6); c.rotateZ(Math.PI/2); c.rotateX(0.35); c.translate((xc!==undefined?xc:x0),y0+oy,oz); (i===0?B.conductores:B['cond'+(i%3)]).push(c); } };
    let yLow=Infinity;
    if(p.type==='T'){ anclas.forEach(a=>{ bundle(a.x,a.y,f.LV/2,a.x+a.sx*(0.25+f.LV/4)); const gr=new THREE.BoxGeometry(0.3,0.08,0.08); gr.translate(a.x+a.sx*0.15,a.y,0); B.aisladores.push(gr); }); yLow=Math.min(yLow,yA-0.26); }
    else { const a=anclas[0]; bundle(a.x,a.y); yLow=Math.min(yLow,a.y-0.03); }
    // pastoral con luminaria LED (alumbrado público)
    if(p.lum!==false){ const yP=H-0.15; const rP=poleRad(r0,r1,yP,H); tube(B.crucetas,V(0,yP,rP),V(0,yP+0.6,rP+0.9),0.03,0.03,8); tube(B.crucetas,V(0,yP+0.6,rP+0.9),V(0,yP+0.75,rP+1.5),0.03,0.028,8); const lum=new THREE.BoxGeometry(0.22,0.09,0.55); lum.translate(0,yP+0.74,rP+1.6); B.aisladores.push(lum); }
    // acometida domiciliaria (conductor concéntrico hacia una vivienda)
    if(p.acom!==false){ const yC=H-0.9; const q0=V(0,yC,0.05), q1=V(3.5,yC-2.6,-6.0); const tb=new THREE.TubeGeometry(new THREE.QuadraticBezierCurve3(q0,V(1.8,yC-1.9,-3.0),q1),10,0.012,5,false); B.conductores.push(tb); const box=new THREE.BoxGeometry(0.3,0.42,0.14); box.translate(3.5,yC-2.7,-6.05); B.aisladores.push(box); }
    // retenida
    if(p.type!=='S'){ const nR=p.type==='T'?1:1; const top=V(0,H-0.5,0), anc=V(-H*0.55,-0.6,0); const d=new THREE.Vector3().subVectors(anc,top); const g=new THREE.CylinderGeometry(0.01,0.01,d.length(),5); g.translate(0,d.length()/2,0); const q=new THREE.Quaternion().setFromUnitVectors(UP,d.clone().normalize()); g.applyMatrix4(new THREE.Matrix4().compose(top,q,new THREE.Vector3(1,1,1))); B.conductores.push(g); const blk=new THREE.BoxGeometry(0.4,0.4,0.4); blk.translate(anc.x,anc.y-0.35,anc.z); B.fund[1].push(blk); }
    f.levels.push({y:yA,l:0.2});
    const info={H:H+(p.lum!==false?0.75:0),Hbody:H,H0:H,base:2*r0,bR:2*r1,hTronco:0,feet,yLow,anclas:[],fam:f,levels:f.levels,armW:1.8,poste:true,bt:true,mat:wood?'PM':'PC'};
    let piezas=0; for(const kx in B){ if(kx==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[kx].length; } info.piezas=piezas; return {B,info}; }


  /* ===================== TORRE ATIRANTADA EN V (VSL / Chainette), 500 kV: mástiles y viga en celosía ===================== */

  /* celosía "loft" entre dos cuadriláteros (4 esquinas cada uno, en orden): montantes + X + tirantes por panel */
  function latticeLoft(B,q0,q1,s,bucket,wMul){ const L=q0[0].distanceTo(q1[0]); const w=0.11*s*(wMul||1), wd=0.055*s, wt=0.05*s; const per=(q0[0].distanceTo(q0[1])+q0[1].distanceTo(q0[2]))/2; const n=Math.max(2,Math.round(L/Math.max(1.3*s,per*0.8)));
    const P=(t,i)=>q0[i].clone().lerp(q1[i],t);
    for(let k=0;k<n;k++){ const t0=k/n,t1=(k+1)/n; for(let i=0;i<4;i++) bar(bucket,P(t0,i),P(t1,i),w,w); [[0,1],[1,2],[2,3],[3,0]].forEach(([i,j])=>{ bar(bucket,P(t0,i),P(t1,j),wd,wd); bar(bucket,P(t1,i),P(t0,j),wd,wd); bar(bucket,P(t1,i),P(t1,j),wt,wt); }); } }
  function latticeStrut(B,p0,p1,hw0,hw1,s,bucket){ const axis=new THREE.Vector3().subVectors(p1,p0); const L=axis.length(); const u=axis.clone().normalize(); const ref= Math.abs(u.x)<0.9? new THREE.Vector3(1,0,0) : new THREE.Vector3(0,0,1); const e1=new THREE.Vector3().crossVectors(u,ref).normalize(); const e2=new THREE.Vector3().crossVectors(u,e1).normalize();
    const n=Math.max(2,Math.round(L/Math.max(1.3*s,(hw0+hw1)*0.8))); const w=0.11*s, wd=0.055*s; const c=[[-1,-1],[1,-1],[1,1],[-1,1]];
    const P=(t,i)=>{ const hw=hw0+(hw1-hw0)*t; return p0.clone().addScaledVector(u,L*t).addScaledVector(e1,c[i][0]*hw).addScaledVector(e2,c[i][1]*hw); };
    for(let k=0;k<n;k++){ const t0=k/n,t1=(k+1)/n; for(let i=0;i<4;i++) bar(bucket,P(t0,i),P(t1,i),w,w); [[0,1],[1,2],[2,3],[3,0]].forEach(([i,j])=>{ bar(bucket,P(t0,i),P(t1,j),wd,wd); bar(bucket,P(t1,i),P(t0,j),wd,wd); bar(bucket,P(t1,i),P(t1,j),0.05*s,0.05*s); }); } }
  function buildVSL(p){ const f=fam(Object.assign({},p,{sil:'celosia',disp:'horizontal'})); f.sil='vsl'; f.disp='horizontal (V atirantada)'; const s=f.s; const H=Math.round(f.H*0.92)+(0); f.H=H; const D=f.D||12.5;
    const B={patas:[],cuerpo:[],crucetas:[],aisladores:[],conductores:[],cond0:[],cond1:[],cond2:[],concreto:[],madera:[],fund:[[],[],[],[]]};
    // viga rígida: debe cubrir los dos puntos de cuelgue de las cadenas en V de las fases exteriores (±0.55·ins alrededor de ±D) más el margen de la cúspide
    const dzV=0.55*f.ins; const dep=Math.max(1.8,1.0*s+1.0), hwB=0.7*s, zT=D+dzV+0.6*s+0.4; const yB=H-dep;
    // mástiles en celosía desde la rótula común hasta la viga; se unen a la viga hacia los cuartos de su longitud (las fases exteriores cuelgan por fuera de los mástiles)
    const zM=0.52*D; const base=[V(0,0.7,-0.9),V(0,0.7,0.9)], top=[V(0,yB+dep*0.45,-zM),V(0,yB+dep*0.45,zM)];
    latticeStrut(B,base[0],top[0],0.42*s,0.8*s,s,B.cuerpo); latticeStrut(B,base[1],top[1],0.42*s,0.8*s,s,B.cuerpo);
    // nudo mástil–viga: cartelas (diagonales cortas) entre la cabeza del mástil y los cordones inferiores de la viga
    [-1,1].forEach(sz=>{ const zt=sz*zM; [[-hwB,-1],[hwB,-1],[hwB,1],[-hwB,1]].forEach(([x,d])=>bar(B.cuerpo,V(x*0.6,yB-0.35*s,zt-d*0.5*s),V(x,yB,zt+d*(0.8*s+0.35*s)),0.08*s,0.08*s)); });
    // rótula, pedestal y zapata central
    const hinge=new THREE.BoxGeometry(1.4*s,0.5,3.0); hinge.translate(0,0.4,0); B.patas.push(hinge); const ped=new THREE.BoxGeometry(1.7*s,0.7,3.6); ped.translate(0,-0.25,0); const zap=new THREE.BoxGeometry(3.4*s,0.9,5.4); zap.translate(0,-1.05,0); B.fund[0].push(ped,zap);
    const feet=[V(-0.85*s,-0.6,-1.8),V(0.85*s,-0.6,-1.8),V(0.85*s,-0.6,1.8),V(-0.85*s,-0.6,1.8)];
    // viga superior en celosía y cúspides de guarda en sus extremos
    latticeBeam(B,-zT,zT,H,dep,hwB,s,B.crucetas); const anclas=[];
    [-1,1].forEach(sz=>{ const zz=sz*(zT-0.9); const tp=V(0,H+f.guard*0.55,zz); [[-hwB,-0.7],[hwB,-0.7],[hwB,0.7],[-hwB,0.7]].forEach(([x,dz])=>bar(B.cuerpo,V(x,H,zz+dz),tp,0.07*s,0.07*s)); anclas.push({k:'guard',x:0,y:tp.y,z:zz}); });
    // retenidas: 4, desde los extremos de la viga a bloques de anclaje
    [-1,1].forEach(sz=>{ [-1,1].forEach(sx=>{ guyWire(B,V(0,H-dep*0.5,sz*zT),V(sx*H*0.45,-0.6,sz*(zT+H*0.5)),B.fund[sz>0?3:2],feet); }); });
    [-D,0,D].forEach(z=>anclas.push({k:'cond',x:0,y:yB-0.15,z,v:true}));
    const type=p.type, n=p.nCond||1; let yLow=Infinity, phi=0;
    anclas.forEach(a=>{ if(a.k==='guard'){ attachGuard(B,f,a,0.028); return; } const ph=phi++; yLow=Math.min(yLow,attachPhase(B,f,a,type,n,0.055,ph,f.ins*0.9+1.1*s)); });
    const Htop=Math.max(...anclas.map(a=>a.y)); const info={H:Htop,Hbody:H,H0:Htop-f.ext,base:2.4,bR:2*hwB,hTronco:0,feet:feet.slice(0,4),yLow,anclas,fam:f,levels:[{y:yB,l:D}],armW:2*zT,vsl:true};
    let piezas=0; for(const kx in B){ if(kx==='fund') B.fund.forEach(a=>piezas+=a.length); else piezas+=B[kx].length; } info.piezas=piezas; return {B,info}; }

  /* siluetas disponibles por nivel de tensión y circuitos */
  function silsFor(kv,circ,mat){
    if(kv<1) return ['bt'];
    if(kv<35) return ['poste','compacto','hpole'].concat(kv>=30?['mono']:[]);
    if(kv<100) return ['celosia','bandera'].concat(circ==='DT'?['tonel']:[]).concat(['portico','mono','hmono','poste','compacto','hpole']);
    if(kv<300) return ['celosia','bandera'].concat(circ==='DT'?['tonel','danubio']:['gato']).concat(['portico','mono','hmono']);
    return ['celosia'].concat(circ==='DT'?['tonel']:['gato','vsl']).concat(['portico','mono','hmono']);
  }

  function merge(arr){ if(!arr.length) return null; const MU=THREE.BufferGeometryUtils; arr.forEach(g=>{ if(!g.attributes.normal) g.computeVertexNormals(); for(const a of Object.keys(g.attributes)) if(a!=='position'&&a!=='normal') g.deleteAttribute(a); }); return arr.length>1? MU.mergeBufferGeometries(arr,false) : arr[0]; }
  const SILS=[['auto','Automática (según módulo / material)'],['celosia','Celosía autosoportada'],['bandera','Celosía bandera (ST vertical, un lado)'],['tonel','Celosía tonel / barril (DT)'],['danubio','Celosía Danubio (DT, 2 niveles)'],['gato','Cabeza de gato (ST horizontal)'],['portico','Pórtico en celosía (H-frame)'],['vsl','Atirantada en V (VSL, 500 kV)'],['mono','Poste tubular de acero (ménsulas davit)'],['hmono','Pórtico de postes de acero (H-frame tubular)'],['poste','Poste de concreto / madera con crucetas'],['compacto','Poste compacto con aisladores line-post'],['hpole','Pórtico de dos postes (concreto / madera)'],['bt','Red BT: poste con conductor autoportante']];
  return {build,merge,fam,SILS,silsFor};
})();
