/* ===================== UI ===================== */
const $ = s => document.querySelector(s);
const $$ = s => Array.from(document.querySelectorAll(s));
const fmt = (v,d=0) => (v==null||isNaN(v)) ? '—' : v.toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const fmtK = v => v==null?'—': Math.abs(v)>=1e6 ? (v/1e6).toLocaleString('en-US',{maximumFractionDigits:2})+' M' : Math.abs(v)>=1e3 ? (v/1e3).toLocaleString('en-US',{maximumFractionDigits:0})+' k' : fmt(v);
const pct = (v,d=1) => (v==null||isNaN(v))?'—':(v).toLocaleString('en-US',{maximumFractionDigits:d})+' %';
const esc = s => String(s??'').replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let toastT; function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('on'); clearTimeout(toastT); toastT=setTimeout(()=>t.classList.remove('on'),2200); }

const state = {
  kv:220, zone:'Sierra', alt:'3000-4000', rural:'rural', struct:'DT', cg:'CG3',
  cond:{mat:'ACAR',n:1,size:1000,unit:'MCM'}, moduleN:null, manualModule:false,
  riskRanges:null, mc:null, scenarios:[]
};

/* ---------- helpers for inputs ---------- */
function segVal(id){ const b=$(id+' button.on'); return b? b.dataset.v : null; }
function setSeg(id,v){ $$(id+' button').forEach(b=>b.classList.toggle('on', b.dataset.v===v)); }
function readInputs(){
  const num=id=>parseFloat($(id).value)||0;
  return {
    kv:state.kv, zone:state.zone, alt:state.alt, rural:state.rural, struct:state.struct, cg:$('#selCG').value, cond:state.cond,
    km:Math.max(0.1,num('#inKm')), span:Math.max(100,num('#inSpan')),
    pSusp:num('#inPSusp'), pAng:num('#inPAng'), pAnc:num('#inPAnc'),
    sNor:num('#inSNor'), sAre:num('#inSAre'), sRoc:num('#inSRoc'),
    access:parseFloat($('#selAccess').value), ext:num('#inExt'), servW:0, servP:0,
    allowQ:num('#inAllowQ'), allowP:num('#inAllowP'), gg:num('#inGG'), ind:num('#inInd'), owner:num('#inOwner'), eng:num('#inEng'),
    esc:(window.PROJ&&PROJ.manualPct()!==null? PROJ.manualPct():0), risk:num('#inRisk'), cont:num('#inCont'), phase:num('#inPhase'), igv:num('#inIGV'), tc:num('#inTC')||3.479,
    expW:0.6, expC:0.35, fix:50, steel:(byN[state.moduleN]&&byN[state.moduleN].steelUsdTon)||1464.75,
    cls:parseInt($('#pClass').value), name:$('#pName').value, client:$('#pClient').value, rev:$('#pRev').value
  };
}

/* ---------- module & conductor selects ---------- */
function refreshStructOptions(){
  const opts=structOptions(state.kv);
  if(!opts.includes(state.struct)) state.struct = opts.includes('DT')&&state.struct==='DT'?'DT':opts[0];
  $('#selStruct').innerHTML = opts.map(o=>`<option value="${o}" ${o===state.struct?'selected':''}>${STRUCT_LABELS[o]}</option>`).join('');
  // circuits segment follows struct
  setSeg('#segCirc', state.struct==='DT'?'DT':'ST');
}
function refreshCondOptions(){
  // module conductors for this kv first, then quotations
  const seen=new Map();
  MODS.filter(m=>m.kv===state.kv && m.cond).forEach(m=>{ const k=condKey(m.cond)+'|'+m.cond.n; if(!seen.has(k)) seen.set(k,{...m.cond, src:'COES'}); });
  const groupsA=[...seen.values()];
  const groupsB=DB.cot.conductores.map(q=>{ const mcm=/MCM/.test(q.seccion); return {mat:q.tipo,size:parseFloat(q.seccion),unit:mcm?'MCM':'mm²',n:state.cond.n||1,src:'cot'}; })
    .filter(c=>!groupsA.some(a=>a.mat===c.mat&&a.size===c.size&&a.unit===c.unit));
  const cur=state.cond; let html='<optgroup label="Conductores de los módulos COES">';
  html+=groupsA.map(c=>`<option value="${c.mat}|${c.size}|${c.unit}|${c.n}">${condLabel(c)}</option>`).join('');
  html+='</optgroup><optgroup label="Otras secciones cotizadas (elige N° por fase abajo)">';
  html+=groupsB.map(c=>`<option value="${c.mat}|${c.size}|${c.unit}|0">${c.mat} ${c.size} ${c.unit}</option>`).join('');
  html+='</optgroup>';
  $('#selCond').innerHTML=html;
  const want=`${cur.mat}|${cur.size}|${cur.unit}|${cur.n}`;
  const want0=`${cur.mat}|${cur.size}|${cur.unit}|0`;
  const sel=$('#selCond'); if([...sel.options].some(o=>o.value===want)) sel.value=want; else if([...sel.options].some(o=>o.value===want0)) sel.value=want0; else { sel.selectedIndex=0; applyCondSel(); }
  refreshCondHint();
}
function applyCondSel(){
  const [mat,size,unit,n]=$('#selCond').value.split('|');
  state.cond={mat,size:parseFloat(size),unit,n:parseInt(n)||state.cond.n||1};
  refreshCondHint();
}
function refreshCondHint(){
  const c=state.cond; const p=condUsdKm(c);
  const nSel=`<span class="pill-row" style="display:inline-flex;gap:4px;vertical-align:middle;margin-left:6px">${[1,2,3,4].map(k=>`<span class="chip ${c.n===k?'on':''}" data-n="${k}" style="padding:1px 7px">${k}×</span>`).join('')}</span>`;
  $('#condHint').innerHTML=`${condMm2(c).toFixed(0)} mm² · ${fmt(condKgKm(c))} kg/km · USD ${fmt(p.usd)}/km (${p.src}) · por fase: ${nSel}`;
  $$('#condHint .chip').forEach(ch=>ch.onclick=()=>{ state.cond.n=parseInt(ch.dataset.n); refreshCondHint(); recalc(); });
}
function refreshModuleSelect(){
  const inp={kv:state.kv,zone:state.zone,alt:state.alt,rural:state.rural,struct:state.struct,cond:state.cond,cg:$('#selCG').value};
  const list=MODS.filter(m=>m.kv===state.kv).map(m=>({m,s:scoreModule(m,inp)})).sort((a,b)=>b.s-a.s);
  const auto=list[0].m;
  if(!state.manualModule || !byN[state.moduleN] || byN[state.moduleN].kv!==state.kv){ state.moduleN=auto.n; state.manualModule=false; }
  $('#selModule').innerHTML=list.map(({m,s})=>`<option value="${m.n}" ${m.n===state.moduleN?'selected':''}>${m.n} · ${m.code}${m.n===auto.n?' (auto)':''}</option>`).join('');
  const M=byN[state.moduleN];
  $('#modHint').textContent = `${M.zoneTxt||''} · ${STRUCT_LABELS[M.struct]} · ${condLabel(M.cond)} · ${fmt(M.usdkm)} USD/km (COES)`;
}
function applyModuleDefaults(M, keepUser){
  const mix=moduleMix(M); const soil=moduleSoil(M);
  if(!keepUser){
    $('#inSpan').value=M.span||400;
    $('#inPSusp').value=Math.round(mix.susp); $('#inPAng').value=Math.round(mix.ang); $('#inPAnc').value=Math.round(mix.anc);
    $('#inSNor').value=Math.round(soil.nor); $('#inSAre').value=Math.round(soil.are); $('#inSRoc').value=Math.round(soil.roc);
    $('#selCG').value=M.cg||'CG3';
  }
  $('#mixHint').textContent=`Módulo ${M.n}: ${Math.round(mix.susp)} / ${Math.round(mix.ang)} / ${Math.round(mix.anc)} % (${mix.total} estructuras en ${M.km} km, vano ${M.span} m)`;
}


/* ---------- EDT de costos: flujo alcance → ítem → subtotales acumulados (A, B, C, E) ---------- */
const fmtMM = v => (v==null||isNaN(v)) ? '—' : Math.abs(v)>=1e6 ? (v/1e6).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+' MM' : Math.abs(v)>=1e3 ? (v/1e3).toLocaleString('en-US',{maximumFractionDigits:1})+' k' : fmt(v);
function edtFlow(o){
  // o.items: [{n,name,scope,value,color}] en orden 1,2,3,4,5,D · o.subs: [{k,name,formula,span,value}] · o.unit
  const items=o.items, subs=o.subs; const nR=items.length;
  let h=`<div class="edt" style="--edt-rows:${nR};--edt-subs:${subs.length}">`;
  h+=`<div class="edt-h edt-h1">Alcance del ítem (qué incluye)</div><div class="edt-h edt-h2">Ítem del estimado · ${esc(o.unit||'USD')}</div><div class="edt-h edt-h3" style="grid-column:3 / span ${subs.length}">Subtotales acumulados (estructura de quiebre de costos)</div>`;
  const E=(subs[subs.length-1]||{}).value||0;
  items.forEach((it,i)=>{ const r=i+2; const p=E>0?` <span class="edt-p">${(it.value/E*100).toFixed(1)} % de E</span>`:''; h+=`<div class="edt-scope" style="grid-row:${r}">${esc(it.scope||'')}</div><div class="edt-item" style="grid-row:${r};background:${it.color}"><div class="edt-name"><span class="edt-n">${esc(it.n)}</span>${esc(it.name)}</div><div class="edt-v" title="${fmt(it.value)}">${esc(o.unit||'USD')} ${fmtMM(it.value)}${p}</div></div>`; });
  subs.forEach((sb,j)=>{ h+=`<div class="edt-sub" style="grid-row:2 / span ${sb.span};grid-column:${3+j};background:${sb.color||'var(--blue)'}" title="${fmt(sb.value)}"><div class="edt-k">${esc(sb.k)}</div><div class="edt-sn">${esc(sb.name)}</div><div class="edt-f">${esc(sb.formula)}</div><div class="edt-sv">${esc(o.unit||'USD')} ${fmtMM(sb.value)}</div></div>`; });
  h+=`</div><div class="tiny muted" style="margin-top:8px">Lectura: cada subtotal de la derecha acumula los ítems que abarca verticalmente. ${esc(o.note||'A = 1 + 2 · B = A + 3 + 4 · C = B + 5 · E = C + D.')}</div>`;
  return h;
}


/* ---------- especificaciones de la EDT por motor + supuestos por juicio de experto ---------- */
function edtSpecA(R){ const inp=R.inp, cls=CLASSES[inp.cls];
  return {unit:'USD', items:[
    {n:'1',name:'Costo directo',color:'var(--c1)',value:R.directo,scope:`Suministro de estructuras, conductores, cables de guarda, aisladores y puesta a tierra; transporte; obras civiles (accesos, fundaciones); montaje electromecánico; inspección, pruebas y puesta en servicio; gastos generales y utilidad del contratista (${pct(inp.gg)} sobre obras) y allowances (${pct(inp.allowQ)} cantidades + ${pct(inp.allowP)} precios)`},
    {n:'2',name:'Costo indirecto',color:'var(--c3)',value:R.indirecto,scope:`Ingeniería, expediente técnico, EIA, EO, concesión y CIRA (ítem 5.0 COES); gerencia de construcción, supervisión, facilidades temporales y servicios de terceros (${pct(inp.ind)} del directo); costo del dueño (${pct(inp.owner)})`},
    {n:'3',name:'Escalamiento',color:'var(--c5)',value:R.esc,scope:(window.ESC&&R.escDet)? ESC.scopeText(R) : `Variación de precios desde la fecha base (precios ${PRICE.year}) hasta la ejecución (${pct(inp.esc)} de A)`},
    {n:'4',name:'Provisión por evento de riesgo',color:'var(--c4)',value:R.risk,scope:`Riesgos identificables uno a uno, con probabilidad e impacto estimables (${pct(inp.risk)} de A)`},
    {n:'5',name:'Contingencia',color:'var(--crit)',value:R.cont,scope:`Incertidumbre no atribuible a un evento concreto; rango de la ${cls.name} AACE y simulación Monte Carlo sobre el taller de rangos (${pct(inp.cont)} de B)`},
    {n:'D',name:'Costo de fase',color:'var(--c7)',value:R.D,scope:`Estudios de ingeniería de la siguiente etapa (${pct(inp.phase)} de C)`}],
   subs:[{k:'A',name:'Estimado neto',formula:'(1 + 2)',span:2,value:R.A,color:'#1E3F5F'},{k:'B',name:'Estimado base',formula:'(1 + 2 + 3 + 4)',span:4,value:R.B,color:'#274F78'},{k:'C',name:'Costo de ejecución',formula:'(1 + 2 + 3 + 4 + 5)',span:5,value:R.C,color:'#2C5F8A'},{k:'E',name:'Monto total de inversión',formula:'(C + D)',span:6,value:R.E,color:'#1B3654'}],
   note:'A = 1 + 2 · B = A + 3 + 4 · C = B + 5 · E = C + D. Sin IGV; servidumbre excluida (ver supuestos).'}; }
/* Supuestos por juicio de experto (documentados) — se muestran en Bases e Informe */
function supuestos(space,inp){ const RR= space==='A' ? (typeof R!=='undefined'?R:null) : (typeof R2!=='undefined'?R2:null); const cls=CLASSES[inp.cls]; const A=space==='A';
  return [
    ['Alcance físico','Línea aérea completa entre pórticos de llegada: estructuras, conductores, cables de guarda, aislamiento, puesta a tierra, accesos y fundaciones; no incluye bahías de subestación ni telecomunicaciones de largo alcance.','Práctica de estimación de líneas (COES, módulos LT; AACE 18R-97)'],
    ['Base de precios',A?'Módulos COES 2025/26 (APUs, cotizaciones DFJ/Panghao/Jiangsu/Daji) escalados al año '+PRICE.year+' por índices; USD sin IGV.':'Precios I-402/I-403 de la BDME Osinergmin 2025 depurados por vigencia y kits paramétricos MT/BT de mercado, escalados al año '+PRICE.year+'; USD sin IGV.','COES 2025/26; Osinergmin REST_MOD_INV_2025; «Precios y marcas»'],
    ['Gastos generales y utilidad del contratista',A?pct(inp.gg)+' sobre obras civiles y montaje (los APU COES no los incluyen).':pct(inp.gg)+' + '+pct(inp.ut)+' sobre montaje y obras civiles (criterio Osinergmin).','COES: APUs sin GG/U; Osinergmin, criterios de costos directos e indirectos feb-2026 (10 % + 10 %)'],
    ['Allowances',A?pct(inp.allowQ)+' de cantidades y '+pct(inp.allowP)+' de precios sobre el directo contratista (metrados y precios aún no firmes en '+cls.name+').':'Incluidos en los rangos de la clase (no se aplican allowances explícitos en la estructura regulatoria).','AACE RP 34R-05 (basis of estimate) y práctica de Clase 3–4'],
    ['Costo indirecto',A?'Ingeniería y permisos según ítem 5.0 del módulo COES; gerencia de construcción, supervisión, facilidades temporales y servicios de terceros '+pct(inp.ind)+' del directo; costo del dueño '+pct(inp.owner)+'.':'Supervisión '+pct(inp.sup)+', gastos administrativos 1.35 % e intereses intercalarios '+pct(inp.fin)+' (estructura Osinergmin); ingeniería/estudios del dueño '+pct(inp.eng)+' y costo del dueño '+pct(inp.owner)+'.','Rangos típicos de proyectos de transmisión: indirectos 8–15 %, dueño 3–5 % (benchmarks EPC Perú/LatAm; COES ítem 5.0)'],
    ['Escalamiento',(window.ESC&&RR&&RR.escDet)? ESC.supuestoText(RR) : 'De la fecha base de precios al año de ejecución, por índices según grupo de costo.', (RR&&RR.escDet&&RR.escDet.set==='cru')? 'CRU – Construction Escalation Index (abr-2025), tabla del usuario' : 'LME (Al, Cu, Zn); BLS CPI-U; INEI materiales y mano de obra; «Precios y marcas» (tasas anuales editables)'],
    ['Provisión por eventos de riesgo',pct(inp.risk)+' del estimado neto para riesgos identificados (permisos, interferencias, clima).','AACE RP 42R-08; registro de riesgos del proyecto'],
    ['Contingencia',pct(inp.cont)+' del estimado base, dentro del rango de '+cls.name+' ('+({5:'35–100',4:'25–35',3:'15–25',2:'10–15',1:'5–10'})[inp.cls]+' %); validar con PERT / Monte Carlo (pestaña Riesgo).','AACE RP 18R-97 (precisión por clase) y RP 42R-08'],
    ['Costo de fase',pct(inp.phase)+' del costo de ejecución: estudios de ingeniería de la siguiente etapa (factibilidad / ingeniería básica).','Práctica de gates de inversión (FEL 2–3): 1–2 % del CAPEX'],
    ['Servidumbre','Excluida del estimado: depende de la tasación predial, negociación con propietarios y trazo definitivo; se trata como partida del dueño aparte (referencia BDME 2026: 60 kV 1.6–1.9 kUSD/km sierra; 220 kV 2.2–2.9 kUSD/km; 500 kV 5–6 kUSD/km).','Osinergmin, costos de servidumbre 2026 (R.M. 514-2025-EF/15); valores arancelarios MEF'],
    ['Exclusiones','Bahías de llegada y subestaciones, compensación reactiva, telecomunicaciones troncales, obras de mitigación social, IGV (se muestra aparte), costos financieros del dueño.','Alcance del estimador (solo líneas)'],
    ['Precisión esperada',cls.name+': '+cls.lo[1]+'…'+cls.lo[0]+' % / +'+cls.hi[0]+'…+'+cls.hi[1]+' %; definición del proyecto '+cls.def+'.','AACE RP 18R-97 (2020)']
  ]; }
function supuestosHTML(space,inp){ return `<table class="tbl small"><thead><tr><th>Supuesto</th><th>Criterio adoptado</th><th>Referencia</th></tr></thead><tbody>${supuestos(space,inp).map(r=>`<tr><td><b>${esc(r[0])}</b></td><td>${esc(r[1])}</td><td class="tiny muted">${esc(r[2])}</td></tr>`).join('')}</tbody></table>`; }
window.edtSpecA=edtSpecA; window.supuestosHTML=supuestosHTML;

/* ---------- SVG chart helpers ---------- */
const COLORS=['var(--c1)','var(--c2)','var(--c3)','var(--c4)','var(--c5)','var(--c6)','var(--c7)','var(--c8)'];
function svgBars(rows, opts={}){
  // rows: [{label, value, color, hi}] horizontal bars
  const w=opts.w||600, rh=opts.rh||22, lw=opts.lw||190, pad=6;
  const max=Math.max(...rows.map(r=>r.value),1e-9);
  const h=rows.length*rh+10;
  let s=`<svg class="chart" viewBox="0 0 ${w} ${h}" role="img">`;
  rows.forEach((r,i)=>{ const y=i*rh+5; const bw=(w-lw-90)*r.value/max;
    s+=`<text x="${lw-6}" y="${y+rh*0.68}" text-anchor="end" ${r.hi?'font-weight="700" style="fill:var(--ink)"':''}>${esc(r.label)}</text>`;
    s+=`<rect x="${lw}" y="${y+4}" width="${Math.max(1,bw)}" height="${rh-8}" rx="2" fill="${r.color||'var(--c1)'}"></rect>`;
    s+=`<text x="${lw+bw+6}" y="${y+rh*0.68}" class="num" style="font-size:11px">${r.text!=null?r.text:fmt(r.value)}</text>`;
  });
  return s+'</svg>';
}
function svgDonut(parts, total){
  const R=70, r=44, cx=90, cy=90; let a=-Math.PI/2; let s=`<svg class="chart" viewBox="0 0 180 180" style="max-width:220px;margin:auto">`;
  const sum=parts.reduce((x,p)=>x+p.value,0)||1;
  parts.forEach((p,i)=>{ const f=p.value/sum; if(f<=0) return; const a2=a+f*Math.PI*2; const large=f>0.5?1:0;
    const x1=cx+R*Math.cos(a),y1=cy+R*Math.sin(a),x2=cx+R*Math.cos(a2),y2=cy+R*Math.sin(a2);
    const x3=cx+r*Math.cos(a2),y3=cy+r*Math.sin(a2),x4=cx+r*Math.cos(a),y4=cy+r*Math.sin(a);
    s+=`<path d="M${x1},${y1} A${R},${R} 0 ${large} 1 ${x2},${y2} L${x3},${y3} A${r},${r} 0 ${large} 0 ${x4},${y4} Z" fill="${COLORS[i%COLORS.length]}"><title>${esc(p.label)}: ${fmt(p.value)} (${pct(f*100)})</title></path>`; a=a2; });
  s+=`<text x="${cx}" y="${cy-4}" text-anchor="middle" style="font-size:13px;font-weight:700;fill:var(--ink)">${fmtK(total)}</text><text x="${cx}" y="${cy+12}" text-anchor="middle" style="font-size:10px">USD directo</text></svg>`;
  return s;
}
function svgWaterfall(steps){
  // steps: [{label, value, type:'add'|'total'}]
  const w=640, h=steps.length*26+16, lw=250, bwmax=w-lw-110;
  const totalMax=Math.max(...steps.map(s=>s.cum||s.value));
  let s=`<svg class="chart" viewBox="0 0 ${w} ${h}">`; let cum=0;
  steps.forEach((st,i)=>{ const y=i*26+6; let x0,bw,col;
    if(st.type==='total'){ cum=st.value; x0=0; bw=st.value/totalMax*bwmax; col='var(--blue)'; }
    else { x0=cum/totalMax*bwmax; bw=st.value/totalMax*bwmax; cum+=st.value; col=st.color||'var(--c3)'; }
    s+=`<text x="${lw-6}" y="${y+15}" text-anchor="end" ${st.type==='total'?'font-weight="700" style="fill:var(--ink)"':''}>${esc(st.label)}</text>`;
    s+=`<rect x="${lw+x0}" y="${y+4}" width="${Math.max(1.5,bw)}" height="16" rx="2" fill="${col}" opacity="${st.type==='total'?1:.85}"></rect>`;
    s+=`<text x="${lw+x0+bw+6}" y="${y+15}" class="num" style="font-size:11px;${st.type==='total'?'font-weight:700;fill:var(--ink)':''}">${fmt(st.value)}</text>`;
  });
  return s+'</svg>';
}
function svgLine(points, opts={}){
  // points: [{x,y}] normalized to 0..1 ; opts.marks: [{x,label}]
  const w=520,h=220,pl=48,pr=16,pt=14,pb=34;
  const xs=points.map(p=>p.x), ys=points.map(p=>p.y);
  const xmin=Math.min(...xs), xmax=Math.max(...xs);
  const X=v=>pl+(v-xmin)/(xmax-xmin||1)*(w-pl-pr), Y=v=>pt+(1-v)*(h-pt-pb);
  let s=`<svg class="chart" viewBox="0 0 ${w} ${h}">`;
  for(let g=0;g<=4;g++){ const y=Y(g/4); s+=`<line class="grid" x1="${pl}" x2="${w-pr}" y1="${y}" y2="${y}"></line><text x="${pl-6}" y="${y+4}" text-anchor="end">${g*25}%</text>`; }
  const d=points.map((p,i)=>(i?'L':'M')+X(p.x).toFixed(1)+','+Y(p.y).toFixed(1)).join(' ');
  s+=`<path d="${d}" fill="none" stroke="var(--blue)" stroke-width="2"></path>`;
  (opts.marks||[]).forEach(m=>{ const x=X(m.x); s+=`<line x1="${x}" x2="${x}" y1="${pt}" y2="${h-pb}" stroke="${m.color||'var(--accent)'}" stroke-dasharray="3 3"></line><text x="${x}" y="${h-pb+14}" text-anchor="middle" style="fill:${m.color||'var(--accent)'};font-weight:700">${esc(m.label)}</text>`; });
  s+=`<text x="${pl}" y="${h-6}" style="font-size:10px">USD ${fmtK(xmin)}</text><text x="${w-pr}" y="${h-6}" text-anchor="end" style="font-size:10px">USD ${fmtK(xmax)}</text>`;
  return s+'</svg>';
}
function svgHist(s, bins=30, base){
  const min=s[0], max=s[s.length-1]; const cnt=new Array(bins).fill(0);
  s.forEach(v=>{ let b=Math.floor((v-min)/(max-min||1)*bins); if(b>=bins) b=bins-1; cnt[b]++; });
  const w=520,h=140,pl=10,pb=18; const mx=Math.max(...cnt); const bw=(w-2*pl)/bins;
  let out=`<svg class="chart" viewBox="0 0 ${w} ${h}">`;
  cnt.forEach((c,i)=>{ const bh=c/mx*(h-pb-8); out+=`<rect x="${pl+i*bw+1}" y="${h-pb-bh}" width="${bw-2}" height="${bh}" fill="var(--c2)"></rect>`; });
  if(base!=null){ const x=pl+(base-min)/(max-min||1)*(w-2*pl); out+=`<line x1="${x}" x2="${x}" y1="6" y2="${h-pb}" stroke="var(--accent)" stroke-width="2"></line><text x="${x+4}" y="16" style="fill:var(--accent);font-weight:700">Base</text>`; }
  out+=`<text x="${pl}" y="${h-4}" style="font-size:10px">${fmtK(min)}</text><text x="${w-pl}" y="${h-4}" text-anchor="end" style="font-size:10px">${fmtK(max)}</text>`;
  return out+'</svg>';
}

/* ---------- render: resumen ---------- */
let R=null;
function renderResumen(){
  const M=R.M, inp=R.inp, cls=CLASSES[inp.cls];
  $('#kpis').innerHTML=`
    <div class="card kpi hero"><div class="l">Monto total de inversión (E) · USD sin IGV · precios ${PRICE.year}</div><div class="v">${fmt(R.E)}<small>USD</small></div><div class="d">S/ ${fmt(R.E*inp.tc)} (TC ${inp.tc}) · con IGV USD ${fmt(R.ET)} · ${fmt(R.usdKm)} USD/km</div></div>
    <div class="card kpi accent"><div class="l">Costo por kilómetro</div><div class="v">${fmt(R.usdKm)}<small>USD/km</small></div><div class="d">Directo ${fmt(R.dirKm)} USD/km · COES eq. ${fmt(R.coesEqKm)} USD/km (módulo ${M.n} sin servidumbre: ${fmt(M.usdkmSinServ)})</div></div>
    <div class="card kpi"><div class="l">Estructuras y acero</div><div class="v">${fmt(R.nStruct)}<small>estructuras</small></div><div class="d">${fmt(R.tons,0)} t de acero · ${fmt(R.tonKm,1)} t/km · ${fmt(R.tons/R.nStruct,1)} t/estructura</div></div>
    <div class="card kpi"><div class="l">Contingencia ${cls.name}</div><div class="v">${fmt(R.cont)}<small>USD</small></div><div class="d">${pct(inp.cont)} del estimado base · rango esperado ${cls.lo[0]}…${cls.lo[1]} / +${cls.hi[0]}…+${cls.hi[1]} %</div></div>`;
  const wn=$('#wfNote'); if(wn) wn.textContent=`USD sin IGV · precios ${PRICE.year} (cotizaciones actualizadas ×${(R.escF||1).toFixed(3)}) · ejecución ${PROJ.describe()}`;
  $('#waterfall').innerHTML=edtFlow(edtSpecA(R));
  // class card
  const lo=(cls.lo[0]+cls.lo[1])/2, hi=(cls.hi[0]+cls.hi[1])/2;
  const vlo=R.E*(1+cls.lo[1]/100), vlo2=R.E*(1+cls.lo[0]/100), vhi2=R.E*(1+cls.hi[0]/100), vhi=R.E*(1+cls.hi[1]/100);
  const span=vhi-vlo; const p=v=>((v-vlo)/span*100).toFixed(1)+'%';
  $('#classCard').innerHTML=`<div class="badge-class">${cls.name} <span class="small muted" style="font-family:var(--font-body);font-weight:500">· ${esc(cls.uso)}</span></div>
    <div class="small muted" style="margin:4px 0 10px">Definición del proyecto ${cls.def} · método: ${esc(cls.metodo)} · AACE 18R-97</div>
    <div class="range"><div class="lo">${fmt(R.E*(1+lo/100))}<div class="tiny">bajo (${lo}%)</div></div><div class="mid">${fmt(R.E)}</div><div class="hi">${fmt(R.E*(1+hi/100))}<div class="tiny">alto (+${hi}%)</div></div></div>
    <div class="rangebar"><i style="left:${p(vlo)};width:${p(vhi)}"></i><i style="left:${p(vlo2)};width:${((vhi2-vlo2)/span*100).toFixed(1)}%;background:var(--blue)"></i><b style="left:${p(R.E)}"></b></div>
    <div class="split-lbl" style="margin-top:6px"><span>${fmtK(vlo)} (${cls.lo[1]}%)</span><span>${fmtK(vhi)} (+${cls.hi[1]}%)</span></div>
    <div class="tiny" style="margin-top:8px">Barra oscura: rango típico; barra clara: rango extremo de la clase. La contingencia recomendada por el procedimiento de la compañía para ${cls.name} es ${({5:'35–100',4:'25–35',3:'15–25',2:'10–15',1:'5–10'})[inp.cls]} %.</div>`;
  // donut
  const parts=[
    {label:'Estructuras',value:R.items['2.1'].tot},{label:'Conductores',value:R.items['2.2'].tot},{label:'Obras civiles y accesos',value:R.items['1.1'].tot+R.items['1.2'].tot+R.items['1.3'].tot},
    {label:'Cables de guarda',value:R.items['2.3'].tot},{label:'Aisladores y herrajes',value:R.items['2.4'].tot},{label:'Puesta a tierra',value:R.items['2.5'].tot},{label:'Transporte',value:R.items['2.6'].tot},{label:'Inspección y pruebas',value:R.sumPP}];
  $('#donutTot').textContent=`Directo contratista F = USD ${fmt(R.F)}`;
  $('#donut').innerHTML=`<div style="display:grid;grid-template-columns:auto 1fr;gap:12px;align-items:center">${svgDonut(parts,R.F)}<div class="legend" style="flex-direction:column;gap:4px">${parts.map((p,i)=>`<span><i style="background:${COLORS[i]}"></i>${p.label} <b class="num">${pct(p.value/R.F*100)}</b></span>`).join('')}</div></div>`;
  // ratios
  const kmc=inp.km*(inp.struct==='DT'?2:1);
  const rows=[
    ['USD/km (total inversión, sin IGV)',fmt(R.usdKm)],['USD/km costo directo',fmt(R.dirKm)],['USD/km-circuito (directo)',fmt(R.directo/kmc)],
    ['USD por estructura (directo)',fmt(R.directo/R.nStruct)],['USD/t de acero instalada (ítem 2.1)',fmt(R.items['2.1'].tot/Math.max(1,R.tons))],
    ['Suministro / obras (F)',`${pct(R.sumSup/R.F*100)} / ${pct((R.sumCiv+R.sumEm+R.sumPP)/R.F*100)}`],['Obras civiles / montaje EM',`${pct(R.sumCiv/R.F*100)} / ${pct((R.sumEm+R.sumPP)/R.F*100)}`],
    ['Estructuras por km',fmt(1000/inp.span,2)],['Acero por km',fmt(R.tonKm,1)+' t'],['Conductor',`${condLabel(inp.cond)} · ${fmt(R.factors.kgUser)} kg/km · USD ${fmt(R.factors.cpU.usd)}/km`],
    ['Servidumbre','excluida del estimado (referencia módulo COES: USD '+fmt(R.servMod/inp.km)+'/km)'],['S/ total (TC '+inp.tc+')','S/ '+fmt(R.E*inp.tc)]];
  $('#ratios').innerHTML=`<dl class="kv">${rows.map(r=>`<dt>${r[0]}</dt><dd>${r[1]}</dd>`).join('')}</dl>`;
  // benchmark
  const brows=MODS.map(m=>({label:`${m.n} ${m.code}`,value:m.usdkmSinServ,color:m.n===M.n?'var(--blue)':'var(--c2)',hi:m.n===M.n}));
  brows.push({label:`★ Tu estimado (COES eq.)`,value:R.coesEqKm,color:'var(--accent)',hi:true});
  brows.sort((a,b)=>b.value-a.value);
  $('#bench').innerHTML=svgBars(brows,{rh:16,lw:230,w:760});
  // referencia cruzada Osinergmin BDME (mismo nivel de tensión)
  if(typeof OSI!=='undefined' && $('#benchOsi')){
    const om=OSI.mods.filter(m=>m.kv===inp.kv);
    if(om.length){ const orows=om.map(m=>({label:`${m.code.replace(/^L[FT]-/,'')} · ${m.terna==='D'?'DT':'ST'} ${m.condMm2} mm² ${m.zona.split(' ')[0]}${m.altTxt?' '+m.altTxt.split(' ')[0]:''}`,value:m.usdKm-(m.servidumbre||0),color:'var(--c4)'}));
      orows.push({label:'★ Tu estimado (COES eq.)',value:R.coesEqKm,color:'var(--accent)',hi:true}); orows.sort((a,b)=>b.value-a.value);
      const avg=om.reduce((a,m)=>a+m.usdKm-(m.servidumbre||0),0)/om.length;
      $('#benchOsi').innerHTML=svgBars(orows,{rh:16,lw:300,w:760})+`<div class="tiny">Módulos BDME de ${inp.kv} kV (valor regulatorio Osinergmin sin servidumbre, sin IGV): ${om.length} módulos, promedio ${fmt(avg)} USD/km; tu estimado equivale a ${pct(R.coesEqKm/avg*100,0)} del promedio. Las bases difieren (precios CIF Osinergmin vs. cotizaciones COES 2025, GG/U y estructura de indirectos), por lo que la comparación es orientativa.</div>`;
      $('#benchOsiCard').hidden=false; }
    else { $('#benchOsiCard').hidden=true; }
  }
}

/* ---------- render: directo ---------- */
function renderDirecto(){
  const it=R.items, inp=R.inp, M=R.M;
  const L=inp.km; const F=R.F;
  const tr=(k,name,type,o,lvl)=>`<tr class="${lvl||''}"><td class="num">${k}</td><td>${esc(name)} ${type?`<span class="tag ${type}">${type==='sum'?'suministro':type==='civ'?'civil':type==='em'?'montaje':'dueño'}</span>`:''}</td><td class="n">${fmt(o.sum)}</td><td class="n">${fmt(o.civ)}</td><td class="n">${fmt(o.em)}</td><td class="n"><b>${fmt(o.tot)}</b></td><td class="n">${fmt(o.tot/L)}</td><td class="n">${pct(o.tot/F*100)}</td><td><div class="bar"><i style="width:${Math.min(100,o.tot/F*100*2.5)}%"></i></div></td></tr>`;
  let h=`<table><thead><tr><th>Ítem</th><th>Partida</th><th class="n">Suministro USD</th><th class="n">Obras civiles USD</th><th class="n">Montaje EM USD</th><th class="n">Total USD</th><th class="n">USD/km</th><th class="n">% de F</th><th></th></tr></thead><tbody>`;
  h+=`<tr class="lvl1"><td>1.0</td><td>Obras civiles</td><td></td><td class="n">${fmt(R.sumCiv)}</td><td></td><td class="n">${fmt(R.sumCiv)}</td><td class="n">${fmt(R.sumCiv/L)}</td><td class="n">${pct(R.sumCiv/F*100)}</td><td></td></tr>`;
  ['1.1','1.2','1.3'].forEach(k=>{ const d=ITEMS.find(x=>x[0]===k); h+=tr(k,d[1],d[2],it[k]); });
  const em={sum:R.sumSup,civ:0,em:R.sumEm,tot:R.sumSup+R.sumEm};
  h+=`<tr class="lvl1"><td>2.0</td><td>Obras electromecánicas y suministro</td><td class="n">${fmt(em.sum)}</td><td></td><td class="n">${fmt(em.em)}</td><td class="n">${fmt(em.tot)}</td><td class="n">${fmt(em.tot/L)}</td><td class="n">${pct(em.tot/F*100)}</td><td></td></tr>`;
  ['2.1','2.2','2.3','2.4','2.5','2.6'].forEach(k=>{ const d=ITEMS.find(x=>x[0]===k); h+=tr(k,d[1],d[2],it[k]); });
  ['3.0','4.0'].forEach(k=>{ const d=ITEMS.find(x=>x[0]===k); h+=tr(k,d[1],d[2],it[k]); });
  h+=`<tr class="tot"><td>F</td><td>Costo directo contratista</td><td class="n">${fmt(R.sumSup)}</td><td class="n">${fmt(R.sumCiv)}</td><td class="n">${fmt(R.sumEm+R.sumPP)}</td><td class="n">${fmt(F)}</td><td class="n">${fmt(F/L)}</td><td class="n">100 %</td><td></td></tr>`;
  h+=`<tr class="sub"><td>G</td><td>Distribuibles del contratista (GG + utilidad ${pct(inp.gg)} sobre obras)</td><td></td><td></td><td></td><td class="n">${fmt(R.G)}</td><td class="n">${fmt(R.G/L)}</td><td class="n">${pct(R.G/F*100)}</td><td></td></tr>`;
  h+=`<tr class="sub"><td></td><td>Allowances de cantidades (${pct(inp.allowQ)}) y precios (${pct(inp.allowP)})</td><td></td><td></td><td></td><td class="n">${fmt(R.allowQ+R.allowP)}</td><td class="n">${fmt((R.allowQ+R.allowP)/L)}</td><td class="n">${pct((R.allowQ+R.allowP)/F*100)}</td><td></td></tr>`;
  h+=`<tr class="tot"><td>1</td><td>Costo directo (LE2)</td><td></td><td></td><td></td><td class="n">${fmt(R.directo)}</td><td class="n">${fmt(R.directo/L)}</td><td class="n">${pct(R.directo/F*100)}</td><td></td></tr>`;
  h+=tr('5.0','Expediente técnico, ingeniería de detalle, EIA, EO, concesión, CIRA (dentro del costo indirecto)','own',{sum:0,civ:0,em:0,tot:R.est},'sub');
  h+=`</tbody></table>`;
  $('#directoTbl').innerHTML=h;
  const f=R.factors;
  $('#directoNote').innerHTML=`Factores aplicados al módulo ${M.n} (${M.km} km): longitud ×${f.fL.toFixed(3)} · estructuras/km ×${f.fCount.toFixed(3)} · peso/torre ×${f.fW.toFixed(3)} (mezcla ×${f.fMix.toFixed(2)}, conductor ×${f.fCondW.toFixed(2)}, extensión ×${f.fExt.toFixed(2)}) · suelo ×${f.fSoil.toFixed(3)} · accesos ×${f.acc} · precio conductor ×${f.fCondP.toFixed(3)} · guarda ×${f.fCG.toFixed(3)} · acero ×${f.fSteel.toFixed(3)}`;
  // families
  const scale=R.nStruct/(M.structs.total||1);
  let fh=`<table><thead><tr><th>Familia</th><th class="n">N° módulo</th><th class="n">t módulo</th><th class="n">t/estructura</th><th class="n">N° proyecto</th><th class="n">USD/und (sum.)</th></tr></thead><tbody>`;
  (M.fams||[]).forEach(fm=>{ const n=fm.count||0; const t=fm.ton||0; const usdT=M.steelUsdTon||inp.steel; const towers=fm.var.filter(v=>!/pata|stub|parrilla|rotula|perno|cruceta|mensula|ménsula/i.test(v[0]));
    const usdU = towers.length&&towers.some(v=>v[3])? (towers.reduce((a,v)=>a+(v[1]||0)*(v[3]||0),0)/Math.max(1,towers.reduce((a,v)=>a+(v[1]||0),0))) : (n?t/n*usdT:0);
    fh+=`<tr><td>${esc(fm.name)}<div class="tiny">${towers.slice(0,6).map(v=>`${esc(v[0])} ${v[1]||0}u${v[2]?' · '+fmt(v[2],1)+' t':''}`).join(' · ')}${towers.length>6?' …':''}</div></td><td class="n">${fmt(n)}</td><td class="n">${fmt(t,1)}</td><td class="n">${n?fmt(t/n,2):'—'}</td><td class="n">${fmt(Math.round(n*scale*f.fMix**0))}</td><td class="n">${fmt(usdU*f.fW/f.fMix)}</td></tr>`; });
  fh+=`</tbody></table>`;
  $('#famTbl').innerHTML=fh;
  $('#famNote').textContent=`Acero: USD ${fmt(M.steelUsdTon||inp.steel)}/t (CIF ${fmt(DB.cot.torre.cif)} + arancel ${DB.cot.torre.arancelPct}% + aduana ${DB.cot.torre.aduanaPct}%) · montaje ${(()=>{const r=(M.obras||[]).find(o=>/^Instalaci[oó]n de estructuras/i.test(o[1])||(/Estructuras tipo/i.test(o[1])&&o[2]==='Ton')); return r&&r[4]?'USD '+fmt(r[4])+'/t':'según APU';})()}`;
  // conductors etc
  const c=inp.cond; const km=inp.km;
  let ch=`<table><thead><tr><th>Elemento</th><th class="n">Cantidad</th><th class="n">kg/km</th><th class="n">USD/km · und</th><th class="n">Suministro USD</th></tr></thead><tbody>`;
  ch+=`<tr><td>Conductor ${condLabel(c)} (${c.n} × 3 fases${inp.struct==='DT'?' × 2 ternas':''}, +2 % flechas y empalmes)</td><td class="n">${fmt(km*3*c.n*(inp.struct==='DT'?2:1)*1.02,1)} km</td><td class="n">${fmt(f.kgUser)}</td><td class="n">${fmt(f.cpU.usd)}</td><td class="n">${fmt(it['2.2'].sum)}</td></tr>`;
  cgList(inp.cg).forEach(k=>{ ch+=`<tr><td>Cable de guarda ${k}</td><td class="n">${fmt(km,1)} km</td><td class="n">${k==='OPGW'?fmt((M.opgw&&M.opgw.kgkm)||478):fmt((M.ehs&&M.ehs.kgkm)||594)}</td><td class="n">${fmt(guardUsdKm(k,M))}</td><td class="n"></td></tr>`; });
  ch+=`<tr><td>Cables de guarda con accesorios (ítem 2.3)</td><td></td><td></td><td></td><td class="n">${fmt(it['2.3'].sum)}</td></tr>`;
  (M.ins||[]).forEach(i=>{ ch+=`<tr><td>${esc(i.desc)} <span class="tiny">(módulo)</span></td><td class="n">${fmt(i.qty*f.fL*f.fCount)} und</td><td></td><td class="n">${fmt(i.usd,2)}</td><td class="n">${fmt(i.qty*f.fL*f.fCount*i.usd)}</td></tr>`; });
  ch+=`<tr><td>Cadenas de aisladores y herrajes (ítem 2.4)</td><td></td><td></td><td></td><td class="n">${fmt(it['2.4'].sum)}</td></tr>`;
  ch+=`<tr><td>Puesta a tierra (ítem 2.5)</td><td></td><td></td><td></td><td class="n">${fmt(it['2.5'].sum)}</td></tr>`;
  ch+=`</tbody></table>`;
  $('#condTbl').innerHTML=ch;
}

/* ---------- render: metrados ---------- */
function renderObras(){
  const M=R.M, f=R.factors, inp=R.inp;
  const perStruct=/nivelaci|estructura|torre|pata|stub|excavaci|relleno|concreto|acero de refuerzo|encofrado|solado|eliminaci|fundaci|anclaje|protecci|puesta a tierra|contrapeso|antitrepado|placa|señal|medici|clasificaci|instalaci[oó]n de estructuras|jabalina|resistencia/i;
  const perKm=/replanteo|camino|acceso|conductor|tendido|guarda|opgw|ehs|empalme|lastrado|mejoramiento|faja|servidumbre|limpieza/i;
  let h=`<table><thead><tr><th>Ítem</th><th>Partida</th><th>Und</th><th class="n">Metrado módulo</th><th class="n">Metrado proyecto</th><th class="n">P.U. USD</th><th class="n">Total USD</th><th>Escala</th></tr></thead><tbody>`;
  let tot=0;
  (M.obras||[]).forEach(r=>{ let [code,desc,unit,qty,pu,total]=r; const lvl=code.split('.').length; const isHdr=!unit||pu==null; if(!isHdr&&qty==null) qty=0;
    let fac=f.fL, how='km';
    if(/glb|gbl|glo/i.test(unit)){ fac=(inp.fix/100+(1-inp.fix/100)*f.fL); how='fijo/km'; }
    else if(/^Ton$/i.test(unit)||/^t$/i.test(unit)){ fac=f.fL*f.fStruct; how='t acero'; }
    else if(/excavaci/i.test(desc)){ const key=/arena/i.test(desc)?'are':/roca/i.test(desc)?'roc':'nor'; const base=f.sb[key]||0; fac=base>0? f.fL*f.fCount*f.fMix*(f.su[key]/base): (f.su[key]>0? f.fL*f.fCount*f.fMix*f.su[key]/100*3:0); how='suelo'; }
    else if(perStruct.test(desc)&&!perKm.test(desc)){ fac=f.fL*f.fCount*(/concreto|acero|encofrado|relleno|solado|eliminaci/i.test(desc)?f.fMix:1); how='estructuras'; }
    else if(/camino|acceso/i.test(desc)){ fac=f.fL*f.acc; how='km·accesos'; }
    else if(/conductor/i.test(desc)&&/km/i.test(unit)){ fac=f.fL*f.fCondN; how='km·fase'; }
    if(isHdr){ h+=`<tr class="${lvl<=1?'lvl1':'lvl2'}"><td class="num">${code}</td><td colspan="5">${esc(desc)}</td><td class="n"></td><td></td></tr>`; return; }
    const q=qty*fac, t=q*pu; tot+=t;
    h+=`<tr><td class="num">${code}</td><td>${esc(desc)}</td><td>${esc(unit)}</td><td class="n">${fmt(qty,2)}</td><td class="n">${fmt(q,2)}</td><td class="n">${fmt(pu,2)}</td><td class="n">${fmt(t)}</td><td class="tiny">${how}</td></tr>`; });
  h+=`<tr class="tot"><td></td><td colspan="5">Presupuesto de obra escalado (referencial, sin GG+U)</td><td class="n">${fmt(tot)}</td><td></td></tr></tbody></table>`;
  $('#obrasTbl').innerHTML=h;
}

/* ---------- render: APUs ---------- */
let apuFilter='all';
function renderApus(){
  const M=R.M; const q=($('#apuSearch').value||'').toLowerCase();
  const ids=M.apus||[];
  const list=ids.map(id=>({id,a:DB.apus[id]})).filter(x=>x.a);
  $('#apuNote').textContent=`${list.length} análisis del módulo ${M.n} (${M.code}). Rendimiento, cuadrilla y recursos según la base COES; precios de recursos de la región ${M.zone}.`;
  const catName=['Mano de obra','Materiales','Equipos','Movilidades','Subcontratas','Otros'];
  const catCol=['var(--c1)','var(--c3)','var(--c4)','var(--c7)','var(--c5)','var(--c8)'];
  let tot=[0,0,0,0,0,0];
  let html='';
  list.forEach(({id,a},idx)=>{
    const isOC=/^1|^2|^3/.test(a.c||'') && !/montaje|tendido|instalaci[oó]n de estructuras|clasificaci|opgw|guarda|conductor/i.test(a.n);
    const kind = (M.apus.indexOf(id) < (list.filter(x=>x.a).length)) ? null : null;
    const text=(a.n+' '+(a.c||'')+' '+a.res.map(r=>r[1]||r[2]).join(' ')).toLowerCase();
    if(q && !text.includes(q)) return;
    const sub=[0,0,0,0,0,0]; a.res.forEach(r=>{ sub[r[0]]+= (r[5]||0); });
    const s=sub.reduce((x,y)=>x+y,0)||1;
    if(apuFilter==='oc' && !isApuOC(a)) return; if(apuFilter==='me' && isApuOC(a)) return;
    tot=tot.map((t,i)=>t+sub[i]);
    html+=`<details class="apu"><summary><span class="cd">${esc(a.c||'')}</span><span>${esc(a.n)}<div class="tiny">${a.r?`rend. ${fmt(a.r,2)} ${esc(a.ru||'')}`:''}</div></span><span class="mix" title="MO / MAT / EQ / MOV / SC">${sub.map((v,i)=>v>0?`<i style="width:${v/s*100}%;background:${catCol[i]}"></i>`:'').join('')}</span><span class="cu">${fmt(a.cu,2)} <span class="tiny">USD/${esc((a.u||'').replace(/\/d[ií]a$/i,''))}</span></span></summary>
      <div class="det"><table><thead><tr><th>Código</th><th>Recurso</th><th>Und</th><th class="n">Cuadrilla</th><th class="n">Cantidad</th><th class="n">Precio USD</th><th class="n">Parcial USD</th></tr></thead><tbody>
      ${[0,1,2,3,4,5].map(ci=>{ const rows=a.res.filter(r=>r[0]===ci); if(!rows.length) return ''; return `<tr class="lvl2"><td colspan="6">${catName[ci]}</td><td class="n">${fmt(sub[ci],2)}</td></tr>`+rows.map(r=>{ if(r[1]){ const rn=DB.resNames[r[1]]||['',''] ; return `<tr><td class="num">${esc(r[1])}</td><td>${esc(rn[0])}</td><td>${esc(rn[1])}</td><td class="n">${fmt(r[2],2)}</td><td class="n">${fmt(r[3],4)}</td><td class="n">${fmt(r[4],2)}</td><td class="n">${fmt(r[5],2)}</td></tr>`; } return `<tr><td></td><td>${esc(r[2])}</td><td>%</td><td></td><td></td><td></td><td class="n">${fmt(r[5],2)}</td></tr>`; }).join(''); }).join('')}
      </tbody></table></div></details>`;
  });
  $('#apuList').innerHTML=html||'<div class="card muted">Sin resultados.</div>';
  const s=tot.reduce((x,y)=>x+y,0)||1;
  $('#apuSummary').innerHTML=`<div class="eyebrow">Composición agregada de los APUs mostrados</div><div class="split">${tot.map((v,i)=>v>0?`<i style="width:${v/s*100}%;background:${catCol[i]}" title="${catName[i]}"></i>`:'').join('')}</div><div class="legend">${tot.map((v,i)=>v>0?`<span><i style="background:${catCol[i]}"></i>${catName[i]} ${pct(v/s*100)}</span>`:'').join('')}</div>`;
}
function isApuOC(a){ return !/montaje|tendido|instalaci[oó]n de estructuras|clasificaci[oó]n de (torres|estructuras)|opgw|guarda|conductor|empalme|antitrepado|pruebas|puesta en servicio|contrapeso|fleje|inspecci|cadena|aislador|señalizaci|numeraci|VSL|CSL|atirantad/i.test(a.n); }

/* ---------- render: cotizaciones ---------- */
let resRegion='Costa', resType='MO';
function renderCot(){
  const c=DB.cot;
  let h=`<table><thead><tr><th>Tipo</th><th>Sección</th><th class="n">DFJ</th><th class="n">Panghao</th><th class="n">Prom. CIF</th><th class="n">Arancel</th><th class="n">Aduana</th><th class="n">Final USD/km</th></tr></thead><tbody>`;
  c.conductores.forEach(q=>{ h+=`<tr><td>${q.tipo}</td><td>${esc(q.seccion)}</td><td class="n">${fmt(q.dfj)}</td><td class="n">${fmt(q.panghao)}</td><td class="n">${fmt(q.cif)}</td><td class="n">${fmt(q.arancel)}</td><td class="n">${fmt(q.aduana)}</td><td class="n"><b>${fmt(q.final)}</b></td></tr>`; });
  h+='</tbody></table>'; $('#cotCond').innerHTML=h;
  $('#cotSteel').innerHTML=`<dl class="kv"><dt>Torre de acero (celosía)</dt><dd>JIANGSU ${fmt(c.torre.jiangsu)} · DAJI ${fmt(c.torre.daji)} → CIF ${fmt(c.torre.cif)} + arancel ${c.torre.arancelPct}% (${fmt(c.torre.arancel)}) + aduana ${c.torre.aduanaPct}% (${fmt(c.torre.aduana)}) = <b>USD ${fmt(c.torre.final,2)}/t</b></dd>
    <dt>OPGW 36 hilos</dt><dd>DFJ ${fmt(c.opgw.dfj)} · Panghao ${fmt(c.opgw.panghao)} → CIF ${fmt(c.opgw.cif)} + aduana ${fmt(c.opgw.aduana)} = <b>USD ${fmt(c.opgw.final,2)}/km</b> (los módulos usan 1 800 – 3 307 USD/km según fibras y kA²s)</dd>
    <dt>EHS 7/16" 70 mm²</dt><dd>USD 1 535.47/km (incluye accesorios)</dd><dt>Alumoweld / ACSR guarda</dt><dd>USD 1 842.56/km</dd>
    <dt>Flete terrestre (MTC, ago-2025)</dt><dd>USD ${fmt(R.M.flete||101,2)}/t para el módulo base (${R.M.zone}); rango 27 – 187 USD/t según distancia virtual Lima–obra</dd></dl>`;
  let o=`<table><thead><tr><th>Descripción</th><th>Und</th><th class="n">USD</th></tr></thead><tbody>`;
  c.postes.forEach(p=>o+=`<tr><td>${esc(p.desc)}</td><td>und</td><td class="n">${fmt(p.usd,2)}</td></tr>`);
  c.aisladores.forEach(p=>o+=`<tr><td>${esc(p.desc)}</td><td>und</td><td class="n">${fmt(p.usd,2)}</td></tr>`);
  c.pat.forEach(p=>o+=`<tr><td>${esc(p.desc)}</td><td>${esc(p.unit)}</td><td class="n">${fmt(p.usd,2)}</td></tr>`);
  o+='</tbody></table>'; $('#cotOther').innerHTML=o;
  renderRes();
}
function renderRes(){
  const rows=(DB.resources[resRegion]||[]).filter(r=>r[0].startsWith(resType+'-'));
  let h=`<table><thead><tr><th>Código</th><th>Recurso</th><th>Und</th><th class="n">USD</th><th class="n">S/ (TC ${R?R.inp.tc:3.479})</th></tr></thead><tbody>`;
  rows.forEach(r=>{ h+=`<tr><td class="num">${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td><td class="n">${fmt(r[3],2)}</td><td class="n">${fmt(r[3]*(R?R.inp.tc:3.479),2)}</td></tr>`; });
  $('#resTbl').innerHTML=h+'</tbody></table>';
}

/* ---------- render: riesgo ---------- */
function renderRiesgo(){
  const inp=R.inp, cls=CLASSES[inp.cls];
  let h=`<table><thead><tr><th>Clase</th><th>Uso</th><th>Definición</th><th class="n">Rango bajo</th><th class="n">Rango alto</th><th>Método típico</th></tr></thead><tbody>`;
  [5,4,3,2,1].forEach(k=>{ const c=CLASSES[k]; h+=`<tr class="${k===inp.cls?'sel':''}"><td><b>${c.name}</b></td><td>${esc(c.uso)}</td><td>${c.def}</td><td class="n">${c.lo[0]} … ${c.lo[1]} %</td><td class="n">+${c.hi[0]} … +${c.hi[1]} %</td><td class="small">${esc(c.metodo)}</td></tr>`; });
  $('#aaceTbl').innerHTML=`<div class="tbl-wrap">${h}</tbody></table></div><div class="tiny" style="margin-top:8px">Rangos de precisión esperados según AACE International RP 18R-97 (industria de procesos), aplicables como referencia a infraestructura eléctrica. La contingencia se estima con RP 42R-08 (método de rangos / simulación).</div>`;
  const pk=riskPackages(R);
  if(!state.riskRanges||state.riskRanges.cls!==inp.cls){ state.riskRanges={cls:inp.cls, r:JSON.parse(JSON.stringify(RISK_DEFAULT[inp.cls]))}; }
  const rr=state.riskRanges.r;
  let t=`<table><thead><tr><th>Paquete</th><th class="n">Base USD</th><th class="n">Mín %</th><th class="n">Máx %</th><th class="n">Esperado PERT</th><th class="n">Δ USD</th></tr></thead><tbody>`;
  let sumB=0,sumE=0;
  pk.forEach(p=>{ const r=rr[p.k]; const mn=p.base*(1+r[0]/100), mx=p.base*(1+r[1]/100); const e=(mn+mx+4*p.base)/6; sumB+=p.base; sumE+=e;
    t+=`<tr><td>${esc(p.name)}</td><td class="n">${fmt(p.base)}</td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="0" value="${r[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="1" value="${r[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">${fmt(e)}</td><td class="n">${fmt(e-p.base)}</td></tr>`; });
  const rs=rr.sys||[0,0]; const fSys=(1+rs[0]/100+1+rs[1]/100+4)/6; const sumE2=sumE*fSys;
  t+=`<tr class="sub"><td>${SYS_NAME}</td><td class="n">×</td><td class="n"><input type="number" class="rk" data-k="sys" data-i="0" value="${rs[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="sys" data-i="1" value="${rs[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">×${fSys.toFixed(4)}</td><td class="n">${fmt(sumE2-sumE)}</td></tr>`;
  t+=`<tr class="tot"><td>Estimado base (B)</td><td class="n">${fmt(sumB)}</td><td></td><td></td><td class="n">${fmt(sumE2)}</td><td class="n">${fmt(sumE2-sumB)}</td></tr></tbody></table>`;
  $('#riskTbl').innerHTML=t;
  sumE=sumE2;
  /* la tabla se vuelve a dibujar al confirmar el valor (change), no en cada tecla: así se pueden escribir negativos y no se pierde el foco */
  $$('#riskTbl input.rk').forEach(i=>i.onchange=()=>{ if(!rr[i.dataset.k]) rr[i.dataset.k]=[0,0]; rr[i.dataset.k][parseInt(i.dataset.i)]=parseFloat(i.value)||0; renderRiesgo(); });
  const cDet=(sumE-sumB)/sumB*100;
  $('#riskSum').innerHTML=`<div class="grid g3"><div class="card flat kpi"><div class="l">Contingencia PERT (valor esperado)</div><div class="v" style="font-size:22px">${pct(cDet,2)}</div><div class="d">USD ${fmt(sumE-sumB)}</div></div><div class="card flat kpi"><div class="l">Contingencia aplicada</div><div class="v" style="font-size:22px">${pct(inp.cont)}</div><div class="d">USD ${fmt(R.cont)}</div></div><div class="card flat" style="display:grid;align-content:center"><button class="btn sm" id="btnUsePert">Usar ${pct(cDet)} como contingencia</button></div></div>`;
  $('#btnUsePert').onclick=()=>{ $('#inCont').value=cDet.toFixed(1); recalc(); toast('Contingencia actualizada'); };
  renderMC();
  if(window.PERTMAP) PERTMAP.render($('#pertMap'),'A');
}
function renderMC(){
  const mc=state.mc;
  if(!mc){ $('#mcOut').innerHTML='<div class="tiny">Ejecuta la simulación para obtener P10–P90: cada paquete se muestrea con una distribución beta-PERT (media = esperado PERT de la tabla) o triangular, sin correlación entre paquetes, y el riesgo sistémico multiplica el total.</div>'; $('#scurve').innerHTML='<div class="tiny">La curva S aparecerá tras la simulación.</div>'; return; }
  const conf=parseInt($('#mcP').value); const Pc=mc.P(conf); const base=mc.base;
  const stale= Math.abs(base-R.B)>0.001*Math.max(1,R.B) ? `<div class="tiny" style="color:var(--warn);margin-bottom:6px">⚠ Simulación desactualizada: se corrió con B = USD ${fmt(base)} y el estimado base actual es USD ${fmt(R.B)}. Vuelve a ejecutarla.</div>` : '';
  $('#mcOut').innerHTML=`${stale}<dl class="kv"><dt>Base (B)</dt><dd>${fmt(base)}</dd><dt>Distribución</dt><dd>${mc.dist==='tri'?'triangular':'beta-PERT'} por paquete</dd><dt>Media</dt><dd>${fmt(mc.mean)} (${pct((mc.mean-base)/base*100)})</dd><dt>Desv. estándar</dt><dd>${fmt(mc.sd)} (${pct(mc.sd/base*100)})</dd><dt>P10</dt><dd>${fmt(mc.P(10))}</dd><dt>P50</dt><dd>${fmt(mc.P(50))}</dd><dt>P80</dt><dd>${fmt(mc.P(80))}</dd><dt>P90</dt><dd>${fmt(mc.P(90))}</dd><dt>Contingencia a P${conf}</dt><dd><b>${fmt(Pc-base)} (${pct((Pc-base)/base*100)})</b></dd></dl>
    ${svgHist(mc.s,32,base)}<button class="btn sm" id="btnUseMC" style="margin-top:8px">Usar P${conf} como contingencia</button>`;
  $('#btnUseMC').onclick=()=>{ $('#inCont').value=((Pc-base)/base*100).toFixed(1); recalc(); toast('Contingencia actualizada con P'+conf); };
  const N=mc.s.length; const pts=[]; for(let i=0;i<=100;i+=2){ pts.push({x:mc.P(Math.min(99.99,i)),y:i/100}); }
  $('#scurve').innerHTML=svgLine(pts,{marks:[{x:base,label:'Base'},{x:Pc,label:'P'+conf,color:'var(--good)'}]})+`<div class="tiny">Curva acumulada del estimado base B con incertidumbre por paquete. Contingencia recomendada = P${conf} − B.</div>`;
}

/* ---------- render: BD ---------- */
function renderBD(){
  const q=($('#bdSearch').value||'').toLowerCase();
  let h=`<table><thead><tr><th>N°</th><th>Código</th><th class="n">kV</th><th>Zona</th><th>Estructura</th><th>Conductor</th><th>CG</th><th class="n">km ref.</th><th class="n">Vano m</th><th class="n">Estruct.</th><th class="n">t acero</th><th class="n">USD/km sin serv.</th><th class="n">USD/km sin IGV</th></tr></thead><tbody>`;
  MODS.forEach(m=>{ const txt=`${m.n} ${m.code} ${m.name} ${m.zone} ${m.struct}`.toLowerCase(); if(q&&!txt.includes(q)) return;
    h+=`<tr class="click ${R&&m.n===R.M.n?'sel':''}" data-n="${m.n}"><td class="num">${m.n}</td><td class="num" style="white-space:nowrap">${m.code}</td><td class="n">${m.kv}</td><td style="white-space:nowrap">${m.zone} ${m.alt} ${m.rural}</td><td>${STRUCT_LABELS[m.struct]}</td><td>${condLabel(m.cond)}</td><td>${m.cg}</td><td class="n">${fmt(m.km,1)}</td><td class="n">${fmt(m.span)}</td><td class="n">${fmt(m.structs.total)}</td><td class="n">${fmt(m.steelTon)}</td><td class="n">${fmt(m.usdkmSinServ)}</td><td class="n"><b>${fmt(m.usdkm)}</b></td></tr>`; });
  $('#bdTbl').innerHTML=h+'</tbody></table>';
  $$('#bdTbl tr.click').forEach(tr=>tr.onclick=()=>{ const m=byN[parseInt(tr.dataset.n)]; loadModuleAsBase(m); });
  const M=R.M; $('#bdDescTitle').textContent=`Módulo ${M.n} · ${M.code}`; $('#bdDesc').textContent=M.desc||'';
}
function loadModuleAsBase(m){
  state.kv=m.kv; state.zone=m.zone; state.alt=m.alt; state.rural=m.rural; state.struct=m.struct; state.cond={...m.cond}; state.moduleN=m.n; state.manualModule=true;
  setSeg('#segKv',String(m.kv)); setSeg('#segZone',m.zone); setSeg('#segAlt',m.alt); setSeg('#segRural',m.rural); $('#selCG').value=m.cg;
  refreshStructOptions(); refreshCondOptions(); refreshModuleSelect(); applyModuleDefaults(m,false); recalc(); toast(`Módulo ${m.n} cargado como base`);
}

/* ---------- render: bases ---------- */
function renderBases(){
  const M=R.M, inp=R.inp, f=R.factors;
  const li=[
    `<b>Módulo base COES:</b> ${M.n} · ${esc(M.code)} — ${esc(M.name)}. Tramo representativo ${M.km} km, ${M.structs.total} estructuras, vano promedio ${M.span} m, ${esc(M.zoneTxt||'')}. Costo COES ${fmt(M.usdkm)} USD/km sin IGV (${fmt(M.usdkmSinServ)} sin servidumbre).`,
    `<b>Método:</b> estimación paramétrica por módulos (AACE 18R-97, ${CLASSES[inp.cls].name}). Los costos por partida del módulo se escalan por longitud (×${f.fL.toFixed(3)}) y se ajustan por densidad de estructuras (vano ${inp.span} m vs ${M.span} m → ×${f.fCount.toFixed(3)} estructuras/km), peso por estructura (×${f.fW.toFixed(3)}: vano^${inp.expW}, conductor^${inp.expC}, mezcla de tipos ×${f.fMix.toFixed(2)}, extensión ${inp.ext>=0?'+':''}${inp.ext} m), tipo de suelo en excavación (×${f.fSoil.toFixed(3)}), dificultad de accesos (×${f.acc}) y precios de conductor (×${f.fCondP.toFixed(3)}), cable de guarda (×${f.fCG.toFixed(3)}) y acero (×${f.fSteel.toFixed(3)}).`,
    `<b>Cantidades:</b> ${inp.km} km, ${R.nStruct} estructuras (${Math.round(f.mixUser.susp)} % suspensión, ${Math.round(f.mixUser.ang)} % ángulo, ${Math.round(f.mixUser.anc)} % anclaje/terminal), ${fmt(R.tons)} t de acero (${fmt(R.tonKm,1)} t/km), conductor ${condLabel(inp.cond)} (${fmt(f.kgUser)} kg/km, USD ${fmt(f.cpU.usd)}/km, ${esc(f.cpU.src)}), cable de guarda ${inp.cg} (${cgList(inp.cg).join(' + ')}). Suelo: ${Math.round(f.su.nor)} % normal / ${Math.round(f.su.are)} % arena / ${Math.round(f.su.roc)} % roca.`,
    `<b>Precios:</b> base COES setiembre 2026 (Revista Costos ago-2025, cotizaciones DFJ/Panghao/Wesco para conductores y OPGW, JIANGSU/DAJI para acero de torres a ${fmt(inp.steel)} USD/t, flete MTC ${fmt(M.flete||0)} USD/t), sin IGV, TC ${inp.tc} S/ por USD. Los precios unitarios de obra provienen de APUs (mano de obra, materiales, equipos, movilidades, subcontratos) sin gastos generales ni utilidad.`,
    `<b>Estructura del estimado (LE2):</b> F costo directo contratista = suministro + obras civiles + montaje + pruebas; G distribuibles = ${pct(inp.gg)} sobre obras; allowances ${pct(inp.allowQ)} cantidades y ${pct(inp.allowP)} precios; 1. costo directo = F + G + allowances; 2. costo indirecto = ingeniería/estudios/EIA/permisos según COES 5.0 (${fmt(R.est)} USD) + gerencia y supervisión de construcción ${pct(inp.ind)} del directo (servicios, campamento, movilidad, instalaciones temporales) + costo del dueño ${pct(inp.owner)}; servidumbre excluida (partida del dueño, ver supuestos); A estimado neto = 1 + 2; 3. escalamiento ${R.escDet? R.escDet.pct.toFixed(2)+' %' : pct(inp.esc)} de A (${R.escDet? 'fecha base → ejecución '+PROJ.describe() : 'manual'}); 4. provisión por riesgos ${pct(inp.risk)} de A; B estimado base = A + 3 + 4; 5. contingencia ${pct(inp.cont)} de B (${CLASSES[inp.cls].name}); C costo de ejecución = B + 5; D costo de la fase ${pct(inp.phase)} de C; E monto total de inversión = C + D.`,
    `<b>Precisión esperada:</b> ${CLASSES[inp.cls].lo[0]} … ${CLASSES[inp.cls].lo[1]} % / +${CLASSES[inp.cls].hi[0]} … +${CLASSES[inp.cls].hi[1]} % (AACE 18R-97). La contingencia debe validarse con el taller de análisis de rangos (RP 42R-08) — ver pestaña Riesgo.`,
    `<b>Limitaciones:</b> herramienta paramétrica de prefactibilidad/factibilidad; no reemplaza metrados de ingeniería, estudio de suelos, trazo definitivo ni cotizaciones firmes. Cruces especiales, vanos largos (> 800 m), zonas de alta contaminación o hielo, y requerimientos sociales/arqueológicos deben tratarse como partidas adicionales.`
  ];
  $('#basesTxt').innerHTML=li.map(x=>`<p>${x}</p>`).join('');
  const sup=$('#supuestosA'); if(sup) sup.innerHTML=supuestosHTML('A',inp);
  $('#fuentes').innerHTML=[
    'COES – Desarrollo de “Base de Datos de Costos de Sistemas de Transmisión”, Informe Final de Módulos (R. Andrade Z.), módulos 1–9 (500 kV), 20–36 (220 kV), 40–48 (138 kV), 50–62 (60 kV).',
    'Obras de referencia: LT 500 kV Chilca–Marcona, Campas–Carapongo, Marcona–Montalvo; LT 220 kV Kiman Ayllu, Tintaya–Constancia; LT 138 kV Aguaytía–Pucallpa; LT 60 kV Las Viñas–Nueva Motupe, Chosica, Piura Oeste–Sullana.',
    'Cotizaciones 2025: Wesco Anixter, DFJ, Panghao (conductores/OPGW); JIANGSU Guohua, DAJI, Mega Estructuras (torres); Coinsa (postes). Revista Costos ago-2025; flete MTC Res. 027-91 TC/CRTT.',
    'AACE International RP 18R-97 (Cost Estimate Classification System) y RP 42R-08 (Risk Analysis and Contingency Determination Using Parametric Estimating / Range Estimating). PMI PMBOK® 7 – Estimación de costos y reserva de contingencia.',
    'Plantilla CAPEX Clase 3 (estándar LE2) y procedimiento de estimación de contingencia de CAPEX (método determinístico PERT y análisis de rangos).',
    'Referencias de mercado Perú (pestaña «Referencias Perú»): MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública de inversiones de transmisión, distribución y electrificación rural; OECE – SEACE 3.0, buscador público de procedimientos de selección (obras). Extracción oct-2026; montos llevados a USD 2026 sin IGV.'
  ].map(x=>`<li>${x}</li>`).join('');
}

/* ---------- scenarios ---------- */
function loadScen(){ try{ state.scenarios=JSON.parse(localStorage.getItem('capexlt.scen')||'[]'); }catch(e){ state.scenarios=[]; } }
function saveScen(){ try{ localStorage.setItem('capexlt.scen',JSON.stringify(state.scenarios)); }catch(e){} }
function renderScen(){
  $('#scenList').innerHTML=state.scenarios.map((s,i)=>`<div class="scen"><div><b>${esc(s.name)}</b><div class="tiny">${esc(s.sum)}</div></div><div style="display:flex;gap:4px"><button class="btn sm ghost" data-load="${i}">Cargar</button><button class="btn sm ghost" data-del="${i}" title="Eliminar">✕</button></div></div>`).join('')||'<div class="tiny">Sin escenarios guardados.</div>';
  $$('#scenList [data-load]').forEach(b=>b.onclick=()=>{ applyState(state.scenarios[parseInt(b.dataset.load)].st); toast('Escenario cargado'); });
  $$('#scenList [data-del]').forEach(b=>b.onclick=()=>{ state.scenarios.splice(parseInt(b.dataset.del),1); saveScen(); renderScen(); });
}
function snapshotState(){
  const o={state:{kv:state.kv,zone:state.zone,alt:state.alt,rural:state.rural,struct:state.struct,cond:state.cond,moduleN:state.moduleN,manualModule:state.manualModule}, inputs:{}};
  $$('#side input, #side select').forEach(el=>{ if(el.id&&!el.closest('#projCard')) o.inputs[el.id]=el.value; });
  return o;
}
function applyState(o){
  Object.assign(state,o.state); state.cond={...o.state.cond};
  Object.entries(o.inputs).forEach(([id,v])=>{ const el=document.getElementById(id); if(el) el.value=v; });
  setSeg('#segKv',String(state.kv)); setSeg('#segZone',state.zone); setSeg('#segAlt',state.alt); setSeg('#segRural',state.rural);
  refreshStructOptions(); refreshCondOptions(); refreshModuleSelect(); applyModuleDefaults(byN[state.moduleN],true); recalc();
}

/* ---------- export ---------- */
function directoCSV(){
  const rows=[['Item','Partida','Suministro USD','Obras civiles USD','Montaje EM USD','Total USD','USD/km']];
  ITEMS.forEach(([k,n])=>{ const o=k==='5.0'?{sum:0,civ:0,em:0,tot:R.est}:R.items[k]; rows.push([k,n,o.sum.toFixed(0),o.civ.toFixed(0),o.em.toFixed(0),o.tot.toFixed(0),(o.tot/R.inp.km).toFixed(0)]); });
  [['F','Costo directo contratista',R.F],['G','Distribuibles GG+U',R.G],['','Allowances',R.allowQ+R.allowP],['1','Costo directo',R.directo],['','Gerencia, supervisión y facilidades',R.ind],['','Costo del dueño',R.owner],['','Ingeniería, estudios, EIA y permisos',R.est],['2','Costo indirecto',R.indirecto],['A','Estimado neto',R.A],['3','Escalamiento',R.esc],['4','Provisión por riesgos',R.risk],['B','Estimado base',R.B],['5','Contingencia',R.cont],['C','Costo de ejecución',R.C],['D','Costo de la fase',R.D],['E','Monto total de inversión (sin IGV)',R.E],['','IGV',R.igv],['','Total con IGV',R.ET]].forEach(r=>rows.push([r[0],r[1],'','','',r[2].toFixed(0),(r[2]/R.inp.km).toFixed(0)]));
  return rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
}
async function download(name,content,type){
  try{
    if(window.claude && typeof window.claude.use==='function'){
      const dl=await window.claude.use('downloads');
      if(dl){ try{ await dl.save({filename:name,data:content}); toast('Archivo guardado'); }catch(e){ if(e&&e.code==='declined') toast('Descarga cancelada'); else toast('No se pudo guardar: '+(e&&e.code||'error')); } return; }
      toast('Descarga no disponible en este visor; copia la tabla o usa el archivo .html local'); return;
    }
    const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([content],{type})); a.download=name; document.body.appendChild(a); a.click(); a.remove(); toast('Descarga iniciada');
  }catch(e){ toast('No se pudo descargar'); }
}
async function copyText(t){ try{ await navigator.clipboard.writeText(t); toast('Copiado al portapapeles'); }catch(e){ const ta=document.createElement('textarea'); ta.value=t; document.body.appendChild(ta); ta.select(); try{document.execCommand('copy'); toast('Copiado');}catch(_){toast('Selecciona y copia manualmente');} ta.remove(); } }

/* ---------- recalc ---------- */
let activeTab='exec';
function recalc(){
  const inp=readInputs();
  const M=byN[state.moduleN]||pickModule(inp);
  R=estimate(inp,M);
  const own=!window.APP_MODE||window.APP_MODE==='coes'; // la cabecera es del espacio activo
  if(own){ $('#chipModule').textContent=`Módulo ${M.n} · ${M.code}`;
  $('#chipClass').textContent=CLASSES[inp.cls].name;
  $('#chipDate').textContent=`Precios ${PRICE.year} · TC ${inp.tc}`; const cb=$('#chipBase'); if(cb) cb.textContent='Base COES 09/2026'; }
  $('#extLbl').textContent=(inp.ext>=0?'+':'')+inp.ext+' m';
  $('#contHint').textContent=`Contingencia sugerida para ${CLASSES[inp.cls].name}: ${CLASSES[inp.cls].cont} % (rango de la compañía ${({5:'35–100',4:'25–35',3:'15–25',2:'10–15',1:'5–10'})[inp.cls]} %). Escalamiento y riesgos se aplican sobre el estimado neto (A); la servidumbre está excluida del estimado.`;
  renderResumen(); renderDirecto(); renderObras(); renderApus(); renderRiesgo(); renderBD(); renderBases(); renderCot();
  { const ro=$('#inEscRO'); if(ro) ro.textContent= R.escDet? `${R.escDet.pct.toFixed(2)} %${R.escDet.manual?' (manual)':' (calculado)'}` : pct(inp.esc); if(activeTab==='esc'&&window.ESC) ESC.render($('#escA'),R,'A'); if(activeTab==='refs'&&window.REFS) REFS.render($('#refsA'),{kv:inp.kv,usdKm:R.usdKm,priceYear:PRICE.year}); }
  if(window.V3) V3.update(R);
  if(window.P2) P2.update(R);
  if(window.syncKvBar&&own) syncKvBar(inp.kv);
  if(window.renderInforme) renderInforme('A');
  try{ localStorage.setItem('capexlt.last',JSON.stringify(snapshotState())); }catch(e){}
}

/* ---------- init ---------- */
function init(){
  // segments
  [['#segKv','kv',v=>parseInt(v)],['#segZone','zone',v=>v],['#segAlt','alt',v=>v],['#segRural','rural',v=>v]].forEach(([id,key,cv])=>{
    $$(id+' button').forEach(b=>b.onclick=()=>{ setSeg(id,b.dataset.v); state[key]=cv(b.dataset.v); state.manualModule=false;
      if(key==='zone'&&state.zone!=='Sierra'){ state.alt='<3000'; setSeg('#segAlt','<3000'); }
      if(key==='alt'&&state.alt!=='<3000'&&state.zone!=='Sierra'){ state.zone='Sierra'; setSeg('#segZone','Sierra'); }
      if(key==='kv'){ refreshStructOptions(); refreshModuleSelect(); const M0=byN[state.moduleN]; if(M0&&M0.cond) state.cond={...M0.cond}; refreshCondOptions(); }
      refreshModuleSelect(); applyModuleDefaults(byN[state.moduleN],false); recalc(); }); });
  $$('#segCirc button').forEach(b=>b.onclick=()=>{ const v=b.dataset.v; const opts=structOptions(state.kv); state.struct = v==='DT' ? (opts.includes('DT')?'DT':state.struct) : (opts.find(o=>o!=='DT')||state.struct); state.manualModule=false; refreshStructOptions(); refreshCondOptions(); refreshModuleSelect(); applyModuleDefaults(byN[state.moduleN],false); recalc(); });
  $('#selStruct').onchange=e=>{ state.struct=e.target.value; state.manualModule=false; refreshStructOptions(); refreshCondOptions(); refreshModuleSelect(); applyModuleDefaults(byN[state.moduleN],false); recalc(); };
  $('#selCond').onchange=()=>{ applyCondSel(); state.manualModule=false; refreshModuleSelect(); recalc(); };
  $('#selCG').onchange=()=>{ state.manualModule=false; refreshModuleSelect(); recalc(); };
  $('#selModule').onchange=e=>{ state.moduleN=parseInt(e.target.value); state.manualModule=true; const M=byN[state.moduleN]; $('#modHint').textContent=`${M.zoneTxt||''} · ${STRUCT_LABELS[M.struct]} · ${condLabel(M.cond)} · ${fmt(M.usdkm)} USD/km (COES)`; applyModuleDefaults(M,false); recalc(); };
  $$('#side input').forEach(el=>{ el.addEventListener('input',()=>{ if(el.id==='scenName'||el.closest('#projCard')) return; clearTimeout(el._t); el._t=setTimeout(recalc,120); }); });
  $('#selAccess').onchange=recalc;
  $('#btnReset').onclick=()=>{ if(window.APP_MODE==='osi'){ if(window.osiReset) osiReset(); return; } if(window.APP_MODE==='se'){ if(window.seReset) seReset(); return; } applyModuleDefaults(byN[state.moduleN],false); recalc(); toast('Valores del módulo restablecidos'); };
  $('#btnTheme').onclick=()=>{ const r=document.documentElement; const cur=r.getAttribute('data-theme'); const dark=cur? cur==='dark' : matchMedia('(prefers-color-scheme: dark)').matches; r.setAttribute('data-theme',dark?'light':'dark'); try{localStorage.setItem('capexlt.theme',dark?'light':'dark');}catch(e){} if(window.V3) V3.theme(); };
  try{ const th=localStorage.getItem('capexlt.theme'); if(th) document.documentElement.setAttribute('data-theme',th); }catch(e){}
  // tabs
  $$('#tabs button').forEach(b=>b.onclick=()=>{ $$('#tabs button').forEach(x=>x.classList.toggle('on',x===b)); $$('#p-exec,#p-resumen,#p-directo,#p-metrados,#p-apus,#p-cot,#p-3d,#p-esc,#p-riesgo,#p-bd,#p-refs,#p-bases,#p-informe').forEach(p=>p.classList.toggle('on',p.id==='p-'+b.dataset.t)); activeTab=b.dataset.t; if(window.V3){ if(activeTab==='3d') V3.mount('bimSlotDesign'); else if(activeTab==='resumen') V3.mount('bimSlotResumen'); else if(activeTab==='exec'&&document.getElementById('bimSlotExec')) V3.mount('bimSlotExec'); } if(activeTab==='informe'&&window.renderInforme) renderInforme('A'); if(activeTab==='esc'&&window.ESC) ESC.render($('#escA'),R,'A'); if(activeTab==='refs'&&window.REFS) REFS.render($('#refsA'),{kv:R.inp.kv,usdKm:R.usdKm,priceYear:PRICE.year}); });
  const bp=$('#btnPrint'); if(bp) bp.onclick=()=>window.print();
  $$('[data-goto]').forEach(b=>b.onclick=()=>{ const t=$(`#tabs button[data-t="${b.dataset.goto}"]`); if(t) t.click(); window.scrollTo({top:0,behavior:'smooth'}); });
  if(/^#(exec|resumen|directo|metrados|apus|cot|3d|esc|riesgo|bd|refs|bases|informe)$/.test(location.hash)){ const b=$(`#tabs button[data-t="${location.hash.slice(1)}"]`); if(b) b.click(); }
  // apu
  $('#apuSearch').oninput=()=>renderApus();
  $$('#apuFilter .chip').forEach(c=>c.onclick=()=>{ $$('#apuFilter .chip').forEach(x=>x.classList.toggle('on',x===c)); apuFilter=c.dataset.f; renderApus(); });
  $$('#resRegion .chip').forEach(c=>c.onclick=()=>{ $$('#resRegion .chip').forEach(x=>x.classList.toggle('on',x===c)); resRegion=c.dataset.r; renderRes(); });
  $$('#resType .chip').forEach(c=>c.onclick=()=>{ $$('#resType .chip').forEach(x=>x.classList.toggle('on',x===c)); resType=c.dataset.r; renderRes(); });
  $('#bdSearch').oninput=()=>renderBD();
  // risk
  $('#btnMC').onclick=()=>{ if(!state.riskRanges||state.riskRanges.cls!==R.inp.cls) state.riskRanges={cls:R.inp.cls, r:JSON.parse(JSON.stringify(RISK_DEFAULT[R.inp.cls]))}; const pk=riskPackages(R); const N=parseInt($('#mcN').value); const dist=$('#mcDist')?$('#mcDist').value:'pert'; const mc=monteCarlo(pk,state.riskRanges.r,N,dist); mc.base=pk.reduce((a,p)=>a+p.base,0); state.mc=mc; renderMC(); if(window.PERTMAP) PERTMAP.render($('#pertMap'),'A'); toast(`Simulación de ${N} iteraciones (${dist==='tri'?'triangular':'beta-PERT'}) completada`); };
  $('#mcP').onchange=()=>renderMC();
  // export
  $('#btnCsv').onclick=()=>download('estimado_capex_lt.csv',directoCSV(),'text/csv');
  $('#btnJson').onclick=()=>download('estimado_capex_lt.json',JSON.stringify({proyecto:R.inp,modulo:R.M.code,resultado:{items:R.items,F:R.F,G:R.G,directo:R.directo,gerencia:R.ind,owner:R.owner,estudios:R.est,indirecto:R.indirecto,A:R.A,esc:R.esc,risk:R.risk,B:R.B,cont:R.cont,C:R.C,D:R.D,E:R.E,igv:R.igv,total:R.ET,nStruct:R.nStruct,tons:R.tons,usdKm:R.usdKm,servidumbre:'excluida'},proyecto_programa:PROJ.get(),escalamiento:window.ESC?ESC.export(R):null,precios:PRICE.export(),factores:R.factors},null,1),'application/json');
  $('#btnCopyDirecto').onclick=()=>copyText(directoCSV().replace(/"/g,'').replace(/,/g,'\t'));
  // scenarios
  loadScen(); renderScen();
  $('#btnSaveScen').onclick=()=>{ const name=$('#scenName').value.trim()||`Escenario ${state.scenarios.length+1}`; state.scenarios.push({name,sum:`${R.inp.kv} kV ${R.inp.struct} ${R.inp.zone} · ${R.inp.km} km · E = USD ${fmtK(R.E)} (${fmt(R.usdKm)} USD/km)`,st:snapshotState()}); saveScen(); renderScen(); $('#scenName').value=''; toast('Escenario guardado'); };
  // initial
  refreshStructOptions(); refreshCondOptions(); refreshModuleSelect();
  let restored=false;
  try{ const last=localStorage.getItem('capexlt.last'); if(last){ const o=JSON.parse(last); if(o&&o.state&&byN[o.state.moduleN]){ applyState(o); restored=true; } } }catch(e){}
  if(!restored){ applyModuleDefaults(byN[state.moduleN],false); $('#inKm').value=60; recalc(); }
  if(window.V3) setTimeout(()=>V3.mount(activeTab==='3d'?'bimSlotDesign':activeTab==='exec'&&document.getElementById('bimSlotExec')?'bimSlotExec':'bimSlotResumen'),50);
}

document.addEventListener('DOMContentLoaded', init);
