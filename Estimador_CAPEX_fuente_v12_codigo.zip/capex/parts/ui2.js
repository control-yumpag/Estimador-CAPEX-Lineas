/* ===================== UI 2 · Redes <= 60 kV ===================== */
window.APP_MODE='coes';
let R2=null, oActiveTab='oexec';
const oState={riskRanges:null, mc:null, scenarios:[]};
const OFLAG={vig:'Vigente',rev:'Revisar',ant:'Antigua',nd:'s/fecha',exp:'Experto',curve:'Curva',mix:'BDME + experto'};
const tagF=f=>f?`<span class="tag ${f}" title="Vigencia de la fuente BDME">${OFLAG[f]||f}</span>`:'';

function readOsiInputs(){
  const v=id=>{ const el=$(id); return el? (parseFloat(el.value)||0) : 0; };
  const kv=parseFloat(segVal('#segOKv'))||60;
  return {
    name:$('#pName').value, client:$('#pClient').value, cls:parseInt($('#pClass').value)||3, kv, zone:segVal('#segOZone'), alt:segVal('#segOAlt'), env:segVal('#segOEnv'),
    hasLine:true, hasSet:false, nExt:0,
    terna:segVal('#segOTerna'), mat:$('#oMat').value, condMm2:parseInt($('#oCond').value), condBT:$('#oCondBT').value, btLum:v('#oBtLum'), btAcom:v('#oBtAcom'), guard:$('#oGuard').value, ins:$('#oIns').value,
    km:Math.max(0.1,v('#oKm')), span:Math.max(30,v('#oSpan')), pS:v('#oPS'), pA:v('#oPA'), pT:v('#oPT'), rock:v('#oRock'), access:parseFloat($('#oAccess').value)||1, imp:v('#oImp'),
    servAuto:true, servKm:0,
    ocF:1, impSet:80, landP:0, accessM:0,
    gg:v('#oGG'), ut:v('#oUt'), sup:v('#oSup'), fin:v('#oFin'), eng:v('#oEng'), owner:v('#oOwner'), esc:(window.PROJ&&PROJ.manualPct()!==null? PROJ.manualPct():0), risk:v('#oRisk'), cont:v('#oCont'), phase:v('#oPhase'), igv:v('#oIGV'), tc:v('#oTC')||3.368
  };
}

/* ---------- gráficos adicionales ---------- */
function svgScatter(series, curves, opts={}){
  const w=560,h=250,pl=56,pr=14,pt=14,pb=34;
  const all=series.flatMap(s=>s.pts);
  const xmax=Math.max(...all.map(p=>p.x),opts.xmax||0)*1.05, ymax=Math.max(...all.map(p=>p.y),opts.ymax||0)*1.08;
  const X=v=>pl+v/xmax*(w-pl-pr), Y=v=>pt+(1-v/ymax)*(h-pt-pb);
  let s=`<svg class="chart scatter" viewBox="0 0 ${w} ${h}">`;
  for(let g=0;g<=4;g++){ const yv=ymax*g/4, y=Y(yv); s+=`<line class="grid" x1="${pl}" x2="${w-pr}" y1="${y}" y2="${y}"></line><text x="${pl-6}" y="${y+4}" text-anchor="end" style="font-size:10px">${fmtK(yv)}</text>`; }
  for(let g=0;g<=5;g++){ const xv=xmax*g/5; s+=`<text x="${X(xv)}" y="${h-pb+14}" text-anchor="middle" style="font-size:10px">${fmt(xv,0)}</text>`; }
  s+=`<text x="${(w+pl)/2}" y="${h-4}" text-anchor="middle" style="font-size:10px">MVA</text>`;
  curves.forEach(c=>{ const d=[]; for(let i=0;i<=60;i++){ const x=xmax*i/60; if(x<=0) continue; const y=c.f(x); if(y>ymax||y<=0) continue; d.push((d.length?'L':'M')+X(x).toFixed(1)+','+Y(y).toFixed(1)); } s+=`<path d="${d.join(' ')}" fill="none" stroke="${c.color}" stroke-width="2" stroke-dasharray="${c.dash||''}"><title>${esc(c.label)}</title></path>`; });
  series.forEach(se=>{ se.pts.forEach(p=>{ s+=`<circle cx="${X(p.x)}" cy="${Y(p.y)}" r="${p.r||4}" fill="${se.color}" stroke="${p.stroke||'none'}" stroke-width="1.5"><title>${esc(p.t||'')}</title></circle>`; }); });
  if(opts.mark){ s+=`<circle cx="${X(opts.mark.x)}" cy="${Y(opts.mark.y)}" r="7" fill="none" stroke="var(--accent)" stroke-width="2.5"></circle><text x="${X(opts.mark.x)+10}" y="${Y(opts.mark.y)-8}" style="fill:var(--accent);font-weight:700;font-size:11px">${esc(opts.mark.label)}</text>`; }
  return s+'</svg>';
}


function edtSpecB(R2){ const inp=R2.inp, cls=CLASSES[inp.cls], L=R2.L;
  return {unit:'USD', items:[
    {n:'1',name:'Costo directo',color:'var(--c1)',value:R2.d1,scope:`Suministro de estructuras, conductores, aisladores y puesta a tierra (CIF + aranceles + aduana + fletes); montaje electromecánico y pruebas; obras civiles; gastos generales y utilidad del contratista (${inp.gg} + ${inp.ut} % de montaje + OC) = total general BDME`},
    {n:'2',name:'Costo indirecto',color:'var(--c3)',value:R2.d2,scope:`Supervisión (${inp.sup} %), gastos administrativos (1.35 %) e intereses intercalarios (${inp.fin} %) de la estructura Osinergmin; ingeniería y estudios del dueño (${inp.eng} %) y costo del dueño (${inp.owner} %)`},
    {n:'3',name:'Escalamiento',color:'var(--c5)',value:R2.esc,scope:(window.ESC&&R2.escDet)? ESC.scopeText(R2) : `Variación de precios desde la fecha base (precios ${PRICE.year}) hasta la ventana de ejecución (${inp.esc} % de A)`},
    {n:'4',name:'Provisión por evento de riesgo',color:'var(--c4)',value:R2.risk,scope:`Riesgos identificables uno a uno, con probabilidad e impacto estimables (${inp.risk} % de A)`},
    {n:'5',name:'Contingencia',color:'var(--crit)',value:R2.cont,scope:`Incertidumbre no atribuible a un evento concreto; rango de la ${cls.name} AACE y simulación Monte Carlo (${inp.cont} % de B)`},
    {n:'D',name:'Costo de fase',color:'var(--c7)',value:R2.D,scope:`Estudios de ingeniería de la siguiente etapa (${inp.phase} % de C)`}],
   subs:[{k:'A',name:'Estimado neto',formula:'(1 + 2)',span:2,value:R2.A,color:'#1E3F5F'},{k:'B',name:'Estimado base',formula:'(1 + 2 + 3 + 4)',span:4,value:R2.B,color:'#274F78'},{k:'C',name:'Costo de ejecución',formula:'(1 + 2 + 3 + 4 + 5)',span:5,value:R2.C,color:'#2C5F8A'},{k:'E',name:'CAPEX de proyecto',formula:'(C + D)',span:6,value:R2.E,color:'#1B3654'}],
   note:`A = 1 + 2 · B = A + 3 + 4 · C = B + 5 · E = C + D. Sin IGV; servidumbre excluida. Valor regulatorio Osinergmin de referencia (total general + supervisión + administrativos + financieros): USD ${fmt(R2.reg)}.`}; }
window.edtSpecB=edtSpecB;

/* ---------- renders ---------- */
function oRenderResumen(){
  const inp=R2.inp, cls=CLASSES[inp.cls], L=R2.L, S=R2.S;
  const scope=[L?`${oKvLabel(inp.kv)} ${L.bt?'red secundaria':inp.terna==='M'?'MRT':inp.terna==='D'?'doble terna':'simple terna'}, ${inp.km} km`:null].filter(Boolean).join(' · ');
  $('#oKpis').innerHTML=`
    <div class="card kpi hero"><div class="l">CAPEX de proyecto (E) · USD sin IGV · precios ${PRICE.year}</div><div class="v">${fmt(R2.E)}<small>USD</small></div><div class="d">S/ ${fmt(R2.E*inp.tc)} (TC ${inp.tc}) · con IGV USD ${fmt(R2.ET)}</div></div>
    <div class="card kpi accent"><div class="l">Valor regulatorio Osinergmin, sin IGV</div><div class="v">${fmt(R2.reg)}<small>USD</small></div><div class="d">total general + supervisión + adm. + financieros (sin servidumbre) · con IGV ${fmt(R2.regIgv)}</div></div>
    <div class="card kpi"><div class="l">Costo por kilómetro</div><div class="v">${L?fmt(R2.usdKm):'—'}<small>USD/km</small></div><div class="d">${L?`regulatorio · proyecto ${fmt(R2.usdKmProj)} USD/km · directo ${fmt(L.directo/inp.km)} USD/km`:'línea no incluida'}</div></div>
    <div class="card kpi"><div class="l">Estructuras</div><div class="v">${L?fmt(L.N):'—'}<small>und</small></div><div class="d">${L?`${fmt(L.nKm,2)} por km · vano ${inp.span} m · ${L.cnt.S} S / ${L.cnt.A} A / ${L.cnt.T} T · ${fmt(L.reg/L.N)} USD por estructura`:''}</div></div>`;
  const wn=$('#oWfNote'); if(wn) wn.textContent=`USD sin IGV · precios ${PRICE.year} (cotizaciones actualizadas ×${(L&&L.escF||1).toFixed(3)}) · ejecución ${PROJ.describe()}`;
  $('#oWaterfall').innerHTML=edtFlow(edtSpecB(R2));
  const lo=R2.E*(1+cls.lo[1]/100), lo2=R2.E*(1+cls.lo[0]/100), hi=R2.E*(1+cls.hi[0]/100), hi2=R2.E*(1+cls.hi[1]/100);
  $('#oClassCard').innerHTML=`<div class="badge-class">${cls.name}</div><div class="small muted">${esc(cls.uso)} · definición ${cls.def}</div>
    <div class="range" style="margin-top:12px"><div class="lo">${fmtK(lo)}<br><span class="tiny">${cls.lo[1]} %</span></div><div class="mid">${fmtK(R2.E)}</div><div class="hi">${fmtK(hi2)}<br><span class="tiny">+${cls.hi[1]} %</span></div></div>
    <div class="rangebar"><i style="left:${(lo-lo)/(hi2-lo)*100}%;width:${(hi2-lo)/(hi2-lo)*100}%;opacity:.35"></i><i style="left:${(lo2-lo)/(hi2-lo)*100}%;width:${(hi-lo2)/(hi2-lo)*100}%"></i><b style="left:${(R2.E-lo)/(hi2-lo)*100}%"></b></div>
    <div class="tiny" style="margin-top:10px">Rango probable ${fmtK(lo2)} – ${fmtK(hi)} (${cls.lo[0]} % / +${cls.hi[0]} %); extremos ${cls.lo[1]} % / +${cls.hi[1]} % (AACE 18R-97). ${esc(scope)}.</div>`;
  const parts=[];
  if(L){ parts.push({label:'Estructuras',value:L.parts.estructuras},{label:'Conductor',value:L.parts.conductor},{label:'Guarda, aisladores, PAT y accesorios',value:L.parts.guarda+L.parts.aisladores+L.parts.pat+L.parts.accesorios+(L.parts.otros||0)},{label:'Montaje',value:L.montaje},{label:'Obras civiles',value:L.oc}); }
  parts.push({label:'Aranceles, aduana y fletes',value:R2.aranc+R2.aduana+R2.fletes});
  $('#oDonut').innerHTML=svgDonut(parts,R2.directo)+`<div class="legend">${parts.map((p,i)=>`<span><i style="background:${COLORS[i%COLORS.length]}"></i>${esc(p.label)} ${pct(p.value/R2.directo*100)}</span>`).join('')}</div>`;
  $('#oDonutTot').textContent=`Costo directo USD ${fmt(R2.directo)}`;
  const kvs=[];
  if(L){ kvs.push(['Directo por km',fmt(L.directo/inp.km)+' USD/km'],['Suministro / montaje / OC',`${pct(L.equipos/L.directo*100,0)} / ${pct(L.montaje/L.directo*100,0)} / ${pct(L.oc/L.directo*100,0)}`],['Costo por estructura (todo incluido)',fmt(L.reg/L.N)+' USD'],['Conductor por km'+(inp.terna==='D'?'-terna':''),fmt(L.parts.conductor/inp.km/(inp.terna==='D'?2:1))+' USD'],['Servidumbre','excluida'+(L.servAuto?' (referencia BDME 2026: USD '+fmt(L.servAuto/inp.km)+'/km)':'')],['Marcas / actualización de precios',`${PRICE.brandSummary()} · ×${(L.escF||1).toFixed(3)} promedio a ${PRICE.year}`]); }
  kvs.push(['Indirectos regulatorios / total general',pct((R2.supv+R2.adm+R2.finc)/R2.tg*100)],['Capa de proyecto (ing., dueño, esc., riesgos, contingencia) / regulatorio',pct((R2.E-R2.reg)/R2.reg*100)],['IGV',fmt(R2.igv)+' USD']);
  $('#oRatios').innerHTML=`<dl class="kv">${kvs.map(([k,v])=>`<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
  // benchmark
  if(L&&L.bt){ const refs=[['Referencia red BT rural (mín.)',9000],['Referencia red BT rural (máx.)',16000],['Referencia red BT urbana (mín.)',14000],['Referencia red BT urbana (máx.)',26000]]; const rws=refs.map(([l,v])=>({label:l,value:v,color:'var(--c2)'})); rws.push({label:`Tu red · BT ${inp.env} · CAAI ${inp.condBT}`,value:R2.usdKm,color:'var(--accent)',hi:true}); rws.sort((a,b)=>a.value-b.value); $('#oBenchTitle').textContent='Benchmark de red secundaria BT: USD/km sin IGV'; $('#oBench').innerHTML=svgBars(rws,{w:760,lw:300,rh:22})+'<div class="tiny">Referencias de mercado 2023–2025 de electrificación rural y ampliaciones de redes secundarias (valor regulatorio equivalente, sin IGV, con alumbrado y acometidas).</div>'; return; }
  $('#oBenchTitle').textContent= L&&L.mt? `Benchmark de línea MT ${inp.kv} kV: USD/km sin IGV` : 'Benchmark de línea: USD/km sin IGV vs. los 12 módulos BDME de 60 kV';
  if(L&&L.mt){ const kv=inp.kv; const refs= inp.terna==='M'? [['Referencia MRT rural (mín.)',8000],['Referencia MRT rural (máx.)',14000]] : kv>=20? [['Referencia trifásica 22.9 kV rural (mín.)',18000],['Referencia trifásica 22.9 kV rural (máx.)',30000]] : [['Referencia trifásica 10–13.2 kV (mín.)',15000],['Referencia trifásica 10–13.2 kV (máx.)',26000]];
    const rws=refs.map(([l,v])=>({label:l,value:v,color:'var(--c2)'})); rws.push({label:`Tu línea · ${kv} kV ${inp.terna==='M'?'MRT':'trifásica'} AAAC ${inp.condMm2} mm²`,value:R2.usdKm,color:'var(--accent)',hi:true}); rws.sort((a,b)=>a.value-b.value); $('#oBench').innerHTML=svgBars(rws,{w:760,lw:300,rh:22})+'<div class="tiny">Referencias de mercado 2023–2025 para electrificación rural (valor regulatorio equivalente, sin IGV); las líneas MT no forman parte de la BDME de transmisión.</div>'; return; }
  const rows=OMOD60.map(m=>({label:`${m.code.replace('LT-','')} · ${m.terna==='D'?'DT':'ST'} ${m.condMm2} mm² ${m.zona.split(' ')[0]}${m.altTxt?' '+m.altTxt.split(' ')[0]:''}`,value:m.usdKm-(m.servidumbre||0),color: L&&L.M&&L.M.code===m.code?'var(--blue)':'var(--c2)',hi:L&&L.M&&L.M.code===m.code}));
  if(L){ rows.push({label:`Tu línea · ${inp.kv} kV ${({TA:'torres',PA:'postes acero',PC:'postes concreto',PM:'postes madera'})[inp.mat]} ${inp.terna==='D'?'DT':'ST'} ${inp.condMm2} mm²`,value:R2.usdKm,color:'var(--accent)',hi:true}); }
  rows.sort((a,b)=>a.value-b.value);
  $('#oBench').innerHTML=svgBars(rows,{w:760,lw:300,rh:20});
}

function oRenderLine(){
  const L=R2.L, inp=R2.inp;
  if(!L){ $('#oLineTbl').innerHTML='<div class="note" style="margin:10px">La línea no está incluida en el alcance (activa “Línea de transmisión” en el panel Proyecto).</div>'; $('#oModCard').innerHTML=''; $('#oServCard').innerHTML=''; $('#oLineNote').textContent=''; return; }
  $('#oLineNote').textContent=`${oKvLabel(inp.kv)} · ${L.bt?'red secundaria aérea':L.mt?(inp.terna==='M'?'MRT':'trifásica'):(inp.terna==='D'?'doble':'simple')+' terna'} · ${L.kit?L.kit.label:STRUCT2[inp.mat]} · ${L.bt?'CAAI '+inp.condBT:'AAAC '+inp.condMm2+' mm²'} · ${inp.km} km · vano ${inp.span} m → ${L.N} estructuras (${L.cnt.S} S / ${L.cnt.A} A / ${L.cnt.T} T). ${L.note} Cotizaciones actualizadas a ${PRICE.year} (×${(L.escF||1).toFixed(3)} promedio); escalamiento a la ejecución en el ítem 3.`;
  let h=`<table><thead><tr><th>Partida</th><th>Código BDME</th><th class="n">Cant.</th><th>Und</th><th class="n">P.U. USD</th><th class="n">Suministro</th><th class="n">Montaje</th><th class="n">Obras civiles</th><th class="n">Total</th><th class="n">USD/km</th></tr></thead><tbody>`;
  L.rows.forEach(r=>{ const tot=r.sum+r.mont+r.oc; h+=`<tr><td>${esc(r.k)} ${tagF(r.flag)}${r.note?`<div class="tiny">${esc(r.note)}</div>`:''}</td><td class="num small">${esc(r.code)}</td><td class="n">${fmt(r.qty,r.unit==='km'||r.unit==='km-terna'?1:0)}</td><td>${r.unit}</td><td class="n">${fmt(r.pu)}</td><td class="n">${fmt(r.sum)}</td><td class="n">${fmt(r.mont)}</td><td class="n">${fmt(r.oc)}</td><td class="n"><b>${fmt(tot)}</b></td><td class="n">${fmt(tot/inp.km)}</td></tr>`; });
  const sub=(k,v,cls='sub')=>`<tr class="${cls}"><td colspan="8">${k}</td><td class="n"><b>${fmt(v)}</b></td><td class="n">${fmt(v/inp.km)}</td></tr>`;
  h+=sub('Suministro de equipos y materiales (CIF / ex-fábrica)',L.equipos);
  h+=sub(`Aranceles (${pct(OSI.pct.arancel*100)}) y gastos de aduana (${pct(OSI.pct.aduana*100)}) sobre ${inp.imp} % importado`,L.aranc+L.aduana);
  h+=sub(`Fletes a obra (${pct(L.fletePct*100)} del suministro, zona ${inp.zone}${inp.mat==='PC'?', postes de concreto ×2.2':''})`,L.fletes);
  h+=sub('Montaje electromecánico',L.montaje); h+=sub('Obras civiles (fundaciones, excavación, accesos)',L.oc);
  h+=sub('Costo directo de la línea',L.directo,'tot');
  h+=sub(`GG + utilidad (${inp.gg} % + ${inp.ut} % de montaje + OC)`,L.ggU); h+=sub('Total general',L.tg,'tot');
  h+=sub(`Supervisión ${inp.sup} % · gastos administrativos ${pct(OSI.pct.adminLT*100,2)} · financieros ${inp.fin} %`,L.supv+L.adm+L.finc);
  h+=sub('Valor regulatorio de la línea, sin servidumbre (sin IGV)',L.reg,'tot');
  h+=`<tr><td colspan="10" class="tiny">Ingeniería de detalle informativa según BDME: ${fmt(L.ingInfo)} USD (${fmt(L.ingInfo/inp.km)} USD/km) — en la BDME no se suma al total del módulo (se considera dentro de supervisión / GG); la capa de proyecto la incluye en “ingeniería / estudios del dueño”.</td></tr>`;
  $('#oLineTbl').innerHTML=h+'</tbody></table>';
  const sv=L.servRow;
  if(L.bt){ const K=OSI.btKit; $('#oModTitle').textContent='Kit paramétrico de red secundaria'; $('#oModCard').innerHTML=`<div class="small"><b>Red secundaria ${inp.env} 380/220 V</b><br>${esc(L.kit.label)}</div><dl class="kv" style="margin-top:8px"><dt>Vano promedio recomendado</dt><dd>${K.rules.avg[inp.env]} m (${K.rules.rec[inp.env][0]}–${K.rules.rec[inp.env][1]} m; máx. ${K.rules.max} m)</dd><dt>Altura mínima al terreno</dt><dd>${K.rules.clr} m (CNE)</dd><dt>Conductor</dt><dd>CAAI ${inp.condBT} · ${K.cond[inp.condBT].amp} A aprox.</dd><dt>Alumbrado / acometidas</dt><dd>${inp.btLum} luminarias/km · ${inp.btAcom} acometidas/km</dd><dt>Directo por km</dt><dd>${fmt(L.directo/inp.km)} USD/km</dd></dl><div class="tiny" style="margin-top:6px">${esc(K.nota)}</div>`; $('#oServCard').innerHTML=supuestosHTML('B',inp); return; }
  $('#oModTitle').textContent= L.mt? 'Kit paramétrico de media tensión' : 'Módulo BDME de referencia';
  if(L.mt){ const r=OSI.mtKit.rules[inp.kv>=20?22.9:10]; $('#oModCard').innerHTML=`<div class="small"><b>Línea de media tensión ${inp.kv} kV</b><br>${esc(L.kit.label)}</div><dl class="kv" style="margin-top:8px"><dt>Vano promedio recomendado</dt><dd>${r.avg} m (${r.rec[0]}–${r.rec[1]} m; máx. ${r.max} m)</dd><dt>Altura mínima al terreno</dt><dd>${r.clr} m (CNE)</dd><dt>Conductor</dt><dd>AAAC ${inp.condMm2} mm² · ${OSI.mtKit.cond[inp.condMm2]?OSI.mtKit.cond[inp.condMm2].amp:'—'} A aprox.</dd><dt>Estructuras (DGE RD 018-2003-EM)</dt><dd>PS alineamiento · PA ángulo · PR retención/terminal</dd><dt>Directo por km</dt><dd>${fmt(L.directo/inp.km)} USD/km</dd><dt>Referencia de mercado</dt><dd>${inp.terna==='M'?'MRT 8–14 kUSD/km':'trifásica 22.9 kV 18–30 kUSD/km'} (electrificación rural 2023–2025)</dd></dl><div class="tiny" style="margin-top:6px">${esc(OSI.mtKit.nota)}</div>`;
    $('#oServCard').innerHTML=supuestosHTML('B',inp); return; }
  const M=L.M||pickOsiModule(inp);
  const d=M.decomp||{};
  $('#oModCard').innerHTML=`<div class="small"><b>${esc(M.code)}</b><br>${esc(M.desc)}</div><dl class="kv" style="margin-top:8px">
    <dt>USD/km BDME (sin IGV)</dt><dd><b>${fmt(M.usdKm)}</b> (${fmt(M.usdKmIgv)} con IGV)</dd><dt>Equipos</dt><dd>${fmt(M.equipos)}</dd><dt>Aranceles + aduana + fletes</dt><dd>${fmt(M.aranceles+M.aduanas+M.fletes)}</dd><dt>Montaje</dt><dd>${fmt(M.montaje)}</dd><dt>Obras civiles</dt><dd>${fmt(M.oc)}</dd><dt>Costo directo</dt><dd>${fmt(M.totalDirecto)}</dd><dt>GG + U</dt><dd>${fmt(M.gg+M.util)}</dd><dt>Supervisión / adm. / financ.</dt><dd>${fmt(M.supervision)} / ${fmt(M.admin)} / ${fmt(M.financieros)}</dd><dt>Servidumbre</dt><dd>${fmt(M.servidumbre)}</dd>
    ${d.towerUnit?`<dt>Descomposición paramétrica</dt><dd>${fmt(d.towerUnit)} USD/torre · ${fmt(d.cond)} conductor/km · ${fmt(d.ins)} aisladores/km · montaje ${fmt(d.montTower)}/torre + ${fmt(d.montString)}/km tendido · OC ${fmt(d.ocTower)}/torre</dd>`:''}
    </dl><div class="tiny" style="margin-top:6px">${inp.mat==='TA'?'Módulo base del estimado (torres).':'Módulo de referencia para comparación (la BDME de 60 kV solo valoriza torres de acero; el estimado con postes es bottom-up con precios I-403).'}</div>`;
  $('#oServCard').innerHTML=supuestosHTML('B',inp);
}

function oRenderRiesgo(){
  const inp=R2.inp; const pk=riskPackagesOsi(R2);
  if(!oState.riskRanges||oState.riskRanges.cls!==inp.cls){ oState.riskRanges={cls:inp.cls,r:JSON.parse(JSON.stringify(RISK2_DEFAULT[inp.cls]))}; }
  const rr=oState.riskRanges.r;
  let t=`<table><thead><tr><th>Paquete</th><th class="n">Base USD</th><th class="n">Mín %</th><th class="n">Máx %</th><th class="n">Esperado PERT</th><th class="n">Δ USD</th></tr></thead><tbody>`;
  let sumB=0,sumE=0;
  pk.forEach(p=>{ const r=rr[p.k]||[0,0]; const mn=p.base*(1+r[0]/100), mx=p.base*(1+r[1]/100); const e=(mn+mx+4*p.base)/6; sumB+=p.base; sumE+=e;
    t+=`<tr><td>${esc(p.name)}</td><td class="n">${fmt(p.base)}</td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="0" value="${r[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="1" value="${r[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">${fmt(e)}</td><td class="n">${fmt(e-p.base)}</td></tr>`; });
  const rs=rr.sys||[0,0]; const fSys=(1+rs[0]/100+1+rs[1]/100+4)/6; const sumE2=sumE*fSys;
  t+=`<tr class="sub"><td>${SYS_NAME}</td><td class="n">×</td><td class="n"><input type="number" class="rk" data-k="sys" data-i="0" value="${rs[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="sys" data-i="1" value="${rs[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">×${fSys.toFixed(4)}</td><td class="n">${fmt(sumE2-sumE)}</td></tr>`;
  t+=`<tr class="tot"><td>Estimado base (B)</td><td class="n">${fmt(sumB)}</td><td></td><td></td><td class="n">${fmt(sumE2)}</td><td class="n">${fmt(sumE2-sumB)}</td></tr></tbody></table>`;
  $('#oRiskTbl').innerHTML=t;
  $$('#oRiskTbl input.rk').forEach(i=>i.onchange=()=>{ if(!rr[i.dataset.k]) rr[i.dataset.k]=[0,0]; rr[i.dataset.k][parseInt(i.dataset.i)]=parseFloat(i.value)||0; oRenderRiesgo(); });
  const cDet=(sumE2-sumB)/sumB*100;
  $('#oRiskSum').innerHTML=`<div class="grid g3"><div class="card flat kpi"><div class="l">Contingencia PERT (valor esperado)</div><div class="v" style="font-size:22px">${pct(cDet,2)}</div><div class="d">USD ${fmt(sumE2-sumB)}</div></div><div class="card flat kpi"><div class="l">Contingencia aplicada</div><div class="v" style="font-size:22px">${pct(inp.cont)}</div><div class="d">USD ${fmt(R2.cont)}</div></div><div class="card flat" style="display:grid;align-content:center"><button class="btn sm" id="oBtnUsePert">Usar ${pct(cDet)} como contingencia</button></div></div>`;
  $('#oBtnUsePert').onclick=()=>{ $('#oCont').value=cDet.toFixed(1); oRecalc(); toast('Contingencia actualizada'); };
  oRenderMC();
  if(window.PERTMAP) PERTMAP.render($('#oPertMap'),'B');
}
function oRenderMC(){
  const mc=oState.mc;
  if(!mc){ $('#oMcOut').innerHTML='<div class="tiny">Ejecuta la simulación para obtener P10–P90: cada paquete se muestrea con una distribución beta-PERT (media = esperado PERT de la tabla) o triangular, sin correlación entre paquetes, y el riesgo sistémico multiplica el total.</div>'; $('#oScurve').innerHTML='<div class="tiny">La curva S aparecerá tras la simulación.</div>'; return; }
  const conf=parseInt($('#oMcP').value); const Pc=mc.P(conf); const base=mc.base;
  const stale= Math.abs(base-R2.B)>0.001*Math.max(1,R2.B) ? `<div class="tiny" style="color:var(--warn);margin-bottom:6px">⚠ Simulación desactualizada: se corrió con B = USD ${fmt(base)} y el estimado base actual es USD ${fmt(R2.B)}. Vuelve a ejecutarla.</div>` : '';
  $('#oMcOut').innerHTML=`${stale}<dl class="kv"><dt>Base (B)</dt><dd>${fmt(base)}</dd><dt>Distribución</dt><dd>${mc.dist==='tri'?'triangular':'beta-PERT'} por paquete</dd><dt>Media</dt><dd>${fmt(mc.mean)} (${pct((mc.mean-base)/base*100)})</dd><dt>Desv. estándar</dt><dd>${fmt(mc.sd)} (${pct(mc.sd/base*100)})</dd><dt>P10</dt><dd>${fmt(mc.P(10))}</dd><dt>P50</dt><dd>${fmt(mc.P(50))}</dd><dt>P80</dt><dd>${fmt(mc.P(80))}</dd><dt>P90</dt><dd>${fmt(mc.P(90))}</dd><dt>Contingencia a P${conf}</dt><dd><b>${fmt(Pc-base)} (${pct((Pc-base)/base*100)})</b></dd></dl>${svgHist(mc.s,32,base)}<button class="btn sm" id="oBtnUseMC" style="margin-top:8px">Usar P${conf} como contingencia</button>`;
  $('#oBtnUseMC').onclick=()=>{ $('#oCont').value=((Pc-base)/base*100).toFixed(1); oRecalc(); toast('Contingencia actualizada con P'+conf); };
  const pts=[]; for(let i=0;i<=100;i+=2){ pts.push({x:mc.P(Math.min(99.99,i)),y:i/100}); }
  $('#oScurve').innerHTML=svgLine(pts,{marks:[{x:base,label:'Base'},{x:Pc,label:'P'+conf,color:'var(--good)'}]});
}

let oPrGrp='all', oPrFlag='all';
function oRenderPrecios(){
  const q=($('#oPrSearch').value||'').toLowerCase();
  const rows=OSI.prices.filter(p=>(oPrGrp==='all'||p.g===oPrGrp)&&(oPrFlag==='all'||p.f===oPrFlag)&&(!q||(p.c+' '+p.d).toLowerCase().includes(q)));
  const lim=400;
  $('#oPrCount').textContent=`${rows.length} partidas${rows.length>lim?` (se muestran ${lim}; afina la búsqueda)`:''}`;
  $('#oPrTbl').innerHTML=`<table><thead><tr><th>Código</th><th>Grupo</th><th>Descripción</th><th>Und</th><th class="n">USD</th><th>Vigencia</th><th class="n">Fuentes</th></tr></thead><tbody>${rows.slice(0,lim).map(p=>`<tr><td class="num" style="white-space:nowrap">${p.c}</td><td class="tiny">${p.g}</td><td class="small">${esc(p.d)}</td><td>${esc(p.u)}</td><td class="n">${fmt(p.p,p.p<10?2:0)}</td><td>${tagF(p.f)} ${p.y?`<span class="tiny">${p.y}</span>`:''}</td><td class="n">${p.n??'—'}</td></tr>`).join('')}</tbody></table>`;
}

function oRenderDepur(){
  $('#oDepurTbl').innerHTML=`<table><thead><tr><th>Tema</th><th>Criterio</th><th>Acción en el estimador</th></tr></thead><tbody>${OSI.depur.map(d=>`<tr><td><b>${esc(d.tema)}</b></td><td class="small">${esc(d.crit)}</td><td class="small">${esc(d.accion)}</td></tr>`).join('')}</tbody></table>`;
  const inp=R2.inp, L=R2.L, S=null, cls=CLASSES[inp.cls];
  const li=[
    `<b>Fuente:</b> ${esc(OSI.meta.fuente)}. ${esc(OSI.meta.nota)}`,
    `<b>Método:</b> estimación ${cls.name} (AACE 18R-97) por módulos y precios unitarios BDME depurados. ${L?(L.bt?`Red secundaria BT: bottom-up con ${esc(L.kit.label)}, conductor autoportante CAAI ${inp.condBT}, alumbrado público y acometidas (kit paramétrico de mercado, DGE RD 031-2003-EM).`:L.mt?`Línea MT ${inp.kv} kV ${inp.terna==='M'?'MRT':'trifásica'}: bottom-up con ${esc(L.kit.label)}, conductor AAAC ${inp.condMm2} mm² a 3.38 USD/kg (BDME), estructuras/montaje/OC de mercado (criterio experto).`:inp.mat==='TA'?`Línea con torres: módulo ${L.M.code} descompuesto paramétricamente (torres ${fmt(L.M.decomp.towerUnit)} USD/und a vano ${L.M.decomp.span} m) y ajustado por vano^0.6, peso de conductor^0.35, mezcla de estructuras, suelo (${inp.rock} % roca) y accesos (×${inp.access}).`:`Línea con ${STRUCT2[inp.mat].toLowerCase()}: bottom-up con estructuras compuestas I-403 (${L.kit?esc(L.kit.label):''}), conductor AAAC ${inp.condMm2} mm² a ${fmt(OSI.lineKit.conductors[inp.condMm2].usdKm)} USD/km, montaje y obras civiles por estructura (criterio experto), tendido ${fmt(OSI.lineKit.montaje.stringUsdKmTerna[inp.kv])} USD/km-terna.`):''}`,
    `<b>Estructura de costos:</b> ${esc(OSI.pct.nota)}${L&&(L.mt||L.bt)?' En redes MT/BT la estructura de indirectos de transmisión se aplica por analogía (GG+U sobre montaje y obras civiles, supervisión, gastos administrativos e intereses intercalarios); para el VNR de distribución ajustar los porcentajes en el grupo «Estructura de costos».':''} Sobre el valor regulatorio se añaden ingeniería/estudios del dueño ${pct(inp.eng)}, costo del dueño ${pct(inp.owner)}, escalamiento ${pct(inp.esc)}, provisión por riesgos ${pct(inp.risk)} y contingencia ${pct(inp.cont)} (${cls.name}).`,
    `<b>Servidumbre:</b> excluida del estimado (gestión predial específica del sitio); referencia BDME 2026 ${L&&L.servAuto?fmt(L.servAuto/inp.km)+' USD/km ('+L.servCode+')':'no aplicable'}.`,
    `<b>Precios, marcas y escalamiento:</b> ${PRICE.basesText('B')}`,
    `<b>Precisión esperada:</b> ${cls.lo[0]} … ${cls.lo[1]} % / +${cls.hi[0]} … +${cls.hi[1]} % (AACE 18R-97); contingencia a validar con análisis de rangos (RP 42R-08), pestaña Riesgo.`,
    `<b>Limitaciones:</b> el extracto de la BDME no incluye I-401 (APU de montaje); los ratios de montaje y obras civiles por estructura son de criterio experto y deben calibrarse con el archivo completo. Las redes MT y BT no forman parte de la BDME de transmisión: se valorizan con kits paramétricos de mercado. No se modelan cruces especiales, líneas subterráneas ni obras sociales.`
  ];
  $('#oBasesTxt').innerHTML=li.map(x=>`<p>${x}</p>`).join('');
  $('#oFuentes').innerHTML=[
    'Referencias de mercado Perú (pestaña «Referencias Perú»): MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública de inversiones de transmisión, distribución y electrificación rural; OECE – SEACE 3.0 (obras). Extracción oct-2026; montos llevados a USD 2026 sin IGV.',
    'Osinergmin – GRT: Base de Datos de Módulos Estándares de Inversión para Sistemas de Transmisión (REST_MOD_INV_2025_PP.xlsm): valorización de líneas (62 módulos 60–500 kV), anexos I-402 (precios consolidados), I-403 (precios por partida) e I-404 (fuentes de precios: reportes de aduanas y facturas 2006–2024).',
    'Osinergmin – Costos de servidumbre unitaria de terrenos rústicos 2026 (R.M. 514-2025-EF/15, Reglamento Nacional de Tasaciones; TC 3.368; r = 4.11 %).',
    'Osinergmin – Criterios de cálculo de costos directos e indirectos (feb-2026): GG, utilidad, supervisión, gastos administrativos e intereses intercalarios (BCRP, tasas de interés).',
    'AACE International RP 18R-97 y RP 42R-08; PMI PMBOK® 7. Plantilla CAPEX Clase 3 (LE2).',
    'DGE/MEM: RD 018-2003-EM (Bases para el diseño de líneas y redes primarias) y RD 031-2003-EM (redes secundarias); CNE Suministro 2011.',
    'Índices de escalamiento: LME (aluminio, cobre, zinc), acero (referencias de exportación), CPI-U (BLS) e INEI (materiales de construcción y mano de obra); ver «Precios y marcas».',
    'Criterio experto para montaje y obras civiles por estructura y para los kits MT/BT; valores adoptados donde la BDME presenta datos inconsistentes (ver pestaña Depuración).'
  ].map(x=>`<li>${x}</li>`).join('');
}

/* ---------- hints / coupling ---------- */
function oKvLabel(kv){ return kv<1? 'BT 380/220 V' : kv+' kV'; }
function oSyncUI(){
  const kv=parseFloat(segVal('#segOKv')), zone=segVal('#segOZone'), mat=$('#oMat').value; const bt=kv<1, mt=kv<30&&!bt;
  // circuitos: MRT solo en MT; doble terna solo AT/MT trifásica
  $('#segOTerna button[data-v="M"]').hidden=!mt; $('#segOTerna button[data-v="D"]').hidden=mt||bt; if((mt||bt)&&segVal('#segOTerna')==='D') setSeg('#segOTerna','S'); if(!mt&&segVal('#segOTerna')==='M') setSeg('#segOTerna','S');
  // conductores
  ['35','50','95'].forEach(v=>$(`#oCond option[value="${v}"]`).hidden=!mt); ['150','240','300','400'].forEach(v=>$(`#oCond option[value="${v}"]`).hidden=mt);
  if(mt&&!['35','50','70','95','120'].includes($('#oCond').value)) $('#oCond').value='70'; if(!mt&&!bt&&['35','50','95'].includes($('#oCond').value)) $('#oCond').value=kv===60?'120':'70';
  $('#oCondBox').hidden=bt; $('#oCondBTBox').hidden=!bt; $('#oGuardBox').hidden=bt; $('#oInsBox').hidden=bt||mt; $('#oBtBox').hidden=!bt; $('#oServBox').hidden=bt;
  $('#oGuard').disabled=mt||bt; $('#oIns').disabled=mt||bt;
  // materiales de estructura
  $('#oMat option[value="PA"]').hidden=mt||bt; $('#oMat option[value="TA"]').hidden=mt||bt; if((mt||bt)&&(mat==='PA'||mat==='TA')) $('#oMat').value='PC';
  $('#oMat option[value="PC"]').textContent= bt? 'Postes CAC 8/200 – 9/200 (red secundaria)' : mt? 'Postes CAC 13 m con crucetas (PS/PA/PR)' : 'Postes de concreto';
  $('#oMat option[value="PM"]').textContent= bt? 'Postes de madera tratada 8–9 m' : mt? 'Postes de madera 12 m con crucetas' : 'Postes de madera'+(kv===60?' (selva / costa)':'');
  $('#oLineCnt').textContent= bt? 'red secundaria: postes, conductor autoportante, alumbrado' : 'estructuras, conductor y trazo';
  // altitud según región
  $$('#segOAlt button').forEach(b=>{ const ok= zone==='Sierra' ? b.dataset.v!=='0-1000' : b.dataset.v==='0-1000'; b.disabled=!ok; b.style.opacity=ok?'':'.4'; });
  if(zone!=='Sierra') setSeg('#segOAlt','0-1000'); else if(segVal('#segOAlt')==='0-1000') setSeg('#segOAlt','1000-3000');
  // torres BDME solo 60 kV
  const ta=$('#oMat option[value="TA"]'); ta.disabled=(kv!==60); if(kv!==60&&$('#oMat').value==='TA'){ $('#oMat').value='PC'; }
  const hint=$('#oServHint'); if(hint&&bt) hint.textContent='';
}
function oApplyDefaults(kind){
  const kv=parseFloat(segVal('#segOKv')), mat=$('#oMat').value, terna=segVal('#segOTerna');
  if(kv<1){ const K=OSI.btKit; const env=segVal('#segOEnv'); if(kind!=='terna'){ $('#oSpan').value=K.rules.avg[env]||45; $('#oImp').value=25; } if(kind==='kv'){ $('#oPS').value=70; $('#oPA').value=18; $('#oPT').value=12; $('#oRock').value=10; if($('#oKm').value>10) $('#oKm').value=5; } return; }
  if(kv<30){ const K=OSI.mtKit.structs[mat]||OSI.mtKit.structs.PC; const kk= kv>=20?22.9:10; if(kind!=='terna'){ $('#oSpan').value=K.span[kk]||150; $('#oImp').value=40; } if(kind==='kv'){ $('#oCond').value='70'; $('#oPS').value=75; $('#oPA').value=15; $('#oPT').value=10; } return; }
  if(kind==='mat'||kind==='kv'||kind==='terna'){ const k=OSI.lineKit.structKits[`${kv}|${terna}|${mat}`]||OSI.lineKit.structKits[`${kv}|S|${mat}`]; $('#oSpan').value = mat==='TA' ? OSI.lineKit.spansTA[60] : (k?k.span:200); $('#oImp').value = ({TA:90,PA:75,PC:45,PM:55})[mat]; }
  if(kind==='kv'){ $('#oCond').value = kv===60?'120':'70'; }
}
function oHints(inp){
  const mix=normMix(inp.pS,inp.pA,inp.pT,'S','A','T'); $('#oMixHint').textContent=`Normalizado: ${Math.round(mix.S)} / ${Math.round(mix.A)} / ${Math.round(mix.T)} %. BDME asume ≈ 70 / 20 / 10.`;
  $('#oContHint').textContent=`Contingencia sugerida para ${CLASSES[inp.cls].name}: ${CLASSES[inp.cls].cont} %. Valida con PERT / Monte Carlo en la pestaña Riesgo.`;
}

/* ---------- export ---------- */
function oCSV(){
  const rows=[['Bloque','Partida','Código','Cant.','Und','P.U.','Suministro','Montaje','Obras civiles','Total']];
  if(R2.L) R2.L.rows.forEach(r=>rows.push(['Línea',r.k,r.code,r.qty.toFixed(2),r.unit,r.pu.toFixed(2),r.sum.toFixed(0),r.mont.toFixed(0),r.oc.toFixed(0),(r.sum+r.mont+r.oc).toFixed(0)]));
  [['Costo directo',R2.directo],['GG + utilidad',R2.ggU],['Total general',R2.tg],['Supervisión',R2.supv],['Gastos administrativos',R2.adm],['Intereses intercalarios',R2.finc],['Valor regulatorio Osinergmin sin servidumbre (sin IGV)',R2.reg],['1 Costo directo (total general)',R2.d1],['Ingeniería / estudios del dueño',R2.eng],['Costo del dueño',R2.owner],['2 Costo indirecto',R2.d2],['A Estimado neto',R2.A],['Escalamiento',R2.esc],['Provisión por riesgos',R2.risk],['B Estimado base',R2.B],['Contingencia',R2.cont],['C Costo de ejecución',R2.C],['D Costo de la fase',R2.D],['E CAPEX de proyecto (sin IGV)',R2.E],['IGV',R2.igv],['Total con IGV',R2.ET]].forEach(r=>rows.push(['Resumen',r[0],'','','','','','','',r[1].toFixed(0)]));
  return rows.map(r=>r.map(c=>`"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
}

/* ---------- escenarios ---------- */
function oLoadScen(){ try{ oState.scenarios=JSON.parse(localStorage.getItem('capexlt.oscen')||'[]'); }catch(e){ oState.scenarios=[]; } }
function oSaveScen(){ try{ localStorage.setItem('capexlt.oscen',JSON.stringify(oState.scenarios)); }catch(e){} }
function oSnapshot(){ const o={inputs:{},segs:{}}; $$('#side2 input, #side2 select').forEach(el=>{ if(el.id&&!el.closest('#projCard')) o.inputs[el.id]= el.type==='checkbox'? el.checked : el.value; }); ['#segOKv','#segOZone','#segOAlt','#segOEnv','#segOTerna'].forEach(id=>o.segs[id]=segVal(id)); return o; }
function oApplyState(o){ Object.entries(o.segs||{}).forEach(([id,v])=>{ if(v) setSeg(id,v); }); Object.entries(o.inputs||{}).forEach(([id,v])=>{ const el=document.getElementById(id); if(!el) return; if(el.type==='checkbox') el.checked=!!v; else el.value=v; }); oSyncUI(); oRecalc(); }
function oRenderScen(){
  $('#oScenList').innerHTML=oState.scenarios.map((s,i)=>`<div class="scen"><div><b>${esc(s.name)}</b><div class="tiny">${esc(s.sum)}</div></div><div style="display:flex;gap:4px"><button class="btn sm ghost" data-load="${i}">Cargar</button><button class="btn sm ghost" data-del="${i}" title="Eliminar">✕</button></div></div>`).join('')||'<div class="tiny">Sin escenarios guardados.</div>';
  $$('#oScenList [data-load]').forEach(b=>b.onclick=()=>{ oApplyState(oState.scenarios[parseInt(b.dataset.load)].st); toast('Escenario cargado'); });
  $$('#oScenList [data-del]').forEach(b=>b.onclick=()=>{ oState.scenarios.splice(parseInt(b.dataset.del),1); oSaveScen(); oRenderScen(); });
}
function osiReset(){ try{ localStorage.removeItem('capexlt.olast'); }catch(e){} oApplyState(OSI_DEFAULT_STATE); toast('Valores por defecto restablecidos'); }
let OSI_DEFAULT_STATE=null;

/* ---------- modo y nivel de tensión ---------- */
const LEVELS={BT:[0.38],MT:[10,13.2,22.9,33],AT:[60,138,220],EAT:[500]};
function levelOf(kv){ return kv<1?'BT':kv<35?'MT':kv<300?'AT':'EAT'; }
function kvTxt(v){ return v<1? '380/220 V' : v+' kV'; }
function isSE(){ return !!(window.PROJ&&PROJ.state&&PROJ.state.obra==='se'); }
function renderKvBar(kv){
  const se=isSE(); const level=levelOf(kv); $$('#segLevel button').forEach(b=>{ b.classList.toggle('on',b.dataset.l===level); const dis= se&&(b.dataset.l==='BT'||b.dataset.l==='MT'); b.disabled=dis; b.classList.toggle('dim',dis); });
  const bar=$('#segKvAll'); if(!bar) return; const vals= se? LEVELS[level].filter(v=>v>=60) : LEVELS[level]; bar.innerHTML=vals.map(v=>`<button data-v="${v}" class="${v===kv?'on':''}">${kvTxt(v)}</button>`).join('');
  $$('#segKvAll button').forEach(b=>b.onclick=()=>selectKv(parseFloat(b.dataset.v)));
  const ch=$('#chipLevel'); if(ch) ch.textContent=`${se?'SE':level} · ${kvTxt(kv)}`; const et=$('#engineTag'); if(et) et.textContent= se? 'motor COES subestaciones (60–500 kV)' : kv>=100? 'motor COES (≥ 138 kV)' : 'motor Osinergmin BDME (≤ 60 kV)';
}
function currentKv(){ return window.APP_MODE==='se' ? (window.sState? sState.kv : 220) : window.APP_MODE==='osi' ? (parseFloat(segVal('#segOKv'))||60) : (typeof state!=='undefined'? state.kv : 220); }
function selectKv(kv){
  if(isSE()){ if(kv<60) kv=220; setMode('se',true); if(window.sState){ const changed=sState.kv!==kv; sState.kv=kv; if(changed&&typeof sApplyKvDefaults==='function') sApplyKvDefaults(kv); if(typeof sSyncUI==='function') sSyncUI(); } if(typeof sRecalc==='function') sRecalc(); renderKvBar(kv); return; }
  window.__lastLineKv=kv; try{ localStorage.setItem('capexlt.linekv',String(kv)); }catch(e){}
  if(kv>=100){ setMode('coes',true); const b=$(`#segKv button[data-v="${kv}"]`); if(b&&!b.classList.contains('on')) b.click(); else if(typeof recalc==='function') recalc(); }
  else { setMode('osi',true); const b=$(`#segOKv button[data-v="${kv}"]`); if(b&&!b.classList.contains('on')) b.click(); else oRecalc(); }
  renderKvBar(kv);
}
window.syncKvBar=function(kv){ renderKvBar(kv); };
function setMode(m,silent){
  window.APP_MODE=m; if(window.PROJ) PROJ.mount(m); const bm=$('#brandMark'); if(bm) bm.textContent= m==='se'?'SE':'LT';
  const lay1=$('.layout:not(#layoutOsi):not(#layoutSe)'), lay2=$('#layoutOsi'), lay3=$('#layoutSe');
  [lay1,lay2,lay3].forEach(l=>{ if(l) l.setAttribute('hidden',''); });
  if(m==='osi'){ lay2.removeAttribute('hidden'); if(window.V3){ V3.ctl.sil='auto'; V3.syncSil(); V3.ctl.type=$('#bType')?$('#bType').value:'S'; V3.mount('bimSlotB'); } if(!silent) oRecalc(); }
  else if(m==='se'){ if(lay3) lay3.removeAttribute('hidden'); if(!silent&&typeof sRecalc==='function') sRecalc(); }
  else { lay1.removeAttribute('hidden'); if(window.V3){ V3.ctl.sil='auto'; V3.syncSil(); V3.ctl.type=$('#v3Type')?$('#v3Type').value:'S'; V3.mount(typeof activeTab!=='undefined'&&activeTab==='3d'?'bimSlotDesign':(typeof activeTab!=='undefined'&&activeTab==='exec'&&document.getElementById('bimSlotExec'))?'bimSlotExec':'bimSlotResumen'); } if(!silent&&typeof recalc==='function'&&R) recalc(); }
  try{ localStorage.setItem('capexlt.mode',m); }catch(e){}
}

/* ---------- BIM del espacio B: especificación de estructura desde la línea ---------- */
function oBimSpec(){
  const inp=R2.inp, L=R2.L; const row=$('#oBimRow'); if(!L){ if(row) row.setAttribute('hidden',''); return null; } if(row) row.removeAttribute('hidden');
  const mat=inp.mat||'PC'; const mrt=inp.terna==='M'; const circ= inp.terna==='D'?'DT':'ST';
  const bt=inp.kv<1; const sil= bt? 'bt' : mat==='TA' ? 'celosia' : mat==='PA' ? 'mono' : 'poste';
  const nGuard= (L.mt||L.bt||!inp.guard||inp.guard==='none'||inp.guard==='0') ? 0 : 1;
  const label= bt ? `Red BT 380/220 V · ${L.kit.label} · CAAI ${inp.condBT}` : L.mt ? `${inp.kv} kV · ${L.kit.label} · ${mrt?'MRT':'trifásica'} · AAAC ${inp.condMm2} mm²` : `${inp.kv} kV ${circ==='DT'?'doble':'simple'} terna · ${({TA:'torres de celosía',PA:'postes de acero',PC:'postes de concreto',PM:'postes de madera'})[mat]||mat} · AAAC ${inp.condMm2} mm²`;
  const ton= L.M&&L.M.decomp&&L.M.decomp.tonTower ? L.M.decomp.tonTower : 0;
  return {kv:inp.kv,circ,ext:0,span:inp.span,mm2:inp.condMm2,zone:inp.zone,sil,mat,mrt,bt,lum:inp.btLum>0,acom:inp.btAcom>0,nGuard,label,nStruct:L.N,nKm:L.nKm,ton,costStruct:L.parts.estructuras+(L.rows.filter(r=>/Estructuras|Torres/.test(r.k)).reduce((a,r)=>a+r.mont+r.oc,0))};
}
/* ---------- recalc ---------- */
function oRecalc(){
  const inp=readOsiInputs();
  R2=estimateOsi(inp);
  oHints(inp);
  if(window.V3){ const sp=oBimSpec(); if(sp){ if(window.APP_MODE==='osi') V3.updateSpec(sp); else V3._specB=sp; } }
  if(window.APP_MODE==='osi'){
    $('#chipModule').textContent = R2.L&&R2.L.M ? `BDME ${R2.L.M.code.replace('LT-','')}` : R2.L&&R2.L.bt ? 'Kit BT (RD 031-2003-EM)' : R2.L&&R2.L.mt ? 'Kit MT (RD 018-2003-EM)' : 'BDME ≤ 60 kV';
    $('#chipClass').textContent=CLASSES[inp.cls].name; $('#chipDate').textContent=`Precios ${PRICE.year} · TC ${inp.tc}`; const cb=$('#chipBase'); if(cb) cb.textContent='Base Osinergmin BDME 2025';
    if(window.syncKvBar) syncKvBar(inp.kv);
  }
  oRenderResumen(); oRenderLine(); oRenderRiesgo(); oRenderDepur(); if(window.renderInforme) renderInforme('B');
  { const ro=$('#oEscRO'); if(ro) ro.textContent= R2.escDet? `${R2.escDet.pct.toFixed(2)} %${R2.escDet.manual?' (manual)':' (calculado)'}` : inp.esc+' %'; if(typeof oActiveTab!=='undefined'&&oActiveTab==='oesc'&&window.ESC) ESC.render($('#escB'),R2,'B'); if(typeof oActiveTab!=='undefined'&&oActiveTab==='orefs') oRenderRefs(); }
  try{ localStorage.setItem('capexlt.olast',JSON.stringify(oSnapshot())); }catch(e){}
}

/* ---------- init ---------- */
function oInit(){
  OSI_DEFAULT_STATE=oSnapshot();
  $$('#segLevel button').forEach(b=>b.onclick=()=>{ if(b.disabled) return; const L=LEVELS[b.dataset.l]; selectKv(b.dataset.l==='AT'?220:b.dataset.l==='MT'?22.9:L[0]); });
  [['#segOKv','kv'],['#segOZone','zone'],['#segOAlt','alt'],['#segOEnv','env'],['#segOTerna','terna']].forEach(([id,k])=>{
    $$(id+' button').forEach(b=>b.onclick=()=>{ if(b.disabled) return; setSeg(id,b.dataset.v); if(k==='kv'||k==='terna'||(k==='env'&&parseFloat(segVal('#segOKv'))<1)) oApplyDefaults(k); oSyncUI(); oRecalc(); }); });
  $('#oMat').onchange=()=>{ oApplyDefaults('mat'); oSyncUI(); oRecalc(); };
  ['#oCond','#oCondBT','#oGuard','#oIns','#oAccess'].forEach(id=>$(id).onchange=oRecalc);
  ['#oServAuto'].forEach(id=>$(id).onchange=()=>{ oSyncUI(); oRecalc(); });
  $$('#side2 input[type=number], #side2 input[type=text]').forEach(el=>el.addEventListener('input',()=>{ if(el.id==='oScenName'||el.closest('#projCard')) return; clearTimeout(el._t); el._t=setTimeout(oRecalc,120); }));
  $$('#tabs2 button').forEach(b=>b.onclick=()=>{ $$('#tabs2 button').forEach(x=>x.classList.toggle('on',x===b)); $$('.panel2').forEach(p=>p.classList.toggle('on',p.id==='p-'+b.dataset.t)); oActiveTab=b.dataset.t; if(oActiveTab==='oprecios') oRenderPrecios(); if(oActiveTab==='oinforme'&&window.renderInforme) renderInforme('B'); if(oActiveTab==='oesc'&&window.ESC) ESC.render($('#escB'),R2,'B'); if(oActiveTab==='orefs') oRenderRefs(); });
  const bp=$('#oBtnPrint'); if(bp) bp.onclick=()=>window.print();
  $('#oPrSearch').oninput=oRenderPrecios;
  $$('#oPrGrp .chip').forEach(c=>c.onclick=()=>{ $$('#oPrGrp .chip').forEach(x=>x.classList.toggle('on',x===c)); oPrGrp=c.dataset.g; oRenderPrecios(); });
  $$('#oPrFlag .chip').forEach(c=>c.onclick=()=>{ $$('#oPrFlag .chip').forEach(x=>x.classList.toggle('on',x===c)); oPrFlag=c.dataset.f; oRenderPrecios(); });
  $('#oBtnMC').onclick=()=>{ if(!oState.riskRanges||oState.riskRanges.cls!==R2.inp.cls) oState.riskRanges={cls:R2.inp.cls,r:JSON.parse(JSON.stringify(RISK2_DEFAULT[R2.inp.cls]))}; const pk=riskPackagesOsi(R2); const N=parseInt($('#oMcN').value); const dist=$('#oMcDist')?$('#oMcDist').value:'pert'; const mc=monteCarlo(pk,oState.riskRanges.r,N,dist); mc.base=pk.reduce((a,p)=>a+p.base,0); oState.mc=mc; oRenderMC(); if(window.PERTMAP) PERTMAP.render($('#oPertMap'),'B'); toast(`Simulación de ${N} iteraciones (${dist==='tri'?'triangular':'beta-PERT'}) completada`); };
  $('#oMcP').onchange=oRenderMC;
  $('#oBtnCsv').onclick=()=>download('estimado_capex_redes.csv',oCSV(),'text/csv');
  $('#oBtnJson').onclick=()=>download('estimado_capex_redes.json',JSON.stringify({proyecto:R2.inp,proyecto_programa:PROJ.get(),escalamiento:window.ESC?ESC.export(R2):null,precios:PRICE.export(),linea:R2.L?{rows:R2.L.rows,directo:R2.L.directo,reg:R2.L.reg,N:R2.L.N,serv:R2.L.serv,modulo:R2.L.M&&R2.L.M.code}:null,resumen:{directo:R2.directo,ggU:R2.ggU,tg:R2.tg,supv:R2.supv,adm:R2.adm,finc:R2.finc,serv:R2.serv,land:R2.land,regulatorio:R2.reg,eng:R2.eng,owner:R2.owner,A:R2.A,esc:R2.esc,risk:R2.risk,B:R2.B,cont:R2.cont,C:R2.C,E:R2.E,igv:R2.igv,total:R2.ET,usdKm:R2.usdKm}},null,1),'application/json');
  oLoadScen(); oRenderScen();
  $('#oBtnSaveScen').onclick=()=>{ const name=$('#oScenName').value.trim()||`Escenario ${oState.scenarios.length+1}`; oState.scenarios.push({name,sum:`${oKvLabel(R2.inp.kv)} · ${R2.inp.km} km · E = USD ${fmtK(R2.E)} (${fmt(R2.usdKm)} USD/km)`,st:oSnapshot()}); oSaveScen(); oRenderScen(); $('#oScenName').value=''; toast('Escenario guardado'); };
  oSyncUI();
  let restored=false; try{ const last=localStorage.getItem('capexlt.olast'); if(last){ oApplyState(JSON.parse(last)); restored=true; } }catch(e){}
  if(!restored) oRecalc();
  let mode='coes'; try{ mode=localStorage.getItem('capexlt.mode')||'coes'; }catch(e){}
  if(location.hash==='#osi') mode='osi'; if(location.hash==='#coes') mode='coes'; if(location.hash==='#se') mode='se';
  if(window.PROJ&&PROJ.state&&PROJ.state.obra==='se') mode='se';
  if(mode==='osi') setMode('osi'); else if(mode==='se'){ if(window.PROJ) PROJ.state.obra='se'; if(typeof sInit==='function') sInit(); setMode('se',true); renderKvBar(window.sState?sState.kv:220); }
}
document.addEventListener('DOMContentLoaded', oInit);

function oRenderRefs(){ if(!window.REFS||!R2||!R2.L) return; REFS.render($('#refsB'),{kv:R2.inp.kv,usdKm:R2.usdKmProj||R2.usdKm,priceYear:PRICE.year}); }
