/* ===================== UI 3 · Subestaciones (módulos COES SE + complementos BDME) ===================== */
let R3=null, sActiveTab='sexec';
const sState={kv:220, riskRanges:null, mc:null};
const SE_SEC={60:[22.9,10],138:[60,22.9,10],220:[138,60,22.9],500:[220]};
const SE_TYPE_SHORT={'Celda de línea':'Línea','Celda de transformación':'Transformación','Celda de acople':'Acople','Celda reactor de barra':'Reactor de barra','Celda de medición de barras':'Medición de barras','Celda reactor de línea':'Reactor de línea','Transformador':'Transformador trifásico','Banco de transformadores':'Banco monofásico','Reactor':'Reactor'};

function readSeInputs(){
  const v=id=>{ const el=$(id); return el? (parseFloat(el.value)||0) : 0; };
  const kv=sState.kv; const cfgOpts=SE_CFGS[kv]||['DB']; let cfg=$('#sCfg').value; if(!cfgOpts.includes(cfg)) cfg=cfgOpts[cfgOpts.length-1];
  return {
    name:$('#pName').value, client:$('#pClient').value, cls:parseInt($('#pClass').value)||3, kv, zone:segVal('#segSZone')||'Sierra', tech:segVal('#segSTech')||'AIS', cfg, ka: kv===220? (parseFloat($('#sKa').value)||40) : null,
    nueva: segVal('#segSNueva')!=='0',
    nL:v('#sNL'), nT:v('#sNT'), nA:v('#sNA'), nRB:v('#sNRB'), nMB: kv===500? v('#sNMB'):0, nRL: kv===500? v('#sNRL'):0,
    nTr:v('#sNTr'), mva:Math.max(1,v('#sMva')), trKind:$('#sTrKind').value, sec:parseFloat($('#sSec').value)||null, wind:2, impSet:80,
    nRx:v('#sNRx'), mvar:Math.max(1,v('#sMvar')), nMT:v('#sNMT'), mtKv:parseFloat($('#sMtKv').value)||22.9,
    areaAuto: segVal('#segSArea')!=='0', area:Math.max(500,v('#sArea')), hCut:v('#sHCut'), hFill:v('#sHFill'), cerco:$('#sCerco').value, viasPct:v('#sVias'), canalMl:v('#sCanal'), accesoM:v('#sAcceso'), edifM2:v('#sEdif'), caseta:$('#sCaseta').value==='1', landUsd:v('#sLandUsd'), landFactor:Math.max(1,v('#sLandF')||1.3),
    gg:v('#sGG'), allowQ:v('#sAllowQ'), allowP:v('#sAllowP'), ind:v('#sInd'), owner:v('#sOwner'), eng:v('#sEng'), esc:(window.PROJ&&PROJ.manualPct()!==null? PROJ.manualPct():0), risk:v('#sRisk'), cont:v('#sCont'), phase:v('#sPhase'), igv:v('#sIGV'), tc:v('#sTC')||3.479
  };
}

/* ---------- sincronización de controles ---------- */
function sSyncUI(){
  const kv=sState.kv; const sel=$('#sCfg'); const cur=sel.value; const opts=SE_CFGS[kv]||['DB'];
  sel.innerHTML=opts.map(k=>`<option value="${k}">${SE_CFG_LABEL[k]}</option>`).join(''); sel.value= opts.includes(cur)? cur : opts[opts.length-1];
  $('#sKaBox').hidden= kv!==220; $('#s500Box').hidden= kv!==500; const na=$('#sNA'); na.disabled= kv===500; if(kv===500) na.value='0'; else if(na.value==='0'&&na.dataset.prev) na.value=na.dataset.prev; na.closest('.field').title= kv===500? 'En interruptor y medio no hay celda de acople':'';
  const ss=$('#sSec'); const curS=ss.value; const secs=SE_SEC[kv]||[22.9]; ss.innerHTML=secs.map(s=>`<option value="${s}">${s} kV</option>`).join(''); ss.value= secs.map(String).includes(curS)? curS : String(secs[0]);
  const tk=$('#sTrKind'); const bankOpt=tk.querySelector('option[value=bank]'); bankOpt.disabled=!(kv===220||kv===500); if(bankOpt.disabled&&tk.value==='bank') tk.value='3f'; if(kv===500) tk.value='bank';
  const auto=segVal('#segSArea')!=='0'; $('#sArea').disabled=auto;
  const nueva=segVal('#segSNueva')!=='0'; $('#grpSCom').hidden=!nueva;
  $('#sCfgHint').innerHTML= kv===500? 'En 500 kV los módulos COES son de interruptor y medio: cada celda de línea o transformación ocupa 2/3 de diámetro (dos interruptores) o 1/3 (un interruptor, cuando comparte diámetro).' : kv===220? 'Doble barra con seccionador de transferencia (DT) y niveles de 31.5 / 40 / 63 kA según módulos COES; simple barra y doble barra en AIS y GIS.' : 'Simple o doble barra en AIS y GIS según módulos COES de '+kv+' kV.';
  const tr=$('#sTrHint'); tr.innerHTML= kv===60? 'Sin módulos COES de transformador de 60 kV: se usa el valor BDME Osinergmin (TPD-060) escalado por MVA, con montaje y obras civiles paramétricos.' : kv===138? 'Módulo COES: transformador trifásico 138 kV de 50 MVA (escalado por MVA^0.55 para otras potencias).' : kv===220? 'Módulos COES: trifásico 220 kV de 50 y 100 MVA; bancos monofásicos 220/138 kV (3×28.3, 3×40, 3×50, 3×100 MVA) y 220/60 kV (3×28.3, 3×40). La potencia se indica por unidad (banco = 3 × monofásico).' : 'Módulos COES: bancos de autotransformadores monofásicos 500/220 kV de 200 y 250 MVA por unidad (3 unidades por banco).';
}
function sKvLabel(kv){ return kv+' kV'; }

/* ---------- EDT ---------- */
function edtSpecC(R){ const inp=R.inp, cls=CLASSES[inp.cls];
  return {unit:'USD', items:[
    {n:'1',name:'Costo directo',color:'var(--c1)',value:R.directo,scope:`Módulos COES de celdas, transformadores y reactores (suministro CIF + aranceles + aduana + flete a obra, obras civiles de bases, montaje, inspección y pruebas) + obras comunes de la subestación (plataforma, cerco, vías, canaletas, malla, edificio) + GG&U ${inp.gg} % sobre obras + allowances ${inp.allowQ} % y ${inp.allowP} %`},
    {n:'2',name:'Costo indirecto',color:'var(--c3)',value:R.indirecto,scope:`Expediente técnico, ingeniería de detalle, EO, concesión (COES 5.0) y permisos ambientales, CIRA y PMA (COES 6.0) de cada módulo${inp.eng?` + ${inp.eng} % adicional`:''}; gerencia y supervisión de construcción ${inp.ind} % del directo; costo del dueño ${inp.owner} %`},
    {n:'3',name:'Escalamiento',color:'var(--c5)',value:R.esc,scope:(window.ESC&&R.escDet)? ESC.scopeText(R) : `Variación de precios desde la fecha base hasta la ejecución (${inp.esc} % de A)`},
    {n:'4',name:'Provisión por evento de riesgo',color:'var(--c4)',value:R.risk,scope:`Riesgos identificables con probabilidad e impacto estimables (${inp.risk} % de A)`},
    {n:'5',name:'Contingencia',color:'var(--crit)',value:R.cont,scope:`Incertidumbre no atribuible a un evento concreto; rango de la ${cls.name} AACE y simulación Monte Carlo (${inp.cont} % de B)`},
    {n:'D',name:'Costo de fase',color:'var(--c7)',value:R.D,scope:`Estudios de ingeniería de la siguiente etapa (${inp.phase} % de C)`}],
   subs:[{k:'A',name:'Estimado neto',formula:'(1 + 2)',span:2,value:R.A,color:'#1E3F5F'},{k:'B',name:'Estimado base',formula:'(1 + 2 + 3 + 4)',span:4,value:R.B,color:'#274F78'},{k:'C',name:'Costo de ejecución',formula:'(1 + 2 + 3 + 4 + 5)',span:5,value:R.C,color:'#2C5F8A'},{k:'E',name:'CAPEX de proyecto',formula:'(C + D)',span:6,value:R.E,color:'#1B3654'}],
   note:`A = 1 + 2 · B = A + 3 + 4 · C = B + 5 · E = C + D. Sin IGV; terreno excluido (referencia USD ${fmt(R.land)}). Suma de módulos COES seleccionados (con 5.0 y 6.0): USD ${fmt(R.coesEq)}.`}; }
window.edtSpecC=edtSpecC;

/* ---------- renders ---------- */
function sRenderResumen(){
  const R=R3, inp=R.inp, cls=CLASSES[inp.cls];
  const nCells=R.nBays; const trTxt= inp.nTr>0? `${inp.nTr} × ${inp.mva} MVA` : 'sin transformación';
  $('#sKpis').innerHTML=`
    <div class="card kpi hero"><div class="l">CAPEX de proyecto (E) · USD sin IGV · precios ${PRICE.year}</div><div class="v">${fmt(R.E)}<small>USD</small></div><div class="d">S/ ${fmt(R.E*inp.tc)} (TC ${inp.tc}) · con IGV USD ${fmt(R.ET)}</div></div>
    <div class="card kpi accent"><div class="l">Suma de módulos COES seleccionados</div><div class="v">${fmt(R.coesEq)}<small>USD</small></div><div class="d">${nCells} celdas · ${trTxt}${inp.nRx?` · ${inp.nRx} reactor(es) de ${inp.mvar} MVAr`:''} · con 5.0 ingeniería y 6.0 permisos</div></div>
    <div class="card kpi"><div class="l">Costo por celda (E)</div><div class="v">${nCells?fmt(R.usdBay):'—'}<small>USD/celda</small></div><div class="d">${nCells?`directo ${fmt(R.directBay)} USD/celda · obras comunes ${fmt(R.com.tot)} USD`:'sin celdas'}</div></div>
    <div class="card kpi"><div class="l">Costo por MVA instalado (E)</div><div class="v">${R.mvaTot?fmt(R.usdMva):'—'}<small>USD/MVA</small></div><div class="d">${R.mvaTot?`${fmt(R.mvaTot)} MVA en ${inp.nTr} unidad(es) · transformación ${fmt(R.rows.filter(r=>r.key==='TR').reduce((a,r)=>a+r.tot,0))} USD`:'sin transformadores'}</div></div>`;
  const wn=$('#sWfNote'); if(wn) wn.textContent=`USD sin IGV · precios ${PRICE.year} (cotizaciones COES mar-2026 actualizadas ×${R.escF.toFixed(3)}) · ejecución ${PROJ.describe()}`;
  $('#sWaterfall').innerHTML=edtFlow(edtSpecC(R));
  $('#sClassCard').innerHTML=`<div class="big">${cls.name}</div><div class="small">${esc(cls.uso)} · definición ${cls.def}</div><div class="tiny" style="margin-top:6px">Precisión esperada (AACE 18R-97): ${cls.lo[1]} … ${cls.lo[0]} % / +${cls.hi[0]} … +${cls.hi[1]} %</div><div class="small" style="margin-top:8px">Rango de E: USD ${fmt(R.E*(1+cls.lo[1]/100))} – ${fmt(R.E*(1+cls.hi[1]/100))}</div>`;
  const parts=[['Equipos de patio y celdas',R.rows.filter(r=>!/^(TR|RX|MT)$/.test(r.key)).reduce((a,r)=>a+r.sup,0),'var(--c1)'],['Transformadores y reactores',R.rows.filter(r=>/^(TR|RX)$/.test(r.key)).reduce((a,r)=>a+r.sup,0),'var(--c3)'],['Celdas MT',R.rows.filter(r=>r.key==='MT').reduce((a,r)=>a+r.sup,0),'var(--c8)'],['Obras civiles de módulos',R.rows.reduce((a,r)=>a+r.oc,0),'var(--c4)'],['Obras comunes',R.com.tot,'var(--c6)'],['Montaje, inspección y pruebas',R.sumEm+R.sumPP,'var(--c2)'],['GG&U y allowances',R.G+R.allowQ+R.allowP,'var(--c7)']].filter(p=>p[1]>0).map(p=>({label:p[0],value:p[1],color:p[2]}));
  $('#sDonutTot').textContent=`costo directo USD ${fmt(R.directo)}`; $('#sDonut').innerHTML=svgDonut(parts,R.directo);
  const ratios=[['Celdas AT/EAT',`${nCells} (${inp.nL} L · ${inp.nT} T · ${inp.nA} A${inp.nRB?' · '+inp.nRB+' RB':''}${inp.nMB?' · '+inp.nMB+' MB':''}${inp.nRL?' · '+inp.nRL+' RL':''})`],['Suministro de equipos',`${fmt(R.sumSup)} USD (${pct(R.sumSup/R.directo*100,0)} del directo)`],['Obras civiles (módulos + comunes)',`${fmt(R.sumOc)} USD`],['Montaje + pruebas',`${fmt(R.sumEm+R.sumPP)} USD`],['Ingeniería y permisos (COES 5.0 + 6.0)',`${fmt(R.est)} USD`],['Área de plataforma',inp.nueva?`${fmt(R.com.area)} m² (${inp.areaAuto?'automática':'manual'}) · terreno ref. ${fmt(R.land)} USD`:'ampliación (sin obras comunes)'],['Peso de equipos (módulos)',`${fmt(R.rows.reduce((a,r)=>a+(r.mod?r.mod.ton*r.n:0),0),1)} t`]];
  $('#sRatios').innerHTML=`<dl class="kv">${ratios.map(r=>`<dt>${r[0]}</dt><dd>${r[1]}</dd>`).join('')}</dl>`;
  // benchmark por celda
  const kv=inp.kv; const cells=SE_MODS.filter(m=>m.kv===kv&&/^Celda/.test(m.type));
  const byType={}; cells.forEach(m=>{ const k=`${SE_TYPE_SHORT[m.type]} ${m.tech}`; (byType[k]=byType[k]||[]).push(m.tot); });
  const rows=Object.entries(byType).map(([k,v])=>({label:`COES ${k} (${v.length} mód., promedio)`,value:v.reduce((a,b)=>a+b,0)/v.length,color:'var(--c2)'}));
  const bd= typeof OSI!=='undefined'? ( kv===60? (OSI.setKit.bay60? {label:'BDME bahía 60 kV AIS (solo equipos)',v:OSI.setKit.bay60.items.reduce((a,i)=>a+i.price,0)+(OSI.setKit.bay60.barras||0)} : null) : (OSI.atKit[String(kv)]&&OSI.atKit[String(kv)].bay? {label:`BDME bahía ${kv} kV AIS (solo equipos)`,v:OSI.atKit[String(kv)].bay.items.reduce((a,i)=>a+i.price,0)+(OSI.atKit[String(kv)].bay.barras||0)} : null) ) : null;
  if(bd&&bd.v>0) rows.push({label:bd.label,value:bd.v,color:'var(--c5)'});
  if(nCells) rows.push({label:'★ Tu subestación · módulos COES por celda (promedio, precios actualizados)',value:R.rows.filter(r=>/^(L|T|A|RB|MB|RL)$/.test(r.key)).reduce((a,r)=>a+r.tot,0)/nCells,color:'var(--accent)',hi:true});
  rows.sort((a,b)=>b.value-a.value);
  $('#sBench').innerHTML=svgBars(rows,{rh:18,lw:330,w:760});
  const rb=$('#sRefBench'); if(rb) rb.innerHTML= window.REFSE? REFSE.benchHTML(sRefCtx()) : '<div class="tiny muted">Módulo de referencias no disponible.</div>';
}
function sRefCtx(){ return {kv:R3.inp.kv,E:R3.E,mva:R3.mvaTot,nueva:R3.inp.nueva}; }
function sRenderRefs(){ if(window.REFSE&&R3) REFSE.render($('#refsC'),sRefCtx()); }
function sRenderCeldas(){
  const R=R3; let h=`<table><thead><tr><th>Partida</th><th>Módulo COES</th><th class="n">Cant.</th><th class="n">Suministro</th><th class="n">Obras civiles</th><th class="n">Montaje</th><th class="n">3.0 + 4.0</th><th class="n">5.0 + 6.0</th><th class="n">Total USD</th><th class="n">Factor</th></tr></thead><tbody>`;
  R.rows.forEach(r=>{ h+=`<tr><td><b>${esc(r.label)}</b>${r.note?`<div class="tiny muted">${esc(r.note)}</div>`:''}</td><td class="num">${r.mod?`${esc(r.mod.code)}<div class="tiny muted">${esc(r.mod.t.slice(0,80))}</div>`:'BDME'}</td><td class="n">${r.n}</td><td class="n">${fmt(r.sup)}</td><td class="n">${fmt(r.oc)}</td><td class="n">${fmt(r.em)}</td><td class="n">${fmt(r.insp+r.prueb)}</td><td class="n">${fmt(r.est+r.perm)}</td><td class="n"><b>${fmt(r.tot)}</b></td><td class="n">${(r.pf||1).toFixed(3)}${r.f&&r.f!==1?` · ×${r.f.toFixed(3)} MVA`:''}</td></tr>`; });
  h+=`<tr class="tot"><td>Módulos</td><td></td><td class="n">${R.nBays}</td><td class="n">${fmt(R.sumSup)}</td><td class="n">${fmt(R.rows.reduce((a,r)=>a+r.oc,0))}</td><td class="n">${fmt(R.sumEm)}</td><td class="n">${fmt(R.sumPP)}</td><td class="n">${fmt(R.estMod)}</td><td class="n">${fmt(R.coesEq)}</td><td></td></tr></tbody></table>`;
  if(R.missing.length) h+=`<div class="err" style="margin-top:8px">Sin módulo en la base para: ${esc(R.missing.join(', '))}.</div>`;
  $('#sRowsTbl').innerHTML=h;
  const sel=$('#sEqSel'); const mods=R.rows.filter(r=>r.mod); const cur=sel.value; sel.innerHTML=mods.map(r=>`<option value="${r.mod.id}">${esc(r.mod.code)} · ${esc(r.label.slice(0,40))}</option>`).join(''); if(mods.some(r=>r.mod.id===cur)) sel.value=cur;
  sRenderEq();
}
function sRenderEq(){ const id=$('#sEqSel').value; const m=SE_BY_ID[id]; if(!m){ $('#sEqTbl').innerHTML='<div class="tiny">Sin módulo seleccionado.</div>'; return; }
  let h=`<table><thead><tr><th>Ítem</th><th>Equipo / material</th><th>Und</th><th class="n">Cant.</th><th class="n">t/und</th><th class="n">USD/und</th><th class="n">USD</th></tr></thead><tbody>`;
  m.sup.forEach(s=>{ h+=`<tr><td class="num">${esc(s[0])}</td><td>${esc(s[1])}</td><td>${esc(s[2]||'')}</td><td class="n">${fmt(s[3],s[3]%1?2:0)}</td><td class="n">${s[4]!=null?fmt(s[4],2):''}</td><td class="n">${fmt(s[5],2)}</td><td class="n">${fmt((s[3]||0)*(s[5]||0))}</td></tr>`; });
  h+=`</tbody></table><div class="tiny muted" style="margin-top:6px">${esc(m.t)} · total COES del módulo USD ${fmt(m.tot)} · peso de equipos ${fmt(m.ton,1)} t · obras civiles ${fmt((m.it['1.1']||[0,0])[1]+(m.it['1.2']||[0,0])[1])} USD</div>`;
  $('#sEqTbl').innerHTML=h; }
function sRenderComunes(){
  const R=R3; const c=R.com;
  if(!R.inp.nueva){ $('#sComTbl').innerHTML='<div class="tiny">Ampliación: las obras comunes no se incluyen (se asume subestación existente con plataforma, cerco, edificio y servicios auxiliares).</div>'; $('#sComNote').textContent=''; }
  else { let h=`<table><thead><tr><th>Partida</th><th>Und</th><th class="n">Cantidad</th><th class="n">Precio unit.</th><th class="n">USD</th><th>Criterio</th></tr></thead><tbody>`;
    c.rows.forEach(r=>{ h+=`<tr><td>${esc(r.name)}</td><td>${esc(r.u)}</td><td class="n">${fmt(r.q,r.q<10?2:0)}</td><td class="n">${fmt(r.pu,2)}</td><td class="n">${fmt(r.tot)}</td><td class="tiny muted">${esc(r.note||'')}</td></tr>`; });
    h+=`<tr class="tot"><td>Obras comunes</td><td></td><td></td><td></td><td class="n">${fmt(c.tot)}</td><td class="tiny">área ${fmt(c.area)} m² · perímetro ${fmt(c.per)} m</td></tr></tbody></table>`;
    $('#sComTbl').innerHTML=h; $('#sComNote').textContent=`USD sin IGV · precios COES marzo 2026 actualizados a ${PRICE.year} · terreno de referencia ${fmt(R.land)} USD (${fmt(c.area*R.inp.landFactor)} m² × ${R.inp.landUsd} USD/m²), excluido`; }
  const C=SE_COM; const blocks=[['Plataforma (movimiento de tierras)',C.plataforma],['Capa de ripio del patio',C.ripio],['Camino de acceso y pavimentos',C.acceso],['Cerco perimétrico',C.cerco],['Canaletas y buzones',C.canaletas],['Vías internas',C.vias],['Malla de puesta a tierra (montaje)',C.pat],['Edificio de control',C.edificio],['Caseta de campo',C.caseta],['Instalaciones eléctricas',C.inst]];
  let g=`<table><thead><tr><th>Bloque</th><th>Partida</th><th>Und</th><th class="n">Cant. ref.</th><th class="n">USD/und</th><th class="n">USD ref.</th></tr></thead><tbody>`;
  blocks.forEach(([n,b])=>{ (b.items||[]).forEach((it,i)=>{ g+=`<tr>${i===0?`<td rowspan="${b.items.length}"><b>${esc(n)}</b><div class="tiny muted">USD ${fmt(b.tot)}</div></td>`:''}<td>${esc(it.d)}</td><td>${esc(it.u||'')}</td><td class="n">${fmt(it.q,it.q<10?2:0)}</td><td class="n">${fmt(it.pu,2)}</td><td class="n">${fmt(it.tot)}</td></tr>`; }); });
  $('#sComRef').innerHTML=g+'</tbody></table>';
}
function sRenderRiesgo(){
  const inp=R3.inp; const pk=riskPackagesSe(R3);
  if(!sState.riskRanges||sState.riskRanges.cls!==inp.cls){ sState.riskRanges={cls:inp.cls,r:JSON.parse(JSON.stringify(RISK3_DEFAULT[inp.cls]))}; }
  const rr=sState.riskRanges.r;
  let t=`<table><thead><tr><th>Paquete</th><th class="n">Base USD</th><th class="n">Mín %</th><th class="n">Máx %</th><th class="n">Esperado PERT</th><th class="n">Δ USD</th></tr></thead><tbody>`;
  let sumB=0,sumE=0;
  pk.forEach(p=>{ const r=rr[p.k]||[0,0]; const mn=p.base*(1+r[0]/100), mx=p.base*(1+r[1]/100); const e=(mn+mx+4*p.base)/6; sumB+=p.base; sumE+=e;
    t+=`<tr><td>${esc(p.name)}</td><td class="n">${fmt(p.base)}</td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="0" value="${r[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="${p.k}" data-i="1" value="${r[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">${fmt(e)}</td><td class="n">${fmt(e-p.base)}</td></tr>`; });
  const rs=rr.sys||[0,0]; const fSys=(1+rs[0]/100+1+rs[1]/100+4)/6; const sumE2=sumE*fSys;
  t+=`<tr class="sub"><td>${SYS_NAME}</td><td class="n">×</td><td class="n"><input type="number" class="rk" data-k="sys" data-i="0" value="${rs[0]}" step="1" style="width:64px;text-align:right"></td><td class="n"><input type="number" class="rk" data-k="sys" data-i="1" value="${rs[1]}" step="1" style="width:64px;text-align:right"></td><td class="n">×${fSys.toFixed(4)}</td><td class="n">${fmt(sumE2-sumE)}</td></tr>`;
  t+=`<tr class="tot"><td>Estimado base (B)</td><td class="n">${fmt(sumB)}</td><td></td><td></td><td class="n">${fmt(sumE2)}</td><td class="n">${fmt(sumE2-sumB)}</td></tr></tbody></table>`;
  $('#sRiskTbl').innerHTML=t;
  $$('#sRiskTbl input.rk').forEach(i=>i.onchange=()=>{ if(!rr[i.dataset.k]) rr[i.dataset.k]=[0,0]; rr[i.dataset.k][parseInt(i.dataset.i)]=parseFloat(i.value)||0; sRenderRiesgo(); });
  const cDet=(sumE2-sumB)/sumB*100;
  $('#sRiskSum').innerHTML=`<div class="grid g3"><div class="card flat kpi"><div class="l">Contingencia PERT (valor esperado)</div><div class="v" style="font-size:22px">${pct(cDet,2)}</div><div class="d">USD ${fmt(sumE2-sumB)}</div></div><div class="card flat kpi"><div class="l">Contingencia aplicada</div><div class="v" style="font-size:22px">${pct(inp.cont)}</div><div class="d">USD ${fmt(R3.cont)}</div></div><div class="card flat" style="display:grid;align-content:center"><button class="btn sm" id="sBtnUsePert">Usar ${pct(cDet)} como contingencia</button></div></div>`;
  $('#sBtnUsePert').onclick=()=>{ $('#sCont').value=cDet.toFixed(1); sRecalc(); toast('Contingencia actualizada'); };
  sRenderMC();
  if(window.PERTMAP) PERTMAP.render($('#sPertMap'),'C');
}
function sRenderMC(){
  const mc=sState.mc;
  if(!mc){ $('#sMcOut').innerHTML='<div class="tiny">Ejecuta la simulación para obtener P10–P90: cada paquete se muestrea con una distribución beta-PERT (media = esperado PERT de la tabla) o triangular, sin correlación entre paquetes, y el riesgo sistémico multiplica el total.</div>'; $('#sScurve').innerHTML='<div class="tiny">La curva S aparecerá tras la simulación.</div>'; return; }
  const conf=parseInt($('#sMcP').value); const Pc=mc.P(conf); const base=mc.base;
  const stale= Math.abs(base-R3.B)>0.001*Math.max(1,R3.B) ? `<div class="tiny" style="color:var(--warn);margin-bottom:6px">⚠ Simulación desactualizada: se corrió con B = USD ${fmt(base)} y el estimado base actual es USD ${fmt(R3.B)}. Vuelve a ejecutarla.</div>` : '';
  $('#sMcOut').innerHTML=`${stale}<dl class="kv"><dt>Base (B)</dt><dd>${fmt(base)}</dd><dt>Distribución</dt><dd>${mc.dist==='tri'?'triangular':'beta-PERT'} por paquete</dd><dt>Media</dt><dd>${fmt(mc.mean)} (${pct((mc.mean-base)/base*100)})</dd><dt>Desv. estándar</dt><dd>${fmt(mc.sd)} (${pct(mc.sd/base*100)})</dd><dt>P10</dt><dd>${fmt(mc.P(10))}</dd><dt>P50</dt><dd>${fmt(mc.P(50))}</dd><dt>P80</dt><dd>${fmt(mc.P(80))}</dd><dt>P90</dt><dd>${fmt(mc.P(90))}</dd><dt>Contingencia a P${conf}</dt><dd><b>${fmt(Pc-base)} (${pct((Pc-base)/base*100)})</b></dd></dl>
    ${svgHist(mc.s,32,base)}<button class="btn sm" id="sBtnUseMC" style="margin-top:8px">Usar P${conf} como contingencia</button>`;
  $('#sBtnUseMC').onclick=()=>{ $('#sCont').value=((Pc-base)/base*100).toFixed(1); sRecalc(); toast('Contingencia actualizada con P'+conf); };
  const pts=[]; for(let i=0;i<=100;i+=2){ pts.push({x:mc.P(Math.min(99.99,i)),y:i/100}); }
  $('#sScurve').innerHTML=svgLine(pts,{marks:[{x:base,label:'Base'},{x:Pc,label:'P'+conf,color:'var(--good)'}]})+`<div class="tiny">Curva acumulada del estimado base B con incertidumbre por paquete. Contingencia recomendada = P${conf} − B.</div>`;
}
let sBaseSel=null;
function sRenderBase(){
  const q=($('#sBaseSearch').value||'').toLowerCase(); const fk=$('#sBaseKv').value, ft=$('#sBaseTech').value, fy=$('#sBaseType').value, fz=$('#sBaseZone').value;
  const list=SE_MODS.filter(m=>(!fk||String(m.kv)===fk)&&(!ft||m.tech===ft)&&(!fy||m.type===fy)&&(!fz||m.zone===fz)&&(!q||`${m.n} ${m.code} ${m.t}`.toLowerCase().includes(q)));
  $('#sBaseCount').textContent=`${list.length} de ${SE_MODS.length} módulos`;
  let h=`<table><thead><tr><th>N°</th><th>Código</th><th>Módulo</th><th class="n">kV</th><th>Tec.</th><th>Región</th><th>Config.</th><th class="n">kA / MVA / MVAr</th><th class="n">Suministro</th><th class="n">OC</th><th class="n">Montaje</th><th class="n">Total USD</th></tr></thead><tbody>`;
  list.forEach(m=>{ const sup=Object.entries(m.it).filter(([k])=>/^2\./.test(k)&&!/^2\.[123]$/.test(k)).reduce((a,[k,v])=>a+(v[0]||0),0); const oc=(m.it['1.1']||[0,0])[1]+(m.it['1.2']||[0,0])[1]; const em=Object.entries(m.it).filter(([k])=>/^2\./.test(k)).reduce((a,[k,v])=>a+(v[2]||0),0);
    const cap= m.ka? m.ka+' kA' : m.bank? '3×'+m.bank+' MVA' : m.mva? m.mva+' MVA' : m.mvar? m.mvar+' MVAr' : '';
    h+=`<tr class="click ${sBaseSel===m.id?'sel':''}" data-id="${m.id}"><td class="num">${m.n}</td><td class="num" style="white-space:nowrap">${esc(m.code)}</td><td>${esc(SE_TYPE_SHORT[m.type]||m.type)}</td><td class="n">${m.kv}${m.sec?'/'+m.sec:''}</td><td>${m.tech}</td><td>${m.zone}</td><td class="small">${esc(m.cfg?SE_CFG_LABEL[seCfgKey(m.cfg)]||m.cfg:'—')}</td><td class="n">${cap}</td><td class="n">${fmt(sup)}</td><td class="n">${fmt(oc)}</td><td class="n">${fmt(em)}</td><td class="n"><b>${fmt(m.tot)}</b></td></tr>`; });
  $('#sBaseTbl').innerHTML=h+'</tbody></table>';
  $$('#sBaseTbl tr.click').forEach(tr=>tr.onclick=()=>{ sBaseSel=tr.dataset.id; sRenderBase(); sRenderBaseDesc(); });
  if(!sBaseSel&&list.length){ sBaseSel=list[0].id; sRenderBaseDesc(); }
}
function sRenderBaseDesc(){ const m=SE_BY_ID[sBaseSel]; if(!m) return; $('#sBaseDescTitle').textContent=`Módulo ${m.n} · ${m.code}`;
  let h=`<p class="small"><b>${esc(m.t)}</b> · ${m.kv} kV ${m.tech} · ${m.zone} · total COES USD ${fmt(m.tot)}${m.tcols?` (suministro ${fmt(m.tcols[0])} · OC ${fmt(m.tcols[1])} · montaje ${fmt(m.tcols[2])})`:''}</p>`;
  h+=`<div class="tbl-wrap"><table><thead><tr><th>Ítem</th><th>Descripción</th><th class="n">Suministro</th><th class="n">Obras civiles</th><th class="n">Montaje</th><th class="n">Total</th></tr></thead><tbody>${Object.entries(m.it).map(([k,v])=>`<tr class="${/^\d\.0$/.test(k)?'sub':''}"><td class="num">${k}</td><td>${esc(v[4])}</td><td class="n">${v[0]!=null?fmt(v[0]):''}</td><td class="n">${v[1]!=null?fmt(v[1]):''}</td><td class="n">${v[2]!=null?fmt(v[2]):''}</td><td class="n">${v[3]!=null?fmt(v[3]):''}</td></tr>`).join('')}</tbody></table></div>`;
  h+=`<h4 style="margin:10px 0 4px">Equipos principales</h4><div class="tbl-wrap"><table><thead><tr><th>Ítem</th><th>Equipo</th><th>Und</th><th class="n">Cant.</th><th class="n">t/und</th><th class="n">USD/und</th></tr></thead><tbody>${m.sup.map(s=>`<tr><td class="num">${esc(s[0])}</td><td>${esc(s[1])}</td><td>${esc(s[2]||'')}</td><td class="n">${fmt(s[3],s[3]%1?2:0)}</td><td class="n">${s[4]!=null?fmt(s[4],2):''}</td><td class="n">${fmt(s[5],2)}</td></tr>`).join('')}</tbody></table></div>`;
  $('#sBaseDesc').innerHTML=h; }
function sSupuestos(inp){ return [
  ['Alcance físico',`Subestación ${inp.kv} kV ${inp.tech} (${SE_CFG_LABEL[inp.cfg]||inp.cfg}), ${inp.nueva?'nueva con obras comunes':'ampliación en subestación existente'}; celdas y equipos como módulos COES completos.`,'COES módulos de subestaciones 2025/26'],
  ['Base de precios','Módulos COES de marzo 2026 (TC 3.479), suministros CIF + aranceles + aduana + flete a obra; obras APU sin GG/U; actualización a la fecha base por grupo de costo (índices del estimador).','COES; «Precios y marcas»'],
  ['Servicios auxiliares por celda','Cada módulo COES incluye tableros de SS.AA. 380/220 Vac y 125 Vcc, rectificador y banco de baterías: en subestaciones con varias celdas esto sobreestima los SS.AA. comunes (≈ 55 kUSD por celda adicional); ajustar con un allowance negativo si se requiere.','Módulos COES, ítem 2.3.1'],
  ['Transformadores',inp.kv===60?'Valor BDME Osinergmin (TPD-060) escalado por MVA^0.55; montaje 12 000 + 350 USD/MVA; obras civiles 18 000 + 600 USD/MVA.':'Módulo COES más cercano en MVA; interpolación log-lineal entre módulos vecinos o exponente 0.55 fuera del rango; se escalan el equipo, su montaje y el transporte.','COES T1/T3; Osinergmin BDME'],
  ['Obras comunes','Cantidades paramétricas (área automática por kV, tecnología, celdas y transformadores) con precios unitarios de los bloques 4.x de los módulos COES; cerco de malla ≈ 22 % del muro.','Juicio de experto'],
  ['GG&U',`${inp.gg} % sobre obras civiles, montaje y pruebas (APU COES sin gastos generales ni utilidad); suministros a precio de mercado.`,'Práctica de licitaciones LE2'],
  ['Allowances',`Cantidades ${inp.allowQ} % y precios ${inp.allowP} % sobre F + G.`,'AACE 34R-05'],
  ['Costo indirecto',`Ingeniería y permisos según ítems 5.0 y 6.0 de cada módulo${inp.eng?` + ${inp.eng} %`:''}; gerencia y supervisión ${inp.ind} % del directo; costo del dueño ${inp.owner} %.`,'COES 5.0 / 6.0; juicio de experto'],
  ['Escalamiento','Calculado por grupo de costo desde la fecha base hasta el programa de ejecución (pestaña Escalamiento).','Índices LME / CPI-U / INEI o CRU'],
  ['Provisión por riesgos',`${inp.risk} % de A.`,'AACE 42R-08'],
  ['Contingencia',`${inp.cont} % de B, dentro del rango de la ${CLASSES[inp.cls].name}; validar con PERT / Monte Carlo (pestaña Riesgo).`,'AACE 18R-97'],
  ['Costo de la fase',`${inp.phase} % de C.`,'FEL 2–3'],
  ['Terreno','Excluido del estimado; se muestra como referencia (área × factor × USD/m²).','Partida del dueño'],
  ['Referencias de mercado Perú','Inversiones Invierte.pe y obras SEACE de la misma tensión (solo subestación) como contraste del orden de magnitud, en USD/MVA a precios 2026 sin IGV; no alimentan el estimado. Sus montos incluyen IGV, supervisión, expediente y, en Invierte.pe, otros componentes del proyecto: comparar con E y validar la ficha.','MEF Invierte.pe; OECE SEACE'],
  ['Exclusiones','Líneas de llegada, telecomunicaciones de red (fibra, SCADA central), compensación serie/SVC, reubicaciones, gestión social, IGV.','—']]; }
function sRenderBases(){
  const R=R3, inp=R.inp;
  const li=[`<b>Método:</b> estimación por módulos COES (AACE 18R-97, ${CLASSES[inp.cls].name}): cada celda, transformador o reactor toma el módulo más cercano de la base (tensión, tecnología, tipo, región, configuración de barras y nivel de cortocircuito) y se multiplica por la cantidad; los transformadores y reactores se escalan por potencia. Las obras comunes se cuantifican paramétricamente con precios unitarios COES.`,
    `<b>Módulos usados:</b> ${R.rows.filter(r=>r.mod).map(r=>`${esc(r.mod.code)} (${r.n} × USD ${fmt(r.mod.tot)})`).join(', ')||'—'}${R.rows.some(r=>!r.mod)?'; complementos BDME Osinergmin: '+R.rows.filter(r=>!r.mod).map(r=>esc(r.label)).join(', '):''}.`,
    `<b>Estructura del estimado (LE2):</b> F = suministro + obras civiles + montaje + inspección y pruebas + obras comunes; G = ${pct(inp.gg)} sobre obras; allowances ${pct(inp.allowQ)} + ${pct(inp.allowP)}; 1 = F + G + allowances; 2 = ingeniería y permisos (COES 5.0 + 6.0 = USD ${fmt(R.estMod)}) + gerencia ${pct(inp.ind)} + dueño ${pct(inp.owner)}; A = 1 + 2; 3 escalamiento ${R.escDet?R.escDet.pct.toFixed(2)+' %':pct(inp.esc)} de A; 4 riesgos ${pct(inp.risk)} de A; B = A + 3 + 4; 5 contingencia ${pct(inp.cont)} de B; C = B + 5; D = ${pct(inp.phase)} de C; E = C + D.`,
    `<b>Precisión esperada:</b> ${CLASSES[inp.cls].lo[0]} … ${CLASSES[inp.cls].lo[1]} % / +${CLASSES[inp.cls].hi[0]} … +${CLASSES[inp.cls].hi[1]} % (AACE 18R-97).`,
    `<b>Limitaciones:</b> herramienta paramétrica de prefactibilidad/factibilidad; no reemplaza el diseño de la subestación (disposición, número de diámetros, celdas de reserva), estudio de suelos, estudios eléctricos ni cotizaciones firmes de transformadores y GIS.`];
  $('#sBasesTxt').innerHTML=li.map(x=>`<p>${x}</p>`).join('');
  $('#sSupuestos').innerHTML=`<table class="tbl small"><thead><tr><th>Supuesto</th><th>Criterio adoptado</th><th>Referencia</th></tr></thead><tbody>${sSupuestos(inp).map(r=>`<tr><td><b>${esc(r[0])}</b></td><td>${esc(r[1])}</td><td class="tiny muted">${esc(r[2])}</td></tr>`).join('')}</tbody></table>`;
  $('#sFuentes').innerHTML=['COES – Desarrollo de “Base de Datos de Costos de Sistemas de Transmisión” 2025/26, Módulos de Subestaciones: celdas AIS y GIS de 60, 138, 220 y 500 kV (línea, transformación, acople, reactor de barra y de línea, medición de barras), transformadores trifásicos, bancos monofásicos y reactores; 318 módulos, precios marzo 2026.','Osinergmin – Base de Datos de Módulos Estándares de Inversión (BDME) 2025: transformadores de potencia 60/33 kV, celdas MT, kits de bahía 60–500 kV (benchmark).','Cotizaciones 2025/26 de las bases COES (interruptores, seccionadores, TC/TT, pararrayos, GIS, transformadores) y Revista Costos.','AACE International RP 18R-97, 34R-05 y 42R-08; PMI PMBOK® 7.','Plantilla CAPEX Clase 3 (estándar LE2) y procedimiento de contingencia (PERT y análisis de rangos).','MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública: inversiones de subestaciones de transmisión y subtransmisión ≥ 33 kV (nuevas, ampliaciones, mejoras, IOARR), costo actualizado o monto viable con IGV.','OECE – SEACE 3.0, buscador público de procedimientos de selección: obras de subestaciones ≥ 33 kV 2014–2026 (valor referencial con IGV; reconvocatorias agrupadas).'].map(x=>`<li>${x}</li>`).join('');
}

/* ---------- recalc ---------- */
function sRecalc(){
  if(!$('#layoutSe')) return;
  const inp=readSeInputs(); R3=estimateSe(inp);
  if(window.APP_MODE==='se'){ const bm=$('#brandMark'); if(bm) bm.textContent='SE';
    $('#chipModule').textContent=`COES SE · ${inp.kv} kV ${inp.tech}`; $('#chipClass').textContent=CLASSES[inp.cls].name; $('#chipDate').textContent=`Precios ${PRICE.year} · TC ${inp.tc}`; const cb=$('#chipBase'); if(cb) cb.textContent='Base COES módulos SE mar-2026';
    if(window.syncKvBar) syncKvBar(inp.kv);
  }
  $('#sSetCnt').textContent=`${inp.kv} kV ${inp.tech} · ${SE_CFG_LABEL[inp.cfg]||inp.cfg} · ${inp.zone}`; $('#sCellCnt').textContent=`${R3.nBays} celdas`; $('#sTrCnt').textContent= inp.nTr? `${inp.nTr} × ${inp.mva} MVA` : 'sin transformación'; $('#sComCnt').textContent= inp.nueva? `USD ${fmtK(R3.com.tot)}` : 'ampliación';
  sRenderResumen(); sRenderCeldas(); sRenderComunes(); sRenderRiesgo(); sRenderBases(); if(window.renderInforme) renderInforme('C');
  { const ro=$('#sEscRO'); if(ro) ro.textContent= R3.escDet? `${R3.escDet.pct.toFixed(2)} %${R3.escDet.manual?' (manual)':' (calculado)'}` : inp.esc+' %'; if(sActiveTab==='sesc'&&window.ESC) ESC.render($('#escC'),R3,'C'); if(sActiveTab==='srefs') sRenderRefs(); }
  try{ localStorage.setItem('capexlt.slast',JSON.stringify(sSnapshot())); }catch(e){}
}
function sSnapshot(){ const o={inputs:{},segs:{},kv:sState.kv}; $$('#side3 input, #side3 select, #side3 textarea').forEach(el=>{ if(el.id&&!el.closest('#projCard')) o.inputs[el.id]= el.type==='checkbox'? el.checked : el.value; }); ['#segSTech','#segSZone','#segSNueva','#segSArea'].forEach(id=>{ o.segs[id]=segVal(id); }); return o; }
function sApplyState(o){ if(!o) return; if(o.kv) sState.kv=o.kv; Object.entries(o.segs||{}).forEach(([id,v])=>{ if(v) setSeg(id,v); }); sSyncUI(); Object.entries(o.inputs||{}).forEach(([id,v])=>{ const el=document.getElementById(id); if(!el) return; if(el.type==='checkbox') el.checked=!!v; else el.value=v; }); }

/* ---------- init ---------- */
function sInit(){
  if(!$('#layoutSe')||window.__seInit) return; window.__seInit=true;
  const SE_DEFAULT_STATE=sSnapshot();
  window.seReset=()=>{ try{ localStorage.removeItem('capexlt.slast'); }catch(e){} sApplyState(SE_DEFAULT_STATE); sState.riskRanges=null; sState.mc=null; sSyncUI(); sRecalc(); toast('Valores por defecto restablecidos'); };
  try{ const s=JSON.parse(localStorage.getItem('capexlt.slast')||'null'); if(s) sApplyState(s); }catch(e){}
  sSyncUI();
  ['#segSTech','#segSZone','#segSNueva','#segSArea'].forEach(id=>{ $$(id+' button').forEach(b=>b.onclick=()=>{ setSeg(id,b.dataset.v); sSyncUI(); sRecalc(); }); });
  $$('#side3 select').forEach(el=>{ if(el.closest('#projCard')) return; el.onchange=()=>{ sSyncUI(); sRecalc(); }; });
  $$('#side3 input[type=number], #side3 input[type=text], #side3 textarea').forEach(el=>el.addEventListener('input',()=>{ if(el.closest('#projCard')) return; clearTimeout(el._t); el._t=setTimeout(sRecalc,150); }));
  $$('#tabs3 button').forEach(b=>b.onclick=()=>{ $$('#tabs3 button').forEach(x=>x.classList.toggle('on',x===b)); $$('.panel3').forEach(p=>p.classList.toggle('on',p.id==='p-'+b.dataset.t)); sActiveTab=b.dataset.t; if(sActiveTab==='sbase') sRenderBase(); if(sActiveTab==='sinforme'&&window.renderInforme) renderInforme('C'); if(sActiveTab==='sesc'&&window.ESC) ESC.render($('#escC'),R3,'C'); if(sActiveTab==='srefs') sRenderRefs(); });
  $('#sBtnPrint').onclick=()=>window.print();
  $('#sEqSel').onchange=sRenderEq;
  ['#sBaseSearch','#sBaseKv','#sBaseTech','#sBaseType','#sBaseZone'].forEach(id=>{ const el=$(id); el.oninput=sRenderBase; el.onchange=sRenderBase; });
  $('#sBaseType').innerHTML='<option value="">Todos los tipos</option>'+[...new Set(SE_MODS.map(m=>m.type))].map(t=>`<option value="${t}">${SE_TYPE_SHORT[t]||t}</option>`).join('');
  $('#sBaseNote').textContent=`${SE_MODS.length} módulos · ${SE_DB.meta.fuente} · precios ${SE_DB.meta.fecha}, TC ${SE_DB.meta.tc}`;
  $('#sBtnMC').onclick=()=>{ if(!sState.riskRanges||sState.riskRanges.cls!==R3.inp.cls) sState.riskRanges={cls:R3.inp.cls,r:JSON.parse(JSON.stringify(RISK3_DEFAULT[R3.inp.cls]))}; const pk=riskPackagesSe(R3); const N=parseInt($('#sMcN').value); const dist=$('#sMcDist').value; const mc=monteCarlo(pk,sState.riskRanges.r,N,dist); mc.base=pk.reduce((a,p)=>a+p.base,0); sState.mc=mc; sRenderMC(); if(window.PERTMAP) PERTMAP.render($('#sPertMap'),'C'); toast(`Simulación de ${N} iteraciones (${dist==='tri'?'triangular':'beta-PERT'}) completada`); };
  $('#sMcP').onchange=sRenderMC;
  sRecalc();
}
/* configuración típica por tensión al cambiar de kV (evita combinaciones irreales): potencia por unidad, tipo de transformador, acople y cortocircuito */
function sApplyKvDefaults(kv){ const set=(id,v)=>{ const e=document.getElementById(id); if(e) e.value=v; }; const D={60:{mva:25,kind:'3f',nA:1,ka:'31.5'},138:{mva:50,kind:'3f',nA:1,ka:'31.5'},220:{mva:100,kind:'3f',nA:1,ka:'40'},500:{mva:300,kind:'bank',nA:0,ka:'63'}}[kv]; if(!D) return; set('sMva',D.mva); set('sTrKind',D.kind); set('sNA',D.nA); set('sKa',D.ka); if(kv!==500){ set('sNRx',0); set('sNMB',0); set('sNRL',0); } }
window.sApplyKvDefaults=sApplyKvDefaults;
window.sRecalc=sRecalc; window.sInit=sInit; window.sState=sState;
