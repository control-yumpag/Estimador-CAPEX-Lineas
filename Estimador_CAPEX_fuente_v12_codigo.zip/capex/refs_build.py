# -*- coding: utf-8 -*-
"""Construye refs.json (referencias de mercado Perú) a partir de los JSON extraídos de Invierte.pe y SEACE.
Uso: python3 refs_build.py invierte_lineas.json seace_lineas_obras.json
"""
import json, re, sys, unicodedata, statistics
from datetime import datetime

# Tipo de cambio promedio anual S/ por USD (BCRP, promedio compra-venta interbancario; 2026 ene-set) — referencial
TC = {2004:3.41,2005:3.30,2006:3.27,2007:3.13,2008:2.92,2009:3.01,2010:2.83,2011:2.75,2012:2.64,2013:2.70,2014:2.84,2015:3.19,2016:3.38,2017:3.26,2018:3.29,2019:3.34,2020:3.50,2021:3.88,2022:3.83,2023:3.74,2024:3.76,2025:3.55,2026:3.45}
# CPI-U promedio anual (BLS) para llevar USD nominales del año a USD 2026 (2026 = ene–set)
CPI = {2004:188.9,2005:195.3,2006:201.6,2007:207.3,2008:215.3,2009:214.5,2010:218.1,2011:224.9,2012:229.6,2013:233.0,2014:236.7,2015:237.0,2016:240.0,2017:245.1,2018:251.1,2019:255.7,2020:258.8,2021:271.0,2022:292.7,2023:304.7,2024:313.7,2025:322.3,2026:331.0}

def norm(s):
    s = unicodedata.normalize('NFD', s or '')
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn').upper()

KV_LEVELS = [500, 220, 138, 66, 60, 33, 22.9, 13.2, 10, 0.38]
def parse_kv(text):
    t = norm(text).replace(',', '.')
    found = set()
    for m in re.finditer(r'(\d{1,3}(?:\.\d{1,2})?)\s*(?:/\s*\d{1,3}(?:\.\d)?)*\s*(?:KV|K V|KILOVOLT)', t):
        try:
            v = float(m.group(1))
        except ValueError:
            continue
        # también los niveles separados por '/' (60/22.9/10)
        seg = m.group(0)
        for p in re.findall(r'\d{1,3}(?:\.\d{1,2})?', seg):
            try: found.add(float(p))
            except ValueError: pass
    if re.search(r'380\s*/\s*220|440\s*/\s*220|220\s*V\b|BAJA TENSION|REDES? SECUNDARIAS?', t) and not found:
        found.add(0.38)
    return sorted(found, reverse=True)

def level_of(kvs):
    for v in kvs:
        for L in KV_LEVELS:
            if abs(v - L) < 0.6 or (L == 22.9 and abs(v - 23) < 0.2):
                return L
    return None

def parse_km(text):
    t = norm(text).replace(',', '.')
    vals = []
    for m in re.finditer(r'(\d{1,4}(?:\.\d{1,3})?)\s*KM\b', t):
        try:
            v = float(m.group(1))
            if 0.05 <= v <= 1500: vals.append(v)
        except ValueError:
            pass
    return vals

def kind_of(name):
    n = norm(name)
    if re.search(r'\bIOARR\b|REMODELACION|RENOVACION|REPARACION|REHABILITACION|REPOSICION|MANTENIMIENTO|REUBICACION|SALDO DE OBRA', n):
        return 'rehab'
    if re.search(r'CREACION|INSTALACION|CONSTRUCCION|AMPLIACION|MEJORAMIENTO Y AMPLIACION|NUEVA LINEA|NUEVA LT', n):
        return 'nuevo'
    if re.search(r'MEJORAMIENTO', n):
        return 'mejora'
    return 'otro'

def scope_of(name):
    n = norm(name)
    has_line = bool(re.search(r'LINEA|L\.T\.?|\bLT\b|REDES? PRIMARIAS?|REDES? SECUNDARIAS?|ELECTRIFICACION|SISTEMA ELECTRICO|ALIMENTADOR|SUBTRANSMISION', n))
    has_set = bool(re.search(r'SUBESTACION|SUB ESTACION|\bSET\b|\bS\.?E\.?T?\b|CELDA|TRANSFORMADOR|BAHIA', n))
    if has_line and has_set: return 'linea+SET'
    if has_line: return 'linea'
    if has_set: return 'SET'
    return 'otro'

def year_of(datestr):
    m = re.search(r'(\d{2})/(\d{2})/(\d{4})', datestr or '')
    return int(m.group(3)) if m else None

def usd(amount_soles, year):
    y = year if year in TC else (2026 if (year or 0) > 2026 else min(TC))
    return amount_soles / TC[y]

def usd26(amount_usd, year):
    y = year if year in CPI else 2026
    return amount_usd * CPI[2026] / CPI[y]

def build_invierte(path):
    data = json.load(open(path, encoding='utf-8'))
    out = []
    for r in data['rows']:
        name = r.get('Nombre') or ''
        alt = r.get('Alternativa') or ''
        kvs = parse_kv(name + ' ' + alt)
        lvl = level_of(kvs)
        kms = parse_km(name + ' ' + alt)
        km = max(kms) if kms else None
        viab = r.get('FechaViabilidad') or ''
        reg = r.get('FechaRegistro') or ''
        year = year_of(viab) or year_of(reg)
        monto = float(r.get('Costo') or 0) or float(r.get('MontoAlternativa') or 0)
        montoV = float(r.get('MontoAlternativa') or 0)
        if monto <= 0: continue
        u = usd(monto, year)
        rec = {
            'src': 'invierte', 'id': str(r.get('CodigoUnico')), 'name': name[:220], 'ent': (r.get('Pliego') or '')[:70],
            'dpto': (r.get('LocalizacionDepartamento') or '')[:24], 'year': year, 'fecha': viab or reg,
            'estado': (r.get('Estado') or ''), 'situ': (r.get('Situacion') or ''), 'marco': r.get('Marco') or '', 'formato': (r.get('TipoFormato') or '')[:28],
            'kvs': kvs[:4], 'kv': lvl, 'km': km, 'kind': kind_of(name), 'scope': scope_of(name),
            'soles': round(monto), 'solesViable': round(montoV), 'usd': round(u), 'usd26': round(usd26(u, year)),
            'dev': round(float(r.get('DevAcumulado') or 0)), 'avf': r.get('avanceFisico'), 'benef': r.get('Beneficiarios'),
            'desc': alt[:260], 'tags': r.get('_tags') or []
        }
        if km:
            rec['usdKm'] = round(u / km); rec['usdKm26'] = round(usd26(u, year) / km)
        out.append(rec)
    return out

def build_seace(path):
    data = json.load(open(path, encoding='utf-8'))
    byNom = {}
    for r in data['rows']:
        nom = r.get('nom') or ''
        d = (r.get('fecha') or '').split(' ')[0]
        key = nom
        dsort = '/'.join(reversed(d.split('/'))) if d else ''
        vr = (r.get('vr') or '').replace(',', '')
        hasVr = bool(re.match(r'^\d', vr))
        cur = byNom.get(key)
        if not cur or dsort > cur['_d'] or (dsort == cur['_d'] and hasVr and not cur['_hasVr']):
            byNom[key] = dict(r, _d=dsort, _hasVr=hasVr)
    out = []
    for r in byNom.values():
        desc = r.get('desc') or ''
        vr = (r.get('vr') or '').replace(',', '')
        try: monto = float(vr)
        except ValueError: monto = 0
        year = year_of(r.get('fecha') or '')
        kvs = parse_kv(desc); lvl = level_of(kvs); kms = parse_km(desc); km = max(kms) if kms else None
        u = usd(monto, year) if monto > 0 else 0
        rec = {'src': 'seace', 'id': r.get('nom'), 'name': desc[:220], 'ent': (r.get('ent') or '')[:70], 'dpto': '', 'year': year, 'fecha': r.get('fecha'),
               'estado': r.get('rein') or 'Convocatoria', 'obj': r.get('obj'), 'cui': r.get('cui') or '', 'snip': r.get('snip') or '',
               'kvs': kvs[:4], 'kv': lvl, 'km': km, 'kind': kind_of(desc), 'scope': scope_of(desc),
               'soles': round(monto), 'usd': round(u), 'usd26': round(usd26(u, year)) if u else 0, 'desc': desc[:260], 'tags': [r.get('tag') or '']}
        if km and u: rec['usdKm'] = round(u / km); rec['usdKm26'] = round(usd26(u, year) / km)
        out.append(rec)
    return out

if __name__ == '__main__':
    inv = build_invierte(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] != '-' else []
    sea = build_seace(sys.argv[2]) if len(sys.argv) > 2 else []
    rows = inv + sea
    meta = {'generado': datetime.now().strftime('%Y-%m-%d'), 'tc': TC, 'cpi': CPI, 'n_invierte': len(inv), 'n_seace': len(sea),
            'fuentes': ['MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública', 'OECE – SEACE 3.0 buscador público de procedimientos de selección (obras)'],
            'nota': 'Montos en soles de la fecha de viabilidad/convocatoria; USD con TC promedio del año (BCRP); USD 2026 por CPI-U (BLS). kV y km extraídos del nombre/descripción (heurística), validar antes de usar.'}
    json.dump({'meta': meta, 'rows': rows}, open('refs.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    withkm = [r for r in rows if r.get('usdKm26')]
    print('rows', len(rows), 'invierte', len(inv), 'seace', len(sea), 'con km', len(withkm))
    from collections import Counter
    print('niveles', Counter(r['kv'] for r in rows).most_common())
    print('con km por nivel', Counter(r['kv'] for r in withkm).most_common())
    for L in [220, 138, 60, 33, 22.9, 13.2, 0.38]:
        v = sorted(r['usdKm26'] for r in withkm if r['kv'] == L and r['scope'] == 'linea' and r['kind'] in ('nuevo', 'mejora'))
        if len(v) >= 2:
            print(L, 'n', len(v), 'mediana', statistics.median(v), 'p25', v[len(v)//4], 'p75', v[3*len(v)//4])
