import sys, json, glob, os
from PIL import Image, ImageDraw, ImageFont
OUT='/home/claude/capex/qa'
names=sys.argv[1].split(',') ; cam=sys.argv[2]; out=sys.argv[3]; cols=int(sys.argv[4]) if len(sys.argv)>4 else 3
ims=[]
for n in names:
    p=f'{OUT}/{n}_{cam}.png'
    if not os.path.exists(p): print('missing',p); continue
    im=Image.open(p).convert('RGB'); ims.append((n,im))
w,h=ims[0][1].size
sc=0.62; W=int(w*sc); H=int(h*sc)
rows=(len(ims)+cols-1)//cols
sheet=Image.new('RGB',(W*cols,(H+22)*rows),'white'); d=ImageDraw.Draw(sheet)
try: font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',15)
except: font=None
for i,(n,im) in enumerate(ims):
    x=(i%cols)*W; y=(i//cols)*(H+22)
    sheet.paste(im.resize((W,H)),(x,y+22)); d.rectangle([x,y,x+W,y+22],fill=(30,40,50)); d.text((x+6,y+3),n,fill='white',font=font)
sheet.save(out); print(out, sheet.size)
