/* Auditoría automática del estimador (ambos motores): aritmética de la cadena, PERT, Monte Carlo, escalamiento, informe, persistencia, móvil.
   Uso: node audit_v10.js [ruta_html]  → imprime JSON con resultados */
const { chromium } = require('playwright');
const file = process.argv[2] || '/mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html';
const out = { file, checks: [], errors: [] };
const ok = (id, cond, detail) => out.checks.push({ id, ok: !!cond, detail });
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1500, height: 1000 } });
  page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|net::|fonts\.g/.test(m.text())) out.errors.push('console: ' + m.text().slice(0, 300)); });
  page.on('pageerror', e => out.errors.push('PAGEERROR: ' + e.message.slice(0, 300)));
  await page.goto('file://' + file, { waitUntil: 'load' });
  await page.waitForTimeout(1200); await page.evaluate(() => localStorage.clear()); await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(1500);

  const chain = async () => page.evaluate(() => {
    const X = APP_MODE === 'osi' ? R2 : R; const inp = X.inp;
    const d1 = APP_MODE === 'osi' ? X.d1 : X.directo, d2 = APP_MODE === 'osi' ? X.d2 : X.indirecto;
    const pk = APP_MODE === 'osi' ? riskPackagesOsi(X) : riskPackages(X);
    const sumPk = pk.reduce((a, p) => a + p.base, 0);
    const esc = X.escDet;
    const escSum = esc ? esc.byGroup.reduce((a, g) => a + g.esc, 0) : null;
    const wSum = esc ? esc.byGroup.reduce((a, g) => a + g.W, 0) : null;
    const ySum = esc ? esc.years.reduce((a, y) => a + y.w, 0) : null;
    return { mode: APP_MODE, kv: inp.kv, cls: inp.cls, d1, d2, A: X.A, esc: X.esc, risk: X.risk, B: X.B, cont: X.cont, C: X.C, D: X.D, E: X.E, phase: inp.phase, contPct: inp.cont, riskPct: inp.risk,
      sumPk, pk: pk.map(p => [p.k, Math.round(p.base)]), escSum, wSum, ySum, escPct: esc ? esc.pct : null, usdKm: X.usdKm, km: inp.km, escKeys: esc ? Object.keys(esc) : null, gKeys: esc && esc.byGroup[0] ? Object.keys(esc.byGroup[0]) : null };
  });
  // --- motor COES 220 kV (inicial)
  let c = await chain();
  out.initial = c;
  ok('A=1+2 (COES)', near(c.A, c.d1 + c.d2), c);
  ok('B=A+3+4 (COES)', near(c.B, c.A + c.esc + c.risk));
  ok('C=B+5 (COES)', near(c.C, c.B + c.cont) && near(c.cont, c.B * c.contPct / 100));
  ok('E=C+D, D=%C (COES)', near(c.E, c.C + c.D) && near(c.D, c.C * c.phase / 100));
  ok('Σ paquetes de riesgo = B (COES)', near(c.sumPk, c.B, 1e-6), { sumPk: c.sumPk, B: c.B, pk: c.pk });
  ok('usdKm = E/km (COES)', near(c.usdKm, c.E / c.km));
  out.escKeys = { escKeys: c.escKeys, gKeys: c.gKeys };
  // --- PERT tabla vs KPI
  await page.click('#tabs button[data-t="riesgo"]'); await page.waitForTimeout(600);
  const pert = await page.evaluate(() => {
    const rows = [...document.querySelectorAll('#riskTbl tbody tr')];
    const num = s => parseFloat(String(s).replace(/[^\d.-]/g, '')) || 0;
    const tot = rows.find(r => /Estimado base/.test(r.textContent)); const tds = tot ? [...tot.children].map(t => t.textContent) : [];
    const kpi = document.querySelector('#riskSum .kpi .v').textContent;
    // recompute from inputs
    const inputs = [...document.querySelectorAll('#riskTbl input.rk')];
    const rr = {}; inputs.forEach(i => { rr[i.dataset.k] = rr[i.dataset.k] || [0, 0]; rr[i.dataset.k][+i.dataset.i] = parseFloat(i.value); });
    const pk = riskPackages(R); let sB = 0, sE = 0; pk.forEach(p => { const r = rr[p.k]; const mn = p.base * (1 + r[0] / 100), mx = p.base * (1 + r[1] / 100); sB += p.base; sE += (mn + mx + 4 * p.base) / 6; });
    const fS = (2 + rr.sys[0] / 100 + rr.sys[1] / 100 + 4) / 6; const sE2 = sE * fS;
    // media triangular equivalente (lo que simula el MC)
    let sT = 0; pk.forEach(p => { const r = rr[p.k]; sT += p.base * (3 + r[0] / 100 + r[1] / 100) / 3; }); const fT = (3 + rr.sys[0] / 100 + rr.sys[1] / 100) / 3;
    return { totB: num(tds[1]), totE: num(tds[4]), kpi, sB, sE2, cDet: (sE2 - sB) / sB * 100, triMeanPct: (sT * fT - sB) / sB * 100, rr };
  });
  out.pert = pert;
  ok('Tabla PERT: Base (B) = R.B', near(pert.totB, Math.round(c.B), 1e-5) || Math.abs(pert.totB - c.B) < 2, { totB: pert.totB, B: c.B });
  ok('Tabla PERT: esperado = Σ(mín+máx+4·base)/6 × fSys', Math.abs(pert.totE - pert.sE2) < 2, { totE: pert.totE, sE2: pert.sE2 });
  ok('KPI contingencia PERT coincide', pert.kpi.replace(/[^\d.]/g, '') === pert.cDet.toFixed(2), { kpi: pert.kpi, cDet: pert.cDet });
  out.pertVsTriangular = { pertPct: pert.cDet, triangularMeanPct: pert.triMeanPct };
  // --- edición de rango por teclado (bug de pérdida de foco / negativos)
  const before = await page.$eval('#riskTbl input.rk[data-k="estr"][data-i="0"]', i => i.value);
  await page.click('#riskTbl input.rk[data-k="estr"][data-i="0"]', { clickCount: 3 }); await page.keyboard.type('-12'); await page.waitForTimeout(200); const focusedWhileTyping = await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('rk') && document.activeElement.value === '-12'); await page.keyboard.press('Tab'); await page.waitForTimeout(400);
  const after = await page.evaluate(() => ({ val: document.querySelector('#riskTbl input.rk[data-k="estr"][data-i="0"]').value, st: state.riskRanges.r.estr[0] }));
  ok('Edición por teclado de rango negativo (-12): foco conservado al escribir y valor aplicado al confirmar', focusedWhileTyping && after.st === -12 && after.val === '-12', { before, after, focusedWhileTyping });
  // --- Monte Carlo
  await page.selectOption('#mcN', { index: 0 }).catch(() => {});
  const mcN = await page.$eval('#mcN', s => s.value);
  await page.click('#btnMC'); await page.waitForTimeout(2500);
  const mc = await page.evaluate(() => { const m = state.mc; return m ? { base: m.base, mean: m.mean, sd: m.sd, p10: m.P(10), p50: m.P(50), p90: m.P(90), min: m.min, max: m.max, n: m.s.length, B: R.B } : null; });
  out.mc = Object.assign({ mcN }, mc);
  ok('MC: P10 ≤ P50 ≤ P90 y base = B', mc && mc.p10 <= mc.p50 && mc.p50 <= mc.p90 && near(mc.base, mc.B, 1e-6), mc);
  const mcDist = await page.evaluate(() => state.mc.dist || 'tri');
  if (mcDist === 'pert') ok('MC beta-PERT: media ≈ esperado PERT de la tabla', mc && Math.abs((mc.mean - mc.base) / mc.base * 100 - pert.cDet) < 1.0, { mcMeanPct: (mc.mean - mc.base) / mc.base * 100, pertPct: pert.cDet });
  else ok('MC: media ≈ media triangular (no PERT) → documentar/corregir', mc && Math.abs((mc.mean - mc.base) / mc.base * 100 - pert.triMeanPct) < 1.5, { mcMeanPct: (mc.mean - mc.base) / mc.base * 100, triMeanPct: pert.triMeanPct, pertPct: pert.cDet });
  const map = await page.evaluate(() => { const el = document.querySelector('#pertMap'); return el ? { svg: !!el.querySelector('svg.pert'), rows: el.querySelectorAll('svg.pert polygon').length, txt: el.textContent.length } : null; });
  ok('Mapa de puntos PERT renderizado (COES)', map && map.svg && map.rows >= 8, map);
  if (await page.$('#mcDist')) { await page.selectOption('#mcDist', 'tri'); await page.click('#btnMC'); await page.waitForTimeout(2000);
    const mcT = await page.evaluate(() => ({ dist: state.mc.dist, meanPct: (state.mc.mean - state.mc.base) / state.mc.base * 100 }));
    ok('MC triangular: media ≈ (Mín+Base+Máx)/3', mcT.dist === 'tri' && Math.abs(mcT.meanPct - pert.triMeanPct) < 1.5, { mcT, triMeanPct: pert.triMeanPct });
    await page.selectOption('#mcDist', 'pert'); }
  // --- escalamiento
  ok('ESC: Σ montos por grupo = esc', c.escSum == null || near(c.escSum, c.esc, 1e-6), { escSum: c.escSum, esc: c.esc });
  ok('ESC: Σ pesos A_g = A', c.wSum == null || near(c.wSum, c.A, 1e-6), { wSum: c.wSum, A: c.A });
  ok('ESC: Σ pesos por año = 1', c.ySum == null || near(c.ySum, 1, 1e-9), { ySum: c.ySum });
  // año de precios 2028 → escalamiento debe bajar (base más cercana a la ejecución)
  const esc26 = c.escPct;
  const esc28 = await page.evaluate(async () => { PRICE.state.year = 2028; PRICE.recalcAll(); await new Promise(r => setTimeout(r, 300)); return { pct: R.escDet ? R.escDet.pct : null, escF: R.escF, year: PRICE.year }; });
  ok('Año de precios 2028: factor de actualización > 1 y escalamiento a ejecución menor', esc28.escF > 1 && esc28.pct != null && esc28.pct < esc26, { esc26, esc28 });
  await page.evaluate(async () => { PRICE.state.year = 2026; PRICE.recalcAll(); await new Promise(r => setTimeout(r, 300)); });
  // --- informe
  await page.click('#tabs button[data-t="informe"]'); await page.waitForTimeout(1500);
  const inf = await page.evaluate(() => { const t = document.querySelector('#informe').textContent; const E = Math.round(R.E).toLocaleString('en-US'); return { hasE: t.includes(E), E, h2: [...document.querySelectorAll('#informe h2')].map(h => h.textContent).slice(0, 14) }; });
  ok('Informe A muestra E del estimado', inf.hasE, inf);
  // --- JSON export consistency
  const js = await page.evaluate(() => JSON.stringify({ E: R.E, B: R.B, esc: ESC.export ? !!ESC.export(R) : null, pr: !!PRICE.export }));
  ok('Exportación JSON disponible (ESC.export, PRICE.export)', /true/.test(js), js);
  // --- niveles / órdenes de magnitud
  const levels = [[0.38, 'BT'], [10, 'MT'], [13.2, 'MT'], [22.9, 'MT'], [33, 'MT'], [60, 'AT'], [138, 'AT'], [220, 'AT'], [500, 'EAT']];
  out.levels = [];
  for (const [kv, L] of levels) {
    await page.evaluate(k => selectKv(k), kv); await page.waitForTimeout(900);
    const cc = await chain();
    const chk = near(cc.A, cc.d1 + cc.d2) && near(cc.B, cc.A + cc.esc + cc.risk) && near(cc.C, cc.B + cc.cont) && near(cc.E, cc.C + cc.D) && near(cc.sumPk, cc.B, 1e-6) && (cc.escSum == null || near(cc.escSum, cc.esc, 1e-6));
    out.levels.push({ kv, L, mode: cc.mode, E: Math.round(cc.E), usdKm: Math.round(cc.E / cc.km), km: cc.km, escPct: cc.escPct, chainOK: chk, sumPk: Math.round(cc.sumPk), B: Math.round(cc.B) });
    ok(`Cadena y paquetes · ${kv} kV (${cc.mode})`, chk, { kv, sumPk: cc.sumPk, B: cc.B, pk: cc.pk });
  }
  // --- Osinergmin: tabla PERT, edición por teclado, MC
  await page.evaluate(() => selectKv(60)); await page.waitForTimeout(900);
  await page.click('#tabs2 button[data-t="oriesgo"]'); await page.waitForTimeout(600);
  const pertB = await page.evaluate(() => { const rows = [...document.querySelectorAll('#oRiskTbl tbody tr')]; const num = s => parseFloat(String(s).replace(/[^\d.-]/g, '')) || 0; const tot = rows.find(r => /Estimado base/.test(r.textContent)); const tds = tot ? [...tot.children].map(t => t.textContent) : []; return { totB: num(tds[1]), B: R2.B, kpi: document.querySelector('#oRiskSum .kpi .v').textContent }; });
  ok('Osinergmin: tabla PERT Base (B) = R2.B', Math.abs(pertB.totB - pertB.B) < 2, pertB);
  await page.click('#oRiskTbl input.rk[data-i="0"]', { clickCount: 3 }); await page.keyboard.type('-9'); await page.waitForTimeout(200); const focB = await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('rk') && document.activeElement.value === '-9'); await page.keyboard.press('Tab'); await page.waitForTimeout(400);
  const afterB = await page.evaluate(() => { const i = document.querySelector('#oRiskTbl input.rk[data-i="0"]'); return { val: i.value, st: oState.riskRanges.r[i.dataset.k][0] }; });
  ok('Osinergmin: edición por teclado de rango negativo (-9): foco conservado y valor aplicado al confirmar', focB && afterB.st === -9, Object.assign({ focB }, afterB));
  const mapB = await page.evaluate(() => { const el = document.querySelector('#oPertMap'); return el ? { svg: !!el.querySelector('svg.pert'), rows: el.querySelectorAll('svg.pert polygon').length } : null; });
  ok('Mapa de puntos PERT renderizado (Osinergmin)', mapB && mapB.svg && mapB.rows >= 4, mapB);
  await page.click('#oBtnMC'); await page.waitForTimeout(2500);
  const mcB = await page.evaluate(() => { const m = oState.mc; return m ? { base: m.base, mean: m.mean, p10: m.P(10), p50: m.P(50), p90: m.P(90), B: R2.B } : null; });
  ok('Osinergmin MC: P10 ≤ P50 ≤ P90 y base = B', mcB && mcB.p10 <= mcB.p50 && mcB.p50 <= mcB.p90 && near(mcB.base, mcB.B, 1e-6), mcB);
  // --- informe B
  await page.click('#tabs2 button[data-t="oinforme"]'); await page.waitForTimeout(1500);
  const infB = await page.evaluate(() => { const t = document.querySelector('#oInforme') ? document.querySelector('#oInforme').textContent : document.body.textContent; return { hasE: t.includes(Math.round(R2.E).toLocaleString('en-US')) }; });
  ok('Informe B muestra E del estimado', infB.hasE, infB);
  // --- persistencia y móvil
  await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(1500);
  const pers = await page.evaluate(() => ({ mode: APP_MODE, kv: (APP_MODE === 'osi' ? R2 : R).inp.kv }));
  ok('Persistencia tras recarga (modo y kV)', pers.mode === 'osi' && pers.kv === 60, pers);
  await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(700);
  const mob = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  ok('Móvil 390 px: sin desplazamiento horizontal', mob.sw <= mob.cw + 1, mob);
  await page.setViewportSize({ width: 1500, height: 1000 });
  ok('Sin errores JS en consola', out.errors.length === 0, out.errors.slice(0, 8));
  await browser.close();
  out.summary = { total: out.checks.length, failed: out.checks.filter(c => !c.ok).length };
  console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error('FATAL', e); process.exit(1); });
