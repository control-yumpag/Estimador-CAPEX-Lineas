/* Auditoría automática del estimador (ambos motores): aritmética de la cadena, PERT, Monte Carlo, escalamiento, informe, persistencia, móvil.
   Uso: node audit_v12.js [ruta_html]  → imprime JSON con resultados */
const { chromium } = require('playwright');
const file = process.argv[2] || '/mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html';
const out = { file, checks: [], errors: [], se: [], v12: {} };
const ok = (id, cond, detail) => out.checks.push({ id, ok: !!cond, detail });
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
(async () => {
  const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-webgl', '--ignore-gpu-blocklist'] });
  const page = await browser.newPage({ viewport: { width: 1500, height: 1000 } });
  page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|net::|fonts\.g/.test(m.text())) out.errors.push('console: ' + m.text().slice(0, 300)); });
  page.on('pageerror', e => out.errors.push('PAGEERROR: ' + e.message.slice(0, 300)));
  await page.goto('file://' + file, { waitUntil: 'load' });
  await page.waitForTimeout(1200); await page.evaluate(() => localStorage.clear()); await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(1500);

  // ===== v12: modo guía, resultado ejecutivo, presets por clase, proxies =====
  const g0 = await page.evaluate(() => ({ ui: document.body.dataset.ui, tab: activeTab, hasE: (document.querySelector('#execA') || {}).innerText.includes((R.E / 1e6).toFixed(R.E >= 1e7 ? 1 : 2)), fields: [...document.querySelectorAll('#gFields [data-gk]')].filter(e => !e.hidden).length, status: document.querySelector('#statusLine').innerText.replace(/\n/g, ' '), hiddenGroups: [...document.querySelectorAll('#side details.grp')].filter(d => d.offsetParent === null).length }));
  ok('v12 · Modo guía por defecto: pestaña Resultado con E, 11 datos esenciales (Clase 3) y línea de estado', g0.ui === 'guide' && g0.tab === 'exec' && g0.hasE && g0.fields === 11 && /220 kV/.test(g0.status) && /Clase 3/.test(g0.status) && g0.hiddenGroups >= 3, g0);
  const bk = await page.evaluate(() => { const b = SIMPLE.buckets(R); const sum = b.reduce((a, o) => a + o.v, 0); const d = SIMPLE.drivers(R); return { sum, E: R.E, dsum: d.tot, directo: R.directo }; });
  ok('v12 · Resultado: Σ (1+2+3+4+5+D) = E y los rubros del directo suman ≈ directo (COES)', near(bk.sum, bk.E, 1e-9) && bk.dsum > 0.8 * bk.directo && bk.dsum <= bk.directo * 1.001, bk);
  await page.selectOption('#pClass', '4'); await page.waitForTimeout(900);
  const pr4 = await page.evaluate(() => ({ A: [R.inp.cont, R.inp.risk, R.inp.allowQ, R.inp.allowP, R.inp.phase], B: ['#oCont', '#oRisk', '#oPhase'].map(s => parseFloat(document.querySelector(s).value)), C: ['#sCont', '#sRisk', '#sAllowQ', '#sAllowP', '#sPhase'].map(s => parseFloat(document.querySelector(s).value)), fields: [...document.querySelectorAll('#gFields [data-gk]')].filter(e => !e.hidden).length, note: document.querySelector('#gClass').innerText }));
  ok('v12 · Clase 4 aplica los ratios por defecto en los tres espacios (cont 30, riesgo 2.5, allowances 6+4, fase 2) y reduce los datos a 5', pr4.A.join() === '30,2.5,6,4,2' && pr4.B.join() === '30,2.5,2' && pr4.C.join() === '30,2.5,6,4,2' && pr4.fields === 5 && /Clase 4/.test(pr4.note), pr4);
  await page.selectOption('#pClass', '5'); await page.waitForTimeout(700);
  const pr5 = await page.evaluate(() => ({ cont: R.inp.cont, fields: [...document.querySelectorAll('#gFields [data-gk]')].filter(e => !e.hidden).map(e => e.dataset.gk).join() }));
  ok('v12 · Clase 5: contingencia 45 % y solo longitud y región', pr5.cont === 45 && pr5.fields === 'km,zone', pr5);
  await page.selectOption('#pClass', '3'); await page.waitForTimeout(800);
  const pr3 = await page.evaluate(() => [R.inp.cont, R.inp.risk, R.inp.allowQ, R.inp.allowP, R.inp.phase].join());
  ok('v12 · Clase 3 restablece cont 20, riesgo 2, allowances 5+3, fase 1.5', pr3 === '20,2,5,3,1.5', pr3);
  await page.fill('#gFields input[data-g="km"]', '75'); await page.waitForTimeout(900);
  await page.click('#gFields .seg[data-g="circ"] button[data-v="ST"]'); await page.waitForTimeout(900);
  const px = await page.evaluate(() => ({ km: R.inp.km, real: document.querySelector('#inKm').value, struct: R.inp.struct, proxyOn: document.querySelector('#gFields .seg[data-g="circ"] button.on').dataset.v, status: document.querySelector('#statusLine').innerText.replace(/\n/g, ' ') }));
  ok('v12 · Los datos de la guía escriben en los motores (km 75, simple terna) y la línea de estado los refleja', px.km === 75 && px.real === '75' && px.struct === 'ST' && px.proxyOn === 'ST' && /75 km/.test(px.status) && /simple terna/.test(px.status), px);
  await page.evaluate(() => { document.querySelector('#gFields input[data-g="km"]').value = '60'; }); await page.fill('#gFields input[data-g="km"]', '60'); await page.click('#gFields .seg[data-g="circ"] button[data-v="DT"]'); await page.waitForTimeout(900);
  await page.click('#btnMode'); await page.waitForTimeout(400);
  const md = await page.evaluate(() => ({ ui: document.body.dataset.ui, visible: [...document.querySelectorAll('#side details.grp')].filter(d => d.offsetParent !== null).length, chip: document.querySelector('#chipModule').offsetParent !== null }));
  await page.click('#btnMode'); await page.waitForTimeout(400);
  const mg = await page.evaluate(() => ({ ui: document.body.dataset.ui, visible: [...document.querySelectorAll('#side details.grp')].filter(d => d.offsetParent !== null).length }));
  ok('v12 · Modo experto muestra todos los grupos y chips; modo guía los oculta', md.ui === 'expert' && md.visible >= 5 && md.chip && mg.ui === 'guide' && mg.visible === 2, { md, mg });
  const intl = await page.evaluate(() => { const l = INTL.lines(220, 2); const acer = l.find(r => r.id === 'acer23-220-dc'); const miso = l.find(r => r.id === 'miso24-230-dc'); const csg = l.find(r => r.id === 'csg23-220-sc'); return { acer: acer && acer.usdMed, acerExp: 502843 * 1.081 * 331 / 304.7, misoLo: miso && miso.usdLo, misoExp: 3.3e6 / 1.609 * 331 / 313.7, csgCirc: csg && csg.circ, csgMed: csg && csg.usdMed, n: l.length }; });
  ok('v12 · Referencias internacionales: conversión a USD 2026 reproducible (ACER 220 kV DC, MISO 230 kV DC) y factor de doble circuito de CSG', intl.n >= 6 && near(intl.acer, intl.acerExp, 1e-6) && near(intl.misoLo, intl.misoExp, 1e-6) && intl.csgCirc === 2 && intl.csgMed > 0, intl);
  const xp = await page.evaluate(() => { SIMPLE.printExec(); return null; }); await page.waitForTimeout(900); await page.evaluate(() => document.body.classList.add('print-exec'));
  await page.emulateMedia({ media: 'print' }); const pdfA = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' } }); await page.emulateMedia({ media: 'screen' }); await page.evaluate(() => document.body.classList.remove('print-exec'));
  const pagesA = (pdfA.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
  const xpi = await page.evaluate(() => { const t = document.querySelector('#execPrint').innerText; return { hasE: t.includes((R.E / 1e6).toFixed(R.E >= 1e7 ? 1 : 2)), hasClase: /Clase 3/.test(t), hasRange: /Rango esperado/.test(t), hasExcl: /No incluye/.test(t) }; });
  ok('v12 · Informe ejecutivo de una página (A4) con E, clase, rango y exclusiones', pagesA === 1 && xpi.hasE && xpi.hasClase && xpi.hasRange && xpi.hasExcl, { pagesA, xpi });

  const chain = async () => page.evaluate(() => {
    const X = APP_MODE === 'osi' ? R2 : R; const inp = X.inp;
    const d1 = APP_MODE === 'osi' ? X.d1 : X.directo, d2 = APP_MODE === 'osi' ? X.d2 : X.indirecto;
    const pk = APP_MODE === 'osi' ? riskPackagesOsi(X) : riskPackages(X);
    const sumPk = pk.reduce((a, p) => a + p.base, 0);
    const esc = X.escDet;
    const escSum = esc ? esc.byGroup.reduce((a, g) => a + g.esc, 0) : null;
    const wSum = esc ? esc.byGroup.reduce((a, g) => a + g.W, 0) : null;
    const ySum = esc ? esc.years.reduce((a, y) => a + y.w, 0) : null;
    return { mode: APP_MODE, kv: inp.kv, cls: inp.cls, d1, d2, A: X.A, esc: X.esc, risk: X.risk, B: X.B, cont: X.cont, C: X.C, D: X.D, E: X.E, phase: inp.phase, contPct: inp.cont, riskPct: inp.risk,
      sumPk, pk: pk.map(p => [p.k, Math.round(p.base)]), escSum, wSum, ySum, escPct: esc ? esc.pct : null, usdKm: X.usdKm, km: inp.km, escKeys: esc ? Object.keys(esc) : null, gKeys: esc && esc.byGroup[0] ? Object.keys(esc.byGroup[0]) : null };
  });
  // --- motor COES 220 kV (inicial)
  let c = await chain();
  out.initial = c;
  ok('A=1+2 (COES)', near(c.A, c.d1 + c.d2), c);
  ok('B=A+3+4 (COES)', near(c.B, c.A + c.esc + c.risk));
  ok('C=B+5 (COES)', near(c.C, c.B + c.cont) && near(c.cont, c.B * c.contPct / 100));
  ok('E=C+D, D=%C (COES)', near(c.E, c.C + c.D) && near(c.D, c.C * c.phase / 100));
  ok('Σ paquetes de riesgo = B (COES)', near(c.sumPk, c.B, 1e-6), { sumPk: c.sumPk, B: c.B, pk: c.pk });
  ok('usdKm = E/km (COES)', near(c.usdKm, c.E / c.km));
  out.escKeys = { escKeys: c.escKeys, gKeys: c.gKeys };
  // --- PERT tabla vs KPI
  await page.click('#tabs button[data-t="riesgo"]'); await page.waitForTimeout(600);
  const pert = await page.evaluate(() => {
    const rows = [...document.querySelectorAll('#riskTbl tbody tr')];
    const num = s => parseFloat(String(s).replace(/[^\d.-]/g, '')) || 0;
    const tot = rows.find(r => /Estimado base/.test(r.textContent)); const tds = tot ? [...tot.children].map(t => t.textContent) : [];
    const kpi = document.querySelector('#riskSum .kpi .v').textContent;
    // recompute from inputs
    const inputs = [...document.querySelectorAll('#riskTbl input.rk')];
    const rr = {}; inputs.forEach(i => { rr[i.dataset.k] = rr[i.dataset.k] || [0, 0]; rr[i.dataset.k][+i.dataset.i] = parseFloat(i.value); });
    const pk = riskPackages(R); let sB = 0, sE = 0; pk.forEach(p => { const r = rr[p.k]; const mn = p.base * (1 + r[0] / 100), mx = p.base * (1 + r[1] / 100); sB += p.base; sE += (mn + mx + 4 * p.base) / 6; });
    const fS = (2 + rr.sys[0] / 100 + rr.sys[1] / 100 + 4) / 6; const sE2 = sE * fS;
    // media triangular equivalente (lo que simula el MC)
    let sT = 0; pk.forEach(p => { const r = rr[p.k]; sT += p.base * (3 + r[0] / 100 + r[1] / 100) / 3; }); const fT = (3 + rr.sys[0] / 100 + rr.sys[1] / 100) / 3;
    return { totB: num(tds[1]), totE: num(tds[4]), kpi, sB, sE2, cDet: (sE2 - sB) / sB * 100, triMeanPct: (sT * fT - sB) / sB * 100, rr };
  });
  out.pert = pert;
  ok('Tabla PERT: Base (B) = R.B', near(pert.totB, Math.round(c.B), 1e-5) || Math.abs(pert.totB - c.B) < 2, { totB: pert.totB, B: c.B });
  ok('Tabla PERT: esperado = Σ(mín+máx+4·base)/6 × fSys', Math.abs(pert.totE - pert.sE2) < 2, { totE: pert.totE, sE2: pert.sE2 });
  ok('KPI contingencia PERT coincide', pert.kpi.replace(/[^\d.]/g, '') === pert.cDet.toFixed(2), { kpi: pert.kpi, cDet: pert.cDet });
  out.pertVsTriangular = { pertPct: pert.cDet, triangularMeanPct: pert.triMeanPct };
  // --- edición de rango por teclado (bug de pérdida de foco / negativos)
  const before = await page.$eval('#riskTbl input.rk[data-k="estr"][data-i="0"]', i => i.value);
  await page.click('#riskTbl input.rk[data-k="estr"][data-i="0"]', { clickCount: 3 }); await page.keyboard.type('-12'); await page.waitForTimeout(200); const focusedWhileTyping = await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('rk') && document.activeElement.value === '-12'); await page.keyboard.press('Tab'); await page.waitForTimeout(400);
  const after = await page.evaluate(() => ({ val: document.querySelector('#riskTbl input.rk[data-k="estr"][data-i="0"]').value, st: state.riskRanges.r.estr[0] }));
  ok('Edición por teclado de rango negativo (-12): foco conservado al escribir y valor aplicado al confirmar', focusedWhileTyping && after.st === -12 && after.val === '-12', { before, after, focusedWhileTyping });
  // --- Monte Carlo
  await page.selectOption('#mcN', { index: 0 }).catch(() => {});
  const mcN = await page.$eval('#mcN', s => s.value);
  await page.click('#btnMC'); await page.waitForTimeout(2500);
  const mc = await page.evaluate(() => { const m = state.mc; return m ? { base: m.base, mean: m.mean, sd: m.sd, p10: m.P(10), p50: m.P(50), p90: m.P(90), min: m.min, max: m.max, n: m.s.length, B: R.B } : null; });
  out.mc = Object.assign({ mcN }, mc);
  ok('MC: P10 ≤ P50 ≤ P90 y base = B', mc && mc.p10 <= mc.p50 && mc.p50 <= mc.p90 && near(mc.base, mc.B, 1e-6), mc);
  const mcDist = await page.evaluate(() => state.mc.dist || 'tri');
  if (mcDist === 'pert') ok('MC beta-PERT: media ≈ esperado PERT de la tabla', mc && Math.abs((mc.mean - mc.base) / mc.base * 100 - pert.cDet) < 1.0, { mcMeanPct: (mc.mean - mc.base) / mc.base * 100, pertPct: pert.cDet });
  else ok('MC: media ≈ media triangular (no PERT) → documentar/corregir', mc && Math.abs((mc.mean - mc.base) / mc.base * 100 - pert.triMeanPct) < 1.5, { mcMeanPct: (mc.mean - mc.base) / mc.base * 100, triMeanPct: pert.triMeanPct, pertPct: pert.cDet });
  const map = await page.evaluate(() => { const el = document.querySelector('#pertMap'); return el ? { svg: !!el.querySelector('svg.pert'), rows: el.querySelectorAll('svg.pert polygon').length, txt: el.textContent.length } : null; });
  ok('Mapa de puntos PERT renderizado (COES)', map && map.svg && map.rows >= 8, map);
  if (await page.$('#mcDist')) { await page.selectOption('#mcDist', 'tri'); await page.click('#btnMC'); await page.waitForTimeout(2000);
    const mcT = await page.evaluate(() => ({ dist: state.mc.dist, meanPct: (state.mc.mean - state.mc.base) / state.mc.base * 100 }));
    ok('MC triangular: media ≈ (Mín+Base+Máx)/3', mcT.dist === 'tri' && Math.abs(mcT.meanPct - pert.triMeanPct) < 1.5, { mcT, triMeanPct: pert.triMeanPct });
    await page.selectOption('#mcDist', 'pert'); }
  // --- escalamiento
  ok('ESC: Σ montos por grupo = esc', c.escSum == null || near(c.escSum, c.esc, 1e-6), { escSum: c.escSum, esc: c.esc });
  ok('ESC: Σ pesos A_g = A', c.wSum == null || near(c.wSum, c.A, 1e-6), { wSum: c.wSum, A: c.A });
  ok('ESC: Σ pesos por año = 1', c.ySum == null || near(c.ySum, 1, 1e-9), { ySum: c.ySum });
  // año de precios 2028 → escalamiento debe bajar (base más cercana a la ejecución)
  const esc26 = c.escPct;
  const esc28 = await page.evaluate(async () => { PRICE.state.year = 2028; PRICE.recalcAll(); await new Promise(r => setTimeout(r, 300)); return { pct: R.escDet ? R.escDet.pct : null, escF: R.escF, year: PRICE.year }; });
  ok('Año de precios 2028: factor de actualización > 1 y escalamiento a ejecución menor', esc28.escF > 1 && esc28.pct != null && esc28.pct < esc26, { esc26, esc28 });
  await page.evaluate(async () => { PRICE.state.year = 2026; PRICE.recalcAll(); await new Promise(r => setTimeout(r, 300)); });
  // --- informe
  await page.click('#tabs button[data-t="informe"]'); await page.waitForTimeout(1500);
  const inf = await page.evaluate(() => { const t = document.querySelector('#informe').textContent; const E = Math.round(R.E).toLocaleString('en-US'); return { hasE: t.includes(E), E, h2: [...document.querySelectorAll('#informe h2')].map(h => h.textContent).slice(0, 14) }; });
  ok('Informe A muestra E del estimado', inf.hasE, inf);
  // --- JSON export consistency
  const js = await page.evaluate(() => JSON.stringify({ E: R.E, B: R.B, esc: ESC.export ? !!ESC.export(R) : null, pr: !!PRICE.export }));
  ok('Exportación JSON disponible (ESC.export, PRICE.export)', /true/.test(js), js);
  // --- niveles / órdenes de magnitud
  const levels = [[0.38, 'BT'], [10, 'MT'], [13.2, 'MT'], [22.9, 'MT'], [33, 'MT'], [60, 'AT'], [138, 'AT'], [220, 'AT'], [500, 'EAT']];
  out.levels = [];
  for (const [kv, L] of levels) {
    await page.evaluate(k => selectKv(k), kv); await page.waitForTimeout(900);
    const cc = await chain();
    const chk = near(cc.A, cc.d1 + cc.d2) && near(cc.B, cc.A + cc.esc + cc.risk) && near(cc.C, cc.B + cc.cont) && near(cc.E, cc.C + cc.D) && near(cc.sumPk, cc.B, 1e-6) && (cc.escSum == null || near(cc.escSum, cc.esc, 1e-6));
    out.levels.push({ kv, L, mode: cc.mode, E: Math.round(cc.E), usdKm: Math.round(cc.E / cc.km), km: cc.km, escPct: cc.escPct, chainOK: chk, sumPk: Math.round(cc.sumPk), B: Math.round(cc.B) });
    ok(`Cadena y paquetes · ${kv} kV (${cc.mode})`, chk, { kv, sumPk: cc.sumPk, B: cc.B, pk: cc.pk });
  }
  // --- Osinergmin: tabla PERT, edición por teclado, MC
  await page.evaluate(() => selectKv(60)); await page.waitForTimeout(900);
  await page.click('#tabs2 button[data-t="oriesgo"]'); await page.waitForTimeout(600);
  const pertB = await page.evaluate(() => { const rows = [...document.querySelectorAll('#oRiskTbl tbody tr')]; const num = s => parseFloat(String(s).replace(/[^\d.-]/g, '')) || 0; const tot = rows.find(r => /Estimado base/.test(r.textContent)); const tds = tot ? [...tot.children].map(t => t.textContent) : []; return { totB: num(tds[1]), B: R2.B, kpi: document.querySelector('#oRiskSum .kpi .v').textContent }; });
  ok('Osinergmin: tabla PERT Base (B) = R2.B', Math.abs(pertB.totB - pertB.B) < 2, pertB);
  await page.click('#oRiskTbl input.rk[data-i="0"]', { clickCount: 3 }); await page.keyboard.type('-9'); await page.waitForTimeout(200); const focB = await page.evaluate(() => document.activeElement && document.activeElement.classList.contains('rk') && document.activeElement.value === '-9'); await page.keyboard.press('Tab'); await page.waitForTimeout(400);
  const afterB = await page.evaluate(() => { const i = document.querySelector('#oRiskTbl input.rk[data-i="0"]'); return { val: i.value, st: oState.riskRanges.r[i.dataset.k][0] }; });
  ok('Osinergmin: edición por teclado de rango negativo (-9): foco conservado y valor aplicado al confirmar', focB && afterB.st === -9, Object.assign({ focB }, afterB));
  const mapB = await page.evaluate(() => { const el = document.querySelector('#oPertMap'); return el ? { svg: !!el.querySelector('svg.pert'), rows: el.querySelectorAll('svg.pert polygon').length } : null; });
  ok('Mapa de puntos PERT renderizado (Osinergmin)', mapB && mapB.svg && mapB.rows >= 4, mapB);
  await page.click('#oBtnMC'); await page.waitForTimeout(2500);
  const mcB = await page.evaluate(() => { const m = oState.mc; return m ? { base: m.base, mean: m.mean, p10: m.P(10), p50: m.P(50), p90: m.P(90), B: R2.B } : null; });
  ok('Osinergmin MC: P10 ≤ P50 ≤ P90 y base = B', mcB && mcB.p10 <= mcB.p50 && mcB.p50 <= mcB.p90 && near(mcB.base, mcB.B, 1e-6), mcB);
  // --- informe B
  await page.click('#tabs2 button[data-t="oinforme"]'); await page.waitForTimeout(1500);
  const infB = await page.evaluate(() => { const t = document.querySelector('#oInforme') ? document.querySelector('#oInforme').textContent : document.body.textContent; return { hasE: t.includes(Math.round(R2.E).toLocaleString('en-US')) }; });
  ok('Informe B muestra E del estimado', infB.hasE, infB);
  // --- Subestaciones (espacio C)
  await page.evaluate(() => document.querySelector('#segObra button[data-v="se"]').click()); await page.waitForTimeout(1200);
  const chainSe = async () => page.evaluate(() => { const X = R3; const pk = riskPackagesSe(X); const e = X.escDet; return { mode: APP_MODE, kv: X.inp.kv, tech: X.inp.tech, cfg: X.inp.cfg, A: X.A, d12: X.directo + X.indirecto, B: X.B, esc: X.esc, risk: X.risk, C: X.C, cont: X.cont, E: X.E, D: X.D, phase: X.inp.phase, contPct: X.inp.cont, sumPk: pk.reduce((a, p) => a + p.base, 0), escSum: e ? e.byGroup.reduce((a, g) => a + g.esc, 0) : null, wSum: e ? e.byGroup.reduce((a, g) => a + g.W, 0) : null, bays: X.nBays, missing: X.missing, rows: X.rows.map(r => r.key + ':' + (r.mod ? r.mod.code : 'bdme')), coes: X.coesEq, usdBay: X.usdBay }; });
  for (const [kv, tech] of [[60, 'AIS'], [60, 'GIS'], [138, 'AIS'], [138, 'GIS'], [220, 'AIS'], [220, 'GIS'], [500, 'AIS'], [500, 'GIS']]) {
    await page.evaluate(k => selectKv(k), kv); await page.waitForTimeout(500);
    await page.evaluate(t => document.querySelector(`#segSTech button[data-v="${t}"]`).click(), tech); await page.waitForTimeout(700);
    const c = await chainSe();
    const okc = c.mode === 'se' && c.kv === kv && c.tech === tech && near(c.A, c.d12) && near(c.B, c.A + c.esc + c.risk) && near(c.C, c.B + c.cont) && near(c.cont, c.B * c.contPct / 100) && near(c.E, c.C + c.D) && near(c.sumPk, c.B, 1e-6) && (c.escSum == null || near(c.escSum, c.esc, 1e-6)) && (c.wSum == null || near(c.wSum, c.A, 1e-6)) && c.bays > 0 && c.missing.length === 0;
    out.se.push({ kv, tech, E: Math.round(c.E), usdBay: Math.round(c.usdBay || 0), rows: c.rows, missing: c.missing });
    ok(`SE ${kv} kV ${tech}: cadena, Σ paquetes = B, escalamiento y cobertura de módulos`, okc, c);
  }
  // módulos correctos por tensión (ningún módulo de otra tensión)
  const badKv = out.se.filter(s => s.rows.some(r => { const code = r.split(':')[1]; if (code === 'bdme') return false; const k = code.match(/^[CTR]\d?-?(\d{1,2})/); return false; }));
  const kvMatch = await page.evaluate(() => { const bad = []; for (const kv of [60, 138, 220, 500]) { selectKv(kv); R3.rows.forEach(r => { if (r.mod && r.mod.kv !== kv) bad.push(kv + ':' + r.mod.code); }); } return bad; });
  ok('SE: los módulos seleccionados tienen la tensión de la subestación', kvMatch.length === 0, kvMatch);
  // informe C, mapa PERT y MC
  await page.evaluate(() => selectKv(220)); await page.waitForTimeout(600);
  await page.click('#tabs3 button[data-t="sriesgo"]'); await page.waitForTimeout(500); await page.click('#sBtnMC'); await page.waitForTimeout(2500);
  const mcC = await page.evaluate(() => ({ dist: sState.mc.dist, meanPct: (sState.mc.mean - sState.mc.base) / sState.mc.base * 100, base: sState.mc.base, B: R3.B, map: !!document.querySelector('#sPertMap svg.pert') }));
  ok('SE MC beta-PERT y mapa de puntos', mcC.map && near(mcC.base, mcC.B, 1e-6) && mcC.meanPct > 2 && mcC.meanPct < 9, mcC);
  await page.click('#tabs3 button[data-t="sinforme"]'); await page.waitForTimeout(1500);
  const infC = await page.evaluate(() => ({ hasE: document.querySelector('#sInforme').textContent.includes(Math.round(R3.E).toLocaleString('en-US')), h2: document.querySelectorAll('#sInforme h2').length }));
  ok('Informe C (subestación) muestra E y secciones', infC.hasE && infC.h2 >= 8, infC);
  // base COES SE: 318 módulos y suma de ítems
  const base = await page.evaluate(() => ({ n: SE_MODS.length, kv: [...new Set(SE_MODS.map(m => m.kv))].sort((a, b) => a - b), types: new Set(SE_MODS.map(m => m.type)).size }));
  ok('Base COES SE embebida: 318 módulos, 4 tensiones', base.n === 318 && base.kv.join() === '60,138,220,500', base);
  // --- v11: en modo SE, los cambios del proyecto (clase, programa) recalculan la subestación y la cabecera sigue siendo la del espacio SE
  await page.evaluate(() => selectKv(138)); await page.waitForTimeout(700);
  const pb = await page.evaluate(() => ({ E: R3.E, cls: R3.inp.cls, esc: R3.esc }));
  await page.selectOption('#pClass', '4'); await page.waitForTimeout(900);
  const pa = await page.evaluate(() => ({ mode: APP_MODE, cls: R3.inp.cls, cont: R3.inp.cont, contExp: CLASSES[4].cont, chipModule: document.querySelector('#chipModule').textContent, chipLevel: document.querySelector('#chipLevel').textContent, kvOn: [...document.querySelectorAll('#segKvAll button.on')].map(b => b.dataset.v).join(), kv: R3.inp.kv, E: R3.E }));
  ok('Modo SE: el cambio de clase recalcula la subestación y la cabecera sigue en SE', pa.mode === 'se' && pa.cls === 4 && pa.cont === pa.contExp && /^COES SE/.test(pa.chipModule) && /^SE/.test(pa.chipLevel) && pa.kvOn === String(pa.kv) && pa.E !== pb.E, { pb, pa });
  await page.selectOption('#pClass', '3'); await page.waitForTimeout(700);
  const e0 = await page.evaluate(() => R3.esc);
  await page.evaluate(() => { const e = document.querySelector('#pStart'); e.value = '2030-01'; e.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(900);
  const e1 = await page.evaluate(() => ({ esc: R3.esc, chip: document.querySelector('#chipModule').textContent, desc: PROJ.describe() }));
  ok('Modo SE: el programa de ejecución recalcula el escalamiento de la subestación', e1.esc > e0 && /^COES SE/.test(e1.chip), { e0, e1 });
  await page.evaluate(() => { const e = document.querySelector('#pStart'); e.value = '2027-10'; e.dispatchEvent(new Event('change', { bubbles: true })); }); await page.waitForTimeout(700);
  await page.evaluate(() => { const set = (id, v) => { const e = document.querySelector(id); e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); }; set('#sNL', '4'); }); await page.waitForTimeout(600);
  await page.evaluate(() => document.querySelector('#btnReset').click()); await page.waitForTimeout(900);
  const rs = await page.evaluate(() => ({ nL: R3.inp.nL, mode: APP_MODE, kv: R3.inp.kv }));
  ok('Modo SE: «Restablecer» devuelve los valores por defecto de la subestación', rs.mode === 'se' && rs.nL === 2, rs);
  // --- v11: referencias de mercado Perú (Invierte.pe + SEACE) en subestaciones
  const rd = await page.evaluate(() => {
    const TC = REFS.meta.tc || {}, CPI = REFS.meta.cpi || {};
    const conv = REFSE.rows.filter(r => r.src === 'invierte' || !/D[OÓ]LAR/i.test(r.mon || '')).map(r => { const y = r.year in TC ? r.year : 2026; const yc = r.year in CPI ? r.year : 2026; const exp = r.soles / TC[y] * CPI[2026] / CPI[yc] / 1.18; return Math.abs(exp - r.usd26x) / Math.max(1, r.usd26x); });
    return { nSe: REFSE.rows.length, nInv: REFSE.rows.filter(r => r.src === 'invierte').length, nSea: REFSE.rows.filter(r => r.src === 'seace').length, nLin: REFS.rows.length,
      badKv: REFSE.rows.filter(r => !(r.kv >= 33)).length, badUsd: REFSE.rows.filter(r => !(r.usd26x > 0)).length, maxConvErr: Math.max(...conv), nConv: conv.length,
      mvaOk: REFSE.rows.filter(r => r.usdMva26x).every(r => Math.abs(r.usdMva26x - r.usd26x / r.mva) <= 1.5), fuentes: (REFSE.meta.fuentes || []).join(' | ') };
  });
  ok('Referencias Perú embebidas: SE ≥ 33 kV (Invierte.pe + SEACE) y líneas', rd.nSe >= 100 && rd.nInv > 0 && rd.nSea > 0 && rd.nLin >= 1000 && rd.badKv === 0 && rd.badUsd === 0 && /Invierte/.test(rd.fuentes) && /SEACE/.test(rd.fuentes), rd);
  ok('Conversión S/ → USD 2026 sin IGV (TC del año, CPI-U, ÷ 1.18) y USD/MVA', rd.maxConvErr < 0.002 && rd.mvaOk, { maxConvErr: rd.maxConvErr, n: rd.nConv, mvaOk: rd.mvaOk });
  await page.evaluate(() => selectKv(60)); await page.waitForTimeout(600);
  await page.evaluate(() => { const set = (id, v) => { const e = document.querySelector(id); e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }; set('#sNTr', '1'); set('#sMva', '25'); }); await page.waitForTimeout(900);
  const rb = await page.evaluate(() => { const b = REFSE.bench(R3.inp.kv, R3.inp.nueva); const v = b.list.map(r => r.usdMva26x).filter(x => x > 0).sort((a, c) => a - c); const m = v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2;
    const txt = document.querySelector('#sRefBench').innerText; const mine = Math.round(R3.E / R3.mvaTot);
    return { n: v.length, med: b.sMva.med, medIndep: m, hasMine: txt.includes(mine.toLocaleString('en-US')), svg: !!document.querySelector('#sRefBench svg'), basis: b.basis, kv: R3.inp.kv, mva: R3.mvaTot }; });
  ok('Benchmark USD/MVA del Resumen (mediana reproducible y estimado marcado)', rb.n >= 4 && near(rb.med, rb.medIndep, 1e-9) && rb.hasMine && rb.svg, rb);
  await page.click('#tabs3 button[data-t="srefs"]'); await page.waitForTimeout(900);
  const rt = await page.evaluate(() => { const el = document.querySelector('#refsC'); return { rows: el.querySelectorAll('tbody tr').length, filters: el.querySelectorAll('[data-f]').length, svgs: el.querySelectorAll('svg').length, pts: el.querySelectorAll('svg circle').length, est: !!el.querySelector('svg polygon'), n: REFSE.filtered({ kv: R3.inp.kv }).length }; });
  ok('Pestaña «Referencias Perú» (SE): filtros, KPI, gráficos y tabla', rt.rows === Math.min(rt.n, 150) && rt.filters >= 7 && rt.svgs >= 2 && rt.pts > 0 && rt.est, rt);
  await page.selectOption('#refsC select[data-f="grp"]', 'all'); await page.selectOption('#refsC select[data-f="scope"]', 'all'); await page.selectOption('#refsC select[data-f="kind"]', 'all'); await page.waitForTimeout(500);
  const rall = await page.evaluate(() => ({ rows: document.querySelectorAll('#refsC tbody tr').length, n: REFSE.rows.filter(r => (r.year || 0) >= REFSE.state.from).length }));
  ok('Filtros «Todos» muestran todas las referencias desde el año filtro', rall.rows === Math.min(rall.n, 150), rall);
  await page.evaluate(() => Object.assign(REFSE.state, { grp: 'auto', scope: 'SET', kind: 'nueva+amp' }));
  await page.click('#tabs3 button[data-t="sinforme"]'); await page.waitForTimeout(1200);
  const ric = await page.evaluate(() => [...document.querySelectorAll('#sInforme h2')].some(h => /Referencias de mercado Perú/.test(h.textContent)));
  ok('Informe C incluye «Referencias de mercado Perú»', ric, ric);
  const fr = await page.evaluate(async () => { const r = V3._dbg().renderer; const f0 = r.info.render.frame; await new Promise(res => setTimeout(res, 1200)); return { f0, f1: r.info.render.frame, mode: APP_MODE }; });
  ok('Visor 3D en pausa mientras está oculto (espacio SE)', fr.mode === 'se' && fr.f1 === fr.f0, fr);
  // ===== v12: subestación 3D paramétrica y configuraciones por tensión =====
  await page.click('#tabs3 button[data-t="sexec"]'); await page.waitForTimeout(900);
  const s3=[];
  for (const [kv, tech] of [[60, 'AIS'], [138, 'GIS'], [220, 'AIS'], [500, 'GIS']]) {
    await page.evaluate(k => selectKv(k), kv); await page.waitForTimeout(700); await page.evaluate(t => document.querySelector(`#segSTech button[data-v="${t}"]`).click(), tech); await page.waitForTimeout(1200);
    s3.push(await page.evaluate(() => { const L = SUB3D.last; const d = SUB3D._dbg(); return { kv: R3.inp.kv, tech: R3.inp.tech, mva: R3.inp.mva, kind: R3.inp.trKind, cells: L && L.info.cells.length, bays: R3.nBays, area3d: L && L.info.area, area: R3.com.area, kids: d.root.children.length, hud: (document.getElementById('subhud') || {}).innerText.slice(0, 60) }; }));
  }
  out.v12.sub3d = s3;
  ok('v12 · Subestación 3D se genera para 60/138/220/500 kV AIS y GIS con tantas celdas como el estimado', s3.every(r => r.cells === r.bays && r.kids > 20 && r.area3d > 0), s3);
  ok('v12 · Plataforma 3D del mismo orden que el área estimada (0.3–3×) en subestación nueva', s3.every(r => r.area3d / r.area > 0.3 && r.area3d / r.area < 3), s3.map(r => ({ kv: r.kv, ratio: +(r.area3d / r.area).toFixed(2) })));
  ok('v12 · Configuración típica por tensión al cambiar kV (500 kV → 300 MVA en banco; 60 kV → 25 MVA trifásico)', s3.find(r => r.kv === 500).mva === 300 && s3.find(r => r.kv === 500).kind === 'bank' && s3.find(r => r.kv === 60).mva === 25, s3.map(r => [r.kv, r.mva, r.kind]));
  await page.evaluate(() => selectKv(220)); await page.waitForTimeout(600); await page.evaluate(() => document.querySelector('#segSTech button[data-v="AIS"]').click()); await page.waitForTimeout(900);
  const bkC = await page.evaluate(() => { const b = SIMPLE.buckets(R3); return { sum: b.reduce((a, o) => a + o.v, 0), E: R3.E, dsum: SIMPLE.drivers(R3).tot, directo: R3.directo }; });
  ok('v12 · Resultado SE: Σ ítems = E y rubros del directo ≈ directo', near(bkC.sum, bkC.E, 1e-9) && bkC.dsum > 0.8 * bkC.directo && bkC.dsum <= bkC.directo * 1.001, bkC);
  await page.evaluate(() => { SIMPLE.printExec(); }); await page.waitForTimeout(900); await page.evaluate(() => document.body.classList.add('print-exec'));
  await page.emulateMedia({ media: 'print' }); const pdfC = await page.pdf({ format: 'A4', printBackground: true, margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' } }); await page.emulateMedia({ media: 'screen' }); await page.evaluate(() => document.body.classList.remove('print-exec'));
  const pagesC = (pdfC.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
  ok('v12 · Informe ejecutivo SE de una página', pagesC === 1, { pagesC });
  await page.evaluate(() => document.querySelector('#segObra button[data-v="lt"]').click()); await page.waitForTimeout(1000);
  await page.evaluate(() => selectKv(60)); await page.waitForTimeout(800);
  // --- v11: referencias Perú en líneas (BDME)
  await page.evaluate(() => selectKv(22.9)); await page.waitForTimeout(900);
  await page.click('#tabs2 button[data-t="orefs"]'); await page.waitForTimeout(900);
  const rl = await page.evaluate(() => { const el = document.querySelector('#refsB'); const b = REFS.bench(R2.inp.kv); return { kv: R2.inp.kv, rows: el.querySelectorAll('tbody tr').length, svgs: el.querySelectorAll('svg').length, nb: b.s.n, usdKm: Math.round(R2.usdKmProj || R2.usdKm) }; });
  ok('Pestaña «Referencias Perú» en líneas (BDME 22.9 kV)', rl.rows > 0 && rl.svgs >= 1 && rl.nb >= 5, rl);
  await page.click('#tabs2 button[data-t="oinforme"]'); await page.waitForTimeout(1200);
  const rib = await page.evaluate(() => [...document.querySelectorAll('#oInforme h2')].some(h => /Referencias de mercado Perú/.test(h.textContent)));
  ok('Informe B incluye referencias de mercado cuando n ≥ 5', rib, rib);
  await page.click('#tabs2 button[data-t="oexec"]'); await page.waitForTimeout(800);
  const bkB = await page.evaluate(() => { const b = SIMPLE.buckets(R2); return { sum: b.reduce((a, o) => a + o.v, 0), E: R2.E, dsum: SIMPLE.drivers(R2).tot, directo: R2.d1, hasE: document.querySelector('#execB').innerText.includes(Math.round(R2.E / 1e3).toLocaleString('en-US')), viewer: (document.getElementById('viewer') || { parentElement: {} }).parentElement.id }; });
  ok('v12 · Resultado BDME: Σ ítems = E, rubros ≈ directo, E visible y BIM montado en el resultado', near(bkB.sum, bkB.E, 1e-9) && bkB.dsum > 0.8 * bkB.directo && bkB.dsum <= bkB.directo * 1.001 && bkB.hasE && bkB.viewer === 'bimSlotExec', bkB);
  await page.click('#tabs2 button[data-t="oresumen"]'); await page.waitForTimeout(500);
  await page.evaluate(() => selectKv(60)); await page.waitForTimeout(800);
  // --- persistencia y móvil
  await page.reload({ waitUntil: 'load' }); await page.waitForTimeout(1500);
  const pers = await page.evaluate(() => ({ mode: APP_MODE, kv: (APP_MODE === 'osi' ? R2 : R).inp.kv }));
  ok('Persistencia tras recarga (modo y kV)', pers.mode === 'osi' && pers.kv === 60, pers);
  await page.setViewportSize({ width: 390, height: 844 }); await page.waitForTimeout(700);
  const mob = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  ok('Móvil 390 px: sin desplazamiento horizontal', mob.sw <= mob.cw + 1, mob);
  await page.setViewportSize({ width: 1500, height: 1000 });
  ok('Sin errores JS en consola', out.errors.length === 0, out.errors.slice(0, 8));
  await browser.close();
  out.summary = { total: out.checks.length, failed: out.checks.filter(c => !c.ok).length };
  console.log(JSON.stringify(out, null, 1));
})().catch(e => { console.error('FATAL', e); process.exit(1); });
