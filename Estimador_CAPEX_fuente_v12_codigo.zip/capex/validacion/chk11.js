const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'}); await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  const g=()=>page.evaluate(()=>APP_MODE==='osi'? {kv:R2.inp.kv,E:Math.round(R2.E),reg:Math.round(R2.reg),usdKm:Math.round(R2.usdKm),N:R2.L.N,dirKm:Math.round(R2.L.directo/R2.inp.km),escF:+R2.L.escF.toFixed(3)} : {kv:R.inp.kv,E:Math.round(R.E),usdKm:Math.round(R.usdKm),N:R.nStruct,escF:+R.escF.toFixed(3)});
  for(const [l,kv] of [['BT','0.38'],['MT','10'],['MT','13.2'],['MT','22.9'],['MT','33'],['AT','60'],['AT','138'],['AT','220'],['EAT','500']]){ await page.click(`#segLevel button[data-l="${l}"]`); await page.waitForTimeout(500); await page.click(`#segKvAll button[data-v="${kv}"]`); await page.waitForTimeout(700); console.log(l,kv,JSON.stringify(await g())); }
  await browser.close();
})();
