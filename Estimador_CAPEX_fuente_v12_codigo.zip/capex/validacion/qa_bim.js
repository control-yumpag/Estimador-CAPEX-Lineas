// Renderiza la matriz de modelos BIM y guarda capturas etiquetadas en /home/claude/capex/qa/
const { chromium } = require('playwright');
const fs=require('fs');
const OUT='/home/claude/capex/qa'; fs.mkdirSync(OUT,{recursive:true});
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  const errs=[]; page.on('pageerror', e=>errs.push('PAGEERROR: '+e.message));
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'}); await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  const cams=(process.argv[2]||'iso,front').split(',');
  const list=[];
  async function shot(name){ const hud=await page.evaluate(()=>document.querySelector('#hud').innerText.replace(/\n/g,' | ')); for(const c of cams){ await page.evaluate(c=>{ V3.ctl.cam=c; const d=V3._dbg(); if(d.lastInfo) { /* setCam via rebuild */ } V3.rebuild(); },c); await page.waitForTimeout(700); const v=await page.$('#viewer'); await v.screenshot({path:`${OUT}/${name}_${c}.png`}); } list.push({name,hud}); console.log(name,'|',hud.slice(0,120)); }
  // ---------- Espacio A (COES) ----------
  await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(1000);
  const A=async(kv,circ,sil,type,disp)=>{ const lvl= kv>=300?'EAT':'AT'; const curL=await page.evaluate(()=>document.querySelector('#segLevel button.on').dataset.l); if(curL!==lvl){ await page.click(`#segLevel button[data-l="${lvl}"]`); await page.waitForTimeout(800); await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(600); }
    const curKv=await page.evaluate(()=>document.querySelector('#segKvAll button.on').dataset.v); if(String(kv)!==curKv){ await page.click(`#segKvAll button[data-v="${kv}"]`); await page.waitForTimeout(800); }
    const curC=await page.evaluate(()=>document.querySelector('#v3Circ button.on').dataset.v); if(curC!==circ){ await page.click(`#v3Circ button[data-v="${circ}"]`); await page.waitForTimeout(800); }
    await page.selectOption('#v3Sil',sil); await page.selectOption('#v3Type',type); await page.selectOption('#v3Disp',disp||'auto'); await page.waitForTimeout(700);
    await shot(`A_${kv}_${circ}_${sil}_${type}${disp&&disp!=='auto'?'_'+disp:''}`); };
  await A(220,'ST','celosia','S'); await A(220,'ST','celosia','A'); await A(220,'ST','celosia','T'); await A(220,'ST','celosia','S','vertical'); await A(220,'ST','celosia','S','horizontal');
  await A(220,'ST','bandera','S'); await A(220,'ST','bandera','T'); await A(220,'ST','gato','S'); await A(220,'ST','gato','T'); await A(220,'ST','portico','S'); await A(220,'ST','portico','T'); await A(220,'ST','mono','S'); await A(220,'ST','mono','T'); await A(220,'ST','hmono','S'); await A(220,'ST','hmono','T');
  await A(220,'DT','celosia','S'); await A(220,'DT','celosia','A'); await A(220,'DT','celosia','T'); await A(220,'DT','tonel','S'); await A(220,'DT','tonel','T'); await A(220,'DT','danubio','S'); await A(220,'DT','danubio','T'); await A(220,'DT','mono','S'); await A(220,'DT','mono','T'); await A(220,'DT','hmono','S');
  await A(500,'ST','celosia','S'); await A(500,'ST','celosia','A'); await A(500,'ST','celosia','T'); await A(500,'ST','gato','S'); await A(500,'ST','gato','A'); await A(500,'ST','gato','T'); await A(500,'ST','portico','S'); await A(500,'ST','portico','T'); await A(500,'ST','vsl','S'); await A(500,'ST','mono','S'); await A(500,'ST','hmono','S');
  await A(138,'ST','celosia','S'); await A(138,'DT','celosia','S');
  // ---------- Espacio B (Osinergmin) ----------
  const B=async(kv,mat,terna,sil,type,tag)=>{ const lvl= kv<1?'BT':kv<35?'MT':'AT'; const curL=await page.evaluate(()=>document.querySelector('#segLevel button.on').dataset.l); const curKv=await page.evaluate(()=>document.querySelector('#segKvAll button.on').dataset.v);
    if(curL!==lvl||String(kv)!==curKv){ await page.click(`#segLevel button[data-l="${lvl}"]`); await page.waitForTimeout(700); await page.click(`#segKvAll button[data-v="${kv}"]`); await page.waitForTimeout(900); }
    await page.selectOption('#oMat',mat); await page.waitForTimeout(300); const curT=await page.evaluate(()=>document.querySelector('#segOTerna button.on').dataset.v); if(curT!==terna){ await page.click(`#segOTerna button[data-v="${terna}"]`); await page.waitForTimeout(500); }
    await page.selectOption('#bSil',sil); await page.selectOption('#bType',type); await page.waitForTimeout(700);
    await shot(`B_${kv}_${mat}_${terna}_${sil}_${type}${tag?'_'+tag:''}`); };
  await B(60,'TA','S','celosia','S'); await B(60,'TA','S','celosia','A'); await B(60,'TA','S','celosia','T'); await B(60,'TA','D','celosia','S'); await B(60,'TA','S','bandera','S'); await B(60,'TA','S','portico','S');
  await B(60,'PA','S','mono','S'); await B(60,'PA','S','mono','T'); await B(60,'PA','S','hmono','S'); await B(60,'PA','D','mono','S');
  await B(60,'PC','S','poste','S'); await B(60,'PC','S','poste','A'); await B(60,'PC','S','poste','T'); await B(60,'PC','D','poste','S'); await B(60,'PC','D','poste','T'); await B(60,'PC','S','compacto','S'); await B(60,'PC','S','compacto','T'); await B(60,'PC','S','hpole','S'); await B(60,'PC','S','hpole','A'); await B(60,'PC','S','hpole','T'); await B(60,'PM','S','hpole','S'); await B(60,'PM','S','poste','S');
  await B(33,'PC','S','poste','S'); await B(33,'PC','S','poste','T'); await B(33,'PC','D','poste','S'); await B(33,'PC','S','compacto','S'); await B(33,'PC','S','hpole','S');
  await B(22.9,'PC','S','poste','S'); await B(22.9,'PC','S','poste','A'); await B(22.9,'PC','S','poste','T'); await B(22.9,'PC','M','poste','S'); await B(22.9,'PC','M','poste','T'); await B(22.9,'PC','S','compacto','S'); await B(22.9,'PC','S','compacto','T'); await B(22.9,'PC','S','hpole','S'); await B(22.9,'PC','S','hpole','T'); await B(22.9,'PM','S','poste','S'); await B(22.9,'PM','S','poste','T');
  await B(10,'PM','S','poste','S'); await B(10,'PC','S','compacto','S');
  await B(0.38,'PC','S','bt','S'); await B(0.38,'PC','S','bt','A'); await B(0.38,'PC','S','bt','T'); await B(0.38,'PM','S','bt','S');
  fs.writeFileSync(`${OUT}/list.json`,JSON.stringify(list,null,1));
  console.log('ERRORS', errs.length, errs.slice(0,6));
  await browser.close();
})();
