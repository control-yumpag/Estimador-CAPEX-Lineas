const { chromium } = require('playwright'); const fs=require('fs');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'}); await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  await page.click('#segLevel button[data-l="EAT"]'); await page.waitForTimeout(900);
  await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(800);
  { const c=await page.evaluate(()=>document.querySelector('#v3Circ button.on').dataset.v); if(c!=='ST'){ await page.click('#v3Circ button[data-v="ST"]'); await page.waitForTimeout(900); } }
  const type=process.argv[2]||'S';
  await page.selectOption('#v3Sil','vsl'); await page.selectOption('#v3Type',type); await page.waitForTimeout(800);
  const shots=[['iso',(i,Ht)=>[-Ht*1.1,Ht*0.7,Ht*1.3],(i,Ht)=>[0,Ht*0.5,0]],['front',(i,Ht)=>[0,Ht*0.55,Ht*1.9],(i,Ht)=>[0,Ht*0.5,0]],['side',(i,Ht)=>[Ht*1.9,Ht*0.55,0],(i,Ht)=>[0,Ht*0.5,0]],['head',(i,Ht)=>[-Ht*0.5,Ht*1.05,Ht*0.75],(i,Ht)=>[0,Ht*0.86,0]],['headfront',(i,Ht)=>[0,Ht*0.9,Ht*0.95],(i,Ht)=>[0,Ht*0.86,0]],['headside',(i,Ht)=>[Ht*0.9,Ht*0.92,0],(i,Ht)=>[0,Ht*0.84,0]]];
  for(const [name,cam,tgt] of shots){
    await page.evaluate(([cam,tgt])=>{ const d=V3._dbg(); const i=d.lastInfo; const yMin=Math.min(...i.feet.map(f=>f.y)); const Ht=i.H-yMin; const c=eval(cam)(i,Ht), t=eval(tgt)(i,Ht); d.controls.target.set(...t); d.camera.position.set(...c); d.controls.update(); },[cam.toString(),tgt.toString()]);
    await page.waitForTimeout(500); const v=await page.$('#viewer'); await v.screenshot({path:`/home/claude/capex/qa/VSL_${type}_${name}.png`}); console.log(name);
  }
  console.log(await page.evaluate(()=>document.querySelector('#hud').innerText.replace(/\n/g,' | ')));
  await browser.close();
})();
