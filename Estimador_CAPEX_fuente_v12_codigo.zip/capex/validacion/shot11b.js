const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']}); const p=await b.newPage({viewport:{width:1440,height:900}});
 const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
 await p.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html',{waitUntil:'load'}); await p.waitForTimeout(1000); await p.evaluate(()=>localStorage.clear()); await p.reload({waitUntil:'load'}); await p.waitForTimeout(1500);
 await p.click('#segObra button[data-v="se"]'); await p.waitForTimeout(1200);
 await p.click('#segKvAll button[data-v="138"]'); await p.waitForTimeout(900);
 await p.evaluate(()=>{ const set=(id,v)=>{ const e=document.querySelector(id); e.value=v; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true})); }; set('#sNTr','1'); set('#sMva','50'); const n=document.querySelector('#projName')||document.querySelector('#pName'); });
 await p.waitForTimeout(900);
 // nombre del proyecto si existe el campo
 await p.evaluate(()=>{ const c=[...document.querySelectorAll('#projCard input')].find(i=>/nombre/i.test((i.closest('.field')||{}).textContent||'')); if(c){ c.value='Subestación 138/22.9 kV – ejemplo'; c.dispatchEvent(new Event('input',{bubbles:true})); c.dispatchEvent(new Event('change',{bubbles:true})); } });
 await p.waitForTimeout(800);
 console.log(await p.evaluate(()=>JSON.stringify({kv:R3.inp.kv,mva:R3.mvaTot,E:Math.round(R3.E),usdMva:Math.round(R3.usdMva),bays:R3.nBays})));
 await p.evaluate(()=>window.scrollTo(0,0)); await p.screenshot({path:'/home/claude/capex/cap/Subestacion_Resumen_138kV.png', fullPage:true});
 await p.click('#tabs3 button[data-t="sceldas"]'); await p.waitForTimeout(800); await p.screenshot({path:'/home/claude/capex/cap/Subestacion_Celdas_138kV.png', fullPage:false});
 await p.click('#tabs3 button[data-t="srefs"]'); await p.waitForTimeout(900); await p.screenshot({path:'/home/claude/capex/cap/Subestacion_Referencias_Peru_138kV.png', fullPage:false});
 await p.click('#tabs3 button[data-t="sriesgo"]'); await p.waitForTimeout(600); await p.click('#sBtnMC'); await p.waitForTimeout(3000); await p.screenshot({path:'/home/claude/capex/cap/Subestacion_Riesgo_PERT_138kV.png', fullPage:true});
 await p.click('#tabs3 button[data-t="sbase"]'); await p.waitForTimeout(1200); await p.screenshot({path:'/home/claude/capex/cap/Subestacion_Base_COES_318_modulos.png', fullPage:false});
 await p.click('#tabs3 button[data-t="sinforme"]'); await p.waitForTimeout(1500);
 await p.emulateMedia({media:'print'}); await p.pdf({path:'/home/claude/capex/cap/Informe_ejemplo_SE_138kV_v11.pdf', format:'A4', printBackground:true, margin:{top:'12mm',bottom:'12mm',left:'12mm',right:'12mm'}}); await p.emulateMedia({media:'screen'});
 // línea 22.9 kV referencias
 await p.click('#segObra button[data-v="lt"]'); await p.waitForTimeout(1000); await p.evaluate(()=>selectKv(22.9)); await p.waitForTimeout(1200);
 await p.click('#tabs2 button[data-t="orefs"]'); await p.waitForTimeout(900); await p.screenshot({path:'/home/claude/capex/cap/Lineas_Referencias_Peru_22.9kV.png', fullPage:false});
 console.log('ERR',errs); await b.close(); })();
