const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  const errs=[]; page.on('console', m=>{ if(['error'].includes(m.type())&&!/ERR_TUNNEL|net::/.test(m.text())) errs.push(m.type()+': '+m.text()); }); page.on('pageerror', e=>errs.push('PAGEERROR: '+e.message));
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'});
  await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  const hud=()=>page.evaluate(()=>document.querySelector('#hud').innerText.replace(/\n/g,' | ').slice(0,150));
  const shot=async(name)=>{ const v=await page.$('#viewer'); await v.screenshot({path:`/home/claude/capex/s9_${name}.png`}); };
  const opts=async(id)=>page.evaluate(id=>[...document.querySelectorAll(`#${id} option`)].map(o=>o.value).join(','),id);
  // Space A 220 DT: sil options + danubio, bandera (ST), hmono
  await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(1000);
  console.log('220 DT opts', await opts('v3Sil'));
  for(const s of ['danubio','hmono']){ await page.selectOption('#v3Sil',s); await page.waitForTimeout(900); console.log('220 DT',s, await hud()); await shot('220DT_'+s); }
  await page.click('#v3Circ button[data-v="ST"]'); await page.waitForTimeout(900); console.log('220 ST opts', await opts('v3Sil'));
  for(const s of ['bandera','hmono']){ await page.selectOption('#v3Sil',s); await page.waitForTimeout(900); console.log('220 ST',s, await hud()); await shot('220ST_'+s); }
  await page.click('#segLevel button[data-l="EAT"]'); await page.waitForTimeout(1200); console.log('500 opts', await opts('v3Sil'), await hud());
  // Space B: 60 kV
  await page.click('#segLevel button[data-l="AT"]'); await page.waitForTimeout(600); await page.click('#segKvAll button[data-v="60"]'); await page.waitForTimeout(1200);
  console.log('60 opts', await opts('bSil'), await hud());
  for(const s of ['hpole','compacto','bandera','celosia']){ await page.selectOption('#bSil',s); await page.waitForTimeout(900); console.log('60',s, await hud()); await shot('60_'+s); }
  await page.selectOption('#oMat','PM'); await page.selectOption('#bSil','hpole'); await page.waitForTimeout(900); console.log('60 PM hpole', await hud()); await shot('60_PM_hpole');
  await page.selectOption('#bType','T'); await page.waitForTimeout(900); console.log('60 PM hpole T', await hud()); await shot('60_PM_hpole_T');
  await page.selectOption('#bType','S'); await page.selectOption('#oMat','PA'); await page.selectOption('#bSil','hmono'); await page.waitForTimeout(900); console.log('60 PA hmono', await hud()); await shot('60_PA_hmono');
  // MT 22.9
  await page.click('#segLevel button[data-l="MT"]'); await page.waitForTimeout(1000); console.log('22.9 opts', await opts('bSil'), await hud());
  for(const s of ['compacto','hpole']){ await page.selectOption('#bSil',s); await page.waitForTimeout(900); console.log('22.9',s, await hud()); await shot('229_'+s); }
  await page.selectOption('#bType','A'); await page.selectOption('#bSil','compacto'); await page.waitForTimeout(900); console.log('22.9 compacto A', await hud()); await shot('229_compacto_A'); await page.selectOption('#bType','S');
  // BT
  await page.click('#segLevel button[data-l="BT"]'); await page.waitForTimeout(1000); console.log('BT opts', await opts('bSil'), await hud()); await shot('BT_S');
  await page.selectOption('#bType','T'); await page.waitForTimeout(900); console.log('BT T', await hud()); await shot('BT_T');
  await page.selectOption('#bType','A'); await page.selectOption('#oMat','PM'); await page.waitForTimeout(900); console.log('BT A PM', await hud()); await shot('BT_A_PM');
  await page.selectOption('#bType','S');
  // OBJ export (intercept download)
  const dl=await Promise.all([page.waitForEvent('download',{timeout:5000}).catch(()=>null), page.click('#bObj')]);
  console.log('OBJ download', dl[0]? dl[0].suggestedFilename() : 'none');
  await page.screenshot({path:'/home/claude/capex/s9_BT_page.png'});
  console.log('ERRORS', errs.length, errs.slice(0,10));
  await browser.close();
})();
