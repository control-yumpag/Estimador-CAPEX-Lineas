const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']}); const p=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[]; p.on('pageerror',e=>errs.push(e.message)); p.on('console',m=>{ if(m.type()==='error'&&!/net::|fonts/.test(m.text())) errs.push(m.text()); });
 await p.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html',{waitUntil:'load'}); await p.waitForTimeout(1200); await p.evaluate(()=>localStorage.clear()); await p.reload({waitUntil:'load'}); await p.waitForTimeout(1500);
 await p.click('#tabs button[data-t="riesgo"]'); await p.waitForTimeout(600);
 await p.click('#btnMC'); await p.waitForTimeout(2500);
 const el=await p.$('#pertMap'); await el.scrollIntoViewIfNeeded(); await p.waitForTimeout(300);
 await (await p.$('#pertMap')).screenshot({path:'/home/claude/capex/s10_pertmap_A.png'});
 await p.screenshot({path:'/home/claude/capex/s10_riesgo_A.png', fullPage:true});
 // Osinergmin 60 kV
 await p.evaluate(()=>selectKv(60)); await p.waitForTimeout(900); await p.click('#tabs2 button[data-t="oriesgo"]'); await p.waitForTimeout(600);
 await p.click('#oBtnMC'); await p.waitForTimeout(2500);
 const el2=await p.$('#oPertMap'); await el2.scrollIntoViewIfNeeded(); await p.waitForTimeout(300);
 await el2.screenshot({path:'/home/claude/capex/s10_pertmap_B.png'});
 // informe A con sección PERT
 await p.evaluate(()=>selectKv(220)); await p.waitForTimeout(900);
 await p.click('#tabs button[data-t="informe"]'); await p.waitForTimeout(1500);
 const h2=await p.evaluate(()=>[...document.querySelectorAll('#informe h2')].map(h=>h.textContent));
 console.log('h2', JSON.stringify(h2));
 await p.emulateMedia({media:'print'}); await p.pdf({path:'/home/claude/capex/s10_informeA.pdf', format:'A4', printBackground:true, margin:{top:'12mm',bottom:'12mm',left:'12mm',right:'12mm'}}); await p.emulateMedia({media:'screen'});
 // móvil: mapa
 await p.setViewportSize({width:390,height:844}); await p.click('#tabs button[data-t="riesgo"]'); await p.waitForTimeout(800);
 const el3=await p.$('#pertMap'); await el3.scrollIntoViewIfNeeded(); await p.waitForTimeout(300); await el3.screenshot({path:'/home/claude/capex/s10_pertmap_mobile.png'});
 console.log('errors',errs); await b.close(); })();
