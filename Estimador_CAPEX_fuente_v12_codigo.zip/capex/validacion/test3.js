const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1440,height:1000}});
  const errs=[]; page.on('console', m=>{ if(['error'].includes(m.type())&&!/ERR_TUNNEL|net::/.test(m.text())) errs.push(m.type()+': '+m.text()); }); page.on('pageerror', e=>errs.push('PAGEERROR: '+e.message));
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html#coes', {waitUntil:'load'}); await page.waitForTimeout(1200);
  await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(1200);
  const sum=()=>page.evaluate(()=>document.querySelector('#planSum').innerText.split('\n').slice(0,12).join(' | '));
  console.log('220:', await sum());
  // ternas desde la pestaña
  await page.click('#v3Circ button[data-v="ST"]'); await page.waitForTimeout(800);
  console.log('ST chip', await page.evaluate(()=>document.querySelector('#chipModule').innerText), await page.evaluate(()=>document.querySelector('#hud').innerText.split('\n')[0]));
  // 60 kV postes
  await page.click('#segKvAll button[data-v="138"]'); await page.waitForTimeout(800);
  await page.selectOption('#selStruct','POSTE').catch(()=>{}); await page.waitForTimeout(800);
  console.log('60:', await page.evaluate(()=>document.querySelector('#hud').innerText.split('\n').slice(0,2).join(' | ')), await sum());
  // 500 kV VSL
  await page.click('#segLevel button[data-l="EAT"]'); await page.waitForTimeout(800);
  console.log('500 struct opts', await page.evaluate(()=>Array.from(document.querySelectorAll('#selStruct option')).map(o=>o.value)));
  await page.selectOption('#selStruct','ST-VSL').catch(e=>console.log('no vsl')); await page.waitForTimeout(800);
  console.log('500:', await page.evaluate(()=>document.querySelector('#hud').innerText.split('\n').slice(0,2).join(' | ')));
  await page.screenshot({path:'/home/claude/capex/shot_bim_500.png', clip:{x:360,y:380,width:1080,height:620}});
  // plan: usar en el estimado
  await page.click('#segLevel button[data-l="AT"]'); await page.waitForTimeout(800); await page.click('#tabs button[data-t="3d"]'); await page.waitForTimeout(800);
  await page.click('#planUse'); await page.waitForTimeout(800);
  console.log('after use:', await page.evaluate(()=>({span:document.querySelector('#inSpan').value, km:document.querySelector('#inKm').value, mix:[document.querySelector('#inPSusp').value,document.querySelector('#inPAng').value,document.querySelector('#inPAnc').value], E:R.E})));
  // edit a span in table -> warning
  await page.fill('#planTbl .pl[data-i="2"]','900'); await page.dispatchEvent('#planTbl .pl[data-i="2"]','change'); await page.waitForTimeout(500);
  console.log('edit:', await sum());
  await page.click('#planTbl .pins[data-i="2"]'); await page.waitForTimeout(400); console.log('insert:', (await sum()).slice(0,140));
  await page.click('#planClear'); await page.waitForTimeout(400); console.log('min:', (await sum()).slice(0,160));
  await page.click('#planGen'); await page.waitForTimeout(400); console.log('gen:', (await sum()).slice(0,120));
  // mobile
  await page.setViewportSize({width:390,height:844}); await page.waitForTimeout(600);
  console.log('mobile sw', await page.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})));
  console.log('ERRORS:', errs);
  await browser.close();
})();
