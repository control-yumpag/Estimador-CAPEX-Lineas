const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  const errs=[]; page.on('console', m=>{ if(['error'].includes(m.type())&&!/ERR_TUNNEL|net::/.test(m.text())) errs.push(m.type()+': '+m.text()); }); page.on('pageerror', e=>errs.push('PAGEERROR: '+e.message));
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'});
  await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  const st=()=>page.evaluate(()=>({mode:APP_MODE, lvl:document.querySelector('#segLevel button.on')?.dataset.l, kvs:[...document.querySelectorAll('#segKvAll button')].map(b=>b.textContent+(b.classList.contains('on')?'*':'')).join(','), chips:[...document.querySelectorAll('.status .chip')].map(c=>c.textContent).join(' | '), hero:(document.querySelector(APP_MODE==='osi'?'#oKpis .hero':'#kpis .hero')||{}).innerText?.replace(/\n/g,' | ').slice(0,140), E: APP_MODE==='osi'? Math.round(R2.E): Math.round(R.E), usdKm: APP_MODE==='osi'? Math.round(R2.usdKm||0): Math.round(R.usdKm), hud:document.querySelector('#hud').innerText.split('\n')[0]}));
  console.log('init', JSON.stringify(await st()));
  await page.screenshot({path:'/home/claude/capex/s8_init.png'});
  // levels
  for(const l of ['EAT','MT','BT','AT']){ await page.click(`#segLevel button[data-l="${l}"]`); await page.waitForTimeout(900); console.log(l, JSON.stringify(await st())); await page.screenshot({path:`/home/claude/capex/s8_${l}.png`}); }
  // AT → 60 kV, 138
  await page.click('#segKvAll button[data-v="60"]'); await page.waitForTimeout(900); console.log('60', JSON.stringify(await st()));
  await page.click('#segKvAll button[data-v="138"]'); await page.waitForTimeout(900); console.log('138', JSON.stringify(await st()));
  // MT 13.2 and 10, MRT
  await page.click('#segLevel button[data-l="MT"]'); await page.waitForTimeout(600); await page.click('#segKvAll button[data-v="13.2"]'); await page.waitForTimeout(800); console.log('13.2', JSON.stringify(await st()));
  await page.click('#segOTerna button[data-v="M"]'); await page.waitForTimeout(600); console.log('13.2 MRT', JSON.stringify(await st()));
  await page.click('#segKvAll button[data-v="33"]'); await page.waitForTimeout(800); console.log('33', JSON.stringify(await st()));
  // BT details
  await page.click('#segLevel button[data-l="BT"]'); await page.waitForTimeout(900);
  console.log('BT boxes', await page.evaluate(()=>({bt:!document.querySelector('#oBtBox').hidden, condBT:!document.querySelector('#oCondBTBox').hidden, cond:document.querySelector('#oCondBox').hidden, guard:document.querySelector('#oGuardBox').hidden, serv:document.querySelector('#oServBox').hidden, rows:R2.L.rows.map(r=>r.k.slice(0,40)+' '+Math.round(r.sum+r.mont+r.oc)), N:R2.L.N, span:R2.inp.span, dir:Math.round(R2.L.directo), escF:R2.L.escF})));
  await page.selectOption('#oCondBT','3x70+16/50'); await page.fill('#oBtLum','0'); await page.fill('#oBtAcom','0'); await page.waitForTimeout(600); console.log('BT sin AP', JSON.stringify(await st()));
  await page.click('#segOEnv button[data-v="urbana"]'); await page.waitForTimeout(600); console.log('BT urbano', JSON.stringify(await st()));
  await page.selectOption('#oMat','PM'); await page.waitForTimeout(600); console.log('BT madera', JSON.stringify(await st()));
  await page.click('#tabs2 button[data-t="olinea"]'); await page.waitForTimeout(400); await page.screenshot({path:'/home/claude/capex/s8_BT_linea.png'});
  // price modal: year 2028 + brands
  await page.click('#btnPrecios'); await page.waitForTimeout(500); await page.screenshot({path:'/home/claude/capex/s8_modal.png'});
  await page.selectOption('#pmYear','2028'); await page.waitForTimeout(300);
  await page.selectOption('.pm-brand[data-k="cond"]','indeco'); await page.selectOption('.pm-brand[data-k="cpole"]','magra'); await page.waitForTimeout(300);
  await page.click('#pmApply'); await page.waitForTimeout(800); console.log('BT 2028 indeco', JSON.stringify(await st()));
  console.log('rows f', await page.evaluate(()=>R2.L.rows.slice(0,4).map(r=>[r.k.slice(0,30),r.grp,r.brand,+(r.fS||0).toFixed(3),+(r.fM||0).toFixed(3)])));
  // Space A with 2028 prices
  await page.click('#segLevel button[data-l="AT"]'); await page.waitForTimeout(900); console.log('AT 2028', JSON.stringify(await st()), await page.evaluate(()=>({escF:+R.escF.toFixed(4), f:Object.fromEntries(Object.entries(R.priceF).map(([k,v])=>[k,+v.toFixed(3)]))})));
  await page.click('#btnPrecios'); await page.waitForTimeout(300); await page.selectOption('#pmYear','2026'); await page.click('#pmReset'); await page.waitForTimeout(200); await page.click('#pmApply'); await page.waitForTimeout(800); console.log('AT reset', JSON.stringify(await st()));
  // informe
  await page.click('#tabs button[data-t="informe"]'); await page.waitForTimeout(1500);
  console.log('informe A', await page.evaluate(()=>({len:document.querySelector('#informe').innerHTML.length, h2:[...document.querySelectorAll('#informe h2')].map(h=>h.textContent), img:!!document.querySelector('#informe img')})));
  await page.screenshot({path:'/home/claude/capex/s8_informe.png', fullPage:true});
  await page.click('#segLevel button[data-l="MT"]'); await page.waitForTimeout(900); await page.click('#tabs2 button[data-t="oinforme"]'); await page.waitForTimeout(1200);
  console.log('informe B', await page.evaluate(()=>({len:document.querySelector('#oInforme').innerHTML.length, h2:[...document.querySelectorAll('#oInforme h2')].map(h=>h.textContent), img:!!document.querySelector('#oInforme img')})));
  await page.screenshot({path:'/home/claude/capex/s8_informeB.png', fullPage:true});
  // reload persistence
  await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500); console.log('reload', JSON.stringify(await st()));
  console.log('ERRORS', errs.length, errs.slice(0,10));
  await browser.close();
})();
