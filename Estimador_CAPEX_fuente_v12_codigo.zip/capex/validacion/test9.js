const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']});
  const page = await browser.newPage({viewport:{width:1500,height:1000}});
  const errs=[]; page.on('console', m=>{ if(['error'].includes(m.type())&&!/ERR_TUNNEL|net::/.test(m.text())) errs.push(m.type()+': '+m.text()); }); page.on('pageerror', e=>errs.push('PAGEERROR: '+e.message));
  await page.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html', {waitUntil:'load'});
  await page.waitForTimeout(1200); await page.evaluate(()=>localStorage.clear()); await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500);
  const st=()=>page.evaluate(()=>{ const X= APP_MODE==='osi'? R2 : R; return {mode:APP_MODE, chipLevel:document.querySelector('#chipLevel').textContent, projIn: document.querySelector('#projCard').parentElement.id, kv:X.inp.kv, A:Math.round(X.A), esc:Math.round(X.esc), pct:+X.escDet.pct.toFixed(3), manual:X.escDet.manual, E:Math.round(X.E), sched:PROJ.describe(), years:X.escDet.years.map(Y=>Y.y+':'+(Y.w*100).toFixed(0)).join(' '), set:X.escDet.set, ro:(document.querySelector(APP_MODE==='osi'?'#oEscRO':'#inEscRO')||{}).textContent, groups:X.escDet.byGroup.map(g=>g.g+':'+(g.share*100).toFixed(0)+'%:'+(1+g.f).toFixed(3)).join(' ')}; });
  console.log('init', JSON.stringify(await st()));
  await page.screenshot({path:'/home/claude/capex/s9_init.png'});
  // change schedule: start 2028-03, 8 months, curve campana, CRU
  await page.fill('#pStart','2028-03'); await page.dispatchEvent('#pStart','change'); await page.waitForTimeout(400);
  await page.fill('#pMonths','8'); await page.dispatchEvent('#pMonths','change'); await page.waitForTimeout(400);
  console.log('sched 2028-03 x8', JSON.stringify(await st()));
  await page.selectOption('#pIdxSet','cru'); await page.waitForTimeout(500); console.log('CRU', JSON.stringify(await st()));
    // esc tab A
  await page.click('#tabs button[data-t="esc"]'); await page.waitForTimeout(600);
  console.log('escA html', await page.evaluate(()=>({len:document.querySelector('#escA').innerHTML.length, h3:[...document.querySelectorAll('#escA h3')].map(h=>h.textContent), rows:document.querySelectorAll('#escA table.esc-tbl tbody tr').length, cols:document.querySelectorAll('#escA table.esc-tbl thead th').length})));
  await page.screenshot({path:'/home/claude/capex/s9_escA.png', fullPage:true});
  // manual override
  await page.fill('#pEscManual','5'); await page.dispatchEvent('#pEscManual','change'); await page.waitForTimeout(500); console.log('manual 5', JSON.stringify(await st()));
  await page.fill('#pEscManual',''); await page.dispatchEvent('#pEscManual','change'); await page.waitForTimeout(500); console.log('auto again', JSON.stringify(await st()));
  // class change via shared card
  await page.selectOption('#pClass','4'); await page.waitForTimeout(600); console.log('class4', await page.evaluate(()=>({chip:document.querySelector('#chipClass').textContent, inCont:document.querySelector('#inCont').value, oCont:document.querySelector('#oCont').value, clsA:R.inp.cls, clsB:R2.inp.cls})));
  await page.selectOption('#pClass','3'); await page.waitForTimeout(500);
  // switch to MT via project card
  await page.click('#segLevel button[data-l="MT"]'); await page.waitForTimeout(900); console.log('MT', JSON.stringify(await st()));
  await page.screenshot({path:'/home/claude/capex/s9_MT.png'});
  await page.click('#tabs2 button[data-t="oesc"]'); await page.waitForTimeout(600);
  console.log('escB html', await page.evaluate(()=>({len:document.querySelector('#escB').innerHTML.length, rows:document.querySelectorAll('#escB table.esc-tbl tbody tr').length})));
  await page.screenshot({path:'/home/claude/capex/s9_escB.png', fullPage:true});
  // name change propagates to both
  await page.fill('#pName','LT 60 kV Prueba'); await page.waitForTimeout(500); console.log('name', await page.evaluate(()=>({a:R.inp.name,b:R2.inp.name})));
  // BT & EAT
  await page.click('#segLevel button[data-l="BT"]'); await page.waitForTimeout(900); console.log('BT', JSON.stringify(await st()));
  await page.click('#segLevel button[data-l="EAT"]'); await page.waitForTimeout(900); console.log('EAT', JSON.stringify(await st()));
  // informe A with esc section
  await page.click('#tabs button[data-t="informe"]'); await page.waitForTimeout(1500);
  console.log('informe A', await page.evaluate(()=>({h2:[...document.querySelectorAll('#informe h2')].map(h=>h.textContent), esc:!!document.querySelector('#informe table.esc-tbl'), tl:!!document.querySelector('#informe .esc-tl')})));
  await page.emulateMedia({media:'print'}); await page.pdf({path:'/home/claude/capex/s9_informeA.pdf', format:'A4', printBackground:true, margin:{top:'12mm',bottom:'12mm',left:'12mm',right:'12mm'}}); await page.emulateMedia({media:'screen'});
  // reload persistence of project card
  await page.reload({waitUntil:'load'}); await page.waitForTimeout(1500); console.log('reload', JSON.stringify(await st()), await page.evaluate(()=>({name:document.querySelector('#pName').value,start:document.querySelector('#pStart').value,months:document.querySelector('#pMonths').value,set:document.querySelector('#pIdxSet').value})));
  // mobile
  await page.setViewportSize({width:390,height:844}); await page.waitForTimeout(600); console.log('mobile sw', await page.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})));
  console.log('ERRORS', errs.length, errs.slice(0,10));
  await browser.close();
})();
