const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']}); const p=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR '+e.message)); p.on('console',m=>{ if(m.type()==='error'&&!/net::|fonts/.test(m.text())) errs.push(m.text().slice(0,200)); });
 await p.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html',{waitUntil:'load'}); await p.waitForTimeout(1200); await p.evaluate(()=>localStorage.clear()); await p.reload({waitUntil:'load'}); await p.waitForTimeout(1500);
 console.log('errors after load', errs.length, errs);
 console.log('data', await p.evaluate(()=>JSON.stringify({refs:REFS.rows.length, refse:REFSE.rows.length, metaSe:REFSE.meta.n_invierte+'/'+REFSE.meta.n_seace})));
 // COES línea: pestaña refs
 await p.click('#tabs button[data-t="refs"]'); await p.waitForTimeout(800);
 console.log('A refs', await p.evaluate(()=>{ const el=document.querySelector('#refsA'); return JSON.stringify({on:document.querySelector('#p-refs').classList.contains('on'), rows:el.querySelectorAll('tbody tr').length, kpi:[...el.querySelectorAll('.kpi .v')].map(x=>x.textContent).join(' | '), svg:el.querySelectorAll('svg').length}); }));
 await p.screenshot({path:'/home/claude/capex/s11_refsA.png', fullPage:false});
 // filtro nivel todos
 await p.selectOption('#refsA select[data-f="lvl"]','MT'); await p.waitForTimeout(500);
 console.log('A refs MT', await p.evaluate(()=>{ const el=document.querySelector('#refsA'); return JSON.stringify({rows:el.querySelectorAll('tbody tr').length, kpi:[...el.querySelectorAll('.kpi .v')].map(x=>x.textContent).join(' | ')}); }));
 // informe A
 await p.click('#tabs button[data-t="informe"]'); await p.waitForTimeout(1200);
 console.log('A informe h2', await p.evaluate(()=>[...document.querySelectorAll('#informe h2')].map(h=>h.textContent).join(' | ')));
 await p.click('#tabs button[data-t="resumen"]'); await p.waitForTimeout(800);
 // SE
 await p.click('#segObra button[data-v="se"]'); await p.waitForTimeout(1500);
 console.log('SE resumen bench', await p.evaluate(()=>{ const el=document.querySelector('#sRefBench'); return JSON.stringify({kv:R3.inp.kv, mva:R3.mvaTot, E:Math.round(R3.E), usdMva:Math.round(R3.usdMva), svg:el.querySelectorAll('svg').length, txt:el.innerText.slice(0,400)}); }));
 await p.evaluate(()=>document.querySelector('#sRefBench').scrollIntoView()); await p.waitForTimeout(300); await p.screenshot({path:'/home/claude/capex/s11_se_refbench.png'});
 await p.click('#tabs3 button[data-t="srefs"]'); await p.waitForTimeout(900);
 const seInfo=async()=>p.evaluate(()=>{ const el=document.querySelector('#refsC'); return JSON.stringify({on:document.querySelector('#p-srefs').classList.contains('on'), rows:el.querySelectorAll('tbody tr').length, kpi:[...el.querySelectorAll('.kpi .v')].map(x=>x.textContent).join(' | '), d:[...el.querySelectorAll('.kpi .d')].map(x=>x.textContent).join(' | '), svgs:el.querySelectorAll('svg').length, pts:el.querySelectorAll('svg circle').length, est:!!el.querySelector('svg polygon')}); });
 console.log('SE refs 220?', await seInfo());
 await p.screenshot({path:'/home/claude/capex/s11_se_refs.png', fullPage:true});
 // 138 kV con transformador 50 MVA
 await p.click('#segKvAll button[data-v="138"]'); await p.waitForTimeout(1000);
 await p.fill('#sNTr','1'); await p.fill('#sMva','50'); await p.dispatchEvent('#sMva','input'); await p.waitForTimeout(900);
 console.log('SE refs 138', await seInfo(), await p.evaluate(()=>JSON.stringify({kv:R3.inp.kv,mva:R3.mvaTot,E:Math.round(R3.E)})));
 await p.screenshot({path:'/home/claude/capex/s11_se_refs138.png', fullPage:true});
 // filtros: todos los niveles, fuente seace, buscar
 await p.selectOption('#refsC select[data-f="grp"]','all'); await p.waitForTimeout(400); console.log('all', await seInfo());
 await p.selectOption('#refsC select[data-f="scope"]','all'); await p.waitForTimeout(400); console.log('all scope', await seInfo());
 await p.selectOption('#refsC select[data-f="src"]','seace'); await p.waitForTimeout(400); console.log('seace', await seInfo());
 await p.fill('#refsC input[data-f="q"]','QUENCORO'); await p.waitForTimeout(700); console.log('q', await seInfo());
 // sort
 await p.click('#refsC th[data-k="year"]'); await p.waitForTimeout(400); console.log('sorted', await p.evaluate(()=>[...document.querySelectorAll('#refsC tbody tr td:nth-child(6)')].map(t=>t.textContent).join(',')));
 // reset filters
 await p.evaluate(()=>{ Object.assign(REFSE.state,{grp:'auto',src:'all',kind:'nueva+amp',scope:'SET',q:''}); });
 // 60 kV ampliación
 await p.click('#segKvAll button[data-v="60"]'); await p.waitForTimeout(800); await p.click('#segSNueva button[data-v="0"]'); await p.waitForTimeout(900);
 console.log('SE 60 ampl', await seInfo(), await p.evaluate(()=>document.querySelector('#sRefBench').innerText.slice(0,300)));
 // informe C
 await p.click('#tabs3 button[data-t="sinforme"]'); await p.waitForTimeout(1500);
 console.log('C informe h2', await p.evaluate(()=>[...document.querySelectorAll('#sInforme h2')].map(h=>h.textContent).join(' | ')));
 // BDME
 await p.click('#segObra button[data-v="lt"]'); await p.waitForTimeout(1000); await p.click('#segLevel button[data-l="MT"]'); await p.waitForTimeout(1200);
 console.log('mode', await p.evaluate(()=>APP_MODE+' '+R2.inp.kv));
 await p.click('#tabs2 button[data-t="orefs"]'); await p.waitForTimeout(900);
 console.log('B refs', await p.evaluate(()=>{ const el=document.querySelector('#refsB'); return JSON.stringify({rows:el.querySelectorAll('tbody tr').length, kpi:[...el.querySelectorAll('.kpi .v')].map(x=>x.textContent).join(' | '), d:[...el.querySelectorAll('.kpi .d')].map(x=>x.textContent).join(' | ')}); }));
 await p.screenshot({path:'/home/claude/capex/s11_refsB.png', fullPage:false});
 await p.click('#tabs2 button[data-t="oinforme"]'); await p.waitForTimeout(1200);
 console.log('B informe h2', await p.evaluate(()=>[...document.querySelectorAll('#oInforme h2')].map(h=>h.textContent).join(' | ')));
 await p.setViewportSize({width:390,height:844}); await p.click('#tabs2 button[data-t="orefs"]'); await p.waitForTimeout(600); console.log('mobile', await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})));
 console.log('ERRORS', errs); await b.close(); })();
