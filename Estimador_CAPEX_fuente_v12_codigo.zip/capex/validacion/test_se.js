const { chromium } = require('playwright');
(async()=>{ const b=await chromium.launch({args:['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist']}); const p=await b.newPage({viewport:{width:1500,height:1000}});
 const errs=[]; p.on('pageerror',e=>errs.push('PAGEERROR '+e.message)); p.on('console',m=>{ if(m.type()==='error'&&!/net::|fonts/.test(m.text())) errs.push(m.text().slice(0,200)); });
 await p.goto('file:///mnt/user-data/outputs/Estimador_CAPEX_LT_COES.html',{waitUntil:'load'}); await p.waitForTimeout(1200); await p.evaluate(()=>localStorage.clear()); await p.reload({waitUntil:'load'}); await p.waitForTimeout(1500);
 console.log('errors after load', errs);
 // cambiar a subestación
 await p.click('#segObra button[data-v="se"]'); await p.waitForTimeout(1200);
 const st=async()=>p.evaluate(()=>({mode:APP_MODE, kv:sState.kv, E:Math.round(R3.E), A:Math.round(R3.A), bays:R3.nBays, coes:Math.round(R3.coesEq), com:Math.round(R3.com.tot), chip:document.querySelector('#chipLevel').textContent, tag:document.querySelector('#engineTag').textContent, kvbar:[...document.querySelectorAll('#segKvAll button')].map(b=>b.textContent+(b.classList.contains('on')?'*':'')).join(' '), projIn:document.querySelector('#projCard').parentElement.id, missing:R3.missing, rows:R3.rows.map(r=>r.key+':'+(r.mod?r.mod.code:'bdme')+':'+Math.round(r.tot)).join(' '), esc:R3.escDet&&R3.escDet.pct.toFixed(2), escSum:R3.escDet&&R3.escDet.byGroup.reduce((a,g)=>a+g.esc,0), escAmt:R3.esc }));
 console.log('SE init', JSON.stringify(await st()));
 await p.screenshot({path:'/home/claude/capex/s11_se_resumen.png', fullPage:true});
 // 500 kV
 await p.click('#segLevel button[data-l="EAT"]'); await p.waitForTimeout(1000); console.log('500', JSON.stringify(await st()));
 // GIS + Costa + bank
 await p.click('#segSTech button[data-v="GIS"]'); await p.waitForTimeout(600); await p.click('#segSZone button[data-v="Costa"]'); await p.waitForTimeout(600);
 await p.fill('#sNRx','1'); await p.waitForTimeout(400); await p.fill('#sNMB','1'); await p.waitForTimeout(500); console.log('500 GIS', JSON.stringify(await st()));
 // 60 kV
 await p.click('#segLevel button[data-l="AT"]'); await p.waitForTimeout(800); await p.click('#segKvAll button[data-v="60"]'); await p.waitForTimeout(1000); console.log('60', JSON.stringify(await st()));
 // pestañas
 for(const t of ['sceldas','scomunes','sesc','sriesgo','sbase','sbases','sinforme']){ await p.click(`#tabs3 button[data-t="${t}"]`); await p.waitForTimeout(900); const info=await p.evaluate(tt=>{ const el=document.querySelector('#p-'+tt); return {len:el.innerHTML.length, tables:el.querySelectorAll('table').length}; },t); console.log('tab',t,JSON.stringify(info)); await p.screenshot({path:`/home/claude/capex/s11_se_${t}.png`, fullPage:true}); }
 // MC + mapa
 await p.click('#tabs3 button[data-t="sriesgo"]'); await p.waitForTimeout(500); await p.click('#sBtnMC'); await p.waitForTimeout(2500);
 console.log('risk', await p.evaluate(()=>{ const pk=riskPackagesSe(R3); return JSON.stringify({sumPk:Math.round(pk.reduce((a,q)=>a+q.base,0)),B:Math.round(R3.B),map:!!document.querySelector('#sPertMap svg.pert'),mcMean:Math.round(sState.mc.mean)}); }));
 await p.screenshot({path:'/home/claude/capex/s11_se_riesgo_mc.png', fullPage:true});
 // informe pdf
 await p.click('#tabs3 button[data-t="sinforme"]'); await p.waitForTimeout(1500);
 console.log('informe h2', await p.evaluate(()=>[...document.querySelectorAll('#sInforme h2')].map(h=>h.textContent).join(' | ')));
 await p.emulateMedia({media:'print'}); await p.pdf({path:'/home/claude/capex/s11_informeC.pdf', format:'A4', printBackground:true, margin:{top:'12mm',bottom:'12mm',left:'12mm',right:'12mm'}}); await p.emulateMedia({media:'screen'});
 // volver a línea
 await p.click('#segObra button[data-v="lt"]'); await p.waitForTimeout(1200); console.log('back lt', await p.evaluate(()=>({mode:APP_MODE, kv:(APP_MODE==='osi'?R2:R).inp.kv, chip:document.querySelector('#chipLevel').textContent, projIn:document.querySelector('#projCard').parentElement.id})));
 // recarga: persistencia de SE
 await p.click('#segObra button[data-v="se"]'); await p.waitForTimeout(800); await p.reload({waitUntil:'load'}); await p.waitForTimeout(1800); console.log('reload', JSON.stringify(await st()));
 await p.setViewportSize({width:390,height:844}); await p.waitForTimeout(600); console.log('mobile', await p.evaluate(()=>({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})));
 console.log('ERRORS', errs); await b.close(); })();
