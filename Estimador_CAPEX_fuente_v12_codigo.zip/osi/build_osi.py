"""Construye osi.json: base depurada Osinergmin BDME para redes <= 60 kV."""
import json, re, math
import openpyxl
import numpy as np

OUT = '/home/claude/capex/osi.json'
lt = json.load(open('osi_lt.json'))
i403 = json.load(open('i403.json'))
i402 = json.load(open('i402.json'))
vig = json.load(open('vigencia.json'))
trafo = json.load(open('trafo_src.json'))

# ---------- catálogo de precios (I-402 / I-403) ----------
cat = {}
for r in i402 + i403:
    if r['code'] not in cat:
        cat[r['code']] = r
def P(code, default=None):
    r = cat.get(code)
    if r is None:
        if default is None:
            raise KeyError(code)
        return default
    return round(float(r['price']), 2)

def vigflag(code):
    v = vig.get(code)
    if not v or v.get('ymax') is None:
        return 'nd', None, v.get('n') if v else None
    y = v['ymax']; n = v.get('n', 0)
    if y >= 2018: f = 'vig'
    elif y >= 2013: f = 'rev'
    else: f = 'ant'
    return f, y, n

# ---------- servidumbre 2026 ----------
wb = openpyxl.load_workbook('serv.xlsx', data_only=True, read_only=True)
ws = wb['Servidumbre LT (2026)']
serv = {}
for r in ws.iter_rows(min_row=4, max_row=50, max_col=13, values_only=True):
    code = r[1]
    if not code or not re.match(r'^\d{3}[A-Z]{3}\d$', str(code)): continue
    num = lambda x: float(x) if isinstance(x, (int, float)) else 0.0
    serv[code] = dict(kv=int(r[2]), zona=str(r[3]).replace('  ', ' ').strip(), nEstr=num(r[4]), ancho=num(r[5]),
                      medidas=str(r[6]), areaEstr=num(r[7]), cTerreno=round(num(r[8]), 4), cAires=round(num(r[9]), 4),
                      usdKm=round(num(r[10]), 2), addEstr=round(num(r[12]), 2))
servVal = {'COR0': 1.1275, 'SIR0': 1.0444, 'SIR1': 0.6015, 'SIR2': 0.2295, 'SER0': 0.1832}
servMeta = dict(fuente='Osinergmin BDME 2026 – Costos de servidumbre unitaria de terrenos rústicos (R.M. 514-2025-EF/15, Reglamento Nacional de Tasaciones)',
                tc=3.368, r=0.0411, n=30, nota='Valor de servidumbre = VAS x FA x FD; terreno de estructuras al 100 % y aires de la faja al 10 %. Zonas urbanas: 0 en BDME (se asume vía pública).')

# ---------- módulos LT Osinergmin ----------
ZON = {'COR': 'Costa rural', 'COU': 'Costa urbana', 'SIR': 'Sierra rural', 'SIU': 'Sierra urbana', 'SER': 'Selva rural', 'SEU': 'Selva urbana'}
ALT = {'COR': {0: '0–1000 msnm'}, 'SER': {0: '0–1000 msnm'}, 'SIR': {0: '1000–3000 msnm', 1: '3001–4500 msnm', 2: '> 4500 msnm'}}
def parse_code(code):
    m = re.match(r'L[FT]-(\d{3})([A-Z]{3})(\d)(T[AM]|P[ACM])([SD])(\d)C(\d)(\d{3,4})([A-Z])', code)
    if not m: return None
    kv, zc, ai, st, td, ng, cf, cs, cl = m.groups()
    return dict(kv=int(kv), zc=zc, alt=int(ai), zona=ZON.get(zc, zc), altTxt=ALT.get(zc, {}).get(int(ai), ''), struct=st, terna=td,
                nGuard=int(ng), condFam=int(cf), condMm2=int(cs), condLbl=cl)

C1 = {70: P('C1-070'), 120: P('C1-120'), 150: P('C1-150'), 240: P('C1-240'), 300: P('C1-300'), 400: P('C1-400'), 500: P('C1-500'), 600: P('C1-600'), 700: P('C1-700')}
GUARD = P('CGACG01')
CHAIN60 = P('CA05SU2-060')
mods = []
for code, r in lt.items():
    pc = parse_code(code)
    if not pc: continue
    tg = r['totalDirecto'] + r['gg'] + r['util']
    m = dict(code=code, desc=r['desc'], **pc)
    for k in ['impor', 'nac', 'equipos', 'aranceles', 'aduanas', 'fletes', 'montaje', 'oc', 'inspPruebas', 'ingDet', 'totalDirecto', 'gg', 'util', 'totalGeneral', 'supervision', 'financieros', 'servidumbre', 'admin', 'usdKm', 'usdKmIgv']:
        m[k] = round(r[k], 2)
    m['finEff'] = round(r['financieros'] / tg, 4)
    m['fletePct'] = round(r['fletes'] / r['equipos'], 4)
    m['arancPct'] = round(r['aranceles'] / r['impor'], 4) if r['impor'] else 0
    m['aduanaPct'] = round(r['aduanas'] / r['impor'], 4) if r['impor'] else 0
    # descomposición paramétrica (solo 60 kV, torres)
    if pc['kv'] == 60 and pc['struct'] == 'TA':
        span = 300.0; nkm = 1000 / span; nt = 1 if pc['terna'] == 'S' else 2
        cond = 3 * nt * C1[pc['condMm2']] * 1.03
        guard = pc['nGuard'] * GUARD * 1.03
        ins = nkm * 3 * nt * CHAIN60
        pat = nkm * 200.0
        towers = r['equipos'] - cond - guard - ins - pat
        m['decomp'] = dict(span=span, nKm=round(nkm, 3), cond=round(cond), guard=round(guard), ins=round(ins), pat=round(pat), towers=round(towers),
                           towerUnit=round(towers / nkm), montTower=round(r['montaje'] * 0.55 / nkm), montString=round(r['montaje'] * 0.30), montOther=round(r['montaje'] * 0.15),
                           ocTower=round(r['oc'] / nkm))
    mods.append(m)
mods.sort(key=lambda m: (m['kv'], m['zc'], m['alt'], m['terna'], m['condMm2']))
print('módulos', len(mods), 'de 60 kV:', sum(1 for m in mods if m['kv'] == 60))

# ---------- porcentajes estructura Osinergmin ----------
pct = dict(gg=0.10, util=0.10, util500=0.071, sup=0.1311, sup500=0.025, ingSet=0.0386, ingLt500=0.025,
           adminLT=0.0135, adminSET=0.02135, finRate={60: 0.0269, 33: 0.0269, 138: 0.0428, 220: 0.0428, 500: 0.072},
           finMonths={60: 10, 33: 10, 138: 15, 220: 15, 500: 24}, finEff={60: 0.0122, 33: 0.0122, 138: 0.0196, 220: 0.0196, 500: 0.0299},
           igv=0.18, arancel=0.033, aduana=0.028, flete={'Costa': 0.0096, 'Sierra': 0.020, 'Selva': 0.0385},
           nota='GG y utilidad = 10 % c/u sobre montaje + obras civiles; supervisión 13.11 %, gastos administrativos (LT 1.35 %, SET 2.135 %) e intereses intercalarios (tasa 2.69 % a 10 meses en 60/33 kV → 1.22 % efectivo) sobre el total general. Fuente: Osinergmin, Criterios de cálculo de costos directos e indirectos (feb-2026) y valorizaciones BDME 2025.')

# ---------- kit de líneas <= 60 kV ----------
def item(code, qty=1, adj=None, note=None):
    f, y, n = vigflag(code)
    d = dict(code=code, desc=cat[code]['desc'], unit=cat[code]['unit'], bdme=P(code), qty=qty, flag=f, y=y, n=n)
    d['price'] = round(adj if adj is not None else P(code) * qty, 2)
    if note: d['note'] = note
    return d

structKits = {
 # kv|terna|material : {S,A,T: {price, code, desc, mont, oc, note}}
 '60|S|PA': dict(label='Postes de acero autosoportados 21 m – 60 kV simple terna (suspensión 1 poste 21/1000; ángulo 1 poste 21/2350; terminal 25/6300)', span=250,
    S=dict(sup=round(P('PA21/1000') + P('FPA21/1000') + 350), code='PA21/1000 + ferretería + crucetas', mont=1100, oc=1700), A=dict(sup=round(P('PA21/2350') + P('FPA21/1000') + 700), code='PA21/2350 + ferretería + crucetas', mont=1700, oc=2700), T=dict(sup=P('EASPA25/6300A2'), code='EASPA25/6300A2', mont=2000, oc=3300)),
 '60|D|PA': dict(label='Postes de acero autosoportados – 60 kV doble terna (áng./terminal con 2 postes)', span=250,
    S=dict(sup=P('EADPA25/1450S1'), code='EADPA25/1450S1', mont=1300, oc=1900), A=dict(sup=P('EADPA25/4150A1'), code='EADPA25/4150A1', mont=2600, oc=4300), T=dict(sup=P('EADPA25/7500A2'), code='EADPA25/7500A2', mont=3000, oc=5100)),
 '60|S|PC': dict(label='Postes de concreto armado centrifugado 21 m – 60 kV simple terna (+12 % por crucetas y aislamiento de 60 kV)', span=180,
    S=dict(sup=round(P('ECSPC21/1700S2') * 1.12), code='ECSPC21/1700S2 ×1.12', mont=900, oc=1400), A=dict(sup=round(P('PC21/2400') + P('FPC21/1700') + 1100), code='PC21/2400 + ferretería + crucetas/retenidas', mont=1400, oc=2100), T=dict(sup=round(2 * P('PC21/2400') + 2 * P('FPC21/1700') + 1600), code='2×PC21/2400 + ferretería + retenidas', mont=1700, oc=2700)),
 '60|D|PC': dict(label='Postes de concreto 25 m – 60 kV doble terna (estructuras dobles en áng./terminal; precio ×1.9 sobre simple terna, criterio experto)', span=190,
    S=dict(sup=round(P('ECSPC25/1300S1') * 1.15), code='ECSPC25/1300S1 ×1.15', mont=1000, oc=1500), A=dict(sup=round(P('ECSPC25/2800A1') * 1.9), code='ECSPC25/2800A1 ×1.9', mont=2200, oc=3400), T=dict(sup=round(P('ECSPC25/4200A1') * 1.9), code='ECSPC25/4200A1 ×1.9', mont=2600, oc=4200)),
 '60|S|PM': dict(label='Postes de madera tratada 95–100 pies – 60 kV simple terna (selva / costa)', span=180,
    S=dict(sup=P('EMD060PM95C2S1'), code='EMD060PM95C2S1', mont=650, oc=950), A=dict(sup=P('EMD060PM95C6S3'), code='EMD060PM95C6S3', mont=1200, oc=1700), T=dict(sup=P('EMD060PM95C1A2'), code='EMD060PM95C1A2', mont=1400, oc=2100)),
 '33|S|PC': dict(label='Postes de concreto 21 m – 33 kV simple terna', span=150,
    S=dict(sup=P('ECSPC21/1700S2'), code='ECSPC21/1700S2', mont=700, oc=950), A=dict(sup=round(P('PC21/2400') + P('FPC21/1700') + 900), code='PC21/2400 + ferretería + crucetas/retenidas', mont=1100, oc=1600), T=dict(sup=round(2 * P('PC21/2400') + 2 * P('FPC21/1700') + 1300), code='2×PC21/2400 + ferretería + retenidas', mont=1500, oc=2300)),
 '33|D|PC': dict(label='Postes de concreto 21 m – 33 kV doble terna (criterio experto ×1.6 / ×1.9)', span=140,
    S=dict(sup=round(P('ECSPC21/1700S2') * 1.2), code='ECSPC21/1700S2 ×1.2', mont=800, oc=1050), A=dict(sup=round((P('PC21/2400') + P('FPC21/1700') + 900) * 1.9), code='(PC21/2400 + ferr.) ×1.9', mont=1900, oc=2700), T=dict(sup=round((2 * P('PC21/2400') + 2 * P('FPC21/1700') + 1300) * 1.6), code='(2×PC21/2400 + ferr.) ×1.6', mont=2400, oc=3600)),
 '33|S|PM': dict(label='Postes de madera tratada 65–70 pies – 33 kV simple terna', span=140,
    S=dict(sup=round(P('PM65C4') + P('FPM85C4') + 260), code='PM65C4 + ferretería + cruceta', mont=500, oc=700), A=dict(sup=round(P('PM70C3') + P('FPM85C4') + 650), code='PM70C3 + ferretería + retenidas', mont=900, oc=1100), T=dict(sup=round(2 * P('PM70C1') + 2 * P('FPM85C4') + 900), code='2×PM70C1 + ferretería + retenidas', mont=1200, oc=1600)),
 '33|S|PA': dict(label='Postes de acero 21 m – 33 kV simple terna', span=200,
    S=dict(sup=round(P('PA21/1000') + P('FPA21/1000') + 320), code='PA21/1000 + ferretería + cruceta', mont=900, oc=1400), A=dict(sup=round(P('PA21/2200') + P('FPA21/1000') + 700), code='PA21/2200 + ferretería + crucetas', mont=1400, oc=2200), T=dict(sup=round(2 * P('PA21/2350') + 2 * P('FPA21/1000') + 900), code='2×PA21/2350 + ferretería', mont=1900, oc=2900)),
}
conductors = {}
for mm2 in [70, 120, 150, 240, 300, 400]:
    c = 'C1-%03d' % mm2
    f, y, n = vigflag(c)
    kgkm = {70: 193, 120: 330, 150: 412, 240: 660, 300: 825, 400: 1100}[mm2]
    conductors[mm2] = dict(code=c, desc='Conductor AAAC %d mm²' % mm2, usdKm=P(c), kgKm=kgkm, flag=f, y=y, n=n, amp={70: 230, 120: 320, 150: 370, 240: 500, 300: 580, 400: 700}[mm2])
guards = {'none': dict(code='—', desc='Sin cable de guarda', usdKm=0), 'EHS516': dict(code='CGACG01', desc='Cable de guarda AoGo 5/16" EHS', usdKm=P('CGACG01')), 'EHS38': dict(code='CGACG02', desc='Cable de guarda AoGo 3/8" EHS', usdKm=P('CGACG02'))}
insulators = {
 60: dict(chain=dict(S=item('CA05SU2-060'), A=item('CA07AN2-060')), poly=dict(S=item('AP060SU00-070'), A=item('AP060AN00-070'))),
 33: dict(chain=dict(S=item('AP033SU00-070', adj=32, note='BDME 8.22 USD/cjto (fuente 2015, un solo dato): incompatible con un aislador polimérico 33 kV con herrajes; se adopta 32 USD (mercado 2025)'),
                     A=item('AP033AN00-070', adj=38, note='BDME 9.29 USD/cjto: se adopta 38 USD (criterio experto)')),
          poly=dict(S=item('AP033SU00-070', adj=32, note='ídem'), A=item('AP033AN00-070', adj=38, note='ídem'))),
}
pat = dict(code='PT-CO035N', desc='Puesta a tierra: contrapeso copperweld N° 2 AWG (30 m por estructura) + electrodo', usdStr=round(0.03 * P('PT-CO035N') + 60), src='PT-CO035N %.0f USD/km' % P('PT-CO035N'))
lineKit = dict(structKits=structKits, conductors=conductors, guards=guards, insulators=insulators, pat=pat,
               accesorios=dict(pct=0.03, desc='Juntas, amortiguadores, señalización, numeración y ferretería menor (3 % del suministro de conductores y estructuras)'),
               montaje=dict(stringUsdKmTerna={60: 3400, 33: 2600}, otherUsdKm={60: 2400, 33: 1600}, insulPct=0.12,
                            nota='Tendido de conductores (USD/km-terna) y trabajos complementarios (aisladores, PAT, pruebas, inspección) derivados del módulo BDME LT-060 (montaje 16,064 USD/km ≈ 55 % estructuras, 30 % tendido, 15 % otros); I-401 no disponible en el extracto → valores editables.'),
               spansTA={60: 300})

# ---------- curvas de transformadores ----------
def fit(fam, ymin):
    pts = [(r['mva'], r['p1'], r['year'], r['src']) for r in trafo if r['code'].startswith(fam) and r['year'] >= ymin]
    x = np.log([p[0] for p in pts]); y = np.log([p[1] for p in pts])
    b, a = np.polyfit(x, y, 1)
    pred = np.exp(a) * np.array([p[0] for p in pts]) ** b
    sd = float(np.std(np.log(np.array([p[1] for p in pts]) / pred)))
    return dict(a=round(float(math.exp(a))), b=round(float(b), 3), n=len(pts), ymin=ymin, sdLog=round(sd, 3), pts=[dict(mva=p[0], usd=round(p[1]), y=p[2]) for p in pts])
tpd060 = fit('TPD-060MT', 2016)
tpd033 = fit('TPD-033MT', 2015)
tpt060 = fit('TPT-060MTMT', 2016)
allpts = {fam: [dict(mva=r['mva'], usd=round(r['p1']), y=r['year']) for r in trafo if r['code'].startswith(fam)] for fam in ['TPD-060MT', 'TPT-060MTMT', 'TPD-033MT']}
bdmeTr = {}
for c, r in cat.items():
    if c.startswith(('TPD-060MT', 'TPT-060MTMT', 'TPD-033MT')):
        f, y, n = vigflag(c); mva = int(c.split('-')[2])
        bdmeTr[c] = dict(mva=mva, usd=P(c), flag=f, y=y, n=n)
trafoCurves = dict(
    tpd060=dict(**{k: v for k, v in tpd060.items() if k != 'pts'}, label='60/MT kV, 2 devanados, 325 kVp', formula='USD = a · MVA^b'),
    tpd033=dict(**{k: v for k, v in tpd033.items() if k != 'pts'}, label='33/MT kV, 2 devanados, 170 kVp', formula='USD = a · MVA^b (≤ 12 MVA); sobre 12 MVA se usa 0.85 × curva 60 kV'),
    tpt060=dict(factor=1.25, n=tpt060['n'], fitA=tpt060['a'], fitB=tpt060['b'], label='60/MT/MT kV, 3 devanados', formula='1.25 × curva 60/MT (el ajuste directo con 9 datos 2016–2020 da exponente 0.155, no representativo bajo 25 MVA)'),
    pts=allpts, bdme=bdmeTr,
    nota='Curvas ajustadas por mínimos cuadrados en log-log sobre fuentes I-404 (reportes de aduanas / facturas) actualizadas por Osinergmin a la fecha base; se descartan fuentes anteriores a 2016 (2015 en 33 kV) por antigüedad y dispersión (ratio 0.5–2.0 en la serie completa). El valor consolidado BDME (I-402) promedia todas las fuentes, incluidas 2007–2013, y por ello resulta más alto en 15–40 MVA.')

# ---------- kit subestación ----------
def kit(codes):
    return [item(c, q, adj, note) for c, q, adj, note in codes]
setKit = {
 'bay60': dict(label='Bahía de línea 60 kV AIS (barra simple)', items=kit([
    ('INC060TE0325', 1, None, None), ('SLC060ES0325', 1, None, 'Seccionador de línea con cuchilla de puesta a tierra'), ('SBC060ES0325', 1, None, None), ('TCC060ES0325', 3, None, None), ('TVC060ES0325', 3, None, None), ('PRC060C20325', 3, None, None),
    ('SPSBC060', 2, None, 'Estructuras soporte (seccionadores, pararrayos, aisladores poste)'), ('SPPRC060', 3, None, None), ('SPASC060', 6, None, None), ('BCC060SIC1EDBMD', 1, None, 'Barras, conexiones y aisladores de barra'), ('POC060', 2200, None, 'Pórticos: 2,200 kg de acero galvanizado por bahía (criterio experto)'), ('CPC060LI', 1, None, 'Tablero de control, protección (87L/21/67N) y medición'), ('CCC060BP', 12, None, 'Cables de control y fuerza BT')]),
    mont=16000, oc=14000),
 'bay60T': dict(label='Bahía de transformador 60 kV AIS', items=kit([
    ('INC060TE0325', 1, None, None), ('SBC060ES0325', 1, None, None), ('TCC060ES0325', 3, None, None), ('PRC060C20325', 3, None, None), ('SPSBC060', 1, None, None), ('SPPRC060', 3, None, None), ('SPASC060', 4, None, None),
    ('BCC060SIC1EDBMD', 1, None, None), ('POC060', 1600, None, 'Pórtico de bahía de transformador'), ('CPC060TR', 1, None, 'Control, protección (87T/50-51/49) y medición'), ('CCC060BP', 12, None, None)]),
    mont=14500, oc=12500),
 'bay60C': dict(label='Acoplamiento / seccionamiento de barras 60 kV AIS (doble barra)', items=kit([
    ('INC060TE0325', 1, None, None), ('SBC060ES0325', 2, None, None), ('TCC060ES0325', 3, None, None), ('SPSBC060', 2, None, None), ('BCC060SIC1EDBMD', 1, None, None), ('POC060', 1200, None, None), ('CPC060TR', 1, 32000, 'Control y protección de acoplamiento (≈ 50 % de un tablero de transformador)'), ('CCC060BP', 8, None, None)]),
    mont=13000, oc=11000),
 'bus60': dict(label='Medición de barra 60 kV (por barra)', items=kit([('TVC060ES0325', 3, None, None), ('SBC060ES0325', 1, None, None), ('SPSBC060', 1, None, None), ('SPASC060', 3, None, None)]), mont=2500, oc=3000),
 'gis60': dict(label='Bahía GIS 60 kV (línea o transformador, barra simple)', items=kit([('MGC060SB0325', 1, None, 'Módulo encapsulado SF6 incl. interruptor, seccionadores, TC'), ('MGC060TV0325', 1, None, None), ('CNC060BP', 1, None, 'Terminal / conexión de cable'), ('CPC060LI', 1, None, None), ('CCC060BP', 10, None, None)]), mont=18000, oc=4000),
 'gis60D': dict(label='Bahía GIS 60 kV doble barra', items=kit([('MGC060DB0325', 1, None, None), ('MGC060TV0325', 1, None, None), ('CNC060BP', 1, None, None), ('CPC060LI', 1, None, None), ('CCC060BP', 10, None, None)]), mont=20000, oc=4500),
 'gis60C': dict(label='Acoplamiento GIS 60 kV', items=kit([('MGC060AL0325', 1, None, None), ('CPC060TR', 1, 32000, None), ('CCC060BP', 8, None, None)]), mont=15000, oc=3000),
 'bay33': dict(label='Bahía de línea 33 kV AIS', items=kit([
    ('INC033TE0170', 1, None, None), ('SLC033ES0170', 1, None, None), ('SBC033ES0170', 1, None, None), ('TCC033ES0170', 3, None, None), ('TVC033ES0170', 3, None, None), ('PRC033C20170', 3, None, None),
    ('SPSBC033', 1, None, None), ('SPSLC033', 1, None, None), ('SPPRC033', 3, None, None), ('POC033', 1300, None, 'Pórticos 33 kV'), ('CPC033LI', 1, None, None), ('CCC033SA', 1, None, None)]),
    barras=6000, mont=10000, oc=9000),
 'bay33T': dict(label='Bahía de transformador 33 kV AIS', items=kit([
    ('INC033TE0170', 1, None, None), ('SBC033ES0170', 1, None, None), ('TCC033ES0170', 3, None, None), ('PRC033C20170', 3, None, None), ('SPSBC033', 1, None, None), ('SPPRC033', 3, None, None), ('POC033', 1000, None, None), ('CPC033TR', 1, None, None), ('CCC033SA', 1, None, None)]),
    barras=6000, mont=9000, oc=8000),
 'cells': {
    '23|CMC': dict(label='Celdas metal-clad 22.9 kV, 125 kVp, 630 A', SA=item('CMC023SA0125'), ST=item('CMC023ST0125'), SM=item('CMC023SM0125'), DC=item('CMC023SC0125', adj=45000, note='BDME 9,500 USD (un dato, s/fecha) no es consistente con una celda de acoplamiento con interruptor; se adopta 45,000 (CMC010DC ×1.1)')),
    '10|CMC': dict(label='Celdas metal-clad 10 kV, 75 kVp, 630 A', SA=item('CMC010SA0075'), ST=item('CMC010ST0075', adj=33000, note='BDME 19,786 < celda de alimentador (30,304); una celda de llegada de transformador con TC/relé 87T no es menor que un alimentador → se adopta 33,000'), SM=item('CMC010SM0075'), DC=item('CMC010DC0125')),
    '23|CEN': dict(label='Celdas encapsuladas (GIS MT) 23 kV, 1250 A', SA=item('CEN023SA'), ST=item('CEN023ST'), SM=item('CEN023SM'), DC=item('CEN023DC')),
    '10|CEN': dict(label='Celdas encapsuladas (GIS MT) 10 kV, 1250 A', SA=item('CEN010SA', adj=45000, note='BDME 86,589 (2 datos s/fecha) duplica el valor de la celda 23 kV equivalente; se adopta 45,000'), ST=item('CEN010ST'), SM=item('CEN010SM'), DC=item('CEN010DC')),
    '33|CEN': dict(label='Celdas encapsuladas 33 kV, 1250 A', SA=item('CEN033SL'), ST=item('CEN033ST'), SM=item('CEN033SM'), DC=item('CEN033DC')),
 },
 'cellMont': 2200, 'cellOc': 1800,
 'caps': {23: dict(usdMvar=round(P('CBF023-0004-0125') / 4), src='CBF023-0004-0125 (4 MVAR) = %.0f USD' % P('CBF023-0004-0125'), flag='nd'),
          10: dict(usdMvar=6000, src='BDME CBF010-0004-0075 = %.0f USD (1,960 USD/MVAR) → inconsistente con 22.9 kV (11,472 USD/MVAR); se adopta 6,000 USD/MVAR' % P('CBF010-0004-0075'), flag='rev'),
          33: dict(usdMvar=round(P('CBF023-0004-0170') / 4 * 1.15), src='CBF023-0004-0170 ×1.15 (criterio experto)', flag='rev'),
          60: dict(usdMvar=round(P('CBF060-0020-0325') / 20), src='CBF060-0020-0325 (20 MVAR, 2020) = %.0f USD' % P('CBF060-0020-0325'), flag='vig')},
 'ssaa': {60: dict(items=kit([('TP023-100-0125', 1, None, 'Transformador SS.AA. 100 kVA'), ('BBC048-100', 1, None, 'Banco de baterías 48 Vcc + cargador')]), extra=[('Banco de baterías 110 Vcc 100 Ah + cargador redundante', 14000), ('Tableros SS.AA. CA / CC, UPS, iluminación y tomas', 21000)], mont=4500),
          33: dict(items=kit([('TP023-050-0125', 1, None, None), ('BBC048-100', 1, None, None)]), extra=[('Banco de baterías 110 Vcc 60 Ah + cargador', 9000), ('Tableros SS.AA. CA / CC, UPS, iluminación', 12000)], mont=3000)},
 'scada': {60: dict(usd=48000, desc='RTU / gateway IEC 61850-104, red LAN, HMI local, enlace de comunicaciones (radio/FO) – criterio experto; el BDME lista componentes de telecomunicaciones de bajo peso individual', mont=6000),
           33: dict(usd=26000, desc='RTU + comunicaciones (criterio experto)', mont=3500)},
 'avr': item('RBC060', note='Tablero regulador de tensión (AVR) por transformador con OLTC'),
 'trafoMont': dict(fixed=12000, perMva=350, desc='Montaje, tratamiento de aceite, pruebas y puesta en servicio del transformador: 12,000 + 350 USD/MVA'),
 'earth': dict(usdM2=22, montPct=0.6, desc='Malla de puesta a tierra: conductor Cu 70–120 mm², electrodos y soldadura exotérmica (22 USD/m² de patio, criterio experto)'),
 'oc': dict(patioM2=35, trafoFix=18000, trafoPerMva=600, controlM2=1300, controlBaseM2={60: 110, 33: 80}, cellM2=6, gisM2=1400, gisBaseM2=220, gisPerBay=55,
            canalBay=6000, canalCell=1500, fenceUsdM=160, roadsM2=22, accessUsdM=90,
            nota='Obras civiles paramétricas (el análisis de obras civiles BDME no está en el extracto): explanación y nivelación 35 USD/m², fundaciones de equipos por bahía AIS (14,000 USD en 60 kV / 9,000 en 33 kV), fundación + foso colector + muro cortafuego de transformador (18,000 + 600 USD/MVA), casa de control / sala de celdas (110 m² + 6 m²/celda a 1,300 USD/m²), canalizaciones, cerco perimétrico (160 USD/m), vías internas y drenaje (22 USD/m²), acceso vehicular (90 USD/m).'),
 'area': dict(ais60=dict(base=900, perBay=500, perTrafo=280), ais33=dict(base=600, perBay=300, perTrafo=180), gis60=dict(base=450, perBay=120, perTrafo=280)),
 'landUsdM2': dict(rural=8, urbana=60),
}

# ---------- tabla de precios depurada (<= 60 kV) ----------
EXC = re.compile(r'(138|220|500)')
SKIP = re.compile(r'^(BRI|RCC|CBC|SVC|RFC|ABO|APO|CDO|CSO|MMO|MTO|RSCO|SRCO|PMCR|CPPO|CSC|DCCO|RPTN|HARD|SOFT|SRE|JUCOACMO|SOPTAN|EQUIT|TRAON|ANTENAMO|MUX|MPLS|ODFS|FOADSS|FOOPGW|CAJAEMPFO|ACOP|FPA|FPC|FPM|JE|AM|MA|GRAN|GRSU|CGE|BRAQA|CCE|IEE|EXTMOV|EXTPOR|CAMAGN|VA|SAN|SSU|EN|ES|ESA|MENSM|REGFALLA|GABFALLAS|GABRELE|PACRES|RSU|RSC|RSCB|RSCSA|CCCB|CAJAAGRU|CONDESCARGAS|EPAA|N2X|NN|AN|SU)(?![A-Z])')
def relevant(code, r):
    if EXC.search(code): return False
    if r['cat'] in ('Teleco', 'Telecom', 'CC'): return False
    if SKIP.match(code): return False  # SVC, reactores, telecom, registradores de falla, ferretería menor
    return True
prices = []
for code, r in sorted(cat.items()):
    if not relevant(code, r): continue
    f, y, n = vigflag(code)
    fam = re.match(r'[A-Z]+', code).group(0)
    grp = 'LINEAS' if r['cat'] in ('LINEAS', 'LLTT') else 'SET'
    prices.append(dict(c=code, g=grp, d=r['desc'][:120], u=r['unit'], p=round(float(r['price']), 2), f=f, y=y, n=n))
print('precios depurados', len(prices))

depur = [
 dict(tema='Alcance', crit='Solo se conservan módulos y precios de 60 kV, 33 kV y media tensión (22.9 / 10 kV) de la BDME; se excluyen 138/220/500 kV, reactores, SVC, registradores de falla y telecomunicaciones (peso < 1 % del CAPEX en redes ≤ 60 kV).', accion='Excluido del espacio ≤ 60 kV (disponible en el espacio COES para 138–500 kV).'),
 dict(tema='Vigencia de fuentes (I-404)', crit='Cada precio consolidado se clasifica por la fecha de su fuente más reciente: Vigente (≥ 2018), Revisar (2013–2017), Antigua (< 2013), s/fecha (sin fuente identificable en el extracto). Las fuentes antiguas se actualizan por índices, pero no capturan cambios tecnológicos ni de mercado (p. ej. transformadores 2007–2013 con precios 40–90 % mayores).', accion='Las partidas Antigua/Revisar se muestran con marca y no se usan como valor por defecto cuando existe una curva o dato reciente.'),
 dict(tema='Transformadores de potencia', crit='La serie I-404 tiene 119 fuentes (2006–2023) con dispersión ×0.5–×2.0 respecto a una curva potencia. Se ajusta USD = a·MVA^b solo con fuentes ≥ 2016 (60/MT: 15 datos, 2 devanados) y ≥ 2015 (33/MT: 10 datos).', accion='Curva depurada por defecto; el valor consolidado BDME queda como referencia comparativa en la pestaña Precios.'),
 dict(tema='Datos inconsistentes', crit='Aisladores poliméricos 33 kV a 8–10 USD/conjunto, celda de acoplamiento 22.9 kV a 9,500 USD, celda de llegada de transformador 10 kV más barata que un alimentador, celda encapsulada 10 kV al doble de la de 23 kV, banco de capacitores 10 kV a 1,960 USD/MVAR: incompatibles con el alcance técnico de la partida.', accion='Se adopta un valor experto de mercado 2025 y se deja nota en la partida (editable).'),
 dict(tema='Partidas de bajo peso', crit='Ferretería individual, amortiguadores, juntas, manguitos, estructuras soporte menores y cables de BT se agregan como porcentaje (3 %) o como lote por bahía, en lugar de metrarse una a una (impacto < 0.5 % del CAPEX).', accion='Agregado en “accesorios” / “lotes por bahía”.'),
 dict(tema='Montaje y obras civiles', crit='El extracto disponible del REST_MOD_INV_2025 no incluye I-401 (APU de montaje) ni el análisis de obras civiles de subestaciones. Para líneas se deriva del módulo BDME LT-060 (montaje/estructura, tendido/km, OC/estructura); para subestaciones se usan ratios paramétricos de referencia (criterio experto) declarados en Bases.', accion='Valores editables; pendiente calibrar cuando se disponga del archivo completo.'),
 dict(tema='Servidumbre', crit='Se usa la valorización BDME 2026 (R.M. 514-2025-EF/15): terreno de estructuras al 100 % del valor y aires de la faja al 10 %. En zona urbana la BDME asume 0 (vía pública).', accion='Cálculo automático por tensión / región / altitud, editable.'),
 dict(tema='Estructura de costos', crit='Se reproduce la estructura regulatoria Osinergmin (GG 10 % y utilidad 10 % sobre montaje + OC; supervisión 13.11 %; gastos administrativos 1.35 % LT / 2.135 % SET; intereses intercalarios 2.69 % a 10 meses) y se superpone la capa de proyecto AACE (ingeniería del dueño, escalamiento, riesgos y contingencia por clase).', accion='Dos lecturas: valor regulatorio (VNR-like) y CAPEX de proyecto.'),
]

osi = dict(meta=dict(fuente='Osinergmin – Base de Datos de Módulos Estándares de Inversión para Sistemas de Transmisión (REST_MOD_INV_2025_PP), Anexos I-402/I-403/I-404, valorizaciones LT y servidumbre 2026',
                     fechaBase='2025-2026', tc=3.368, nota='Precios en USD sin IGV. Extracto parcial del archivo (1.0 MB de 8.7 MB): faltan valorizaciones de módulos SET, I-401 (montaje) y análisis de obras civiles.'),
           pct=pct, serv=serv, servVal=servVal, servMeta=servMeta, mods=mods, lineKit=lineKit, trafo=trafoCurves, setKit=setKit, prices=prices, depur=depur)
s = json.dumps(osi, ensure_ascii=False, separators=(',', ':'))
open(OUT, 'w', encoding='utf-8').write(s)
print('osi.json', len(s), 'bytes ->', OUT)

# ---------- kit subestaciones AT / EAT (138 / 220 / 500 kV) ----------
def kitc(codes):
    return [item(c, q, adj, note) for c, q, adj, note in codes]
atKit = {
 138: dict(
   bay=dict(label='Bahía de línea 138 kV AIS', items=kitc([('INC138TE0650',1,None,None),('SLC138ES0650',1,None,'con cuchilla de puesta a tierra'),('SBC138ES0650',1,None,None),('TCC138ES0650',3,None,None),('TVC138ES0650',3,None,None),('PRC138C30650',3,None,None),('SPSBC138',2,None,None),('SPPRC138',3,None,None),('SPASC138',6,None,None),('BCC138SIC1EDBMD',1,None,None),('POC138',4500,None,'pórticos 4,500 kg (criterio experto)'),('CPC138LI',1,None,None),('CCC060BP',16,None,'cables de control y fuerza')]), mont=28000, oc=25000),
   bayT=dict(label='Bahía de transformador 138 kV AIS', items=kitc([('INC138TE0650',1,None,None),('SBC138ES0650',1,None,None),('TCC138ES0650',3,None,None),('PRC138C30650',3,None,None),('SPSBC138',1,None,None),('SPPRC138',3,None,None),('SPASC138',4,None,None),('BCC138SIC1EDBMD',1,None,None),('POC138',3200,None,None),('CPC138TR',1,None,None),('CCC060BP',16,None,None)]), mont=25000, oc=22000),
   bayC=dict(label='Acoplamiento 138 kV AIS (doble barra)', items=kitc([('INC138TE0650',1,None,None),('SBC138ES0650',2,None,None),('TCC138ES0650',3,None,None),('SPSBC138',2,None,None),('BCC138SIC1EDBMD',1,None,None),('POC138',2500,None,None),('CPC138TR',1,34000,'≈ 50 % de un tablero'),('CCC060BP',10,None,None)]), mont=22000, oc=18000),
   bus=dict(label='Medición de barra 138 kV', items=kitc([('TVC138ES0650',3,None,None),('SBC138ES0650',1,None,None),('SPSBC138',1,None,None),('SPASC138',3,None,None)]), mont=5000, oc=5000),
   gis=dict(label='Bahía GIS 138 kV (barra simple)', items=kitc([('MGC138SB0650',1,None,None),('MGC138TV0650',1,None,None),('CPC138LI',1,None,None),('CCC060BP',14,None,None)]), mont=32000, oc=8000),
   gisD=dict(label='Bahía GIS 138 kV (doble barra)', items=kitc([('MGC138DB0650',1,None,None),('MGC138TV0650',1,None,None),('CPC138LI',1,None,None),('CCC060BP',14,None,None)]), mont=36000, oc=9000),
   gisT=dict(label='Bahía GIS 138 kV transformador', items=kitc([('MGC138DT0650',1,None,None),('CPC138TR',1,None,None),('CCC060BP',14,None,None)]), mont=30000, oc=8000),
   trafo=dict(two=dict(a=round(71000*1.35), b=0.551, src='1.35 × curva 60/MT (los 10 datos I-404 de 138 kV, 2007–2015, dan exponente 0.20 no representativo)', n=10, ymin=2011), three=dict(a=103205, b=0.547, src='curva 138/AT/MT y 138/MT/MT, n=10, fuentes ≥ 2013', n=10, ymin=2013)),
   avr=item('RBC138'), reactor=dict(unit='RCC138', pts={8:P('RCC138-008-0650'),10:P('RCC138-010-0650'),15:P('RCC138-015-0650')}, note='reactor trifásico 138 kV (BDME, s/fecha)'),
   ssaa=dict(sup=95000, mont=9000, desc='Transformadores SS.AA. (2), bancos 110/48 Vcc, cargadores, tableros CA/CC, UPS, grupo electrógeno 50 kVA (GEC050 6,785 USD BDME)'),
   scada=dict(sup=140000, mont=14000, desc='SCADA / sistema de automatización IEC 61850, gateway, teleprotección, comunicaciones'),
   earthM2=26, trafoMont=dict(fixed=28000, perMva=300), trafoOc=dict(fixed=45000, perMva=350),
   area=dict(ais=dict(base=2200, perBay=900, perTrafo=500), gis=dict(base=900, perBay=140, perTrafo=450)),
   oc=dict(patioM2=38, controlM2=1400, controlBase=220, gisM2=1600, gisBase=300, gisPerBay=80, canalBay=12000, fenceUsdM=170, roadsM2=25, accessUsdM=110)),
 220: dict(
   bay=dict(label='Bahía de línea 220 kV AIS', items=kitc([('INC220TE1050',1,None,'operación tripolar (uni-tripolar UE: 69,762 USD)'),('SLC220ES1050',1,None,None),('SBC220ES1050',1,None,None),('STC220ES1050',1,None,'seccionador de puesta a tierra'),('TCC220ES1050',3,None,None),('TVC220ES1050',3,None,None),('PRC220C31050',3,None,None),('SPSBC220',2,None,None),('SPPRC220',3,None,None),('SPASC220',6,None,None),('BCC220SIC1EDBMD',1,None,None),('POC220',7500,None,'pórticos 7,500 kg (criterio experto)'),('CPC220LI',1,None,None),('CCC060BP',20,None,None)]), mont=45000, oc=40000),
   bayT=dict(label='Bahía de transformador 220 kV AIS', items=kitc([('INC220TE1050',1,None,None),('SBC220ES1050',1,None,None),('TCC220ES1050',3,None,None),('PRC220C31050',3,None,None),('SPSBC220',1,None,None),('SPPRC220',3,None,None),('SPASC220',4,None,None),('BCC220SIC1EDBMD',1,None,None),('POC220',5500,None,None),('CPC220TR',1,None,None),('CCC060BP',20,None,None)]), mont=40000, oc=35000),
   bayC=dict(label='Acoplamiento 220 kV AIS (doble barra)', items=kitc([('INC220TE1050',1,None,None),('SBC220ES1050',2,None,None),('TCC220ES1050',3,None,None),('SPSBC220',2,None,None),('BCC220SIC1EDBMD',1,None,None),('POC220',4000,None,None),('CPC220TR',1,40000,'≈ 50 % de un tablero'),('CCC060BP',12,None,None)]), mont=36000, oc=30000),
   bus=dict(label='Medición de barra 220 kV', items=kitc([('TVC220ES1050',3,None,None),('SBC220ES1050',1,None,None),('SPSBC220',1,None,None),('SPASC220',3,None,None)]), mont=8000, oc=8000),
   gis=dict(label='Bahía GIS 220 kV (barra simple)', items=kitc([('MGC220SB1050',1,None,None),('MGC220TV1050',1,None,None),('CPC220LI',1,None,None),('CCC060BP',18,None,None)]), mont=60000, oc=12000),
   gisD=dict(label='Bahía GIS 220 kV (doble barra)', items=kitc([('MGC220DB1050',1,None,None),('MGC220TV1050',1,None,None),('CPC220LI',1,None,None),('CCC060BP',18,None,None)]), mont=66000, oc=13000),
   gisT=dict(label='Bahía GIS 220 kV transformador', items=kitc([('MGC220DT1050',1,None,None),('CPC220TR',1,None,None),('CCC060BP',18,None,None)]), mont=55000, oc=12000),
   gisC=dict(label='Acoplamiento GIS 220 kV', items=kitc([('MGC220AL1050',1,None,None),('CPC220TR',1,40000,None),('CCC060BP',12,None,None)]), mont=50000, oc=10000),
   trafo=dict(two=dict(a=85165, b=0.603, src='curva 220/AT y 220/MT (2 devanados), n=21, fuentes ≥ 2012', n=21, ymin=2012), three=dict(factor=1.2, src='1.2 × curva 220 de 2 devanados (fuentes 2014–2023 de 50–150 MVA)', n=15)),
   avr=item('RBC220'), reactor=None,
   ssaa=dict(sup=140000, mont=12000, desc='Transformadores SS.AA., bancos 220/48 Vcc (BBC220-200 6,873; CRC220 8,675), tableros TSC-220 / TSC-380/220 / TTA, UPS, grupo electrógeno'),
   scada=dict(sup=220000, mont=20000, desc='Sistema de automatización IEC 61850, gateway, teleprotección, registrador de fallas (RFC220 47,906), comunicaciones'),
   earthM2=28, trafoMont=dict(fixed=40000, perMva=400), trafoOc=dict(fixed=60000, perMva=450),
   area=dict(ais=dict(base=3500, perBay=1400, perTrafo=800), gis=dict(base=1200, perBay=180, perTrafo=700)),
   oc=dict(patioM2=40, controlM2=1450, controlBase=300, gisM2=1650, gisBase=380, gisPerBay=100, canalBay=18000, fenceUsdM=180, roadsM2=26, accessUsdM=120)),
 500: dict(
   bay=dict(label='Bahía de línea 500 kV AIS (interruptor y medio: 1.5 interruptores por circuito)', items=kitc([('INC500UE1550',1.5,None,'operación unipolar'),('SLC500ES1550',1,None,None),('SBC500ES1550',3,None,None),('TCC500ES1550',4.5,None,None),('TVC500ES1550',3,None,None),('PRC500C51550',3,None,None),('CPC500LI',1,None,None),('CCC060BP',30,None,None)]), barras=95000, mont=115000, oc=110000),
   bayT=dict(label='Bahía de autotransformador 500 kV (interruptor y medio)', items=kitc([('INC500UE1550',1.5,None,None),('SBC500ES1550',3,None,None),('TCC500ES1550',4.5,None,None),('PRC500C51550',3,None,None),('CPC500TR',1,None,None),('CCC060BP',30,None,None)]), barras=95000, mont=105000, oc=100000),
   bayC=None,
   bus=dict(label='Medición de barra 500 kV', items=kitc([('TVC500ES1550',3,None,None),('SBC500ES1550',1,None,None)]), mont=15000, oc=15000),
   gis=dict(label='Diámetro GIS 500 kV (interruptor y medio, 2 circuitos)', items=kitc([('MGC500IM1550',1,None,'un diámetro completo'),('CPC500LI',2,None,None),('CCC060BP',40,None,None)]), mont=160000, oc=30000, perCircuits=2),
   trafo=dict(auto=dict(a=1420000, b=0.5, ref=250, src='banco de 3 unidades monofásicas 500/220/MT (TMT-500MATMT 250 MVA: 1.30–1.50 MUSD por unidad, fuentes 2015–2024); USD_unidad = 1.42 M × (MVA_unidad/250)^0.5', n=7, ymin=2015)),
   avr=None, reactor=dict(unit='RMC500', pts={20:P('RMC500-020-1550'),28:P('RMC500-028-1550'),40:P('RMC500-040-1550')}, neutral=P('RMN500-1550'), note='banco de 3 reactores monofásicos + reactor de neutro (BDME 2023)'),
   ssaa=dict(sup=260000, mont=22000, desc='SS.AA. con TV cargable 500 kV (TVC500ES1550-100 120,000), bancos 220/48 Vcc, tableros, UPS, grupo electrógeno'),
   scada=dict(sup=380000, mont=35000, desc='Automatización IEC 61850, teleprotección, PMU, comunicaciones OPGW/MPLS'),
   earthM2=32, trafoMont=dict(fixed=60000, perMva=180), trafoOc=dict(fixed=140000, perMva=250),
   area=dict(ais=dict(base=12000, perBay=3200, perTrafo=1500), gis=dict(base=3000, perBay=400, perTrafo=1500)),
   oc=dict(patioM2=45, controlM2=1500, controlBase=450, gisM2=1750, gisBase=600, gisPerBay=160, canalBay=35000, fenceUsdM=190, roadsM2=28, accessUsdM=130)),
}
atKit['nota']='Bahías tipo con equipos I-402/I-403 (vigencia 2020–2025 en interruptores, seccionadores, TC/TV y pararrayos); montaje y obras civiles por bahía, fundación de transformadores, edificios y patio son ratios de prediseño (criterio experto) al no estar el análisis de obras civiles en el extracto.'

# ---------- kit líneas MT (22.9 / 10 kV) y subestaciones de distribución MT/BT ----------
AAAC_KG = P('AAAC')  # USD/kg
mtKit = dict(
  cond={35:dict(kgKm=96,usdKm=round(96*AAAC_KG),amp=150),50:dict(kgKm=137,usdKm=round(137*AAAC_KG),amp=190),70:dict(kgKm=193,usdKm=round(193*AAAC_KG),amp=230),95:dict(kgKm=262,usdKm=round(262*AAAC_KG),amp=280),120:dict(kgKm=330,usdKm=round(330*AAAC_KG),amp=320)},
  structs={
    'PC': dict(label='Postes CAC 13/300 – 13/400 con crucetas (armados PS/PA/PR, DGE RD 018-2003-EM)', span={22.9:150,10:110},
      S=dict(sup=780,code='CAC 13/300 + cruceta + 3 aisladores pin poliméricos + ferretería',mont=230,oc=140), A=dict(sup=1150,code='CAC 13/400 + cruceta doble + aisladores + 1 retenida',mont=320,oc=220), T=dict(sup=1650,code='CAC 13/400 + crucetas + 6 aisladores de anclaje + 2 retenidas',mont=420,oc=300)),
    'PM': dict(label='Postes de madera tratada 12 m con crucetas', span={22.9:140,10:100},
      S=dict(sup=560,code='PM 40\' cl. 5 + cruceta madera + aisladores pin',mont=200,oc=110), A=dict(sup=880,code='PM 40\' + cruceta doble + retenida',mont=280,oc=180), T=dict(sup=1350,code='PM 40\' + crucetas + anclaje + 2 retenidas',mont=380,oc=250)),
  },
  mrt=dict(structF=0.7, condF=1/3, note='MRT: monofásico con retorno total por tierra (1 conductor); estructuras más ligeras (×0.7) y puesta a tierra reforzada'),
  pat=dict(usdStr=120, every=3, note='puesta a tierra cada 3 estructuras y en todas las de anclaje'),
  montString={22.9:900,10:800}, other={22.9:600,10:500},
  serv={22.9:dict(ancho=11, usdKm=dict(Costa=980,Sierra=900,Selva=170)),10:dict(ancho=6, usdKm=dict(Costa=540,Sierra=490,Selva=95))},
  rules={22.9:dict(avg=150,rec=[120,200],max=260,min=40,clr=7.0),10:dict(avg=110,rec=[80,140],max=200,min=30,clr=6.5)},
  nota='Precios de postes CAC, crucetas, aisladores y retenidas de MT no están en el extracto BDME de transmisión (pertenecen a la base de distribución): valores de mercado 2025 (criterio experto). Conductor AAAC a 3.38 USD/kg (BDME).')
def tpprice(kv,kva):
    fam='TP023' if kv==22.9 else 'TP010'; bil='0125' if kv==22.9 else '0075'
    pts={k:P(f'{fam}-{k:03d}-{bil}') for k in [50,100,160,250,400]}
    return pts
sedKit = dict(
  trafo={22.9:tpprice(22.9,0), 10:tpprice(10,0)},
  types={
    'mono': dict(label='Monoposte (≤ 100 kVA)', maxKva=100, sup=dict(postes=560, herrajes=380, seccfus=3*P('SCC023-0125'), parar=3*P('PRC023C20125'), tableroBT=1400, pat=260), mont=900, oc=450),
    'bi':   dict(label='Biposte (160–400 kVA)', maxKva=400, sup=dict(postes=1120, herrajes=650, seccfus=3*P('SCC023-0125'), parar=3*P('PRC023C20125'), tableroBT=2200, pat=320), mont=1500, oc=900),
    'caseta': dict(label='Caseta / compacta (≥ 400 kVA, urbana)', maxKva=1000, sup=dict(celdaMT=12500, tableroBT=3800, pat=450, obraCaseta=0), mont=2600, oc=14000),
  },
  redBT=dict(usdKm=9500, desc='Red BT autoportante 3×70+N mm² con postes CAC 8/200 cada 40 m (criterio experto)'),
  nota='Transformadores de distribución TP023/TP010 50–400 kVA del BDME (vigencia 2023–2024); 500–1000 kVA extrapolados con exponente 0.75. Postes, herrajes y tableros BT: mercado 2025.')

osi['atKit']=atKit; osi['mtKit']=mtKit; osi['sedKit']=sedKit
s = json.dumps(osi, ensure_ascii=False, separators=(',', ':'))
open(OUT, 'w', encoding='utf-8').write(s)
print('osi.json (con AT/MT/SED)', len(s), 'bytes')
