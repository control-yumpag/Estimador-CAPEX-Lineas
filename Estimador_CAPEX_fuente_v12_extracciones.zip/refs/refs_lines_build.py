# -*- coding: utf-8 -*-
"""Construye /home/claude/capex/refs.json (referencias de mercado Perú para LÍNEAS y redes BT/MT/AT/EAT)
a partir de Invierte.pe (solo subprogramas de distribución, electrificación rural y transmisión) y SEACE 3.0 (obras).
Uso: python3 refs_lines_build.py invierte_energia.json seace_obras.json
"""
import json, re, sys, statistics, collections
from datetime import date
sys.path.insert(0, '/home/claude/capex')
import refs_build as RB
from refs_build import norm

SUBP_OK = re.compile(r'DISTRIBUCION DE ENERGIA|ELECTRIFICACION RURAL|TRANSMISION DE ENERGIA')
NOT_ELEC = re.compile(r'AGUA POTABLE|SANEAMIENTO|RESIDUOS|RIEGO|CARRETERA|PISTAS|VEREDAS|EDUCATIV|SALUD|HOSPITAL|COLEGIO|INSTITUCION EDUCATIVA')

def kind_of(name):
    n = norm(name)
    if re.search(r'\bSALDO\b', n): return 'saldo'
    if re.search(r'\bIOARR\b|REMODELACION|RENOVACION|REPARACION|REHABILITACION|REPOSICION|MANTENIMIENTO|REUBICACION|ADQUISICION|SUSTITUCION|OPTIMIZACION', n): return 'rehab'
    m = re.search(r'CREACION|CONSTRUCCION|INSTALACION|AMPLIACION|MEJORAMIENTO|ELECTRIFICACION', n)
    if not m: return 'otro'
    if m.group(0) == 'MEJORAMIENTO' and not re.search(r'MEJORAMIENTO Y AMPLIACION', n): return 'mejora'
    return 'nuevo'

def build_invierte(path):
    data = json.load(open(path, encoding='utf-8'))
    keep = [r for r in data['rows'] if SUBP_OK.search(norm(r.get('Subprograma') or '')) and not NOT_ELEC.search(norm(r.get('Nombre') or ''))]
    tmp = '/tmp/claude-0/-home-claude/a17ea37c-7887-5c0c-9c5c-9863d83b292d/scratchpad/inv_lines.json'
    json.dump({'rows': keep}, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False)
    out = RB.build_invierte(tmp)
    for r in out: r['kind'] = kind_of(r['name'])
    return out

def build_seace(path):
    from refs_se_build import sig_tokens, jacc
    out = [r for r in RB.build_seace(path) if r['soles'] > 0 and r['scope'] in ('linea', 'linea+SET')]
    out.sort(key=lambda r: (r.get('fecha') or '')[6:10] + (r.get('fecha') or '')[3:5] + (r.get('fecha') or '')[0:2], reverse=True)
    groups = []
    for r in out:
        tk = sig_tokens(r['name'])
        for g in groups:
            if jacc(g[0]['_tk'], tk) >= 0.7: g.append(r); break
        else: r['_tk'] = tk; groups.append([r])
    res = []
    for g in groups:
        r = g[0]; r.pop('_tk', None); r['kind'] = kind_of(r['name']); r['nconv'] = len(g); res.append(r)
    return res

KEEP = ('src', 'id', 'name', 'ent', 'dpto', 'year', 'estado', 'kv', 'km', 'kind', 'scope', 'soles', 'usd', 'usdKm26', 'desc', 'nconv')
def slim(r):
    o = {k: r[k] for k in KEEP if k in r and r[k] not in (None, '', [])}
    if 'desc' in o: o['desc'] = o['desc'][:200]
    if 'name' in o: o['name'] = o['name'][:200]
    return o

if __name__ == '__main__':
    inv = build_invierte(sys.argv[1]); sea = build_seace(sys.argv[2]) if len(sys.argv) > 2 else []
    rows = [slim(r) for r in inv + sea if r.get('kv') is not None]
    meta = {'generado': date.today().isoformat(), 'tc': RB.TC, 'cpi': RB.CPI, 'n_invierte': len(inv), 'n_seace': len(sea),
            'fuentes': ['MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública (subprogramas distribución, electrificación rural y transmisión)', 'OECE – SEACE 3.0 buscador público de procedimientos de selección (obras)'],
            'nota': 'Montos en soles de la fecha de viabilidad/convocatoria; USD con TC promedio del año (BCRP); USD 2026 por CPI-U (BLS). kV y km extraídos del nombre/descripción (heurística), validar antes de usar.'}
    json.dump({'meta': meta, 'rows': rows}, open('/home/claude/capex/refs.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    withkm = [r for r in rows if r.get('usdKm26')]
    print('rows', len(rows), 'invierte', len(inv), 'seace', len(sea), 'con km', len(withkm))
    print('niveles', collections.Counter(r['kv'] for r in rows).most_common())
    print('tipo', collections.Counter(r['kind'] for r in rows).most_common(), 'alcance', collections.Counter(r['scope'] for r in rows).most_common())
    for L in [500, 220, 138, 66, 60, 33, 22.9, 13.2, 10, 0.38]:
        v = sorted(round(r['usdKm26'] / 1.18) for r in withkm if r['kv'] == L and r['scope'] == 'linea' and r['kind'] in ('nuevo', 'mejora'))
        if v: print(L, 'n', len(v), 'mediana s/IGV', statistics.median(v), 'p25', v[len(v)//4], 'p75', v[3*len(v)//4])
