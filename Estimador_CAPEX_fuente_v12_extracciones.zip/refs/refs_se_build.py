# -*- coding: utf-8 -*-
"""Construye refs_se.json: referencias de mercado Perú para SUBESTACIONES (≥ 33 kV)
a partir de Invierte.pe (Banco de Inversiones, consulta avanzada) y SEACE 3.0 (procedimientos de obra).
Uso: python3 refs_se_build.py invierte_energia.json seace_obras.json
"""
import json, re, sys, unicodedata, statistics, collections
from datetime import date
sys.path.insert(0, '/home/claude/capex')
from refs_build import TC, CPI, norm, usd, usd26, year_of

STD = [500, 220, 138, 66, 60, 50, 33]
def kv_list(text):
    t = norm(text).replace(',', '.')
    out = set()
    for m in re.finditer(r'((?:\d{1,3}(?:\.\d{1,2})?\s*/\s*)*\d{1,3}(?:\.\d{1,2})?)\s*K\s?V\b', t):
        for p in re.findall(r'\d{1,3}(?:\.\d{1,2})?', m.group(1)):
            v = float(p)
            if 0.2 < v <= 550: out.add(v)
    return sorted(out, reverse=True)
def hv_level(kvs):
    for v in kvs:
        for L in STD:
            if abs(v - L) < 0.6 or (L == 33 and 33 <= v <= 35) or (L == 66 and abs(v - 69) < 0.6): return L
    return None
def mva_of(text):
    t = norm(text).replace(',', '.')
    vals = []
    for m in re.finditer(r'(\d{1,2})\s*X\s*(\d{1,4}(?:\.\d{1,2})?)\s*MVA', t):
        vals.append(float(m.group(1)) * float(m.group(2)))
    for m in re.finditer(r'((?:\d{1,4}(?:\.\d{1,2})?\s*[/-]\s*)*\d{1,4}(?:\.\d{1,2})?)\s*MVA\b', t):
        grp = m.group(1); pre = t[max(0, m.start() - 2):m.start()]
        if re.search(r'X\s*$', pre): continue
        nums = [float(x) for x in re.findall(r'\d{1,4}(?:\.\d{1,2})?', grp)]
        nums = [v for v in nums if 0.5 <= v <= 2000]
        if nums: vals.append(max(nums))
    return max(vals) if vals else None
SE_RE = re.compile(r'SUB\s?ESTACI|\bS\.?E\.?T\.?\b|\bSET\b|\bS\.E\.?\b|CELDA|TRANSFORMADOR|\bMVA\b|SUBESTACION DE POTENCIA|TRANSFORMACION')
LINE_RE = re.compile(r'LINEA|\bL\.?T\.?\b|SUBTRANSMISION|ALIMENTADOR')
SED_RE = re.compile(r'SUBESTACION(ES)? DE DISTRIBUCION|SUB ESTACION(ES)? DE DISTRIBUCION|SED\b|BIPOSTE|MONOPOSTE')
DIST_RE = re.compile(r'ELECTRIFICACION|REDES? (PRIMARIA|SECUNDARIA)S?|RED PRIMARIA|SISTEMA ELECTRICO RURAL|HABILITACION|CONEXIONES DOMICILIARIAS|ALUMBRADO|SERVICIO DE ENERGIA ELECTRICA MEDIANTE|SUMINISTRO DE ENERGIA ELECTRICA MEDIANTE|PEQUENO SISTEMA ELECTRICO')
POW_RE = re.compile(r'\bSET\b|S\.E\.T|POTENCIA|MVA|SUBESTACION (DE TRANSFORMACION|ELECTRICA)|(60|66|69|138|220|500)\s*K\s?V')
def is_se_project(text):
    n = norm(text)
    if not SE_RE.search(n): return False
    if DIST_RE.search(n) and not POW_RE.search(n): return False
    if SED_RE.search(n) and not POW_RE.search(n): return False
    return True
def kind_of(name):
    """Naturaleza de la inversión según el primer verbo del nombre (formato Invierte.pe)."""
    n = norm(name)
    if re.search(r'\bSALDO\b', n): return 'saldo'
    if re.search(r'\bIOARR\b|RENOVACION|REPARACION|REHABILITACION|REPOSICION|MANTENIMIENTO|REUBICACION|REMODELACION|ADQUISICION|SUSTITUCION|OPTIMIZACION', n): return 'rehab'
    m = re.search(r'CREACION|CONSTRUCCION|INSTALACION|IMPLEMENTACION|AMPLIACION|MEJORAMIENTO|REFORZAMIENTO|REPOTENCIA', n)
    if not m: return 'otro'
    v = m.group(0)
    if v == 'MEJORAMIENTO' and re.search(r'MEJORAMIENTO Y AMPLIACION', n): return 'ampliacion'
    if v in ('CREACION', 'CONSTRUCCION'): return 'nueva'
    if v in ('INSTALACION', 'IMPLEMENTACION'):
        return 'nueva' if re.search(r'(INSTALACION|IMPLEMENTACION) DE (LA |UNA )?(NUEVA )?(SUB ?ESTACION|SET\b)', n) else 'ampliacion'
    if v == 'AMPLIACION': return 'ampliacion'
    return 'mejora'
def tech_of(text):
    t = norm(text)
    return 'GIS' if re.search(r'\bGIS\b|ENCAPSULAD|AISLAD[AO] EN (GAS|SF6)', t) else ('AIS' if re.search(r'\bAIS\b|CONVENCIONAL', t) else '')

def build_invierte(path):
    rows = json.load(open(path, encoding='utf-8'))['rows']
    out = []
    for r in rows:
        sp = norm(r.get('Subprograma') or '')
        if not re.search(r'ENERG|ELECTRIF', sp) or re.search(r'GENERACION', sp): continue
        name = r.get('Nombre') or ''; alt = r.get('Alternativa') or ''
        txt = name + ' ' + alt
        if not is_se_project(name): continue
        kvs = kv_list(name) or kv_list(alt); L = hv_level(kvs)
        if not L or L < 33: continue
        monto = float(r.get('Costo') or 0) or float(r.get('MontoAlternativa') or 0)
        if monto <= 0: continue
        year = year_of(r.get('FechaViabilidad') or '') or year_of(r.get('FechaRegistro') or '')
        u = usd(monto, year); u26 = usd26(u, year)
        mva = mva_of(name) or mva_of(alt)
        rec = {'src': 'invierte', 'id': str(r.get('CodigoUnico')), 'name': name[:240], 'ent': (r.get('Pliego') or '')[:70], 'uf': (r.get('Uf') or '')[:70],
               'dpto': (r.get('LocalizacionDepartamento') or '')[:24], 'year': year, 'fecha': r.get('FechaViabilidad') or r.get('FechaRegistro') or '',
               'estado': r.get('Estado') or '', 'situ': r.get('Situacion') or '', 'kvs': kvs[:5], 'kv': L, 'sec': [v for v in kvs if v < L][:3], 'mva': mva,
               'kind': kind_of(name), 'scope': 'linea+SET' if LINE_RE.search(norm(name)) else 'SET', 'tech': tech_of(txt),
               'soles': round(monto), 'usd': round(u), 'usd26': round(u26), 'usd26x': round(u26 / 1.18), 'desc': alt[:280],
               'dev': round(float(r.get('DevAcumulado') or 0)) if r.get('DevAcumulado') else None, 'avf': r.get('avanceFisico'), 'exp': r.get('FlagExpedienteTecnico') if 'FlagExpedienteTecnico' in r else None}
        if mva: rec['usdMva26x'] = round(u26 / 1.18 / mva)
        out.append(rec)
    return out

SIG_STOP = set('DE LA EL LOS LAS DEL EN Y A PARA POR CON AL SU SUS UN UNA E O DISTRITO PROVINCIA DEPARTAMENTO REGION OBRA EJECUCION CONTRATACION PROYECTO SALDO'.split())
def sig_tokens(text):
    t = re.sub(r'\([^)]*(DERIVAD|PROCEDIMIENTO|CONVOCATORIA)[^)]*\)', ' ', norm(text))
    t = re.sub(r'(\d)([A-Z])', r'\1 \2', re.sub(r'([A-Z])(\d)', r'\1 \2', t))
    return set(w for w in re.findall(r'[A-Z0-9]+', t) if (len(w) >= 3 or w.isdigit()) and w not in SIG_STOP)
def jacc(a, b):
    return len(a & b) / max(1, len(a | b))

def build_seace(path):
    if not path: return []
    data = json.load(open(path, encoding='utf-8'))
    rows = data['rows'] if isinstance(data, dict) else data
    cand = []
    for r in rows:
        desc = r.get('desc') or ''
        if not is_se_project(desc): continue
        kvs = kv_list(desc); L = hv_level(kvs)
        if not L or L < 33: continue
        vr = (r.get('vr') or '').replace(',', '')
        try: monto = float(vr)
        except ValueError: monto = 0
        if monto <= 0: continue
        d = (r.get('fecha') or '').split(' ')[0]
        cand.append(dict(r, _d='/'.join(reversed(d.split('/'))) if d else '', _m=monto, _kvs=kvs, _L=L, _tok=sig_tokens(desc)))
    # reconvocatorias / procesos repetidos: misma obra (descripción casi igual) -> se conserva la convocatoria más reciente
    cand.sort(key=lambda r: r['_d'], reverse=True)
    groups = []
    for r in cand:
        for g in groups:
            if jacc(g[0]['_tok'], r['_tok']) >= 0.72: g.append(r); break
        else: groups.append([r])
    out = []
    for g in groups:
        r = g[0]; desc = r.get('desc') or ''; n = norm(desc); monto = r['_m']; kvs = r['_kvs']; L = r['_L']
        year = year_of(r.get('fecha') or '')
        dol = re.search(r'D[OÓ]LAR', norm(r.get('mon') or ''))
        u = monto if dol else usd(monto, year); u26 = usd26(u, year)
        mva = mva_of(desc)
        rec = {'src': 'seace', 'id': r.get('nom'), 'name': desc[:240], 'ent': (r.get('ent') or '')[:70], 'uf': '', 'dpto': '', 'year': year, 'fecha': r.get('fecha') or '',
               'estado': r.get('rein') or 'Convocatoria', 'situ': '', 'kvs': kvs[:5], 'kv': L, 'sec': [v for v in kvs if v < L][:3], 'mva': mva,
               'kind': kind_of(desc), 'scope': 'linea+SET' if LINE_RE.search(n) else 'SET', 'tech': tech_of(desc),
               'soles': round(monto * (1 if not dol else TC.get(year, 3.5))), 'usd': round(u), 'usd26': round(u26), 'usd26x': round(u26 / 1.18), 'desc': desc[:280], 'mon': r.get('mon') or '',
               'nconv': len(g), 'convs': [x.get('nom') for x in g[1:]][:4]}
        if mva: rec['usdMva26x'] = round(u26 / 1.18 / mva)
        out.append(rec)
    return out

if __name__ == '__main__':
    inv = build_invierte(sys.argv[1])
    sea = build_seace(sys.argv[2] if len(sys.argv) > 2 else None)
    rows = inv + sea
    meta = {'generado': date.today().isoformat(), 'n_invierte': len(inv), 'n_seace': len(sea),
            'fuentes': ['MEF – Banco de Inversiones (Invierte.pe), consulta avanzada pública', 'OECE – SEACE 3.0, buscador público de procedimientos de selección (obras)'],
            'nota': 'Montos con IGV a precios de la fecha de viabilidad / convocatoria; USD con TC promedio del año (BCRP); USD 2026 con CPI-U; sin IGV ÷ 1.18. kV, MVA y alcance extraídos del texto (heurística): validar en la ficha.'}
    json.dump({'meta': meta, 'rows': rows}, open('/home/claude/capex/refs_se.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print('refs_se', len(rows), 'invierte', len(inv), 'seace', len(sea))
    print('por kV', collections.Counter(r['kv'] for r in rows).most_common())
    print('alcance', collections.Counter(r['scope'] for r in rows), 'tipo', collections.Counter(r['kind'] for r in rows))
    print('fuente x tipo', collections.Counter((r['src'], r['kind']) for r in rows).most_common())
    wm = [r for r in rows if r.get('usdMva26x')]
    print('con MVA', len(wm))
    for L in (60, 138, 220):
        v = sorted(r['usdMva26x'] for r in wm if r['kv'] == L and r['scope'] == 'SET')
        if v: print(L, 'kV SET n', len(v), 'mediana USD/MVA', statistics.median(v))
