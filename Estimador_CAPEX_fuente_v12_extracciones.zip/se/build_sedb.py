import json,glob,re,collections,os
mods=[json.load(open(p,encoding='utf-8')) for p in glob.glob('/home/claude/se/json/*.json')]
def rnd(v,d=0): return None if v is None else (round(v,d) if d else round(v))
db=[]; tcs=collections.Counter(); dates=collections.Counter()
for m in mods:
    me=m['meta']; kv=me['kv']; sec=me['sec']
    if me['type']=='Banco de transformadores' and sec: kv=220
    if me['type']=='Banco de transformadores' and 'T1-50' in (m['code'] or ''): kv=500; sec=220
    it={}; tcols=None
    for k,v in m['items'].items():
        if re.match(r'^\d{1,2}(\.\d{1,2}){0,3}$',k):
            if any(x for x in (v['sup'],v['oc'],v['em'],v['tot'])): it[k]=[rnd(v['sup']),rnd(v['oc']),rnd(v['em']),rnd(v['tot']),v['d'][:70]]
        else:
            tcols=[rnd(v['sup']),rnd(v['oc']),rnd(v['em'])]
    sup=[[s['c'],s['d'][:90],s.get('u'),s.get('q'),s.get('t'),s.get('pu')] for s in m['supply'] if not s.get('cat') and (s.get('tot') or 0)>0]
    ton=sum((s.get('t') or 0)*(s.get('q') or 0) for s in m['supply'] if not s.get('cat') and (s.get('tot') or 0)>0 and str(s.get('c','')).startswith(('2.1','2.2')) and (s.get('t') or 0)<300)
    civ=[[o['c'],o['d'][:50],o['tot']] for o in m['obras'] if o.get('grp') and o['tot'] and re.match(r'^(1\.\d|2\.\d)$',o['c'])]
    tcs[m['tc']]+=1; dates[m['fecha']]+=1
    bank=me['bank']
    db.append({'id':m['id'],'n':me['n'],'code':m['code'],'t':(m['title'] or m['file'])[:120],'kv':kv,'sec':sec,'tech':me['tech'],'zone':me['zone'],'type':me['type'],'cfg':me['cfg'],'ka':me['ka'],'mva':me['mva'],'mvar':me['mvar'],'bank':bank,'tot':rnd(m['total']),'tcols':tcols,'it':it,'sup':sup,'civ':civ,'ton':round(ton,1)})
db.sort(key=lambda d:(d['kv'] or 0,d['tech'],d['type'],d['zone'] or '',d['n'] or 0))
m55=[m for m in mods if m['id']=='1hL1gZmybBpjkpQMSrkGF96xCMvMtcZdH'][0]
ref=m55['ref_comunes']
def find(g): return next((r for r in ref if r['grp']==g),None)
comunes={'nota':'Bloques de referencia 4.x (obras comunes de la subestación base) incluidos en todos los módulos COES; precios unitarios USD sin IGV, marzo 2026.',
 'plataforma':{'items':find('Plataforma Sub Estación Eléctrica')['items'],'tot':find('Plataforma Sub Estación Eléctrica')['gtot']},
 'ripio':{'items':find('Movimiento de Tierras')['items'],'tot':find('Movimiento de Tierras')['gtot']},
 'acceso':{'items':find('Camino de Acceso')['items']+find('Pavimentos')['items']+find('Cunetas')['items'],'tot':13967.18+27618.87+13993.57,'m2':817.61},
 'cerco':{'tot':1434549.47,'ml':1600,'items':[{'d':'Cerco de ladrillo caravista con cimiento corrido, columnas y vigas, tarrajeo, pintura, puertas y concertina','u':'m','q':1600,'pu':round(1434549.47/1600,2),'tot':1434549.47}]},
 'canaletas':{'items':find('Canaletas y buzones (Incluye tapas)')['items'],'tot':find('Canaletas y buzones (Incluye tapas)')['gtot'],'ml':2192},
 'vias':{'tot':5552690.39,'m2':60503.09,'items':[i for r in ref if r['grp'] in ('Pavimentos','Sardineles') for i in r['items']][3:]},
 'pat':{'items':find('Malla Puesta de Tierra')['items'],'tot':find('Malla Puesta de Tierra')['gtot'],'ml':20440.23},
 'edificio':{'tot':390368.45,'m2':207.81,'items':[{'d':'Edificio de control (obra civil completa, ~208 m² de falso piso: cimentación, estructura, techo, acabados, cisterna, instalaciones sanitarias)','u':'m²','q':207.81,'pu':round(390368.45/207.81,2),'tot':390368.45}]},
 'caseta':{'tot':147979.39,'items':[{'d':'Caseta de campo / sala de tableros (obra civil completa)','u':'glb','q':1,'pu':147979.39,'tot':147979.39}]},
 'inst':{'items':find('Instalaciones Eléctricas')['items'],'tot':find('Instalaciones Eléctricas')['gtot']},
 'patio220_montaje':{'items':find('Patio de 220kV')['items'],'tot':find('Patio de 220kV')['gtot']},
 'barras220_montaje':{'items':find('Sistema de barras en 220kV')['items'],'tot':find('Sistema de barras en 220kV')['gtot']}}
meta={'fuente':'COES – Base de Datos de Costos de Sistemas de Transmisión 2025/26, Módulos de Subestaciones (celdas AIS/GIS 60–500 kV, transformadores, bancos y reactores), 318 módulos','fecha':max(dates,key=dates.get),'tc':max(tcs,key=tcs.get),'n':len(db),'tcs':dict(tcs),'fechas':dict(dates)}
json.dump({'meta':meta,'mods':db,'comunes':comunes},open('/home/claude/capex/se_db.json','w',encoding='utf-8'),ensure_ascii=False,separators=(',',':'))
print('se_db.json', os.path.getsize('/home/claude/capex/se_db.json')/1e6,'MB')
# verificación: suma de items vs total 7.0
bad=0
for d in db:
    s=0
    for k,v in d['it'].items():
        if k in ('7.0',) or re.match(r'^\d\.0$',k) and k not in ('3.0','4.0','5.0','6.0'): continue
        if k in ('2.1','2.2','2.3'): continue
        s+=(v[3] or 0)
    if abs(s-d['tot'])>5: bad+=1; print('desvío',d['code'],round(s),d['tot'],[k for k in d['it']])
print('módulos con suma de ítems ≠ total:',bad)
