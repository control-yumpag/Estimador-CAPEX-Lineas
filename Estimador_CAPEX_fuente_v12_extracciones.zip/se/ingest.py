# -*- coding: utf-8 -*-
"""Uso: python3 ingest.py <ruta_resultado_tool> <fileId>
Decodifica el JSON {content(base64),title,...} del tool result, guarda el xlsx temporal, lo parsea con parse_se.py
y escribe /home/claude/se/json/<fileId>.json. Borra el tool result y el xlsx al terminar."""
import sys, os, json, base64, traceback
sys.path.insert(0, '/home/claude/se')
from parse_se import parse
res, fid = sys.argv[1], sys.argv[2]
os.makedirs('/home/claude/se/json', exist_ok=True); os.makedirs('/home/claude/se/tmp', exist_ok=True)
o = json.load(open(res, encoding='utf-8'))
title = o.get('title') or fid
data = base64.b64decode(o['content'])
xp = '/home/claude/se/tmp/' + fid + '.xlsx'
open(xp, 'wb').write(data)
try:
    d = parse(xp, title); d['id'] = fid; d['bytes'] = len(data)
    json.dump(d, open('/home/claude/se/json/' + fid + '.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print('OK', fid, title[:70], 'total', d.get('total'), 'items', len(d.get('items', {})), 'supply', len(d.get('supply', [])))
except Exception as e:
    traceback.print_exc(); print('FAIL', fid, title[:70])
finally:
    for p in (xp, res):
        try: os.remove(p)
        except OSError: pass
