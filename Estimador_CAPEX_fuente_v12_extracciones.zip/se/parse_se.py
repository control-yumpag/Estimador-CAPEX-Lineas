# -*- coding: utf-8 -*-
"""Parsea un módulo COES de subestación (xlsx) → dict compacto.
Uso: python3 parse_se.py archivo.xlsx > salida.json
"""
import sys, re, json, datetime, unicodedata
import openpyxl

def norm(s):
    s = unicodedata.normalize('NFD', str(s or ''))
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn')

def num(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool): return float(v)
    return None

def clean(v):
    if isinstance(v, float): return round(v, 2)
    if isinstance(v, datetime.datetime): return v.strftime('%Y-%m-%d')
    return v

def meta_from_title(fname, title):
    t = norm(fname + ' ' + (title or ''))
    m = {}
    mm = re.match(r'\s*(\d+)', fname); m['n'] = int(mm.group(1)) if mm else None
    mk = re.search(r'(500|220|138|60)\s*kV', t, re.I); m['kv'] = int(mk.group(1)) if mk else None
    m['tech'] = 'GIS' if re.search(r'\bGIS\b', t) else 'AIS'
    mz = re.search(r'(Costa|Sierra|Selva)', t, re.I); m['zone'] = mz.group(1).capitalize() if mz else None
    tl = t.lower()
    if 'banco de transformadores' in tl: m['type'] = 'Banco de transformadores'
    elif 'modulo de transformador' in tl or 'autotransformador' in tl: m['type'] = 'Transformador'
    elif 'modulo de reactor' in tl and 'celda' not in tl: m['type'] = 'Reactor'
    elif 'reactor linea' in tl or 'reactor de linea' in tl: m['type'] = 'Celda reactor de línea'
    elif 'reactor' in tl: m['type'] = 'Celda reactor de barra'
    elif 'transformacion' in tl: m['type'] = 'Celda de transformación'
    elif 'acople' in tl: m['type'] = 'Celda de acople'
    elif 'medicion' in tl: m['type'] = 'Celda de medición de barras'
    elif 'linea' in tl: m['type'] = 'Celda de línea'
    else: m['type'] = 'Otro'
    if re.search(r'2\s*tercios', tl): m['cfg'] = '2/3 (interruptor y medio, 2 interruptores)'
    elif re.search(r'1\s*tercio', tl): m['cfg'] = '1/3 (interruptor y medio, 1 interruptor)'
    elif re.search(r'-DT\b|doble barra con secc(?:ionador)? de transferencia|-DB-ST\b', t, re.I): m['cfg'] = 'Doble barra + seccionador de transferencia'
    elif re.search(r'-DB\b|-D-|doble barra', t, re.I): m['cfg'] = 'Doble barra'
    elif re.search(r'-SB\b|-S-|simple barra', t, re.I): m['cfg'] = 'Simple barra'
    else: m['cfg'] = None
    mka = re.search(r'(31\.5|40|63)\s*kA', t); m['ka'] = float(mka.group(1)) if mka else None
    mmva = re.search(r'(\d+(?:\.\d+)?)\s*MVA\b', t, re.I); m['mva'] = float(mmva.group(1)) if mmva else None
    mmvar = re.search(r'(\d+(?:\.\d+)?)\s*MVAR', t, re.I); m['mvar'] = float(mmvar.group(1)) if mmvar else None
    mx = re.search(r'3\s*x\s*(\d+(?:\.\d+)?)', t, re.I); m['bank'] = float(mx.group(1)) if mx else None
    msec = re.search(r'220-(138|60)\s*kV', t, re.I); m['sec'] = int(msec.group(1)) if msec else None
    return m

def parse(path, fname=None):
    fname = fname or path.split('/')[-1]
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    out = {'file': fname, 'sheets': wb.sheetnames}
    # ---- Módulo (resumen)
    if 'Módulo' in wb.sheetnames or 'Modulo' in wb.sheetnames:
        ws = wb['Módulo' if 'Módulo' in wb.sheetnames else 'Modulo']
        items = {}; title = None; code = None; tc = None; fecha = None
        for row in ws.iter_rows(values_only=True):
            vals = [v for v in row if v not in (None, '')]
            if not vals: continue
            s0 = str(vals[0]).strip()
            if title is None and len(vals) == 1 and len(s0) > 15: title = s0; continue
            if s0.lower().startswith('código') or s0.lower().startswith('codigo'):
                code = str(vals[1]).strip() if len(vals) > 1 else None; continue
            if s0.lower().startswith('tipo de cambio'):
                tc = num(vals[1]) if len(vals) > 1 else None
                for v in vals:
                    if isinstance(v, datetime.datetime): fecha = v.strftime('%Y-%m-%d')
                continue
            if re.match(r'^\d+(\.\d+)*$', s0) and len(vals) >= 2:
                desc = str(vals[1]).strip(); nums = [num(v) for v in vals[2:]]; nums = [x for x in nums if x is not None]
                # columnas: sup, oc, em, total — se identifican por posición en la fila completa
                full = list(row);
                try:
                    i0 = next(i for i, v in enumerate(full) if v == vals[0])
                except StopIteration: i0 = 0
                cells = full[i0 + 2:i0 + 6]
                sup, oc, em, tot = [num(c) for c in (cells + [None] * 4)[:4]]
                if tot is None and nums: tot = nums[-1]
                items[s0] = {'d': desc[:110], 'sup': sup, 'oc': oc, 'em': em, 'tot': tot}
        out.update({'title': title, 'code': code, 'tc': tc, 'fecha': fecha, 'items': items})
        t7 = items.get('7.0', {}).get('tot')
        out['total'] = t7
    # ---- Suministro: A código, B descripción, C unidad, D cantidad, E ton, F costo unitario, G total; categorías con total en H
    if 'Suministro' in wb.sheetnames:
        ws = wb['Suministro']; sup = []; cat = None
        for row in ws.iter_rows(values_only=True):
            r = list(row) + [None] * 10
            a, b, c, d, e, f, g, h = r[:8]
            sa = str(a).strip() if a not in (None, '') else ''
            if sa and re.match(r'^\d+\.\d+$', sa) and isinstance(b, str) and num(d) is None:
                cat = sa
                tot = num(h) if num(h) is not None else num(g)
                sup.append({'c': sa, 'd': b.strip()[:80], 'cat': True, 'tot': clean(tot) if tot else 0, 'ton': clean(num(e)) if num(e) else None})
                continue
            if isinstance(b, str) and num(d) is not None:
                qty = num(d); tot = num(g); pu = num(f)
                if qty and qty > 0 and (tot or pu):
                    sup.append({'c': sa or ((cat or '') + '.x'), 'd': b.strip().replace('\n', ' ')[:160], 'u': c, 'q': clean(qty), 't': clean(num(e)), 'pu': clean(pu), 'tot': clean(tot)})
        out['supply'] = sup
    # ---- Obras: A código, descripción en B..E (indentación), F unidad, G metrado, H precio, I parcial; bloques de referencia 4.x (obras comunes)
    if 'Obras' in wb.sheetnames:
        ws = wb['Obras']; mod = []; ref = []
        for row in ws.iter_rows(values_only=True):
            r = list(row) + [None] * 12
            a = r[0]; sa = str(a).strip() if a not in (None, '') else ''
            desc = next((str(x).strip() for x in r[1:5] if isinstance(x, str) and x.strip()), None)
            unit, met, pu, par = r[5], num(r[6]), num(r[7]), num(r[8])
            if sa in ('4.1', '4.2', '4.3', '4.4', '4.5'):
                if desc and unit in (None, '') and met is None and pu is None:
                    ref.append({'grp': desc[:70], 'gtot': clean(par) if par is not None else None, 'items': []})
                elif desc and (par is not None or pu is not None):
                    if ref: ref[-1]['items'].append({'d': desc[:100], 'u': unit, 'q': clean(met), 'pu': clean(pu), 'tot': clean(par)})
                continue
            if sa and re.match(r'^\d+(\.\d+)*$', sa) and desc:
                if unit in (None, '') and met is None and pu is None:
                    mod.append({'c': sa, 'd': desc[:90], 'grp': True, 'tot': clean(par) if par is not None else None})
                elif par is not None and par != 0:
                    mod.append({'c': sa, 'd': desc[:120], 'u': unit, 'q': clean(met), 'pu': clean(pu), 'tot': clean(par)})
            elif not sa and desc and par not in (None, 0) and unit not in (None, ''):
                mod.append({'c': (mod[-1]['c'] if mod else '') + '.x', 'd': desc[:120], 'u': unit, 'q': clean(met), 'pu': clean(pu), 'tot': clean(par)})
            elif desc and desc.lower().startswith('presupuesto de obra'):
                out['obras_total'] = clean(par if par is not None else num(r[2]))
        out['obras'] = mod; out['ref_comunes'] = ref
    out['meta'] = meta_from_title(fname, out.get('title'))
    return out

if __name__ == '__main__':
    p = sys.argv[1]
    d = parse(p, sys.argv[2] if len(sys.argv) > 2 else None)
    json.dump(d, sys.stdout, ensure_ascii=False, separators=(',', ':'))
